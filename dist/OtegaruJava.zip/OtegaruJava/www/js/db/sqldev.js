// お手軽DB (DB入門) - SQL Developer 風の画面
//  - 左: 「接続」パネル (接続 → 表・ビュー・順序 → 列)
//  - 中央: 接続ごとのワークシート (文の実行 Ctrl+Enter・スクリプトの実行 F5・コミット F11・ロールバック F12)
//  - 下: 問合せ結果・スクリプト出力・H2 ログ
//  - データベースは H2 (Oracle 互換モード)。runtime/DbServer.java を常駐ヘルパー経由で使う
//  - エラーは ORA- に置き換え、H2 の元のメッセージも見られるようにする (db/oracle.js)
'use strict';

const DbUI = (() => {
  const { $, $$, IS_MAC, esc, files, settings, ui } = IDE;
  const F = IDE.fn;

  const CONN_FILE = '.otegaru/connections.json';     // 保存した接続 (SQL Developer の接続の設定)
  const SHEET_DIR = '.otegaru/worksheets/';          // ワークシートの内容 (接続ごと)
  const DB_FILE = '.otegaru/db/xe.sql';              // データベースの確定した内容 (H2 の SCRIPT。起動したら読み込む)
  // この種類の文を実行したら、データベースの内容を保存する (DDL は自動でコミットされる)
  const SAVE_KINDS = new Set(['COMMIT', 'CREATE', 'DROP', 'ALTER', 'TRUNCATE', 'RENAME', 'GRANT', 'REVOKE', 'COMMENT']);
  const SERVICES = ['XEPDB1', 'FREEPDB1'];           // 教材のサービス名 (Windows の XE と、Mac の Free)

  const st = {
    inited: false,
    conns: [],                 // [{name, user, password, savePassword, host, port, type: 'service'|'sid', service}]
    open: new Map(),           // 接続名 -> {user, admin, cdb}
    meta: new Map(),           // 接続名 -> {tables: [{name, type}], columns: {表: [{name, type, nullable}]}, sequences: []}
    expanded: new Set(['root']),
    selected: null,
    sheets: [],                // [{conn, path, cm, pane, tab, timer}]
    active: null,
    javaReady: null,
    lastQuery: null,           // 最後の SELECT の結果 {cols, rows, sql}
    busy: false,
    dirty: false,              // 保存が必要な文 (COMMIT・DDL) を実行した
    loading: null,             // データベースの読み込み中の Promise
  };

  const ICONS = {
    dbconn: '<svg viewBox="0 0 16 16" width="16" height="16"><ellipse cx="8" cy="4" rx="5.5" ry="2.2" fill="#c8dcf5" stroke="#4a6fa5"/><path d="M2.5 4v8c0 1.2 2.5 2.2 5.5 2.2s5.5-1 5.5-2.2V4" fill="#dfeafa" stroke="#4a6fa5"/><path d="M2.5 8c0 1.2 2.5 2.2 5.5 2.2s5.5-1 5.5-2.2" fill="none" stroke="#4a6fa5"/></svg>',
    dbconnOn: '<svg viewBox="0 0 16 16" width="16" height="16"><ellipse cx="8" cy="4" rx="5.5" ry="2.2" fill="#c8dcf5" stroke="#4a6fa5"/><path d="M2.5 4v8c0 1.2 2.5 2.2 5.5 2.2s5.5-1 5.5-2.2V4" fill="#dfeafa" stroke="#4a6fa5"/><path d="M2.5 8c0 1.2 2.5 2.2 5.5 2.2s5.5-1 5.5-2.2" fill="none" stroke="#4a6fa5"/><circle cx="12" cy="12" r="3.2" fill="#2fa52f" stroke="#1d7a1d"/></svg>',
    dbplus: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M8 2v12M2 8h12" stroke="#2fa52f" stroke-width="3"/></svg>',
    dbfolder: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/></svg>',
    dbtable: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="1.5" y="2.5" width="13" height="11" fill="#fff" stroke="#4a6fa5"/><rect x="1.5" y="2.5" width="13" height="3" fill="#7fa6db"/><path d="M1.5 9h13M6 5.5v8M10.5 5.5v8" stroke="#9cb3d6"/></svg>',
    dbview: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="1.5" y="2.5" width="13" height="11" fill="#fff" stroke="#6a8a4a"/><rect x="1.5" y="2.5" width="13" height="3" fill="#9cc47a"/><circle cx="8" cy="9.5" r="2.2" fill="none" stroke="#6a8a4a"/></svg>',
    dbseq: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="1.5" y="3.5" width="13" height="9" rx="1" fill="#fff" stroke="#8a6a35"/><text x="8" y="11" font-size="7" font-family="Arial" font-weight="bold" fill="#8a6a35" text-anchor="middle">123</text></svg>',
    dbcol: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="5" y="2" width="6" height="12" fill="#fff" stroke="#7a8aa0"/><rect x="5" y="2" width="6" height="3" fill="#b9c8de"/></svg>',
    dbgrid: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="1.5" y="2.5" width="13" height="11" fill="#fff" stroke="#555"/><path d="M1.5 6h13M1.5 9.5h13M6 2.5v11M10.5 2.5v11" stroke="#999"/></svg>',
    h2log: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2" y="1.5" width="12" height="13" fill="#fff" stroke="#777"/><text x="8" y="10.5" font-size="6.5" font-family="Arial" font-weight="bold" fill="#1565c0" text-anchor="middle">H2</text></svg>',
    runStmt: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M4 2.5 L13 8 L4 13.5 Z" fill="#2fa52f" stroke="#1d7a1d"/></svg>',
    runScript: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 1.5h7l2 2v7H2z" fill="#fff" stroke="#777"/><path d="M3.5 5h5M3.5 7h5" stroke="#aaa"/><path d="M8 7.5 L14.5 11.2 L8 15 Z" fill="#2fa52f" stroke="#1d7a1d"/></svg>',
    commit: '<svg viewBox="0 0 16 16" width="16" height="16"><ellipse cx="7" cy="4" rx="5" ry="2" fill="#c8dcf5" stroke="#4a6fa5"/><path d="M2 4v7c0 1.1 2.2 2 5 2" fill="#dfeafa" stroke="#4a6fa5"/><path d="M8.5 11.5 L10.5 13.5 L14.5 9" fill="none" stroke="#2fa52f" stroke-width="2"/></svg>',
    rollback: '<svg viewBox="0 0 16 16" width="16" height="16"><ellipse cx="7" cy="4" rx="5" ry="2" fill="#c8dcf5" stroke="#4a6fa5"/><path d="M2 4v7c0 1.1 2.2 2 5 2" fill="#dfeafa" stroke="#4a6fa5"/><path d="M14 12.5a3 3 0 1 0-1.2 1.6" fill="none" stroke="#d9302c" stroke-width="1.6"/><path d="M14.8 10 L14.5 12.8 L11.8 12.2" fill="none" stroke="#d9302c" stroke-width="1.4"/></svg>',
    eraser: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 11 L8 4 L13 8.5 L8.5 13.5 H4.5 Z" fill="#f2a7b6" stroke="#a5566a"/><path d="M5.5 7.8 L10.3 12" stroke="#a5566a"/><path d="M8.5 13.5 H14" stroke="#777"/></svg>',
    sheet: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#7a8aa0"/><path d="M10 1.5v3h3" fill="none" stroke="#7a8aa0"/><text x="8" y="12" font-size="5.5" font-family="Arial" font-weight="bold" fill="#c0392b" text-anchor="middle">SQL</text></svg>',
  };
  Object.assign(IDE.ICON_SVG, ICONS);
  const icon = n => IDE.ICON_SVG[n] || '';

  // =================================================================
  // 接続の設定
  // =================================================================
  function loadConns() {
    try { st.conns = JSON.parse(files.get(CONN_FILE) || '[]'); } catch (e) { st.conns = []; }
  }
  async function saveConns() {
    const text = JSON.stringify(st.conns, null, 2) + '\n';
    await Storage.writeFile(CONN_FILE, text);
    files.set(CONN_FILE, text);
  }
  const connByName = n => st.conns.find(c => c.name === n);

  // =================================================================
  // Java (H2) の準備と、データベースへの命令
  // =================================================================
  function ensureJava() {
    if (st.javaReady) return st.javaReady;
    F.setJavaStatus('Java を準備中…', true);
    st.javaReady = JavaRT.init(17, msg => F.setJavaStatus(msg || 'Java を準備中…', true), { warm: false })
      .then(() => { F.setJavaStatus('H2 (Oracle 互換) ・ JavaSE-' + JavaRT.version, false); return true; })
      .catch(e => {
        st.javaReady = null;
        F.setJavaStatus('Java を起動できません', false);
        F.showError('Java を起動できません', e.message + '\n\nインターネットに接続されているか確認して、ページを読み込み直してください。');
        return false;
      });
    return st.javaReady;
  }
  async function db(args) {
    if (!(await ensureJava())) return { ok: false, code: -1, msg: 'Java を起動できません' };
    let r = await JavaRT.db(args);
    // Java を起動した直後 (または作り直された後) は、保存しておいた内容を読み込んでから
    if (!r.ok && r.code === -3) {
      await loadDb();
      r = await JavaRT.db(args);
    }
    return r;
  }
  /** ワークスペースに保存した内容で、データベースを作り直す (接続はすべて切れる) */
  function loadDb() {
    if (st.loading) return st.loading;
    st.loading = (async () => {
      const r = await JavaRT.db(['load', files.get(DB_FILE) || '']);
      st.open.clear();
      st.meta.clear();
      renderTree();
      renderSheetBar();
      if (!r.ok || r.error) F.showError('データベースを読み込めません', `ワークスペースの ${DB_FILE} を読み込めませんでした。空のデータベースで始めます。\n\n${r.error || r.msg}`);
    })().finally(() => { st.loading = null; });
    return st.loading;
  }
  /** データベースの確定した内容を、ワークスペースに保存する */
  async function saveDb() {
    st.dirty = false;
    const r = await JavaRT.db(['dump']);
    if (!r.ok) { F.status('データベースを保存できません: ' + r.msg); return; }
    if (files.get(DB_FILE) === r.script) return;
    try {
      await Storage.writeFile(DB_FILE, r.script);
      files.set(DB_FILE, r.script);
    } catch (e) { F.status('データベースを保存できません: ' + e.message); }
  }
  /** 利用者の接続で SQL を実行する。Java が作り直された (接続が切れた) ときは、つなぎ直してもう一度 */
  async function sqlOn(conn, sql, maxRows) {
    let r = await db(['sql', conn, sql, String(maxRows || 5000)]);
    if (!r.ok && r.code === -2) {
      const c = connByName(conn);
      if (c && (await db(['connect', conn, c.user, c.password || ''])).ok) r = await db(['sql', conn, sql, String(maxRows || 5000)]);
    }
    return r;
  }
  const lit = s => "'" + String(s).replace(/'/g, "''") + "'";

  // =================================================================
  // 接続する
  // =================================================================
  /** 接続の設定を確かめる (テスト)。成功なら {ok: true, user, admin, cdb}、失敗なら {ok: false, text} */
  async function checkConn(c, pw) {
    if (!c.user) return { ok: false, text: 'ユーザー名を入力してください。' };
    const host = String(c.host || '').trim().toLowerCase();
    if (host !== 'localhost' && host !== '127.0.0.1') return { ok: false, text: 'IO エラー: The Network Adapter could not establish the connection (ホスト名は localhost にします)' };
    if (String(c.port).trim() !== '1521') return { ok: false, text: 'IO エラー: The Network Adapter could not establish the connection (ポートは 1521 にします)' };
    let cdb = false;
    if (c.type === 'sid') {
      if (!/^(xe|free)$/i.test(String(c.service || '').trim())) return { ok: false, text: `ORA-12505: TNS: リスナーは接続記述子で指定されたSIDを現在認識していません` };
      cdb = true;   // SID xe は、全体を管理する CDB につながる (教材の 2.2)
    } else {
      const s = String(c.service || '').trim().toUpperCase();
      if (/^(XE|FREE)$/.test(s)) cdb = true;
      else if (!SERVICES.includes(s)) return { ok: false, text: 'ORA-12514: リスナーは接続記述子でリクエストされたサービスを現在認識していません' };
    }
    const r = await db(['test', c.name, c.user, pw]);
    if (!r.ok) {
      const m = OraSql.mapError(r, '', {});
      return { ok: false, text: m.ora ? `${m.ora}: ${m.text}` : r.msg, h2: r };
    }
    if (!r.admin) return { ok: false, text: `ORA-01045: ユーザー${r.user}にはCREATE SESSION権限がありません。ログオンが拒否されました。` };
    return { ok: true, user: r.user, admin: r.admin, cdb };
  }
  /** 接続する (パスワードを保存していなければ聞く)。成功したら true */
  async function connect(name, quiet) {
    const c = connByName(name);
    if (!c) return false;
    if (st.open.has(name)) return true;
    let pw = c.password || '';
    if (!c.savePassword || !pw) {
      pw = await passwordPrompt(c);
      if (pw == null) return false;
    }
    F.status(`${name} に接続しています…`, true);
    const t = await checkConn(c, pw);
    if (!t.ok) { F.status(''); if (!quiet) await F.showError('接続エラー', t.text); return false; }
    const r = await db(['connect', name, c.user, pw]);
    if (!r.ok) { F.status(''); if (!quiet) await F.showError('接続エラー', r.msg); return false; }
    if (!c.savePassword) c.password = pw;   // この画面を開いている間だけ覚える (保存はしない)
    st.open.set(name, { user: r.user, admin: r.admin, cdb: t.cdb });
    st.expanded.add('C:' + name);
    F.status(`${name} に接続しました`);
    await loadMeta(name);
    renderTree();
    return true;
  }
  async function disconnect(name) {
    if (!st.open.has(name)) return;
    await db(['disconnect', name]);
    st.open.delete(name);
    st.meta.delete(name);
    const c = connByName(name);
    if (c && !c.savePassword) c.password = '';
    renderTree();
    renderSheetBar();
    F.status(`${name} を切断しました`);
  }
  function passwordPrompt(c) {
    return F.dialog({
      title: '接続情報', width: 360,
      html: `<div class="row" style="grid-template-columns:110px 1fr"><label>接続名</label><input type="text" value="${esc(c.name)}" readonly></div>
        <div class="row" style="grid-template-columns:110px 1fr"><label>ユーザー名</label><input type="text" value="${esc(c.user)}" readonly></div>
        <div class="row" style="grid-template-columns:110px 1fr"><label>パスワード</label><input type="password" id="pp-pw" autocomplete="off"></div>`,
      buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取消', value: null }],
      collect: d => ({ pw: $('#pp-pw', d).value }),
      onOpen: d => setTimeout(() => $('#pp-pw', d).focus(), 0),
    }).then(r => r && r.value === 'ok' ? r.pw : null);
  }

  // =================================================================
  // 「データベース接続の作成/選択」ダイアログ
  // =================================================================
  function connectionDialog(selectName) {
    let cur = selectName ? Object.assign({}, connByName(selectName)) : null;
    return F.dialog({
      title: 'データベース接続の作成/選択', width: 760,
      html: `<div class="dbc-wrap">
          <div class="dbc-list"><div class="dbc-head"><span>接続名</span><span>接続の詳細</span></div><div id="dbc-items"></div></div>
          <div class="dbc-form">
            <div class="row"><label>Name</label><input type="text" id="dbc-name" spellcheck="false"></div>
            <div class="row"><label>ユーザー名</label><input type="text" id="dbc-user" spellcheck="false"></div>
            <div class="row"><label>パスワード</label><input type="password" id="dbc-pw" autocomplete="off"></div>
            <div class="row"><label></label><label class="chk"><input type="checkbox" id="dbc-save">パスワードの保存</label></div>
            <div class="dbc-tabs"><span class="on">Oracle</span></div>
            <div class="row"><label>接続タイプ</label><select id="dbc-ctype"><option>基本</option></select></div>
            <div class="row"><label>ホスト名</label><input type="text" id="dbc-host" spellcheck="false"></div>
            <div class="row"><label>ポート</label><input type="text" id="dbc-port" spellcheck="false"></div>
            <div class="row"><label class="chk"><input type="radio" name="dbc-type" value="sid" id="dbc-sid">SID</label><input type="text" id="dbc-sidv" spellcheck="false"></div>
            <div class="row"><label class="chk"><input type="radio" name="dbc-type" value="service" id="dbc-svc">サービス名</label><input type="text" id="dbc-svcv" spellcheck="false"></div>
          </div>
        </div>
        <div class="dbc-bottom"><span id="dbc-status">ステータス :</span>
          <span class="dbc-btns"><button class="dlg-btn" id="dbc-b-save">保存(<u>S</u>)</button><button class="dlg-btn" id="dbc-b-clear">クリア(<u>C</u>)</button><button class="dlg-btn" id="dbc-b-test">テスト(<u>T</u>)</button><button class="dlg-btn default" id="dbc-b-connect">接続(<u>O</u>)</button></span></div>`,
      buttons: [{ label: '取消', value: null }],
      onOpen: (d, api) => {
        const F2 = id => $('#dbc-' + id, d);
        const fill = c => {
          F2('name').value = c ? c.name : '';
          F2('user').value = c ? c.user : '';
          F2('pw').value = c ? (c.password || '') : '';
          F2('save').checked = c ? !!c.savePassword : false;
          F2('host').value = c ? c.host : 'localhost';
          F2('port').value = c ? c.port : '1521';
          const sid = c && c.type === 'sid';
          F2('sid').checked = sid; F2('svc').checked = !sid;
          F2('sidv').value = sid ? c.service : 'xe';
          F2('svcv').value = !sid && c ? c.service : '';
          F2('status').textContent = 'ステータス :';
        };
        const read = () => ({
          name: F2('name').value.trim(), user: F2('user').value.trim(), password: F2('pw').value, savePassword: F2('save').checked,
          host: F2('host').value.trim(), port: F2('port').value.trim(), type: F2('sid').checked ? 'sid' : 'service',
          service: F2('sid').checked ? F2('sidv').value.trim() : F2('svcv').value.trim(),
        });
        const list = () => {
          F2('items').innerHTML = st.conns.map(c => `<div class="li${cur && cur.name === c.name ? ' sel' : ''}" data-n="${esc(c.name)}"><span>${icon('dbconn')} ${esc(c.name)}</span><span class="dim">${esc(c.user)}@//${esc(c.host)}:${esc(c.port)}/${esc(c.service)}</span></div>`).join('');
          $$('.li', F2('items')).forEach(el => {
            el.onclick = () => { cur = Object.assign({}, connByName(el.dataset.n)); fill(cur); list(); };
            el.ondblclick = () => doConnect();
          });
        };
        const status = (ok, text) => { F2('status').textContent = 'ステータス : ' + (ok ? '成功' : '失敗 -テストが失敗しました: ' + text); F2('status').className = ok ? 'ok' : 'ng'; };
        const save = async () => {
          const c = read();
          if (!c.name) { status(false, '接続名を入力してください。'); return null; }
          const saved = Object.assign({}, c, { password: c.savePassword ? c.password : '' });
          const i = st.conns.findIndex(x => x.name === (cur && cur.name) || x.name === c.name);
          if (i >= 0) st.conns[i] = saved; else st.conns.push(saved);
          await saveConns();
          cur = Object.assign({}, saved);
          list();
          renderTree();
          return c;
        };
        const doConnect = async () => {
          const c = read();
          if (!c.name) { status(false, '接続名を入力してください。'); return; }
          if (!connByName(c.name) || JSON.stringify(connByName(c.name)) !== JSON.stringify(Object.assign({}, c, { password: c.savePassword ? c.password : '' }))) await save();
          const t = await checkConn(c, c.password);
          if (!t.ok) { status(false, t.text); return; }
          const conn = connByName(c.name);
          if (!conn.savePassword) conn.password = c.password;
          api.close(null);
          if (await connect(c.name)) openWorksheet(c.name);
        };
        F2('b-save').onclick = async () => { if (await save()) F2('status').textContent = 'ステータス : 保存しました'; };
        F2('b-clear').onclick = () => { cur = null; fill(null); list(); };
        F2('b-test').onclick = async () => {
          F2('status').textContent = 'ステータス : テスト中…';
          const c = read();
          const t = await checkConn(c, c.password);
          status(t.ok, t.text);
        };
        F2('b-connect').onclick = doConnect;
        F2('sidv').addEventListener('focus', () => { F2('sid').checked = true; });
        F2('svcv').addEventListener('focus', () => { F2('svc').checked = true; });
        // Enter で「接続」
        d.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('input')) { e.preventDefault(); e.stopPropagation(); doConnect(); } }, true);
        fill(cur);
        list();
        setTimeout(() => F2('name').focus(), 0);
      },
    });
  }

  // =================================================================
  // 「接続」パネル
  // =================================================================
  const H2_TYPE = col => {
    const t = col.type;
    if (t === 'NUMERIC' || t === 'DECIMAL') return col.prec ? `NUMBER(${col.prec}${col.scale ? ',' + col.scale : ''})` : 'NUMBER';
    if (t === 'CHARACTER VARYING' || t === 'VARCHAR') return `VARCHAR2(${col.len} CHAR)`;
    if (t === 'CHARACTER' || t === 'CHAR') return `CHAR(${col.len} CHAR)`;
    if (t === 'TIMESTAMP') return col.dtprec ? `TIMESTAMP(${col.dtprec})` : 'DATE';
    if (t === 'INTEGER' || t === 'BIGINT' || t === 'SMALLINT') return 'NUMBER(38)';
    return t;
  };
  async function loadMeta(name) {
    const o = st.open.get(name);
    if (!o) return;
    const s = lit(o.user);
    const [t, c, q] = await Promise.all([
      db(['admin', `SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ${s} ORDER BY TABLE_NAME`]),
      db(['admin', `SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, DATETIME_PRECISION, IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ${s} ORDER BY TABLE_NAME, ORDINAL_POSITION`]),
      db(['admin', `SELECT SEQUENCE_NAME FROM INFORMATION_SCHEMA.SEQUENCES WHERE SEQUENCE_SCHEMA = ${s} ORDER BY SEQUENCE_NAME`]),
    ]);
    const m = { tables: [], columns: {}, sequences: [] };
    if (t.ok) m.tables = t.rows.map(r => ({ name: r[0], type: r[1] === 'VIEW' ? 'VIEW' : 'TABLE' }));
    if (c.ok) for (const r of c.rows) (m.columns[r[0]] = m.columns[r[0]] || []).push({ name: r[1], type: r[2], len: r[3], prec: r[4], scale: +r[5] || 0, dtprec: +r[6] || 0, nullable: r[7] === 'YES' });
    if (q.ok) m.sequences = q.rows.map(r => r[0]);
    st.meta.set(name, m);
  }
  function treeRows() {
    const rows = [];
    const add = (id, depth, label, ic, opts = {}) => rows.push({ id, depth, label, icon: ic, ...opts });
    add('root', 0, 'Oracle接続', 'dbfolder', { twisty: true });
    if (!st.expanded.has('root')) return rows;
    for (const c of st.conns) {
      const open = st.open.has(c.name);
      add('C:' + c.name, 1, c.name, open ? 'dbconnOn' : 'dbconn', { twisty: true, conn: c.name });
      if (!open || !st.expanded.has('C:' + c.name)) continue;
      const m = st.meta.get(c.name) || { tables: [], columns: {}, sequences: [] };
      const groups = [['T', '表', m.tables.filter(t => t.type === 'TABLE').map(t => t.name), 'dbtable'], ['V', 'ビュー', m.tables.filter(t => t.type === 'VIEW').map(t => t.name), 'dbview'], ['S', '順序', m.sequences, 'dbseq']];
      for (const [k, label, items, ic] of groups) {
        const gid = k + ':' + c.name;
        add(gid, 2, label, 'dbfolder', { twisty: true, conn: c.name, group: k });
        if (!st.expanded.has(gid)) continue;
        for (const it of items) {
          const iid = 'O:' + c.name + ':' + it;
          add(iid, 3, it, ic, { twisty: k !== 'S', conn: c.name, obj: it });
          if (k !== 'S' && st.expanded.has(iid)) for (const col of m.columns[it] || []) add('L:' + iid + ':' + col.name, 4, col.name, 'dbcol', { dim: H2_TYPE(col) });
        }
      }
    }
    return rows;
  }
  function renderTree() {
    const el = $('#db-tree');
    if (!el) return;
    const rows = treeRows();
    el.innerHTML = rows.map(r => `<div class="tree-row${st.selected === r.id ? ' selected' : ''}" data-id="${esc(r.id)}" style="padding-left:${r.depth * 16 + 2}px">
      <span class="tree-twisty">${r.twisty ? (st.expanded.has(r.id) ? '▼' : '▶') : ''}</span><span class="tree-icon">${icon(r.icon)}</span>
      <span class="tree-label">${esc(r.label)}${r.dim ? `<span class="dim">${esc(r.dim)}</span>` : ''}</span></div>`).join('')
      + (st.conns.length ? '' : `<div class="tree-empty">接続がありません。<br>上の緑の <b>＋</b> (接続の作成...) をクリックして、教材の第2章のとおりに接続を作成してください。</div>`);
  }
  function initTree() {
    const el = $('#db-tree');
    el.addEventListener('mousedown', e => {
      const row = e.target.closest('.tree-row');
      if (!row) return;
      const id = row.dataset.id;
      st.selected = id;
      if (e.button !== 0) { renderTree(); return; }
      if (e.target.closest('.tree-twisty')) { toggle(id); return; }
      // ダブルクリック (描き直すと 2 回目のクリックが別の要素に当たるので、mousedown の回数で見る)
      if (e.detail === 2) { e.preventDefault(); activateRow(id); return; }
      $$('.tree-row.selected', el).forEach(r => r.classList.remove('selected'));
      row.classList.add('selected');
    });
    el.addEventListener('contextmenu', e => {
      e.preventDefault();
      const row = e.target.closest('.tree-row');
      if (!row) return;
      st.selected = row.dataset.id;
      renderTree();
      const id = row.dataset.id;
      const conn = id.startsWith('C:') ? id.slice(2) : null;
      const group = /^[TVS]:/.test(id) ? id.slice(2) : null;
      const obj = id.startsWith('O:') ? id.split(':') : null;
      let items;
      if (conn) items = [
        { label: '接続', action: () => connect(conn).then(ok => ok && openWorksheet(conn)), enabled: () => !st.open.has(conn) },
        { label: '切断', action: () => disconnect(conn), enabled: () => st.open.has(conn) },
        '-',
        { label: 'SQLワークシートを開く', key: 'Alt+F10', icon: 'sheet', action: () => openSheetFor(conn) },
        '-',
        { label: 'プロパティ...', action: () => connectionDialog(conn) },
        { label: '接続の削除', action: () => deleteConn(conn) },
      ];
      else if (group) items = [{ label: 'リフレッシュ', action: () => refresh(group) }];
      else if (obj) items = [{ label: '開く', action: () => openObject(obj[1], obj[2]) }, { label: 'リフレッシュ', action: () => refresh(obj[1]) }];
      else items = [{ label: '接続の作成...', icon: 'dbplus', action: () => connectionDialog() }];
      F.showContextMenu(items, e.clientX, e.clientY);
    });
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter' && st.selected) activateRow(st.selected);
    });
  }
  function toggle(id) {
    if (st.expanded.has(id)) st.expanded.delete(id); else st.expanded.add(id);
    renderTree();
  }
  async function activateRow(id) {
    if (id.startsWith('C:')) { const c = id.slice(2); if (await connect(c)) { openWorksheet(c); } return; }
    if (id.startsWith('O:')) { const [, c, o] = id.split(':'); return openObject(c, o); }
    toggle(id);
  }
  async function refresh(conn) {
    if (!st.open.has(conn)) return;
    await loadMeta(conn);
    renderTree();
  }
  async function deleteConn(name) {
    const ok = await F.dialog({ title: '接続の削除', icon: 'warning', message: `接続 ${name} を削除しますか?\n(データベースの中身は消えません)`, buttons: [{ label: 'はい', value: true, default: true }, { label: 'いいえ', value: false }] });
    if (!ok) return;
    await disconnect(name);
    st.conns = st.conns.filter(c => c.name !== name);
    await saveConns();
    renderTree();
  }
  /** 表・ビューの「列」と「データ」を開く (SQL Developer の表のタブの代わり。結果は問合せ結果に出す) */
  async function openObject(conn, name) {
    const m = st.meta.get(conn);
    const cols = (m && m.columns[name]) || [];
    const r = await sqlOn(conn, `SELECT * FROM "${name.replace(/"/g, '')}"`, 500);
    showBottom('db-result');
    const colHtml = `<table class="db-grid"><thead><tr><th></th><th>COLUMN_NAME</th><th>DATA_TYPE</th><th>NULLABLE</th></tr></thead><tbody>${cols.map((c, i) => `<tr><td class="rn">${i + 1}</td><td>${esc(c.name)}</td><td>${esc(H2_TYPE(c))}</td><td>${c.nullable ? 'Yes' : 'No'}</td></tr>`).join('')}</tbody></table>`;
    $('#db-result').innerHTML = `<div class="db-res-head">${icon('dbtable')} <b>${esc(conn)}.${esc(name)}</b> の列</div>${colHtml}
      <div class="db-res-head">データ ${r.ok ? `(${r.rows.length}${r.more ? '+' : ''} 行)` : ''}</div>${r.ok ? gridHtml(r) : `<div class="db-err">${esc(r.msg)}</div>`}`;
  }

  // =================================================================
  // ワークシート
  // =================================================================
  const sheetPath = conn => SHEET_DIR + conn.replace(/[^A-Za-z0-9_\-.]/g, '_') + '.sql';
  function openWorksheet(conn) {
    let ws = st.sheets.find(s => s.conn === conn);
    if (ws) { activate(ws); return ws; }
    const pane = document.createElement('div');
    pane.className = 'db-pane';
    $('#db-editors').appendChild(pane);
    const path = sheetPath(conn);
    const cm = CodeMirror(pane, {
      value: files.get(path) || '',
      mode: 'text/x-plsql', lineNumbers: true, indentUnit: 2, tabSize: 2, styleActiveLine: true, matchBrackets: true, autoCloseBrackets: true,
      extraKeys: {
        'Ctrl-Space': c => c.showHint({ hint: CodeMirror.hint.sql, tables: hintTables(conn), completeSingle: false }),
        'Ctrl-/': 'toggleComment', 'Cmd-/': 'toggleComment',
      },
    });
    cm.on('inputRead', (c, ch) => { if (ch.text[0] === '.' && settings.autoActivation !== false) setTimeout(() => c.showHint({ hint: CodeMirror.hint.sql, tables: hintTables(conn), completeSingle: false }), 200); });
    ws = { conn, path, cm, pane };
    cm.on('changes', () => { clearTimeout(ws.timer); ws.timer = setTimeout(() => saveSheet(ws), 600); });
    st.sheets.push(ws);
    saveOpenSheets();
    activate(ws);
    return ws;
  }
  async function saveSheet(ws) {
    const text = ws.cm.getValue();
    if (files.get(ws.path) === text) return;
    files.set(ws.path, text);
    try { await Storage.writeFile(ws.path, text); } catch (e) { F.status('ワークシートを保存できません: ' + e.message); }
  }
  function hintTables(conn) {
    const m = st.meta.get(conn);
    const out = {};
    if (m) for (const t of m.tables) out[t.name] = (m.columns[t.name] || []).map(c => c.name);
    return out;
  }
  function activate(ws) {
    st.active = ws;
    for (const s of st.sheets) s.pane.classList.toggle('active', s === ws);
    $('#db-welcome').hidden = !!ws;
    renderTabs();
    renderSheetBar();
    if (ws) setTimeout(() => { ws.cm.refresh(); ws.cm.focus(); }, 0);
    ui.dbActiveSheet = ws ? ws.conn : null;
    F.saveUi();
  }
  async function closeSheet(ws) {
    clearTimeout(ws.timer);
    await saveSheet(ws);
    ws.pane.remove();
    st.sheets.splice(st.sheets.indexOf(ws), 1);
    saveOpenSheets();
    activate(st.sheets[st.sheets.length - 1] || null);
  }
  function saveOpenSheets() { ui.dbSheets = st.sheets.map(s => s.conn); F.saveUi(); }
  function renderTabs() {
    const el = $('#db-tabs');
    el.innerHTML = st.sheets.map((s, i) => `<div class="editor-tab${s === st.active ? ' active' : ''}" data-i="${i}" title="${esc(s.conn)} のワークシート"><span class="tree-icon">${icon('sheet')}</span><span class="et-name">${esc(s.conn)}</span><span class="et-close" title="閉じる">×</span></div>`).join('');
  }
  function renderSheetBar() {
    const ws = st.active;
    const btn = (ic, title, act, dis) => `<button class="tb-btn" data-db="${act}" title="${esc(F.keyLabel(title))}" ${dis ? 'disabled' : ''}>${icon(ic)}</button>`;
    const connected = ws && st.open.has(ws.conn);
    $('#db-ws-bar').innerHTML = !ws ? '' : [
      btn('runStmt', '文の実行 (Ctrl+Enter)', 'runStatement'),
      btn('runScript', 'スクリプトの実行 (F5)', 'runScript'),
      '<span class="tb-sep"></span>',
      btn('commit', 'コミット (F11)', 'commit', !connected),
      btn('rollback', 'ロールバック (F12)', 'rollback', !connected),
      '<span class="tb-sep"></span>',
      btn('eraser', 'クリア (Ctrl+D)', 'clearSheet'),
      `<span class="db-ws-conn">${connected ? icon('dbconnOn') : icon('dbconn')} ${esc(ws.conn)}${connected ? '' : ' (未接続)'}</span>`,
    ].join('');
  }
  function openSheetFor(conn) {
    if (!conn) return chooseConnection().then(c => c && openSheetFor(c));
    return connect(conn).then(ok => { if (ok) openWorksheet(conn); });
  }
  async function chooseConnection() {
    if (!st.conns.length) { connectionDialog(); return null; }
    if (st.conns.length === 1) return st.conns[0].name;
    return F.pickFromList('接続の選択', 'ワークシートを開く接続を選んでください。', st.conns.map(c => c.name));
  }

  // =================================================================
  // 実行
  // =================================================================
  /** 文の実行 (Ctrl+Enter): カーソルの位置の 1 文。SELECT の結果は「問合せ結果」に表で出す */
  async function runStatement() {
    const ws = st.active;
    if (!ws || st.busy) return;
    const cm = ws.cm;
    let stmt;
    if (cm.somethingSelected()) {
      const list = OraSql.split(cm.getSelection());
      stmt = list[0] && Object.assign(list[0], { line: cm.getCursor('from').line + list[0].line });
    } else stmt = OraSql.statementAt(cm.getValue(), cm.indexFromPos(cm.getCursor()));
    if (!stmt) { F.status('実行する SQL がありません。SQL の行にカーソルを置いてから実行してください'); return; }
    // 実行した文を一瞬強調する
    if (!cm.somethingSelected()) {
      const mk = cm.markText(cm.posFromIndex(stmt.from), cm.posFromIndex(stmt.to), { className: 'db-running' });
      setTimeout(() => mk.clear(), 500);
    }
    await withBusy(() => execOne(ws, stmt, 'statement'));
    if (st.dirty) await saveDb();
  }
  /** スクリプトの実行 (F5): すべての文を上から順に実行し、「スクリプト出力」に文字で出す */
  async function runScript() {
    const ws = st.active;
    if (!ws || st.busy) return;
    const cm = ws.cm;
    const sel = cm.somethingSelected();
    const base = sel ? cm.getCursor('from').line : 0;
    const list = OraSql.split(sel ? cm.getSelection() : cm.getValue()).map(s => Object.assign(s, { line: s.line + base }));
    if (!list.length) { F.status('実行する SQL がありません'); return; }
    showBottom('db-script');
    const t0 = performance.now();
    await withBusy(async () => {
      for (const s of list) await execOne(ws, s, 'script');
      if (st.dirty) await saveDb();
    });
    outLine(`<div class="db-done">スクリプトの実行が完了しました。(${((performance.now() - t0) / 1000).toFixed(3)}秒)</div>`, true);
  }
  async function withBusy(fn) {
    st.busy = true;
    F.progress(true);
    try { await fn(); } finally { st.busy = false; F.progress(false); }
  }

  /** 1 つの文を実行する。mode は 'statement' (文の実行) か 'script' (スクリプトの実行) */
  async function execOne(ws, stmt, mode) {
    if (!(await ensureJava())) return false;
    if (!st.open.has(ws.conn) && !(await connect(ws.conn))) return false;
    renderSheetBar();
    const o = st.open.get(ws.conn);
    const sql = OraSql.strip(stmt.sql);
    const cls = OraSql.classify(sql);
    const t0 = performance.now();
    if (SAVE_KINDS.has(cls.kind)) st.dirty = true;
    // シーケンスの番号は、Oracle と同じく ROLLBACK やエラーでも戻らない (第4章 4.5 のエラーで 11・12 を使い、
    // 第7章で 13 になる)。NEXTVAL を使った文は、失敗しても進んだ番号を保存する (コミットしていない行は保存されない)
    if (/\bNEXTVAL\b/i.test(sql)) st.dirty = true;
    const fail = (err, h2, sent) => { log(ws.conn, sql, sent, h2 || null, err); reportError(stmt, sql, cls, err, h2, mode); return false; };
    // H2 では通るが、Oracle ではエラーになる書き方
    const pre = OraSql.precheck(sql, { columnsOf: t => { const m = st.meta.get(ws.conn); return m && m.columns[t] ? m.columns[t].map(c => c.name) : null; } });
    if (pre) return fail(Object.assign({ guessed: false, local: true }, pre), null, []);
    const tr = OraSql.translate(sql, { admin: o.admin, cdb: o.cdb });
    if (tr.error) return fail(Object.assign({ guessed: false, local: true }, tr.error), null, []);
    if (o.cdb && /^CREATE\s+USER\b/i.test(sql)) return fail({ ora: 'ORA-65096', text: '共通ユーザーまたはロール名が無効です', guessed: false, local: true }, null, []);
    if (tr.tx) {
      const r = await db([tr.tx, ws.conn]);
      log(ws.conn, sql, [tr.tx.toUpperCase()], r);
      if (!r.ok) return fail(OraSql.mapError(r, sql, o), r, [tr.tx.toUpperCase()]);
      outMessage(OraSql.successMessage(cls, r), mode);
      return true;
    }
    if (tr.desc) return describe(ws, tr.desc, sql, mode);
    let r = null;
    for (const s of tr.send) {
      r = await sqlOn(ws.conn, s, mode === 'statement' ? 5000 : 5000);
      log(ws.conn, sql, tr.send, r);
      if (!r.ok) return fail(OraSql.mapError(r, sql, o), r, tr.send);
    }
    const sec = ((performance.now() - t0) / 1000).toFixed(3);
    if (r && r.cols) {
      st.lastQuery = { cols: r.cols, rows: r.rows, sql };
      if (mode === 'statement') { showGrid(r, sec); showBottom('db-result'); }
      else outText(textTable(r) + (r.rows.length ? '' : '\nレコードが選択されませんでした。'));
    } else {
      outMessage(OraSql.successMessage(cls, r), mode);
    }
    // 表・順序を作った・消したときは「接続」パネルを更新する
    if (['CREATE', 'DROP', 'ALTER', 'TRUNCATE', 'RENAME'].includes(cls.kind)) refresh(ws.conn);
    return true;
  }
  async function describe(ws, name, sql, mode) {
    await loadMeta(ws.conn);
    const m = st.meta.get(ws.conn);
    const cols = m && m.columns[name];
    if (!cols) {
      const err = { ora: 'ERROR', text: `\nERROR:\nORA-04043: オブジェクト${name}は存在しません。`, guessed: false, local: true, raw: true };
      log(ws.conn, sql, [], null, err);
      outText(`ERROR:\nORA-04043: オブジェクト${name}は存在しません。`);
      showBottom('db-script');
      return false;
    }
    const w = Math.max(4, ...cols.map(c => c.name.length));
    const lines = [`名前${' '.repeat(Math.max(1, w - 1))}NULL?    型`, `${'-'.repeat(w + 1)} -------- ${'-'.repeat(18)}`];
    for (const c of cols) lines.push(`${c.name.padEnd(w + 1)} ${(c.nullable ? '' : 'NOT NULL').padEnd(8)} ${H2_TYPE(c)}`);
    log(ws.conn, sql, ['(INFORMATION_SCHEMA.COLUMNS から作成)'], { ok: true });
    outText(lines.join('\n'));
    showBottom('db-script');
    return true;
  }

  // =================================================================
  // 結果の表示
  // =================================================================
  const isNum = t => /NUMERIC|DECIMAL|INTEGER|BIGINT|SMALLINT|TINYINT|DOUBLE|REAL|FLOAT|DEC/.test(t || '');
  function gridHtml(r) {
    return `<table class="db-grid"><thead><tr><th></th>${r.cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${r.rows.map((row, i) => `<tr><td class="rn">${i + 1}</td>${row.map((v, k) => `<td class="${isNum(r.types[k]) ? 'num' : ''}${v == null ? ' null' : ''}">${v == null ? '(null)' : esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  }
  function showGrid(r, sec) {
    $('#db-result').innerHTML = `<div class="db-res-head">${r.more ? `最初の ${r.rows.length} 行をフェッチしました` : `すべての行がフェッチされました: ${r.rows.length}`} (${sec}秒)</div>${gridHtml(r)}`;
  }
  /** スクリプト出力の表 (SQL*Plus と同じく、見出しの下に - を引く) */
  function textTable(r) {
    const width = (s) => [...String(s)].reduce((n, ch) => n + (/[^\x00-\xff]/.test(ch) ? 2 : 1), 0);
    const pad = (s, w, right) => { const d = w - width(s); return right ? ' '.repeat(Math.max(0, d)) + s : s + ' '.repeat(Math.max(0, d)); };
    const cells = r.rows.map(row => row.map(v => v == null ? '' : String(v)));
    const ws = r.cols.map((c, k) => Math.max(width(c), ...cells.map(row => width(row[k]))));
    const head = r.cols.map((c, k) => pad(c, ws[k], isNum(r.types[k]))).join(' ');
    const line = ws.map(w => '-'.repeat(w)).join(' ');
    return [head, line, ...cells.map(row => row.map((v, k) => pad(v, ws[k], isNum(r.types[k]))).join(' '))].join('\n');
  }
  function outLine(html, noGap) {
    const el = $('#db-script');
    const div = document.createElement('div');
    div.className = 'db-out' + (noGap ? '' : ' gap');
    div.innerHTML = html;
    el.appendChild(div);
    el.scrollTop = el.scrollHeight;
  }
  function outText(text) { outLine(`<pre>${esc(text)}</pre>`); }
  function outMessage(msg, mode) {
    if (!msg) return;
    outLine(`<pre>${esc(msg)}</pre>`);
    if (mode === 'statement') showBottom('db-script');
  }

  /** エラーの表示: ORA- の行と、H2 の元のメッセージ (正確に置き換えたものは折りたたみ、推定は最初から表示) */
  function h2Html(h2, err) {
    if (!h2) return '';
    const link = `<a href="${esc(OraSql.h2DocUrl(h2.code))}" target="_blank" rel="noopener" title="H2 のドキュメント (エラー・コードの説明)">${esc(String(h2.code))}</a>`;
    const msg = `<pre class="h2-msg">${esc(h2.msg)}</pre>`;
    if (settings.dbAlwaysH2) return `<div class="h2-line">[H2 ${link}] ${msg}</div>`;
    if (err.guessed || !err.ora) return `<div class="h2-guess">${err.ora ? '※ 推定です。' : ''}H2 のメッセージ (エラー番号 ${link}):${msg}</div>`;
    return `<details class="h2-fold"><summary>H2 の元のメッセージ</summary><div>H2 のエラー番号 ${link}${msg}</div></details>`;
  }
  function oraLine(err, h2) {
    if (err.raw) return err.text;
    if (err.ora) return `${err.ora}: ${err.text}`;
    return 'エラー: ' + ((h2 && h2.msg.split('\n')[0]) || '');
  }
  function reportError(stmt, sql, cls, err, h2, mode) {
    const body = `<pre class="db-ora">${esc(oraLine(err, h2))}</pre>${h2Html(h2, err)}`;
    // 文の実行の SELECT のエラーは、SQL Developer と同じくダイアログで出す
    if (mode === 'statement' && cls.kind === 'SELECT' && !err.script) {
      F.dialog({ title: 'エラー', width: 560, html: `<div class="db-errdlg"><div class="t">${icon('error')} 文の実行中にエラーが発生しました</div>${body}</div>`, buttons: [{ label: 'OK', value: true, default: true }] });
      return;
    }
    // SP2- (コマンドのつづりの間違い) は、エラー・レポートの形にしない
    if (err.script) outLine(body);
    else outLine(`<pre>${esc(`コマンドの${stmt.line}行目で開始中にエラーが発生しました :\n${sql}\nエラー・レポート -`)}</pre>${body}`);
    if (mode === 'statement') showBottom('db-script');
  }

  /** H2 ログ: 元の SQL、H2 に送った SQL、H2 の結果 */
  function log(conn, sql, sent, r, err) {
    const el = $('#db-h2log');
    const time = new Date().toLocaleTimeString('ja-JP');
    const res = !r ? (err ? `お手軽DB が判定: ${err.ora} ${err.text}` : '') : r.ok ? (r.cols ? `OK (${r.rows.length} 行)` : `OK${typeof r.count === 'number' ? ` (${r.count} 行)` : ''}`) : `エラー ${r.code}: ${r.msg}`;
    const diff = sent && sent.length && !(sent.length === 1 && sent[0] === sql);
    const div = document.createElement('div');
    div.className = 'h2-entry' + (r && !r.ok || err ? ' ng' : '');
    div.innerHTML = `<div class="h"><span class="tm">${esc(time)}</span> <b>${esc(conn)}</b></div>
      <div class="k">SQL</div><pre>${esc(sql)}</pre>
      ${diff ? `<div class="k">H2 に送った SQL</div><pre class="sent">${esc(sent.join(';\n'))}</pre>` : ''}
      <div class="k">結果</div><pre class="res">${r && !r.ok ? `<a href="${esc(OraSql.h2DocUrl(r.code))}" target="_blank" rel="noopener">${esc(String(r.code))}</a> ` : ''}${esc(res)}</pre>`;
    el.appendChild(div);
    while (el.children.length > 300) el.firstChild.remove();
    el.scrollTop = el.scrollHeight;
  }

  async function commit(kind) {
    const ws = st.active;
    if (!ws || !st.open.has(ws.conn)) return;
    const r = await db([kind, ws.conn]);
    log(ws.conn, kind.toUpperCase(), [], r);
    outMessage(r.ok ? (kind === 'commit' ? 'コミットが完了しました。' : 'ロールバックが完了しました。') : r.msg, 'statement');
    if (kind === 'commit') await saveDb();
  }

  // =================================================================
  // 画面 (ビュー・サッシ・メニュー・ツールバー・キー)
  // =================================================================
  function showBottom(v) {
    $$('#db-bottom-tabs .view-tab').forEach(t => t.classList.toggle('active', t.dataset.dbview === v));
    $$('#db-bottom-body .panel').forEach(p => p.classList.toggle('active', p.id === v));
    ui.dbBottom = v;
  }
  function initSashes() {
    const L = ui.dbLayout || {};
    if (L.left) $('#db-left').style.width = L.left + 'px';
    if (L.bottom) $('#db-bottom').style.height = L.bottom + 'px';
    for (const sash of $$('[data-dbsash]')) {
      sash.addEventListener('mousedown', e => {
        e.preventDefault();
        const kind = sash.dataset.dbsash;
        const el = kind === 'left' ? $('#db-left') : $('#db-bottom');
        const start = kind === 'left' ? el.getBoundingClientRect().width : el.getBoundingClientRect().height;
        const sx = e.clientX, sy = e.clientY;
        const move = ev => {
          const v = Math.max(120, kind === 'left' ? start + ev.clientX - sx : start - (ev.clientY - sy));
          if (kind === 'left') el.style.width = v + 'px'; else el.style.height = v + 'px';
          if (st.active) st.active.cm.refresh();
        };
        const up = () => {
          document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up);
          ui.dbLayout = Object.assign({}, ui.dbLayout, { [kind]: Math.round(kind === 'left' ? el.getBoundingClientRect().width : el.getBoundingClientRect().height) });
          F.saveUi();
        };
        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
      });
    }
  }
  function welcomeHtml() {
    const k = s => F.kbdHtml(s);
    return `<h1>DB入門 (SQL Developer 風)</h1><div class="sub">Oracle Database と SQL Developer の代わりに、ブラウザの中のデータベース (H2・Oracle 互換モード) で SQL を学びます。インストールは不要です。</div>
      <div class="cards">
        <div class="card" data-db="newConnection"><b>${icon('dbplus')} 接続を作成する</b><span>教材 第2章と同じ値 (XE_SYSTEM・XE_DBAPP) で接続を作ります</span></div>
        <div class="card" data-db="lessonIndex"><b>${icon('lesson')} 教材の目次を開く</b><span>右のレッスンに DB入門 (Qiita) の目次を表示します</span></div>
        <div class="card" data-db="lessonStart"><b>${icon('lesson')} 第2章から始める</b><span>データベースに接続する</span></div>
      </div>
      <table><tr><td>${k('Ctrl+Enter')}</td><td>文の実行 (カーソルの位置の 1 文。結果は「問合せ結果」に表で表示)</td></tr>
        <tr><td>${k('F5')}</td><td>スクリプトの実行 (すべての文。結果は「スクリプト出力」に文字で表示)</td></tr>
        <tr><td>${k('F11')} / ${k('F12')}</td><td>コミット / ロールバック</td></tr>
        <tr><td>${k('Ctrl+Space')}</td><td>補完 (表名・列名)</td></tr></table>
      <p class="sub" style="margin-top:18px">コミットした内容 (表・データ・ユーザー) は、ワークスペースの <code>${DB_FILE}</code> に保存され、次に開いたときに元に戻ります。コミットしていない変更は、Oracle と同じく、画面を閉じると取り消されます。エラーは Oracle と同じ <code>ORA-</code> の番号と文言に置き換えて表示します。</p>`;
  }

  const MENUS = [
    { label: 'ファイル', key: 'F', items: [
      { label: '新規接続...', icon: 'dbplus', action: () => connectionDialog() },
      { label: 'SQLワークシートを開く', key: 'Alt+F10', icon: 'sheet', action: () => openSheetFor(st.active && st.active.conn) },
      '-',
      { label: '閉じる', key: 'Ctrl+F4', action: () => st.active && closeSheet(st.active), enabled: () => !!st.active },
      { label: '保存', key: 'Ctrl+S', icon: 'save', action: () => st.active && saveSheet(st.active).then(() => F.status('ワークシートを保存しました')), enabled: () => !!st.active },
      '-',
      { label: '終了', action: () => F.command('exit') },
    ] },
    { label: '編集', key: 'E', items: [
      { label: '元に戻す', key: 'Ctrl+Z', action: () => st.active && st.active.cm.undo(), enabled: () => !!st.active },
      { label: 'やり直し', key: 'Ctrl+Y', action: () => st.active && st.active.cm.redo(), enabled: () => !!st.active },
      '-',
      { label: 'すべて選択', key: 'Ctrl+A', action: () => st.active && st.active.cm.execCommand('selectAll'), enabled: () => !!st.active },
      { label: '検索/置換...', key: 'Ctrl+F', action: () => st.active && st.active.cm.execCommand('replace'), enabled: () => !!st.active },
      '-',
      { label: 'コメントの切り替え', key: 'Ctrl+/', action: () => st.active && st.active.cm.toggleComment(), enabled: () => !!st.active },
    ] },
    { label: '表示', key: 'V', items: [
      { label: '接続', icon: 'dbconn', action: () => { $('#db-left').style.display = ''; } },
      { label: '問合せ結果', icon: 'dbgrid', action: () => showBottom('db-result') },
      { label: 'スクリプト出力', icon: 'console', action: () => showBottom('db-script') },
      { label: 'H2 ログ', icon: 'h2log', action: () => showBottom('db-h2log') },
      { label: 'レッスン', icon: 'lesson', action: () => F.showRight('lesson') },
    ] },
    { label: '実行', key: 'R', items: [
      { label: '文の実行', key: 'Ctrl+Enter', icon: 'runStmt', action: runStatement, enabled: () => !!st.active },
      { label: 'スクリプトの実行', key: 'F5', icon: 'runScript', action: runScript, enabled: () => !!st.active },
      '-',
      { label: 'コミット', key: 'F11', icon: 'commit', action: () => commit('commit'), enabled: () => st.active && st.open.has(st.active.conn) },
      { label: 'ロールバック', key: 'F12', icon: 'rollback', action: () => commit('rollback'), enabled: () => st.active && st.open.has(st.active.conn) },
    ] },
    { label: 'ツール', key: 'T', items: [
      { label: 'SQLワークシート', key: 'Alt+F10', icon: 'sheet', action: () => openSheetFor(st.active && st.active.conn) },
      '-',
      { label: 'H2 の元のメッセージを常に表示する', checked: () => !!settings.dbAlwaysH2, action: () => { settings.dbAlwaysH2 = !settings.dbAlwaysH2; F.saveSettings(); F.status(settings.dbAlwaysH2 ? 'エラーのたびに H2 の元のメッセージを表示します' : 'H2 の元のメッセージは、推定のときだけ表示します'); } },
      { label: 'データベースの初期化...', action: resetDatabase },
    ] },
    { label: 'ウィンドウ', key: 'W', items: [
      { label: 'テーマの切り替え (ライト/ダーク)', action: () => F.command('toggleTheme') },
    ] },
    { label: 'ヘルプ', key: 'H', items: [
      { label: 'DB入門 (Qiita) の目次を開く', icon: 'lesson', action: () => lessonGo(0) },
      { label: 'H2 のエラー・コードの一覧', action: () => window.open(OraSql.h2DocUrl(0), '_blank', 'noopener') },
      '-',
      { label: 'お手軽Java について', action: () => F.command('about') },
    ] },
  ];
  function lessonGo(i) { F.showRight('lesson'); Lesson.setCourse('db'); Lesson.go(i); }

  async function resetDatabase() {
    const ok = await F.dialog({ title: 'データベースの初期化', icon: 'warning', message: 'データベースの中身 (ユーザー・表・データ) をすべて消して、Oracle をインストールした直後の状態に戻します。\n接続の設定とワークシートは残ります。\n\n初期化しますか?', buttons: [{ label: '初期化する', value: true }, { label: '取消', value: false, default: true }] });
    if (!ok) return;
    const r = await db(['reset']);
    if (r.ok) await saveDb();
    st.open.clear();
    st.meta.clear();
    renderTree();
    renderSheetBar();
    F.status(r.ok ? 'データベースを初期化しました。第2章の「学習用のユーザーを作る」からやり直せます' : '初期化できませんでした: ' + r.msg);
  }

  function buildToolbar() {
    const btn = (ic, title, act) => `<button class="tb-btn" data-db="${act}" title="${esc(F.keyLabel(title))}">${icon(ic)}</button>`;
    $('#toolbar').innerHTML = [
      btn('dbplus', '新規接続...', 'newConnection'),
      btn('sheet', 'SQLワークシートを開く (Alt+F10)', 'openSheet'),
      btn('save', '保存 (Ctrl+S)', 'saveSheet'),
      '<span class="tb-sep"></span>',
      btn('runStmt', '文の実行 (Ctrl+Enter)', 'runStatement'),
      btn('runScript', 'スクリプトの実行 (F5)', 'runScript'),
      '<span class="tb-sep"></span>',
      btn('lesson', 'レッスンを表示', 'showLesson'),
      `<span class="tb-label" title="データベースは H2 (Oracle 互換モード) です">H2 (Oracle 互換)</span>`,
      Perspective.switcherHtml(),
    ].join('');
  }
  function dbCommand(act) {
    switch (act) {
      case 'newConnection': return connectionDialog();
      case 'refreshTree': return Promise.all([...st.open.keys()].map(refresh)).then(renderTree);
      case 'openSheet': return openSheetFor(st.active && st.active.conn);
      case 'saveSheet': return st.active && saveSheet(st.active).then(() => F.status('ワークシートを保存しました'));
      case 'runStatement': return runStatement();
      case 'runScript': return runScript();
      case 'commit': return commit('commit');
      case 'rollback': return commit('rollback');
      case 'clearSheet': if (st.active) { st.active.cm.setValue(''); st.active.cm.focus(); } return;
      case 'clearOutput': {
        const v = ui.dbBottom || 'db-script';
        if (v === 'db-result') $('#db-result').innerHTML = ''; else $('#' + v).innerHTML = '';
        return;
      }
      case 'showLesson': return F.showRight('lesson');
      case 'lessonIndex': return lessonGo(0);
      case 'lessonStart': return lessonGo(2);
    }
  }
  /** DB入門の画面でのキー (ワークシートの中でも外でも) */
  function keys(e) {
    const ctrl = e.ctrlKey || (IS_MAC && e.metaKey);
    const k = (ctrl ? 'Ctrl+' : '') + (e.shiftKey ? 'Shift+' : '') + (e.altKey ? 'Alt+' : '') + (e.key.length === 1 ? e.key.toUpperCase() : e.key);
    const map = {
      'Ctrl+Enter': runStatement, 'F5': runScript, 'F9': runStatement, 'F11': () => commit('commit'), 'F12': () => commit('rollback'),
      'Ctrl+S': () => dbCommand('saveSheet'), 'Alt+F10': () => dbCommand('openSheet'), 'Ctrl+F4': () => st.active && closeSheet(st.active),
      'Ctrl+D': () => dbCommand('clearSheet'),
    };
    // F5 (ページの読み込み直し) と F11 (全画面) は、ブラウザの動きを止めて DB の操作にする
    if (map[k]) { e.preventDefault(); e.stopPropagation(); map[k](); return; }
    if (e.key === 'Escape') F.closeMenus();
    if (e.altKey && !e.ctrlKey && !e.shiftKey && /^[a-z]$/i.test(e.key)) {
      const m = MENUS.find(x => x.key.toLowerCase() === e.key.toLowerCase());
      if (m) { e.preventDefault(); F.showMenu(m.items, $$('.menu-top')[MENUS.indexOf(m)]); }
    }
  }

  function init() {
    if (st.inited) return;
    st.inited = true;
    $$('#db-workbench [data-icon]').forEach(s => { s.innerHTML = icon(s.dataset.icon); });
    loadConns();
    initTree();
    initSashes();
    $('#db-welcome').innerHTML = welcomeHtml();
    // ボタン ([data-db]) はまとめて受ける (ツールバー・ワークシートのバー・ようこそ)
    document.addEventListener('click', e => {
      const b = e.target.closest('[data-db]');
      if (!b || b.disabled || document.body.dataset.perspective !== 'db') return;
      dbCommand(b.dataset.db);
    });
    $$('#db-bottom-tabs .view-tab').forEach(t => t.addEventListener('mousedown', () => showBottom(t.dataset.dbview)));
    $('#db-tabs').addEventListener('mousedown', e => {
      const t = e.target.closest('.editor-tab');
      if (!t) return;
      const ws = st.sheets[+t.dataset.i];
      if (e.target.closest('.et-close')) { closeSheet(ws); return; }
      if (e.button === 1) { closeSheet(ws); return; }
      activate(ws);
    });
    showBottom(ui.dbBottom || 'db-script');
    renderTree();
    // 前回開いていたワークシート (接続はまだしない。実行するときに接続する)
    for (const c of ui.dbSheets || []) if (connByName(c)) openWorksheet(c);
    const last = st.sheets.find(s => s.conn === ui.dbActiveSheet);
    activate(last || st.sheets[0] || null);
  }
  /** DB入門の画面にしたとき */
  function activate0() {
    init();
    F.buildMenus(MENUS);
    buildToolbar();
    if (st.active) setTimeout(() => { st.active.cm.refresh(); st.active.cm.focus(); }, 0);
    // H2 (Java) の準備は裏で始めておく
    ensureJava();
  }

  /** レッスンの「ワークシートに反映」: 接続のワークシートを開き、教材の SQL に置き換える */
  async function applySql(conn, code) {
    if (IDE.dialogStack.length) { F.status('ダイアログを閉じてから「ワークシートに反映」してください'); return; }
    if (!connByName(conn)) {
      await F.dialog({ title: 'ワークシートに反映', icon: 'info', message: `接続 ${conn} がありません。\n教材 第2章の手順で、接続 ${conn} を作成してから、もう一度「ワークシートに反映」してください。` });
      return;
    }
    const ws = openWorksheet(conn);
    const cur = ws.cm.getValue();
    if (cur.trim() === code.trim()) { F.status('すでに教材と同じ内容です'); return; }
    ws.cm.setValue(code.replace(/\n+$/, '\n'));
    ws.cm.setCursor({ line: 0, ch: 0 });
    ws.cm.focus();
    F.status(`教材の SQL を ${conn} のワークシートに入れました。` + (OraSql.split(code).length > 1 ? 'F5 (スクリプトの実行) で実行できます' : 'Ctrl+Enter (文の実行) で実行できます') + ' (元に戻すには Ctrl+Z)');
  }
  function scriptText() { return $('#db-script') ? $('#db-script').innerText : ''; }

  return {
    activate: activate0, keys, applySql, scriptText, connectionDialog,
    get lastQuery() { return st.lastQuery; },
    get MENUS() { return MENUS; },
    refreshEditors: () => { if (st.active) st.active.cm.refresh(); },
    focusEditor: () => { if (st.active) st.active.cm.focus(); },
  };
})();
