// お手軽Java - レイアウト (サッシ・ビューのタブ・最大化)
'use strict';

(() => {
  const { S, $, $$, ui } = IDE;
  const { command, initConsole, initExplorerEvents, initTooltips, renderMarkers, renderOutline, saveUi } = IDE.fn;

  // =================================================================
  // レイアウト (サッシでサイズ変更、ビューのタブ)
  // =================================================================
  function initLayout() {
    const L = ui.layout || {};
    if (L.left) $('#left').style.width = L.left + 'px';
    if (L.right) $('#right').style.width = L.right + 'px';
    if (L.bottom) $('#view-bottom').style.height = L.bottom + 'px';
    if (L.rightHidden) $('#right').style.display = 'none';
    for (const sash of $$('.sash')) {
      sash.addEventListener('mousedown', e => {
        e.preventDefault();
        const kind = sash.dataset.sash;
        const startX = e.clientX, startY = e.clientY;
        const el = kind === 'left' ? $('#left') : kind === 'right' ? $('#right') : $('#view-bottom');
        const start = kind === 'bottom' ? el.getBoundingClientRect().height : el.getBoundingClientRect().width;
        const move = ev => {
          let v;
          if (kind === 'left') v = start + (ev.clientX - startX);
          else if (kind === 'right') v = start - (ev.clientX - startX);
          else v = start - (ev.clientY - startY);
          v = Math.max(120, Math.min(kind === 'bottom' ? window.innerHeight - 200 : window.innerWidth - 400, v));
          if (kind === 'bottom') el.style.height = v + 'px'; else el.style.width = v + 'px';
          refreshEditors();
        };
        const up = () => {
          document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up);
          ui.layout = ui.layout || {};
          ui.layout[kind] = Math.round(kind === 'bottom' ? el.getBoundingClientRect().height : el.getBoundingClientRect().width);
          saveUi();
        };
        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
      });
    }
    window.addEventListener('resize', refreshEditors);
  }
  function refreshEditors() { if (S.active) S.active.cm.refresh(); }

  function initViews() {
    // 下のビュー
    for (const t of $$('#bottom-tabs .view-tab')) t.addEventListener('mousedown', () => showBottom(t.dataset.view));
    for (const t of $$('#right-tabs .view-tab')) t.addEventListener('mousedown', () => showRight(t.dataset.view));
    for (const t of $$('.view-tabs')) t.addEventListener('dblclick', e => { if (e.target.closest('.view-tab')) toggleMaximize(t.closest('.view')); });
    $$('.view-tools [data-cmd], .view-tabs [data-cmd]').forEach(b => b.addEventListener('click', () => command(b.dataset.cmd)));
    $('#view-explorer .vt-close').addEventListener('click', e => { e.stopPropagation(); });
    showBottom(ui.bottomView === 'console' ? 'ide-console' : (ui.bottomView || 'ide-console'));
    showRight(ui.rightView || 'lesson');
    renderMarkers();
    renderOutline();
    initExplorerEvents();
    initConsole();
    initTooltips();
    $('#editor-tabs').addEventListener('dblclick', e => { if (e.target.closest('.editor-tab')) toggleMaximize($('#editor-area')); });
  }
  function showBottom(v) {
    $$('#bottom-tabs .view-tab').forEach(t => t.classList.toggle('active', t.dataset.view === v));
    $$('#bottom-body .panel').forEach(p => p.classList.toggle('active', p.id === v));
    $('#console-tools').style.visibility = v === 'ide-console' ? 'visible' : 'hidden';
    $('#server-tools').style.display = v === 'servers' ? '' : 'none';
    ui.bottomView = v; saveUi();
  }
  function showRight(v) {
    $('#right').style.display = '';
    $$('#right-tabs .view-tab').forEach(t => t.classList.toggle('active', t.dataset.view === v));
    $$('#right-body .panel').forEach(p => p.classList.toggle('active', p.id === v));
    ui.rightView = v;
    if (ui.layout) ui.layout.rightHidden = false;
    saveUi();
    refreshEditors();
  }
  function toggleMaximize(view) {
    if (S.maximized) { S.maximized.classList.remove('maximized'); const was = S.maximized; S.maximized = null; refreshEditors(); if (was === view) return; }
    if (!view) return;
    view.classList.add('maximized');
    S.maximized = view;
    refreshEditors();
  }

  Object.assign(IDE, { initLayout, initViews, refreshEditors, showBottom, showRight, toggleMaximize });
})();
