// お手軽Java - エディター (CodeMirror・タブ・キー割り当て・保存・検索・行へ移動)
'use strict';

(() => {
  const { S, $, $$, IS_MAC, baseName, binaries, editors, esc, files, isHidden, isJava, parentOf, projVersion, projectOf, settings, ui } = IDE;
  const { applyMarkers, command, contentOf, deco, dialog, fileIcon, fileKind, icon, kbdHtml, openDeclaration, projects, promptText, quickFix, renderExplorer,
    renderOutline, requestBuild, revealInExplorer, saveUi, scheduleOutline, scheduleOutlineSync, severityUnder, showBottom, showContextMenu, showError,
    status, toggleMaximize, updateToolbar } = IDE.fn;

  // =================================================================
  // エディター
  // =================================================================
  function isDirty(e) { return !e.cm.isClean(e.gen); }

  // Java モードを包んで、Javadoc (/** ... */) を通常のコメントと色分けする
  CodeMirror.defineMode('otekaru-java', (config) => {
    const base = CodeMirror.getMode(config, 'text/x-java');
    return Object.assign({}, base, {
      name: 'otekaru-java',
      startState: () => ({ b: CodeMirror.startState(base), doc: false }),
      copyState: s => ({ b: CodeMirror.copyState(base, s.b), doc: s.doc }),
      token(stream, s) {
        const style = base.token(stream, s.b);
        if (style && /comment/.test(style)) {
          const cur = stream.current();
          if (cur.startsWith('/**') && !cur.startsWith('/**/')) s.doc = true;
          const isDoc = s.doc;
          if (/\*\/$/.test(cur)) s.doc = false;
          if (isDoc) return style + ' javadoc';
          if (/TODO/.test(cur)) return style + ' todo';
        }
        return style;
      },
      indent: (s, textAfter, line) => base.indent(s.b, textAfter, line),
      innerMode: s => ({ state: s.b, mode: base }),
    });
  });

  // ファイルの種類ごとの CodeMirror のモードと補完
  const MODES = { java: 'otekaru-java', html: 'htmlmixed', css: 'css', js: 'javascript', xml: 'xml', text: 'text/plain' };
  function hintFor(kind) {
    if (kind === 'html' || kind === 'xml') return CodeMirror.hint.html;
    if (kind === 'css') return CodeMirror.hint.css;
    if (kind === 'js') return CodeMirror.hint.anyword;
    return Assist.hint;
  }

  function openEditor(path, opts = {}) {
    // 画像などは、Eclipse の「システム・エディター」と同じく、パソコンで関連付けされたアプリで開く
    if (binaries.has(path)) {
      Storage.openFile(path).then(() => status(`'${baseName(path)}' を関連付けされたアプリで開きました`),
        () => window.open(Storage.rawUrl(path), '_blank', 'noopener'));
      return null;
    }
    let ed = editors.find(e => e.path === path);
    if (!ed) {
      const pane = document.createElement('div');
      pane.className = 'editor-pane';
      $('#editors').appendChild(pane);
      const kind = fileKind(path);
      const markup = kind === 'html' || kind === 'xml';
      const cm = CodeMirror(pane, {
        value: files.get(path) || '',
        mode: MODES[kind] || 'text/plain',
        lineNumbers: true,
        gutters: ['markers', 'CodeMirror-linenumbers'],
        indentUnit: settings.indentUnit,
        tabSize: 4,
        indentWithTabs: !settings.indentSpaces,
        smartIndent: true,
        electricChars: true,
        matchBrackets: true,
        autoCloseBrackets: { pairs: '()[]{}""\'\'', explode: '[]{}()' },
        styleActiveLine: true,
        lineWrapping: false,
        dragDrop: true,
        extraKeys: editorKeys(),
        hintOptions: kind === 'java' || kind === 'text'
          ? { hint: Assist.hint, completeSingle: true, closeCharacters: /[\s()\[\]{};:>,=+\-*/!&|]/, alignWithWord: true }
          : { hint: hintFor(kind), completeSingle: false },
        // HTML: Eclipse と同じく、「</」を入力したら終了タグを補う。カーソルのあるタグと対になるタグを示す
        autoCloseTags: markup ? { whenOpening: false, whenClosing: true } : false,
        matchTags: markup ? { bothTags: true } : false,
        inputStyle: 'contenteditable',
        spellcheck: false,
      });
      const ruler = document.createElement('div');
      ruler.className = 'overview-ruler';
      pane.appendChild(ruler);
      ed = { path, cm, pane, ruler, gen: cm.changeGeneration(true), marks: [] };
      cm.on('change', (c, ch) => { onEditorChange(ed, ch); });
      cm.on('cursorActivity', () => { updateStatusPos(ed); scheduleOccurrences(ed); scheduleOutlineSync(); });
      cm.on('inputRead', (c, ch) => maybeAutoActivate(ed, ch));
      cm.on('mousedown', (c, e) => { if ((e.ctrlKey || (IS_MAC && e.metaKey)) && e.button === 0) { setTimeout(() => openDeclaration(ed, cm.coordsChar({ left: e.clientX, top: e.clientY })), 0); } });
      cm.on('gutterClick', (c, line, gutter) => { if (gutter === 'markers') quickFix(ed, line); });
      editors.push(ed);
      applyMarkers(ed);
    }
    activate(ed, opts.noFocus);
    if (opts.line != null) gotoPos(ed, opts.line, opts.col || 0, opts.flash);
    return ed;
  }

  /**
   * ファイルではないエディター (サーバーの概要など) を開く
   * @param key エディターを区別する名前 / title タブの名前 / iconName タブのアイコン
   * @param build (pane, markDirty) => { save(): Promise, focus() } 中身を作る関数
   */
  function openCustomEditor(key, title, iconName, build) {
    let ed = editors.find(e => e.path === key);
    if (!ed) {
      const pane = document.createElement('div');
      pane.className = 'editor-pane custom';
      $('#editors').appendChild(pane);
      // CodeMirror と同じ形の、未保存かどうかだけを持つ小さな代わり
      const cm = {
        cur: 0,
        isClean(g) { return g === this.cur; }, changeGeneration() { return this.cur; },
        refresh() {}, focus() { if (ed.custom.focus) ed.custom.focus(); }, setOption() {}, getValue() { return ''; },
      };
      ed = { path: key, title, iconName, cm, pane, gen: 0, marks: [] };
      ed.custom = build(pane, () => { cm.cur++; renderTabs(); });
      editors.push(ed);
    }
    activate(ed);
    return ed;
  }

  function activate(ed, noFocus) {
    S.active = ed;
    for (const e of editors) e.pane.classList.toggle('active', e === ed);
    renderTabs();
    updateWelcome();
    setTimeout(() => { ed.cm.refresh(); if (!noFocus) ed.cm.focus(); }, 0);
    updateStatusPos(ed);
    renderOutline();
    if (ui.linkEditor && !ed.custom) revealInExplorer(ed.path);
    saveUi();
  }

  function renderTabs() {
    const bar = $('#editor-tabs');
    bar.innerHTML = '';
    for (const e of editors) {
      const t = document.createElement('div');
      t.className = 'editor-tab' + (e === S.active ? ' active' : '');
      const dirty = isDirty(e);
      const sev = severityUnder(x => x === e.path);
      // 保存していないときは、Eclipse と同じく名前の前に * を付ける
      t.innerHTML = `<span class="tree-icon">${icon(e.iconName || fileIcon(e.path))}${deco(sev)}</span><span class="et-name">${dirty ? '*' : ''}${esc(e.title || baseName(e.path))}</span><span class="et-close" title="閉じる">${dirty ? '●' : '×'}</span>`;
      t.title = e.title || e.path;
      t.addEventListener('mousedown', ev => {
        if (ev.target.closest('.et-close')) return;
        if (ev.button === 1) { ev.preventDefault(); closeEditor(e); return; }
        activate(e);
      });
      const close = $('.et-close', t);
      close.addEventListener('mouseenter', () => { close.textContent = '×'; });
      close.addEventListener('mouseleave', () => { close.textContent = isDirty(e) ? '●' : '×'; });
      close.addEventListener('click', ev => { ev.stopPropagation(); closeEditor(e); });
      t.addEventListener('contextmenu', ev => {
        ev.preventDefault();
        showContextMenu([
          { label: '閉じる', action: () => closeEditor(e) },
          { label: 'その他を閉じる', action: () => editors.filter(x => x !== e).forEach(x => closeEditor(x)) },
          { label: 'すべて閉じる', action: () => command('closeAll') },
          ...(e.custom ? [] : ['-', { label: 'パッケージ・エクスプローラーで表示', action: () => revealInExplorer(e.path) }]),
        ], ev.clientX, ev.clientY);
      });
      bar.appendChild(t);
    }
    updateToolbar();
  }

  async function closeEditor(ed) {
    if (!ed) return;
    if (isDirty(ed)) {
      const r = await dialog({
        title: 'リソースの保存', message: `'${ed.title || baseName(ed.path)}' は変更されています。変更を保存しますか?`,
        buttons: [{ label: '保存', value: 'save', default: true }, { label: '保存しない', value: 'discard' }, { label: '取り消し', value: null }],
      });
      if (r === null || r === undefined) return;
      if (r === 'save') await saveEditor(ed);
    }
    const i = editors.indexOf(ed);
    editors.splice(i, 1);
    ed.pane.remove();
    if (S.active === ed) {
      S.active = editors[Math.min(i, editors.length - 1)] || null;
      if (S.active) activate(S.active); else { renderTabs(); updateWelcome(); renderOutline(); }
    } else renderTabs();
    renderExplorer();
    saveUi();
  }

  function updateWelcome() {
    const w = $('#welcome');
    if (editors.length) { w.hidden = true; return; }
    w.hidden = false;
    const hasProj = projects().length > 0;
    w.innerHTML = `<h1>ようこそ お手軽Java へ</h1>
      <div class="sub">インストール不要の Java 独習環境です。Eclipse (Pleiades) と同じ操作で、Qiita「Java入門」「HTML入門」の教材を進められます。</div>
      <div class="cards">
        <div class="card" data-cmd="lessonStart"><b>📘 教材を始める</b><span>第2章「開発環境の構築」を右のレッスンに表示します</span></div>
        <div class="card" data-cmd="lessonStartHtml"><b>🌐 HTML入門を始める</b><span>HTML入門の第2章「開発環境の構築」を右のレッスンに表示します</span></div>
        <div class="card" data-cmd="newProject"><b>🆕 Java プロジェクトを作る</b><span>ファイル → 新規 → Java プロジェクト</span></div>
        ${hasProj ? '<div class="card" data-cmd="newClass"><b>☕ クラスを作る</b><span>パッケージを選んでから 新規 → クラス</span></div>' : ''}
        <div class="card" data-cmd="lessonIndex"><b>📑 教材の目次</b><span>【Java入門】目次 (全14章＋付録)</span></div>
        <div class="card" data-cmd="keyAssist"><b>⌨ キー・アシスト</b><span>使えるショートカットの一覧 (Ctrl+Shift+L)</span></div>
      </div>
      <table>
        <tr><td>${kbdHtml('Ctrl+S')}</td><td>保存 (保存すると自動でコンパイルされます)</td></tr>
        <tr><td>${kbdHtml('Ctrl+F11')}</td><td>実行</td></tr>
        <tr><td>${kbdHtml('Ctrl+Space')}</td><td>補完 (sysout, main など)</td></tr>
        <tr><td>${kbdHtml('Ctrl+Shift+F')}</td><td>フォーマット</td></tr>
      </table>
      <p class="sub" style="margin-top:18px">保存場所: ${Storage.mode === 'server' ? esc(Storage.rootPath || 'ワークスペースのフォルダー') : 'このブラウザ (localStorage)'}</p>`;
    $$('[data-cmd]', w).forEach(c => c.onclick = () => command(c.dataset.cmd));
  }

  function onEditorChange(ed, change) {
    renderTabsDebounced();
    scheduleOutline();
    // 編集した行のマーカーは、保存してビルドし直すまで残す (Eclipse と同じ)
  }
  let tabTimer = null;
  function renderTabsDebounced() { clearTimeout(tabTimer); tabTimer = setTimeout(() => { renderTabs(); renderExplorer(); }, 120); }

  function updateStatusPos(ed) {
    if (ed.custom) { $('#st-pos').textContent = ''; return; }
    const c = ed.cm.getCursor();
    $('#st-pos').textContent = `${c.line + 1} : ${c.ch + 1} : ${ed.cm.indexFromPos(c)}`;
  }

  function gotoPos(ed, line, col, flash) {
    const cm = ed.cm;
    cm.setCursor({ line, ch: col || 0 });
    cm.scrollIntoView({ line, ch: col || 0 }, 120);
    if (flash) {
      const h = cm.addLineClass(line, 'background', 'flash-line');
      setTimeout(() => cm.removeLineClass(h, 'background', 'flash-line'), 1500);
    }
    cm.focus();
  }

  // 自動有効化 ("." を入力したら候補を出す)
  let autoTimer = null;
  function maybeAutoActivate(ed, change) {
    if (!settings.autoActivation) return;
    const ch = change.text.join('');
    // HTML は「<」を入力したらタグの候補を出す (Eclipse の HTML エディターと同じ)
    if (fileKind(ed.path) === 'html' && ch === '<') {
      clearTimeout(autoTimer);
      autoTimer = setTimeout(() => { if (S.active === ed) ed.cm.showHint({ completeSingle: false }); }, settings.autoActivationDelay);
      return;
    }
    if (!isJava(ed.path)) return;
    if (ch.length !== 1 || !settings.autoActivationTriggers.includes(ch)) return;
    const tok = ed.cm.getTokenAt(ed.cm.getCursor());
    if (/comment|string/.test(tok.type || '')) return;
    if (ch === '.' && /\d\.$/.test(ed.cm.getLine(ed.cm.getCursor().line).slice(0, ed.cm.getCursor().ch))) return;
    clearTimeout(autoTimer);
    autoTimer = setTimeout(() => { if (S.active === ed) ed.cm.showHint({ completeSingle: false }); }, settings.autoActivationDelay);
  }

  // 出現箇所のマーク (Eclipse の「出現箇所のマーク」)
  let occTimer = null;
  function scheduleOccurrences(ed) {
    clearTimeout(occTimer);
    if (!settings.markOccurrences || !isJava(ed.path)) return;
    occTimer = setTimeout(() => markOccurrences(ed), 350);
  }
  function markOccurrences(ed) {
    const cm = ed.cm;
    (ed.occ || []).forEach(m => m.clear());
    ed.occ = [];
    if (cm.somethingSelected()) return;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch, e = c.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    while (e < line.length && /[\w$]/.test(line[e])) e++;
    const word = line.slice(s, e);
    if (!word || /^\d/.test(word) || Assist.LIB[word] === undefined && ['public', 'private', 'static', 'void', 'int', 'class', 'return', 'new', 'if', 'else', 'for', 'while', 'String'].includes(word)) return;
    const tok = cm.getTokenAt({ line: c.line, ch: s + 1 });
    if (/comment|string|keyword/.test(tok.type || '')) return;
    const b = JavaSrc.blank(cm.getValue());
    const re = new RegExp('(?<![\\w$])' + word.replace(/\$/g, '\\$') + '(?![\\w$])', 'g');
    let m, n = 0;
    while ((m = re.exec(b)) && n < 500) {
      ed.occ.push(cm.markText(cm.posFromIndex(m.index), cm.posFromIndex(m.index + word.length), { className: 'occurrence' }));
      n++;
    }
    if (ed.occ.length < 2) { ed.occ.forEach(x => x.clear()); ed.occ = []; }
  }

  // ---------- エディターのキー割り当て ----------
  function editorKeys() {
    const ifLinked = (key, fallback) => cm => { if (Assist.linkedKey(cm, key)) return; if (fallback) return fallback(cm); return CodeMirror.Pass; };
    const map = {
      'Ctrl-Space': cm => cm.showHint({ completeSingle: true }),
      'Ctrl-/': cm => toggleComment(cm),
      'Ctrl-7': cm => toggleComment(cm),
      'Shift-Ctrl-/': cm => cm.blockComment(cm.getCursor('from'), cm.getCursor('to'), { fullLines: false }),
      'Shift-Ctrl-\\': cm => cm.uncomment(cm.getCursor('from'), cm.getCursor('to')),
      'Shift-Ctrl-F': () => command('format'),
      'Ctrl-I': () => command('correctIndent'),
      'Shift-Ctrl-O': () => command('organizeImports'),
      'Shift-Ctrl-M': () => command('addImport'),
      'Ctrl-D': cm => deleteLines(cm),
      'Alt-Up': cm => moveLines(cm, -1),
      'Alt-Down': cm => moveLines(cm, 1),
      'Ctrl-Alt-Down': cm => duplicateLines(cm, 1),
      'Ctrl-Alt-Up': cm => duplicateLines(cm, 0),
      'Shift-Enter': cm => { const l = cm.getCursor().line; cm.setCursor({ line: l, ch: cm.getLine(l).length }); cm.execCommand('newlineAndIndent'); },
      'Shift-Ctrl-Enter': cm => { const l = cm.getCursor().line; cm.replaceRange('\n', { line: l, ch: 0 }); cm.setCursor({ line: l, ch: 0 }); cm.indentLine(l, 'smart'); cm.setCursor({ line: l, ch: cm.getLine(l).length }); },
      'Ctrl-L': () => command('gotoLine'),
      'Ctrl-F': () => command('find'),
      'Ctrl-K': () => command('findNext'),
      'Shift-Ctrl-K': () => command('findPrev'),
      'F3': () => command('openDecl'),
      'Ctrl-1': () => command('quickFix'),
      'Ctrl-.': () => command('nextAnnotation'),
      'Ctrl-,': () => command('prevAnnotation'),
      'Shift-Ctrl-P': cm => cm.execCommand('goToBracket') ,
      'Shift-Alt-R': () => command('renameSymbol'),
      'Alt-/': () => command('wordComplete'),
      'Ctrl-Y': cm => cm.redo(),
      'Shift-Ctrl-Z': cm => cm.redo(),
      'Tab': ifLinked('Tab', cm => { if (cm.somethingSelected() && cm.getSelection().includes('\n')) cm.indentSelection('add'); else cm.replaceSelection(settings.indentSpaces ? ' '.repeat(settings.indentUnit - (cm.getCursor().ch % settings.indentUnit)) : '\t'); }),
      'Shift-Tab': ifLinked('Shift-Tab', cm => cm.indentSelection('subtract')),
      'Enter': ifLinked('Enter', cm => cm.execCommand('newlineAndIndent')),
      'Esc': ifLinked('Esc', () => CodeMirror.Pass),
      'Ctrl-S': () => command('save'),
      'Shift-Ctrl-S': () => command('saveAll'),
      'Ctrl-F11': () => command('run'),
      'Ctrl-B': () => command('buildAll'),
      'Shift-Ctrl-L': () => command('keyAssist'),
      'Shift-Ctrl-U': () => command('markOccurrencesNow'),
      'Ctrl-M': () => toggleMaximize($('#editor-area')),
      'Ctrl-H': () => command('searchWorkspace'),
      'Ctrl-F4': () => command('closeEditor'),
    };
    // Mac では同じ操作を ⌘ でも行えるようにする (Control + Space の補完はそのまま)
    if (IS_MAC) {
      for (const k of Object.keys(map)) {
        if (!/(^|-)Ctrl-/.test(k) || k === 'Ctrl-Space') continue;
        const mk = k.replace(/(^|-)Ctrl-/, '$1Cmd-');
        if (!(mk in map)) map[mk] = map[k];
      }
    }
    return map;
  }
  // コメントの切り替え: Java は行コメント (//)、HTML・CSS はブロック・コメント (<!-- --> や /* */)
  function toggleComment(cm) {
    const ed = editors.find(e => e.cm === cm);
    if (ed && isJava(ed.path)) return toggleLineComment(cm);
    cm.toggleComment();
  }
  function toggleLineComment(cm) {
    const from = cm.getCursor('from'), to = cm.getCursor('to');
    let endLine = to.line;
    if (to.ch === 0 && to.line > from.line) endLine--;
    const lines = [];
    for (let l = from.line; l <= endLine; l++) lines.push(cm.getLine(l));
    const allCommented = lines.every(t => /^\s*\/\//.test(t) || !t.trim());
    cm.operation(() => {
      for (let l = from.line; l <= endLine; l++) {
        const t = cm.getLine(l);
        if (allCommented) {
          const m = t.match(/^(\s*)\/\/ ?/);
          if (m) cm.replaceRange(m[1], { line: l, ch: 0 }, { line: l, ch: m[0].length });
        } else {
          // Eclipse は行頭 (0 桁目) に // を付ける
          cm.replaceRange('//', { line: l, ch: 0 });
        }
      }
    });
    if (from.line === endLine && !cm.somethingSelected()) cm.setCursor({ line: Math.min(from.line + 1, cm.lineCount() - 1), ch: cm.getCursor().ch });
  }
  function deleteLines(cm) {
    const from = cm.getCursor('from').line, to = cm.getCursor('to').line;
    cm.operation(() => {
      if (to + 1 < cm.lineCount()) cm.replaceRange('', { line: from, ch: 0 }, { line: to + 1, ch: 0 });
      else cm.replaceRange('', { line: Math.max(0, from - 1), ch: from > 0 ? cm.getLine(from - 1).length : 0 }, { line: to, ch: cm.getLine(to).length });
    });
  }
  function moveLines(cm, dir) {
    const from = cm.getCursor('from'), to = cm.getCursor('to');
    let s = from.line, e = to.line;
    if (to.ch === 0 && e > s) e--;
    if ((dir < 0 && s === 0) || (dir > 0 && e >= cm.lineCount() - 1)) return;
    cm.operation(() => {
      const text = cm.getRange({ line: s, ch: 0 }, { line: e, ch: cm.getLine(e).length });
      if (dir < 0) {
        const prev = cm.getLine(s - 1);
        cm.replaceRange(text + '\n' + prev, { line: s - 1, ch: 0 }, { line: e, ch: cm.getLine(e).length });
      } else {
        const next = cm.getLine(e + 1);
        cm.replaceRange(next + '\n' + text, { line: s, ch: 0 }, { line: e + 1, ch: cm.getLine(e + 1).length });
      }
      cm.setSelection({ line: from.line + dir, ch: from.ch }, { line: to.line + dir, ch: to.ch });
    });
  }
  function duplicateLines(cm, below) {
    const from = cm.getCursor('from'), to = cm.getCursor('to');
    let s = from.line, e = to.line;
    if (to.ch === 0 && e > s) e--;
    const text = cm.getRange({ line: s, ch: 0 }, { line: e, ch: cm.getLine(e).length });
    cm.operation(() => {
      cm.replaceRange(text + '\n', { line: s, ch: 0 });
      if (below) cm.setSelection({ line: from.line + (e - s + 1), ch: from.ch }, { line: to.line + (e - s + 1), ch: to.ch });
      else cm.setSelection(from, to);
    });
  }

  // =================================================================
  // 保存とビルド
  // =================================================================
  async function saveEditor(ed) {
    if (!ed) return;
    if (ed.custom) {
      try { await ed.custom.save(); } catch (e) { showError('保存できませんでした', e.message); return; }
      ed.gen = ed.cm.changeGeneration(true);
      renderTabs();
      return;
    }
    const text = ed.cm.getValue();
    try {
      await Storage.writeFile(ed.path, text);
    } catch (e) {
      showError('保存できませんでした', e.message);
      return;
    }
    files.set(ed.path, text);
    ed.gen = ed.cm.changeGeneration(true);
    fileChanged(ed.path);
    renderTabs();
    renderExplorer();
    status(`'${baseName(ed.path)}' を保存しました`);
  }
  function fileChanged(path) {
    S.fileVersion++;
    const p = projectOf(path);
    projVersion.set(p, S.fileVersion);
    if (settings.autoBuild && isJava(path)) requestBuild(p);
  }
  async function saveAll() {
    for (const e of editors.filter(isDirty)) await saveEditor(e);
  }

  // ---------- ワークスペース内の検索 (Ctrl+H) ----------
  async function searchWorkspace() {
    const sel = S.active && !S.active.custom && S.active.cm.getSelection();
    const q = await promptText('検索', '含まれるテキスト(C):', sel && !sel.includes('\n') ? sel : (ui.lastSearch || ''), () => '');
    if (!q) return;
    ui.lastSearch = q; saveUi();
    const el = $('#search');
    const results = [];
    // 文字のファイル (.java・.html・.css など) を探す
    const targets = [...files.keys()].filter(f => projects().includes(projectOf(f)) && !isHidden(f) && fileKind(f) !== 'image').sort();
    for (const f of targets) {
      const lines = (contentOf(f) || '').split('\n');
      lines.forEach((l, i) => { const k = l.toLowerCase().indexOf(q.toLowerCase()); if (k >= 0) results.push({ f, i, l, k }); });
    }
    const byFile = new Map();
    for (const r of results) { if (!byFile.has(r.f)) byFile.set(r.f, []); byFile.get(r.f).push(r); }
    el.innerHTML = `<div class="search-head">'${esc(q)}' - ワークスペースで ${results.length} 件一致</div>` +
      [...byFile].map(([f, rs]) => `<div class="search-file">${icon(fileIcon(f))} ${esc(baseName(f))} <span style="font-weight:normal;color:var(--text-dim)">- ${esc(parentOf(f))} (${rs.length} 件)</span></div>` +
        rs.map(r => `<div class="search-hit" data-f="${esc(f)}" data-l="${r.i}" data-c="${r.k}"><span class="ln">${r.i + 1}:</span>${esc(r.l.slice(0, r.k).trimStart())}<mark>${esc(r.l.substr(r.k, q.length))}</mark>${esc(r.l.slice(r.k + q.length))}</div>`).join('')).join('');
    $$('.search-hit', el).forEach(h => h.addEventListener('dblclick', () => openEditor(h.dataset.f, { line: +h.dataset.l, col: +h.dataset.c, flash: true })));
    $$('.search-hit', el).forEach(h => h.addEventListener('click', () => openEditor(h.dataset.f, { line: +h.dataset.l, col: +h.dataset.c })));
    showBottom('search');
  }

  // ---------- 行へ移動 ----------
  async function gotoLineDialog() {
    if (!S.active) return;
    const n = S.active.cm.lineCount();
    const v = await promptText('行へ移動', `行番号を入力 (1..${n}):`, String(S.active.cm.getCursor().line + 1), x => (/^\d+$/.test(x) && +x >= 1 && +x <= n) ? '' : '1 から ' + n + ' までの数を入力してください');
    if (v) gotoPos(S.active, +v - 1, 0, true);
  }

  Object.assign(IDE, { activate, closeEditor, openCustomEditor, toggleComment, deleteLines, duplicateLines, editorKeys, fileChanged, gotoLineDialog, gotoPos, isDirty, markOccurrences, maybeAutoActivate, moveLines, onEditorChange, openEditor, renderTabs, renderTabsDebounced, saveAll, saveEditor, scheduleOccurrences, searchWorkspace, toggleLineComment, updateStatusPos, updateWelcome });
})();
