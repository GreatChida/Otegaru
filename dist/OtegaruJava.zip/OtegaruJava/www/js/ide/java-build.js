// お手軽Java - Java のビルド (ECJ でのコンパイル)
'use strict';

(() => {
  const { S, building, builtVersion, editors, files, problems, projVersion, projectOf } = IDE;
  const { applyMarkers, isWebProject, javaFilesOf, progress, projectJre, projects, renderExplorer, renderMarkers, renderTabs, setJavaStatus,
    showError, srcRoot, status } = IDE.fn;

  // =================================================================
  // Java (CheerpJ) の準備: Java を使うときだけ読み込む (HTML だけなら読み込まない)
  // =================================================================
  let javaStarting = null;
  /** Java プロジェクトか、.java ファイルを持つプロジェクトがあるか */
  const usesJava = p => !isWebProject(p) || javaFilesOf(p).length > 0;
  function needsJava() { return projects().some(usesJava); }
  /** Java を準備する (準備済みなら何もしない)。準備できたら true を返す */
  function ensureJava() {
    if (javaStarting) return javaStarting;
    // ランタイムの版は、Java を使うプロジェクトだけで決める (HTML だけの動的 Web プロジェクトの JRE は見ない)
    const javaProjects = projects().filter(usesJava);
    const ver = javaProjects.length ? Math.max(...javaProjects.map(projectJre)) : 17;
    const runtimeVer = +(sessionStorage.getItem('otekaru.runtime') || (ver >= 21 ? 21 : 17));
    setJavaStatus('Java を準備中…', true);
    javaStarting = (async () => {
      try {
        await JavaRT.init(runtimeVer, msg => setJavaStatus(msg || 'Java を準備中…', true));
        S.javaReady = true;
        setJavaStatus('JavaSE-' + JavaRT.version, false);
        for (const p of projects()) requestBuild(p);
        return true;
      } catch (e) {
        setJavaStatus('Java を起動できません', false);
        showError('Java を起動できません', e.message + '\n\nインターネットに接続されているか確認して、ページを読み込み直してください。');
        return false;
      }
    })();
    return javaStarting;
  }

  function requestBuild(project) {
    if (!projects().includes(project)) return Promise.resolve();
    // .java の無い動的 Web プロジェクトは、ビルドする物が無い (Java を読み込まない)
    if (isWebProject(project) && !javaFilesOf(project).length) {
      if ((problems.get(project) || []).length) { problems.set(project, []); renderMarkers(); renderExplorer(); }
      return Promise.resolve();
    }
    if (!S.javaReady) { ensureJava(); return Promise.resolve(); }
    let b = building.get(project);
    if (b && b.running) { b.again = true; return b.done; }
    b = { running: true, again: false };
    building.set(project, b);
    b.done = (async () => {
      do {
        b.again = false;
        await buildProject(project);
      } while (b.again);
      b.running = false;
    })();
    return b.done;
  }

  async function buildProject(project) {
    const version = projVersion.get(project) || 0;
    const srcPrefix = srcRoot(project) + '/';
    const map = {};
    for (const f of javaFilesOf(project)) map[f.slice(srcPrefix.length)] = files.get(f);
    status(`ビルド中: ${project}`, true);
    progress(true);
    setJavaStatus('ビルド中…', true);
    const t0 = performance.now();
    try {
      const release = Math.min(projectJre(project), JavaRT.version);
      const r = await JavaRT.compile(project, map, String(release));
      const list = r.diags.filter(d => d.kind === 'ERROR' || d.kind === 'WARNING' || d.kind === 'MANDATORY_WARNING').map(d => ({
        path: d.file ? srcPrefix + d.file : project,
        kind: d.kind === 'ERROR' ? 'ERROR' : 'WARNING',
        line: Math.max(0, d.line - 1), col: Math.max(0, d.col - 1), start: d.start, end: d.end,
        msg: d.msg, code: d.code,
      }));
      problems.set(project, list);
      builtVersion.set(project, version);
      const ne = list.filter(x => x.kind === 'ERROR').length, nw = list.length - ne;
      status(`ビルド完了: ${project} (${((performance.now() - t0) / 1000).toFixed(1)} 秒)` + (ne || nw ? ` エラー ${ne}、警告 ${nw}` : ''));
    } catch (e) {
      status('ビルドに失敗しました: ' + e.message);
    } finally {
      progress(false);
      setJavaStatus('JavaSE-' + JavaRT.version, false);
      for (const ed of editors) if (projectOf(ed.path) === project) applyMarkers(ed);
      renderMarkers();
      renderExplorer();
      renderTabs();
    }
  }
  async function ensureBuilt(project) {
    const b = building.get(project);
    if (b && b.running) await b.done;
    if ((builtVersion.get(project) ?? -1) !== (projVersion.get(project) || 0) || !problems.has(project)) await requestBuild(project);
  }

  Object.assign(IDE, { buildProject, ensureBuilt, ensureJava, needsJava, requestBuild });
})();
