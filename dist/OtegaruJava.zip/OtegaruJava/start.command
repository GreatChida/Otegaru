#!/bin/bash
# お手軽Java を起動します (macOS)。このファイルをダブルクリックしてください
cd "$(dirname "$0")" || exit 1
exec /usr/bin/perl tools/server.pl "$@"
