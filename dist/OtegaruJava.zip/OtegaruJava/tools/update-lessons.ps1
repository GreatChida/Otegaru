﻿# Qiita「【Java入門】」「【HTML入門】」「【DB入門】」シリーズの最新の本文を取得して、内蔵の教材 (www\lessons\*.js) を作り直す
#   使い方: powershell -ExecutionPolicy Bypass -File tools\update-lessons.ps1 [-Course java|html|db|all]
#   - java: www\lessons\lessons.js (window.LESSONS)
#   - html: www\lessons\lessons-html.js (window.LESSONS_HTML)
#   - db: www\lessons\lessons-db.js (window.LESSONS_DB)
param(
  [ValidateSet('java', 'html', 'db', 'all')]
  [string]$Course = 'all'
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
# コースごとの出力先と、目次と各章の記事 ID (目次の順番)
$courses = @(
  @{
    key = 'java'; name = 'Java入門'; var = 'LESSONS'; file = 'lessons.js'
    ids = @(
      '1f0f457d575d4a675c16',
      '6b86112b31faf9091e22', 'd9fe44e3fb2aab706c2c', 'f1d480420fbed38749c8',
      'c9a1813d5ce79c710434', '3a00a5d8154c5c3a5550', '18c6addcb4204d9cbf4e',
      'da06429557905f21b1ab', 'af8e8c4db8e5f61f0b7c', '9145186438ecf5c973f4',
      '3bb1d0850b04b262d078', '25fa2bda4b19ee9e596f', '37acc161b028d6a285a6',
      '4c0d6954d199b7d51941', '7d073b54a53ac623deff', '743cfd1b90cb36315ae5'
    )
  },
  @{
    key = 'html'; name = 'HTML入門'; var = 'LESSONS_HTML'; file = 'lessons-html.js'
    ids = @(
      '4efc23bf7222b2377b2d',
      '4a3e11a2512fda0f63a1', '660b08bc2730550ddb0c', 'f06cee99e049703e076e',
      'd84c5a0ccc3fa11f2c5b', '3becd42fc8725701f9a9', '1bfa3b45b046f4935492',
      'f221417c789cccb33c83', '7b705686cb07916ae74e', '7719835a211755e9d41b',
      'a94b26c30eb9a66e5e1e', '5b64787bb12ab62cd477', 'ab180287bcc210c7886b'
    )
  },
  @{
    key = 'db'; name = 'DB入門'; var = 'LESSONS_DB'; file = 'lessons-db.js'
    ids = @(
      'd1fbd989a20e8eed1cbc',
      '02743e91814a69e33b54', '6ea9dd6339b6606e4f28', 'e6bb5ac4f35003cf12aa',
      '41e87360e6046d93c0bb', 'f0139031247b33eb75e0', '61dc6311b43ac049e202',
      'f87bf37542056b3d729b', '1438af0227c1da6efd47', '722a505697c05f8912e8',
      '128dfee5221a6a5db4ca', '2a159c7129d2da47eec5', '9edc03e7eca75505a218',
      '923d18677cc07e6eec30'
    )
  }
)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
foreach ($c in $courses) {
  if ($Course -ne 'all' -and $Course -ne $c.key) { continue }
  $out = Join-Path $Root ('www\lessons\' + $c.file)
  $list = New-Object System.Collections.ArrayList
  foreach ($id in $c.ids) {
    Write-Host "取得中: $($c.name) $id"
    $res = Invoke-WebRequest -UseBasicParsing -Uri "https://qiita.com/api/v2/items/$id"
    $json = [System.Text.Encoding]::UTF8.GetString($res.RawContentStream.ToArray()) | ConvertFrom-Json
    [void]$list.Add([ordered]@{
      id = $id
      title = $json.title.Replace("【$($c.name)】", '').Trim()
      url = $json.url
      updated = $json.updated_at
      body = $json.body
    })
    Start-Sleep -Milliseconds 300
  }
  $body = ConvertTo-Json -InputObject $list -Depth 4 -Compress
  $text = "// Qiita「【$($c.name)】」シリーズ (chida0818) の本文。tools/update-lessons.ps1 で最新に更新できます`nwindow.$($c.var) = $body;`n"
  [System.IO.File]::WriteAllText($out, $text, (New-Object System.Text.UTF8Encoding($false)))
  Write-Host "作成しました: $out"
}
