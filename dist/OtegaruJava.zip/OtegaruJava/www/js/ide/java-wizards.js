// お手軽Java - Java のウィザード (プロジェクト・パッケージ・クラス)
'use strict';

(() => {
  const { S, $, ICON_SVG, dirs, esc, expanded, files, parentOf, settings, ui } = IDE;
  const { dialog, fileChanged, gotoPos, icon, openEditor, packagesOf, pickFromList, pkgOfDir, projects, renderExplorer, requestBuild, revealInExplorer,
    selectionContext, showError, srcRoot, status, updateWelcome } = IDE.fn;

  function validIdent(s) { return /^[A-Za-z_$][\w$]*$/.test(s) && !['abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char', 'class', 'const', 'continue', 'default', 'do', 'double', 'else', 'enum', 'extends', 'final', 'finally', 'float', 'for', 'goto', 'if', 'implements', 'import', 'instanceof', 'int', 'interface', 'long', 'native', 'new', 'package', 'private', 'protected', 'public', 'return', 'short', 'static', 'strictfp', 'super', 'switch', 'synchronized', 'this', 'throw', 'throws', 'transient', 'try', 'void', 'volatile', 'while', 'true', 'false', 'null', 'var', 'record', 'yield'].includes(s); }

  // ---------- 新規 Java プロジェクト ----------
  async function newProjectWizard() {
    const exists = n => projects().includes(n) || dirs.has(n);
    const r = await dialog({
      title: '新規 Java プロジェクト', width: 560, help: true,
      banner: { title: 'Java プロジェクトの作成', message: 'ワークスペースまたは外部ロケーションに Java プロジェクトを作成します。' },
      html: `<div class="row"><label>プロジェクト名(<u>P</u>):</label><input type="text" id="np-name" spellcheck="false"><span></span></div>
        <label class="chk"><input type="checkbox" checked disabled>デフォルト・ロケーションを使用(<u>D</u>)</label>
        <div class="row"><label style="padding-left:18px">ロケーション(<u>L</u>):</label><input type="text" id="np-loc" readonly><span></span></div>
        <fieldset><legend>JRE</legend>
          <label class="chk"><input type="radio" name="jre" checked>実行環境 JRE の使用(<u>V</u>):
            <select id="np-jre" style="width:auto;margin-left:6px"><option>JavaSE-21</option><option>JavaSE-17</option></select></label>
          <label class="chk"><input type="radio" name="jre" disabled>プロジェクト固有の JRE を使用(<u>S</u>)</label>
          <label class="chk"><input type="radio" name="jre" disabled>デフォルト JRE を使用 (現在は 'JavaSE-21')</label>
        </fieldset>
        <fieldset><legend>プロジェクト・レイアウト</legend>
          <label class="chk"><input type="radio" name="lay" disabled>プロジェクト・フォルダーをソースおよびクラス・ファイルのルートとして使用(<u>U</u>)</label>
          <label class="chk"><input type="radio" name="lay" checked>ソースおよびクラス・ファイルのために別のフォルダーを作成(<u>C</u>)</label>
        </fieldset>
        <fieldset><legend>モジュール</legend>
          <label class="chk"><input type="checkbox" id="np-mod">module-info.java ファイルの作成</label>
        </fieldset>`,
      buttons: [{ label: '< 戻る(B)', value: 'back' }, { label: '次へ(N) >', value: 'next' }, {
        label: '完了(F)', value: 'ok', default: true,
        validate: d => !$('[data-b="2"]', d).disabled,
      }, { label: '取り消し', value: null }],
      collect: d => ({ name: $('#np-name', d).value.trim(), jre: $('#np-jre', d).value, module: $('#np-mod', d).checked }),
      onOpen: (d) => {
        $('[data-b="0"]', d).disabled = true; $('[data-b="1"]', d).disabled = true;
        const upd = () => {
          const n = $('#np-name', d).value.trim();
          $('#np-loc', d).value = (Storage.rootPath ? Storage.rootPath.replace(/\\/g, '/') + '/' : 'workspace/') + n;
          let msg = '', bad = false;
          if (!n) { msg = 'プロジェクト名を入力してください。'; bad = true; }
          else if (!/^[A-Za-z0-9_\-.]+$/.test(n) || n.startsWith('.')) { msg = 'お手軽Java では、プロジェクト名に半角の英数字と _ - . だけが使えます。'; bad = true; }
          else if (exists(n)) { msg = '同じ名前のプロジェクトがすでに存在します。'; bad = true; }
          $('#dlg-msg', d).innerHTML = msg ? (n ? ICON_SVG.error : '') + ' ' + esc(msg) : 'ワークスペースまたは外部ロケーションに Java プロジェクトを作成します。';
          $('[data-b="2"]', d).disabled = bad;
        };
        $('#np-name', d).addEventListener('input', upd);
        upd();
      },
    });
    if (!r || r.value !== 'ok') return;
    await createProject(r.name, +r.jre.replace('JavaSE-', ''), r.module);
  }
  async function createProject(name, jre, module) {
    const proj = `<?xml version="1.0" encoding="UTF-8"?>\n<projectDescription>\n\t<name>${name}</name>\n\t<comment></comment>\n\t<projects>\n\t</projects>\n\t<buildSpec>\n\t\t<buildCommand>\n\t\t\t<name>org.eclipse.jdt.core.javabuilder</name>\n\t\t\t<arguments>\n\t\t\t</arguments>\n\t\t</buildCommand>\n\t</buildSpec>\n\t<natures>\n\t\t<nature>org.eclipse.jdt.core.javanature</nature>\n\t</natures>\n</projectDescription>\n`;
    const cp = `<?xml version="1.0" encoding="UTF-8"?>\n<classpath>\n\t<classpathentry kind="con" path="org.eclipse.jdt.launching.JRE_CONTAINER/org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType/JavaSE-${jre}">\n\t\t<attributes>\n\t\t\t<attribute name="module" value="true"/>\n\t\t</attributes>\n\t</classpathentry>\n\t<classpathentry kind="src" path="src"/>\n\t<classpathentry kind="output" path="bin"/>\n</classpath>\n`;
    const prefs = `eclipse.preferences.version=1\norg.eclipse.jdt.core.compiler.codegen.targetPlatform=${jre}\norg.eclipse.jdt.core.compiler.compliance=${jre}\norg.eclipse.jdt.core.compiler.source=${jre}\norg.eclipse.jdt.core.compiler.release=enabled\n`;
    try {
      await Storage.mkdir(name); dirs.add(name);
      await Storage.mkdir(name + '/src'); dirs.add(name + '/src');
      await writeNew(name + '/.project', proj);
      await writeNew(name + '/.classpath', cp);
      await writeNew(name + '/.settings/org.eclipse.jdt.core.prefs', prefs);
      if (module) await writeNew(name + '/src/module-info.java', `module ${name.replace(/[^\w]/g, '_')} {\n}\n`);
      ui.hiddenProjects = (ui.hiddenProjects || []).filter(p => p !== name);
      expanded.add('P:' + name);
      expanded.add('S:' + name + '/src');
      S.selected = 'P:' + name;
      renderExplorer(); updateWelcome();
      status(`プロジェクト '${name}' を作成しました`);
      requestBuild(name);
    } catch (e) { showError('プロジェクトを作成できません', e.message); }
  }
  async function writeNew(path, content) {
    await Storage.writeFile(path, content);
    files.set(path, content);
    let d = parentOf(path);
    while (d) { dirs.add(d); d = parentOf(d); }
  }

  // ---------- 新規 Java パッケージ ----------
  async function newPackageWizard() {
    const c = selectionContext();
    if (!c.project) { await dialog({ title: '新規 Java パッケージ', message: '先に Java プロジェクトを作成してください。\n(ファイル → 新規 → Java プロジェクト)', icon: 'info' }); return; }
    const initial = c.pkgDir ? pkgOfDir(c.pkgDir) : '';
    const r = await dialog({
      title: '新規 Java パッケージ', width: 520, help: true,
      banner: { title: 'Java パッケージ', message: '新規 Java パッケージを作成します。' },
      html: `<div class="hint" style="margin-bottom:8px">パッケージに対応するフォルダーを作成します。</div>
        <div class="row"><label>ソース・フォルダー(<u>D</u>):</label><input type="text" id="pk-src" value="${esc(srcRoot(c.project))}" readonly><button class="dlg-btn" disabled>参照(<u>O</u>)...</button></div>
        <div class="row"><label>名前(<u>M</u>):</label><input type="text" id="pk-name" value="${esc(initial)}" spellcheck="false"><span></span></div>
        <label class="chk"><input type="checkbox" disabled>package-info.java を作成(<u>C</u>)</label>`,
      buttons: [{ label: '完了(F)', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({ name: $('#pk-name', d).value.trim() }),
      onOpen: d => {
        const upd = () => {
          const n = $('#pk-name', d).value.trim();
          let msg = '', level = '';
          if (!n) { msg = 'パッケージ名が空です。'; level = 'error'; }
          else if (!n.split('.').every(validIdent)) { msg = `'${n}' は有効な Java 識別子ではありません。`; level = 'error'; }
          else if (dirs.has(srcRoot(c.project) + '/' + n.replace(/\./g, '/')) && (packagesOf(c.project).includes(srcRoot(c.project) + '/' + n.replace(/\./g, '/')))) { msg = 'パッケージはすでに存在します。'; level = 'error'; }
          else if (/[A-Z]/.test(n)) { msg = '規則により、パッケージ名は小文字で始まります。'; level = 'warning'; }
          $('#dlg-msg', d).innerHTML = msg ? (level === 'error' ? ICON_SVG.error : ICON_SVG.warning) + ' ' + esc(msg) : '新規 Java パッケージを作成します。';
          $('[data-b="0"]', d).disabled = level === 'error';
        };
        $('#pk-name', d).addEventListener('input', upd);
        upd();
      },
    });
    if (!r || r.value !== 'ok') return;
    const dir = srcRoot(c.project) + '/' + r.name.replace(/\./g, '/');
    try {
      await Storage.mkdir(dir);
      let x = dir; while (x) { dirs.add(x); x = parentOf(x); }
      expanded.add('P:' + c.project); expanded.add('S:' + srcRoot(c.project));
      S.selected = 'K:' + dir;
      renderExplorer();
      status(`パッケージ '${r.name}' を作成しました`);
    } catch (e) { showError('パッケージを作成できません', e.message); }
  }

  // ---------- 新規 Java クラス / インターフェース ----------
  async function newTypeWizard(kind) {
    const c = selectionContext();
    if (!c.project) { await dialog({ title: kind === 'class' ? '新規 Java クラス' : '新規 Java インターフェース', message: '先に Java プロジェクトを作成してください。\n(ファイル → 新規 → Java プロジェクト)', icon: 'info' }); return; }
    const isClass = kind === 'class';
    const pkg = c.pkgDir ? pkgOfDir(c.pkgDir) : '';
    const title = isClass ? '新規 Java クラス' : '新規 Java インターフェース';
    const r = await dialog({
      title, width: 600, help: true,
      banner: { title: isClass ? 'Java クラス' : 'Java インターフェース', message: isClass ? '新規 Java クラスを作成します。' : '新規インターフェースを作成します。' },
      html: `<div class="row"><label>ソース・フォルダー(<u>D</u>):</label><input type="text" value="${esc(srcRoot(c.project))}" readonly><button class="dlg-btn" disabled>参照(<u>O</u>)...</button></div>
        <div class="row"><label>パッケージ(<u>K</u>):</label><input type="text" id="nt-pkg" value="${esc(pkg)}" spellcheck="false"><button class="dlg-btn" id="nt-pkgbtn">参照(<u>W</u>)...</button></div>
        <div class="row"><label><input type="checkbox" disabled> エンクロージング型(<u>Y</u>):</label><input type="text" readonly><button class="dlg-btn" disabled>参照(<u>W</u>)...</button></div>
        <hr style="border:none;border-top:1px solid var(--border-light)">
        <div class="row"><label>名前(<u>M</u>):</label><input type="text" id="nt-name" spellcheck="false"><span></span></div>
        <div class="row"><label>修飾子:</label><div>
          <label><input type="radio" name="vis" value="public" checked> public(<u>P</u>)</label>&nbsp;
          <label><input type="radio" name="vis" value=""> パッケージ(<u>C</u>)</label>&nbsp;
          <label style="color:#999"><input type="radio" disabled> private(<u>V</u>)</label>&nbsp;
          <label style="color:#999"><input type="radio" disabled> protected(<u>T</u>)</label><br>
          ${isClass ? `<label><input type="checkbox" id="nt-abstract"> abstract(<u>T</u>)</label>&nbsp; <label><input type="checkbox" id="nt-final"> final(<u>L</u>)</label>&nbsp; <label style="color:#999"><input type="checkbox" disabled> static(<u>C</u>)</label>` : ''}
        </div><span></span></div>
        ${isClass ? `<div class="row"><label>スーパークラス(<u>S</u>):</label><input type="text" id="nt-super" value="java.lang.Object" spellcheck="false"><button class="dlg-btn" disabled>参照(<u>E</u>)...</button></div>` : ''}
        <div class="row"><label>${isClass ? 'インターフェース(<u>I</u>):' : '拡張インターフェース(<u>I</u>):'}</label><input type="text" id="nt-ifaces" placeholder="(カンマ区切りで入力)" spellcheck="false"><span></span></div>
        ${isClass ? `<div style="margin:8px 0 2px">どのメソッド・スタブを作成しますか?</div>
          <div style="padding-left:16px">
            <label class="chk"><input type="checkbox" id="nt-main">public static void main(String[] args)(<u>V</u>)</label>
            <label class="chk"><input type="checkbox" id="nt-ctors">スーパークラスからのコンストラクター(<u>U</u>)</label>
            <label class="chk"><input type="checkbox" id="nt-inherit" checked>継承された抽象メソッド(<u>H</u>)</label>
          </div>` : ''}
        <div style="margin:8px 0 2px">コメントを追加しますか? (テンプレートの構成およびデフォルト値については<span style="color:var(--link)">ここ</span>を参照)</div>
        <div style="padding-left:16px"><label class="chk"><input type="checkbox" id="nt-comment">コメントの生成(<u>G</u>)</label></div>`,
      buttons: [{ label: '完了(F)', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({
        pkg: $('#nt-pkg', d).value.trim(), name: $('#nt-name', d).value.trim(),
        vis: ($('input[name=vis]:checked', d) || {}).value,
        abstract: isClass && $('#nt-abstract', d).checked, final: isClass && $('#nt-final', d).checked,
        sup: isClass ? $('#nt-super', d).value.trim() : '', ifaces: $('#nt-ifaces', d).value.trim(),
        main: isClass && $('#nt-main', d).checked, ctors: isClass && $('#nt-ctors', d).checked,
        comment: $('#nt-comment', d).checked,
      }),
      onOpen: d => {
        const upd = () => {
          const p = $('#nt-pkg', d).value.trim(), n = $('#nt-name', d).value.trim();
          let msg = '', level = '';
          const path = srcRoot(c.project) + '/' + (p ? p.replace(/\./g, '/') + '/' : '') + n + '.java';
          if (p && !p.split('.').every(validIdent)) { msg = `'${p}' は有効な Java 識別子ではありません。`; level = 'error'; }
          else if (!n) { msg = '型名が空です。'; level = 'error'; }
          else if (!validIdent(n)) { msg = n.includes('.') ? '型名は修飾できません。' : `'${n}' は有効な Java 識別子ではありません。`; level = 'error'; }
          else if (files.has(path)) { msg = '型はすでに存在します。'; level = 'error'; }
          else if (!p) { msg = 'デフォルト・パッケージの使用は推奨されません。'; level = 'warning'; }
          else if (/^[a-z]/.test(n)) { msg = '規則により、Java 型名は大文字で始まります。'; level = 'warning'; }
          $('#dlg-msg', d).innerHTML = msg ? (level === 'error' ? ICON_SVG.error : ICON_SVG.warning) + ' ' + esc(msg) : (isClass ? '新規 Java クラスを作成します。' : '新規インターフェースを作成します。');
          $('[data-b="0"]', d).disabled = level === 'error';
        };
        $('#nt-pkg', d).addEventListener('input', upd);
        $('#nt-name', d).addEventListener('input', upd);
        $('#nt-pkgbtn', d).onclick = async () => {
          const pk = packagesOf(c.project).map(pkgOfDir);
          const sel = await pickFromList('パッケージの選択', 'パッケージを選択してください:', pk.length ? pk : ['(デフォルト・パッケージ)']);
          if (sel != null) { $('#nt-pkg', d).value = sel === '(デフォルト・パッケージ)' ? '' : sel; upd(); }
          setTimeout(() => $('#nt-name', d).focus(), 0);
        };
        upd();
        setTimeout(() => $('#nt-name', d).focus(), 0);
      },
    });
    if (!r || r.value !== 'ok') return;
    const ind = settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t';
    const mods = [r.vis, r.abstract ? 'abstract' : '', r.final ? 'final' : ''].filter(Boolean).join(' ');
    let header = '';
    if (r.pkg) header += `package ${r.pkg};\n\n`;
    let decl = (mods ? mods + ' ' : '') + (isClass ? 'class ' : 'interface ') + r.name;
    if (isClass && r.sup && r.sup !== 'java.lang.Object' && r.sup !== 'Object') decl += ' extends ' + r.sup.split('.').pop();
    if (r.ifaces) decl += (isClass ? ' implements ' : ' extends ') + r.ifaces.split(',').map(s => s.trim().split('.').pop()).filter(Boolean).join(', ');
    const imports = [];
    if (isClass && r.sup && r.sup.includes('.') && !r.sup.startsWith('java.lang.')) imports.push(r.sup);
    for (const i of (r.ifaces || '').split(',').map(s => s.trim())) if (i.includes('.') && !i.startsWith('java.lang.')) imports.push(i);
    if (imports.length) header += imports.map(i => `import ${i};`).join('\n') + '\n\n';
    let body = '';
    if (r.ctors && isClass) body += `\n${ind}public ${r.name}() {\n${ind}${ind}// TODO 自動生成されたコンストラクター・スタブ\n${ind}}\n`;
    if (r.main) body += `\n${ind}public static void main(String[] args) {\n${ind}${ind}// TODO 自動生成されたメソッド・スタブ\n\n${ind}}\n`;
    const comment = r.comment ? '/**\n * \n */\n' : '';
    const code = `${header}${comment}${decl} {\n${body}\n}\n`;
    const path = srcRoot(c.project) + '/' + (r.pkg ? r.pkg.replace(/\./g, '/') + '/' : '') + r.name + '.java';
    try {
      if (r.pkg) { const dir = parentOf(path); await Storage.mkdir(dir); let x = dir; while (x) { dirs.add(x); x = parentOf(x); } }
      await writeNew(path, code);
      fileChanged(path);
      revealInExplorer(path);
      const ed = openEditor(path);
      // カーソルを main の中 (または本体) に置く
      const lines = code.split('\n');
      const li = lines.findIndex(l => l.includes('TODO 自動生成されたメソッド・スタブ'));
      if (li >= 0) gotoPos(ed, li + 1, (ind + ind).length);
      else gotoPos(ed, lines.findIndex(l => l.includes('{')) + 1, ind.length);
    } catch (e) { showError('作成できません', e.message); }
  }


  Object.assign(IDE, { createProject, newPackageWizard, newProjectWizard, newTypeWizard, validIdent, writeNew });
})();
