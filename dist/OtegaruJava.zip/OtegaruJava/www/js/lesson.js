// レッスン・ビュー (Eclipse の「チート・シート」風)
// Qiita「【Java入門】」「【HTML入門】」シリーズ (chida0818) の本文を表示し、
// コードを「エディターに反映」したり、実行結果を教材と「比較」したり、HTML をブラウザーで開いたりできる。
'use strict';

const Lesson = (() => {
  const LS_SOURCE = 'otekaru.lesson.source';   // 'builtin' (内蔵) または 'qiita' (Qiita の最新)
  const LS_QCACHE = 'otekaru.qiitaCache.v2';   // Qiita から取得した本文 {id: {title, url, updated, body, fetchedAt}}
  const LS_COURSE = 'otekaru.lesson.course';   // 表示している教材 ('java' または 'html')
  const AUTHOR = 'chida0818';
  // 教材 (コース) ごとの目次の記事・内蔵の本文・表示中の章を覚える場所
  const COURSES = {
    java: { name: 'Java入門', indexId: '1f0f457d575d4a675c16', data: () => window.LESSONS || [], curKey: 'otekaru.lesson.currentId' },
    html: { name: 'HTML入門', indexId: '4efc23bf7222b2377b2d', data: () => window.LESSONS_HTML || [], curKey: 'otekaru.lesson.currentId.html' },
    db: { name: 'DB入門', indexId: 'd1fbd989a20e8eed1cbc', data: () => window.LESSONS_DB || [], curKey: 'otekaru.lesson.currentId.db' },
  };
  let course = 'java';
  const C = () => COURSES[course];
  const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent || '');
  const TTL = 30 * 60 * 1000;                  // Qiita の本文を取得し直すまでの時間 (30 分)
  let host = null;      // App 側の機能 { applyCode(path, code, opts), consoleText(), openExternal(url), notify(msg) }
  let builtin = [];     // 内蔵の教材 (lessons/lessons.js)
  let lessons = [];     // 今の表示元での章の一覧
  let source = 'builtin';
  let currentId = COURSES.java.indexId;
  let steps = [];       // 表示中の章のコードブロック情報
  const loading = new Map();   // 取得中の記事 id -> Promise
  const failed = new Map();    // 取得に失敗した記事 id -> 理由 (この画面を開いている間は自動では再取得しない)

  // お手軽Java 用の補足 (章の先頭に表示)
  const TIPS = {
    '1f0f457d575d4a675c16': 'この教材は Eclipse (Pleiades) を前提に書かれています。<b>お手軽Java</b> では、Eclipse と JDK のインストールは不要です。この画面の左がパッケージ・エクスプローラー、中央がエディター、下がコンソール/マーカーで、メニューやショートカットも Eclipse と同じように使えます。',
    '6b86112b31faf9091e22': 'お手軽Java では、Java のプログラムはブラウザの中で動きます (CheerpJ が JVM の役目をします)。コンパイラーには Eclipse と同じ ECJ を使っています。',
    'd9fe44e3fb2aab706c2c': '<b>お手軽Java では 2.1 のインストールは不要です (Windows・Mac とも)。</b> 2.2「Java プロジェクトを作る」から、この画面のメニュー <b>ファイル → 新規 → Java プロジェクト</b> で始めてください。書いたプログラムは、ドキュメント (Mac は書類) の <code>workspace</code> フォルダー (最初の起動で選んだワークスペース) に保存されます。',
    '37acc161b028d6a285a6': 'お手軽Java (ブラウザ版の Java) では、スタックトレースの行番号の代わりに <code>Unknown Source</code> と表示されることがあります。そのときは、お手軽Java が補った「→ メソッドの位置」のリンクで、例外が起きたメソッドを開けます。',
    '743cfd1b90cb36315ae5': 'お手軽Java のエラー・メッセージは、Eclipse (Pleiades) とできるだけ同じ日本語にしています。訳が無いものは英語のまま表示されます。',
    // HTML入門
    '4efc23bf7222b2377b2d': 'この教材は Eclipse (Pleiades) と Tomcat を前提に書かれています。<b>お手軽Java</b> では、どちらもインストールは不要です。動的 Web プロジェクトの作成、サーバー・ビューでの Tomcat11_Java25 の開始・停止、ポートの変更は、教材と同じ操作で行えます。作ったページは、教材と同じく Chrome で <code>http://localhost/html/…</code> を開いて確かめます。',
    '660b08bc2730550ddb0c': '<b>お手軽Java では、Eclipse と Tomcat のインストールは不要です (Windows・Mac とも)。</b> 「動的 Web プロジェクトを作る」から始めてください (この画面のメニュー <b>ファイル → 新規 → 動的 Web プロジェクト</b>、またはパッケージ・エクスプローラーのリンク)。下の <b>サーバー</b> タブには、教材で使う <b>Tomcat11_Java25</b> だけがあります。開始するときに Windows のセキュリティ警告は出ません。',
    '3becd42fc8725701f9a9': '画像は、教材と同じく、エクスプローラー (Mac は Finder) からパッケージ・エクスプローラーのフォルダーへドラッグ・アンド・ドロップして取り込めます。',
    // DB入門
    'd1fbd989a20e8eed1cbc': 'この教材は Oracle Database と SQL Developer を前提に書かれています。<b>お手軽Java の「DB入門」の画面</b> (右上の切り替え) では、どちらもインストールは不要です。データベースには、ブラウザの中で動く H2 を Oracle 互換モードで使います。SQL は教材と同じように書けて、エラーも Oracle と同じ <code>ORA-</code> の番号と文言で表示します (H2 の元のメッセージも見られます)。',
    '6ea9dd6339b6606e4f28': '<b>お手軽Java では、SQL Developer の起動と設定は不要です。</b> 日付は最初から <code>YYYY-MM-DD HH24:MI:SS</code> で表示します。2.2 の「データベース接続の作成/選択」は、左の「接続」パネルの緑の <b>＋</b> から、教材と同じ値で入力してください。system のパスワードは、何を入力しても接続できます。',
  };

  function init(h) {
    host = h;
    // 表示元の既定は Qiita の最新 (お手軽Java はネット接続が前提。取得できないときは内蔵の本文を出す)
    try { source = localStorage.getItem(LS_SOURCE) === 'builtin' ? 'builtin' : 'qiita'; } catch (e) { source = 'qiita'; }
    try { course = COURSES[localStorage.getItem(LS_COURSE)] ? localStorage.getItem(LS_COURSE) : 'java'; } catch (e) { course = 'java'; }
    loadCourse();
    render();
    // 新しく追加された章も一覧に出るよう、目次記事も読み込んでおく
    if (source === 'qiita' && currentId !== C().indexId) ensureFresh(C().indexId);
  }
  /** 今の教材 (コース) の内蔵の本文と、表示していた章を読み込む */
  function loadCourse() {
    builtin = C().data().slice();
    try { currentId = localStorage.getItem(C().curKey) || C().indexId; } catch (e) { currentId = C().indexId; }
    buildList();
  }
  /** 教材 (Java入門 / HTML入門) を切り替える。id を指定すると、その章を開く */
  function setCourse(c, id, anchor) {
    if (!COURSES[c]) return;
    if (c !== course) {
      pushHistory();
      course = c;
      try { localStorage.setItem(LS_COURSE, c); } catch (e) { /* 無視 */ }
      loadCourse();
    }
    if (id && lessons.some(x => x.id === id)) { currentId = id; saveCurrent(); }
    render(anchor);
    if (source === 'qiita') ensureFresh(C().indexId);
  }
  function saveCurrent() { try { localStorage.setItem(C().curKey, currentId); } catch (e) { /* 無視 */ } }

  // ------------------------------------------------------------
  // 表示元 (内蔵 / Qiita) と、章の一覧
  // ------------------------------------------------------------
  function loadCache() { try { return JSON.parse(localStorage.getItem(LS_QCACHE) || '{}'); } catch (e) { return {}; } }
  function saveCache(c) { try { localStorage.setItem(LS_QCACHE, JSON.stringify(c)); } catch (e) { /* 容量不足などは無視 */ } }
  const builtinById = id => builtin.find(x => x.id === id);

  /** 目次記事の本文から、章の一覧 [{id, title}] を作る (「[第1章 …](https://qiita.com/chida0818/items/…)」の行) */
  function chaptersFromIndex(body) {
    const out = [];
    const re = new RegExp('^\\[((?:第\\d+章|付録[A-Z])[^\\]]*)\\]\\(https://qiita\\.com/' + AUTHOR + '/items/([0-9a-f]+)[^)]*\\)', 'gm');
    let m;
    while ((m = re.exec(body || ''))) if (!out.some(x => x.id === m[2])) out.push({ id: m[2], title: m[1].trim() });
    return out;
  }

  function buildList() {
    if (source === 'builtin') { lessons = builtin.slice(); return; }
    const cache = loadCache();
    const indexId = C().indexId;
    const index = cache[indexId] || builtinById(indexId);
    const chapters = chaptersFromIndex(index && index.body);
    lessons = [{ id: indexId }].concat(chapters.length ? chapters : builtin.filter(x => x.id !== indexId)).map(c => {
      const q = cache[c.id], b = builtinById(c.id);
      return { id: c.id, title: (q && q.title) || c.title || (b && b.title) || c.id, url: (q && q.url) || (b && b.url) || `https://qiita.com/${AUTHOR}/items/${c.id}` };
    });
  }

  // ---- 教材の本文の補足 (Qiita の記事を直すまで、お手軽Java で足す。記事に同じ見出しができたら足さない) ----
  // DB入門 第3章: 3.7 で DROP したままだと第4章で必ず失敗するので、3.7 の最後で同じ SQL でもう一度作らせる
  const DB3_RECREATE = "\n\n### もう一度テーブルを作る\n\n上の `DROP TABLE` と `DROP SEQUENCE` を実行した場合は、テーブルとシーケンスが無くなっています。**このまま[第4章](https://qiita.com/chida0818/items/41e87360e6046d93c0bb)に進むと、データを登録するときにエラーになります。** 次の SQL（[3.2](#32-%E3%82%B7%E3%83%BC%E3%82%B1%E3%83%B3%E3%82%B9%E3%81%A8%E3%83%86%E3%83%BC%E3%83%96%E3%83%AB%E3%82%92%E4%BD%9C%E3%82%8B) と同じ SQL）を入力し、<kbd>F5</kbd>（スクリプトの実行）を押して、作り直してください。\n\n```sql:ワークシート（XE_DBAPP）\n-- 部署IDの番号を振るシーケンス\nCREATE SEQUENCE SEQ_DEPT NOCACHE;\n\n-- 社員IDの番号を振るシーケンス\nCREATE SEQUENCE SEQ_EMP NOCACHE;\n\n-- 部署テーブル\nCREATE TABLE DEPARTMENT (\n  DEPT_ID    NUMBER(4)  CONSTRAINT PK_DEPARTMENT PRIMARY KEY,\n  DEPT_NAME  VARCHAR2(20 CHAR)  NOT NULL\n);\n\n-- 社員テーブル\nCREATE TABLE EMPLOYEE (\n  EMP_ID      NUMBER(6)  CONSTRAINT PK_EMPLOYEE PRIMARY KEY,\n  NAME        VARCHAR2(20 CHAR)  NOT NULL,\n  GENDER      NUMBER(1)  NOT NULL\n    CONSTRAINT CK_EMPLOYEE_GENDER CHECK (GENDER IN (1, 2)),\n  AGE         NUMBER(3)  NOT NULL,\n  BIRTH_DATE  DATE       NOT NULL,\n  DEPT_ID     NUMBER(4)  NOT NULL\n    CONSTRAINT FK_EMPLOYEE_DEPARTMENT REFERENCES DEPARTMENT (DEPT_ID),\n  ADDRESS     VARCHAR2(10 CHAR)  NOT NULL\n);\n```\n\n「スクリプト出力」に、次の4行が表示されれば成功です。\n\n```text:スクリプト出力\nSequence SEQ_DEPTは作成されました。\n\nSequence SEQ_EMPは作成されました。\n\nTable DEPARTMENTは作成されました。\n\nTable EMPLOYEEは作成されました。\n```\n\n最後に、[3.3](#33-%E4%BD%9C%E6%88%90%E3%81%97%E3%81%9F%E3%83%86%E3%83%BC%E3%83%96%E3%83%AB%E3%82%92%E7%A2%BA%E8%AA%8D%E3%81%99%E3%82%8B) と同じ手順で、「接続」パネルの「表」に `DEPARTMENT` と `EMPLOYEE`、「順序」に `SEQ_DEPT` と `SEQ_EMP` が表示されることを確認します。表示されない場合は、「表」や「順序」を右クリックして **リフレッシュ** を選んでください。";
  const BODY_PATCHES = {
    'e6bb5ac4f35003cf12aa': body => {
      if (body.includes('### もう一度テーブルを作る') || !body.includes('## 3.8')) return body;
      return body.replace("消したら、[3.2](#32-%E3%82%B7%E3%83%BC%E3%82%B1%E3%83%B3%E3%82%B9%E3%81%A8%E3%83%86%E3%83%BC%E3%83%96%E3%83%AB%E3%82%92%E4%BD%9C%E3%82%8B) の SQL をもう一度実行します。シーケンスを作り直すので、番号も **1 から振り直されます**。この章では定義を間違えていなければ消す必要はありませんが、[第4章](https://qiita.com/chida0818/items/41e87360e6046d93c0bb#46-%E3%82%84%E3%82%8A%E7%9B%B4%E3%81%97%E3%81%9F%E3%81%84%E3%81%A8%E3%81%8D)でデータを登録し直したいときにも、この手順を使います。", "消したら、下の「[もう一度テーブルを作る](#もう一度テーブルを作る)」の手順で、[3.2](#32-%E3%82%B7%E3%83%BC%E3%82%B1%E3%83%B3%E3%82%B9%E3%81%A8%E3%83%86%E3%83%BC%E3%83%96%E3%83%AB%E3%82%92%E4%BD%9C%E3%82%8B) と同じ SQL をもう一度実行します。シーケンスを作り直すので、番号も **1 から振り直されます**。この章では定義を間違えていなければ消す必要はありませんが、[第4章](https://qiita.com/chida0818/items/41e87360e6046d93c0bb#46-%E3%82%84%E3%82%8A%E7%9B%B4%E3%81%97%E3%81%9F%E3%81%84%E3%81%A8%E3%81%8D)でデータを登録し直したいときにも、この手順を使います。").replace(/\n*(## 3\.8)/, () => DB3_RECREATE + '\n\n## 3.8');
    },
  };
  /** 本文に補足を足した教材 (補足が無ければそのまま) */
  function withPatches(c) {
    const f = c && BODY_PATCHES[c.id];
    return f ? Object.assign({}, c, { body: f(c.body || '') }) : c;
  }

  /** Qiita モードで表示する本文 (取得済みのもの、無ければ内蔵の本文) */
  function contentFor(id) {
    const q = loadCache()[id];
    if (q) return Object.assign({ from: 'qiita' }, q);
    const b = builtinById(id);
    return b ? Object.assign({ from: 'builtin-fallback' }, b) : null;
  }

  /** Qiita API から記事を取得してキャッシュする。失敗したら理由を返す */
  function fetchQiita(id) {
    if (loading.has(id)) return loading.get(id);
    const p = (async () => {
      try {
        const res = await fetch('https://qiita.com/api/v2/items/' + id, { cache: 'no-store' });
        if (!res.ok) {
          const remain = res.headers.get('Rate-Remaining');
          if ((res.status === 403 || res.status === 429) && remain === '0') {
            const reset = +res.headers.get('Rate-Reset');
            const at = reset ? new Date(reset * 1000).toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' }) : '';
            throw new Error('Qiita の取得回数の上限 (1 時間に 60 回) に達しました' + (at ? `。${at} ごろから再び取得できます` : ''));
          }
          throw new Error(res.status === 404 ? '記事が見つかりません (非公開か削除された可能性があります)' : 'HTTP ' + res.status);
        }
        const d = await res.json();
        const cache = loadCache();
        cache[id] = { id, title: d.title.replace(/【(Java|HTML|DB)入門】/, '').trim(), url: d.url, updated: d.updated_at, body: d.body, fetchedAt: Date.now() };
        saveCache(cache);
        failed.delete(id);
        return null;
      } catch (e) {
        const msg = e instanceof TypeError ? 'Qiita に接続できません (インターネット接続を確認してください)' : e.message;
        failed.set(id, msg);
        return msg;
      } finally {
        loading.delete(id);
      }
    })();
    loading.set(id, p);
    return p;
  }

  /** Qiita モードで、必要なら取得してから描き直す */
  async function ensureFresh(id, force) {
    const q = loadCache()[id];
    const fresh = q && Date.now() - (q.fetchedAt || 0) < TTL;
    if (!force && (fresh || failed.has(id))) return;
    const err = await fetchQiita(id);
    if (source !== 'qiita') return;
    // 目次を読み込んだら章の一覧を作り直す (章の選択欄も描き直す)
    if (id === C().indexId) buildList();
    if (id === currentId || id === C().indexId) render(null, true);
    if (force) host.notify(err ? '取得できませんでした: ' + err : 'Qiita から最新の本文を読み込みました');
  }

  function setSource(s) {
    source = s === 'qiita' ? 'qiita' : 'builtin';
    try { localStorage.setItem(LS_SOURCE, source); } catch (e) { /* 無視 */ }
    buildList();
    if (!lessons.some(x => x.id === currentId)) currentId = C().indexId;
    render();
    if (source === 'qiita') ensureFresh(C().indexId);
  }

  function fmtDate(iso) { return iso ? iso.slice(0, 10).replace(/-/g, '/') : ''; }

  function render(anchor, keepScroll) {
    const el = document.getElementById('lesson');
    let idx = lessons.findIndex(x => x.id === currentId);
    if (idx < 0) { idx = 0; currentId = lessons[0] ? lessons[0].id : C().indexId; }
    const item = lessons[idx];
    if (!item) { el.innerHTML = '<div class="ol-empty">レッスンがありません</div>'; return; }
    const content = withPatches(source === 'qiita' ? contentFor(item.id) : builtinById(item.id));
    const opts = lessons.map(x => `<option value="${esc(x.id)}" ${x.id === currentId ? 'selected' : ''}>${esc(x.title)}</option>`).join('');
    // 表示元の状態
    let badge = '', badgeCls = '';
    if (source === 'builtin') {
      badge = `内蔵の教材 (${fmtDate(content && content.updated)} 時点)`;
    } else if (loading.has(item.id)) {
      badge = 'Qiita から読み込み中…'; badgeCls = 'busy';
    } else if (failed.has(item.id)) {
      badge = (content && content.from === 'qiita' ? `前回取得した本文 (${fmtDate(content.updated)} 更新)` : '内蔵の本文') + ' を表示中: ' + failed.get(item.id);
      badgeCls = 'warn';
    } else if (content && content.from === 'qiita') {
      badge = `Qiita の最新 (${fmtDate(content.updated)} 更新)`; badgeCls = 'ok';
    } else {
      badge = 'Qiita から読み込み中…'; badgeCls = 'busy';
    }
    const scroll = typeof keepScroll === 'number' ? keepScroll : (keepScroll ? el.scrollTop : 0);
    const prev = lessons[idx - 1], next = lessons[idx + 1];
    const back = backStack[backStack.length - 1];
    const backItem = back && lessons.find(x => x.id === back.id);
    el.innerHTML = `
      <div class="lesson-head">
        <button class="lbtn" id="ls-back" ${backItem ? `title="戻る (${esc(backItem.title)})"` : 'title="戻る" disabled'}>戻る</button>
        <a href="#" class="ls-chap${prev ? '' : ' disabled'}" id="ls-prev" ${prev ? `title="前の章: ${esc(prev.title)}"` : 'aria-disabled="true" tabindex="-1"'}>&lt;&lt;</a>
        <select id="ls-select">${opts}</select>
        <a href="#" class="ls-chap${next ? '' : ' disabled'}" id="ls-next" ${next ? `title="次の章: ${esc(next.title)}"` : 'aria-disabled="true" tabindex="-1"'}>&gt;&gt;</a>
        <a class="lbtn" href="${esc(item.url)}" target="_blank" rel="noopener" title="Qiita で開く">Qiita</a>
        <div class="ls-source-row">
          <select id="ls-course" title="教材">${Object.entries(COURSES).map(([k, v]) => `<option value="${k}" ${k === course ? 'selected' : ''}>${v.name}</option>`).join('')}</select>
          <select id="ls-source" title="レッスンに表示する本文">
            <option value="builtin" ${source === 'builtin' ? 'selected' : ''}>内蔵の教材</option>
            <option value="qiita" ${source === 'qiita' ? 'selected' : ''}>Qiita の最新</option>
          </select>
          <span class="ls-badge ${badgeCls}" title="${esc(badge)}">${esc(badge)}</span>
          ${source === 'qiita' ? '<button class="lbtn" id="ls-refresh" title="Qiita から本文を読み込み直す">再読み込み</button>' : ''}
        </div>
      </div>
      <div class="lesson-body${source === 'qiita' ? ' qiita-style' : ''}" id="ls-body"></div>`;
    el.querySelector('#ls-select').onchange = e => goId(e.target.value);
    el.querySelector('#ls-prev').onclick = e => { e.preventDefault(); if (prev) go(idx - 1); };
    el.querySelector('#ls-next').onclick = e => { e.preventDefault(); if (next) go(idx + 1); };
    el.querySelector('#ls-back').onclick = goBack;
    el.querySelector('#ls-source').onchange = e => setSource(e.target.value);
    el.querySelector('#ls-course').onchange = e => setCourse(e.target.value);
    const rb = el.querySelector('#ls-refresh');
    if (rb) rb.onclick = () => { failed.delete(item.id); render(null, true); ensureFresh(item.id, true); };
    const body = el.querySelector('#ls-body');
    if (content) {
      body.innerHTML = renderMarkdown(Object.assign({}, content, { title: content.title || item.title }));
      wire(body);
    } else {
      body.innerHTML = `<h1>${esc(item.title)}</h1><p>Qiita から本文を読み込んでいます…</p>`;
      wire(body);
    }
    if (anchor) {
      const t = body.querySelector('[id="' + CSS.escape(anchor) + '"]');
      if (t) { t.scrollIntoView(); }
    } else el.scrollTop = scroll;
    // Qiita モードでは、古くなっていれば裏で取得し直す
    if (source === 'qiita') ensureFresh(item.id);
  }

  // ------------------------------------------------------------
  // 移動の履歴 (「戻る」で、移動する前の章とスクロール位置に戻る)
  // ------------------------------------------------------------
  const backStack = [];
  function pushHistory() {
    const el = document.getElementById('lesson');
    backStack.push({ course, id: currentId, scroll: el ? el.scrollTop : 0 });
    if (backStack.length > 50) backStack.shift();
  }
  function goBack() {
    while (backStack.length) {
      const h = backStack.pop();
      if (h.course !== course) {
        course = h.course;
        try { localStorage.setItem(LS_COURSE, course); } catch (e) { /* 無視 */ }
        loadCourse();
      }
      if (!lessons.some(x => x.id === h.id)) continue;
      currentId = h.id;
      saveCurrent();
      render(null, h.scroll);
      return;
    }
  }

  function goId(id, anchor) {
    if (!lessons.some(x => x.id === id)) return;
    if (id !== currentId || anchor) pushHistory();
    currentId = id;
    saveCurrent();
    render(anchor);
  }
  function go(i, anchor) {
    if (i < 0 || i >= lessons.length) return;
    goId(lessons[i].id, anchor);
  }

  // ------------------------------------------------------------
  // Markdown (Qiita 記法) の表示
  // ------------------------------------------------------------
  function slug(text) {
    return text.trim().toLowerCase().replace(/<[^>]+>/g, '').replace(/[^\p{L}\p{N}\s\-_]/gu, '').replace(/\s/g, '-');
  }

  function renderMarkdown(l) {
    steps = buildSteps(l.body);
    let stepIdx = 0;
    const renderer = new marked.Renderer();
    renderer.code = function (code, info) {
      if (typeof code === 'object') { info = code.lang; code = code.text; }
      const s = steps[stepIdx++] || { lang: '', label: '', code };
      return codeBlockHtml(s, stepIdx - 1);
    };
    renderer.heading = function (text, level, raw) {
      if (typeof text === 'object') { level = text.depth; raw = text.text; text = this.parser ? this.parser.parseInline(text.tokens) : text.text; }
      return `<h${level} id="${esc(slug(raw || text))}">${text}</h${level}>`;
    };
    renderer.image = function (href, title, text) {
      if (typeof href === 'object') { title = href.title; text = href.text; href = href.href; }
      return `<img src="${esc(href)}" alt="${esc(text || '')}" loading="lazy"${title ? ` title="${esc(title)}"` : ''}>`;
    };
    const md = (src) => marked.parse(src, { renderer, gfm: true, breaks: false, mangle: false, headerIds: false });
    // :::note ブロックを分けて描く
    const parts = [];
    const lines = l.body.split('\n');
    let buf = [], noteBuf = null, noteKind = '';
    const flush = () => { if (buf.length) { parts.push(md(buf.join('\n'))); buf = []; } };
    for (const ln of lines) {
      const m = ln.match(/^:::note\s*(\w*)/);
      if (m && !noteBuf) { flush(); noteBuf = []; noteKind = m[1] || 'info'; continue; }
      if (noteBuf && /^:::\s*$/.test(ln)) { parts.push(`<div class="note ${esc(noteKind)}"><span class="note-icon" aria-hidden="true"></span><div class="note-body">${md(noteBuf.join('\n'))}</div></div>`); noteBuf = null; continue; }
      (noteBuf || buf).push(ln);
    }
    if (noteBuf) buf.push(...noteBuf);
    flush();
    const tip = TIPS[l.id] ? `<div class="otekaru-tip"><b>お手軽Java メモ</b>　${TIPS[l.id]}</div>` : '';
    return `<h1>${esc(l.title)}</h1>${tip}${parts.join('')}`;
  }

  /** 本文のコードブロックを順番に集め、各時点のファイル全体を復元する */
  function buildSteps(body) {
    const lines = body.split('\n');
    const out = [];
    const state = {};
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(/^( *)```(.*)$/);
      if (!m || !m[2].trim()) continue;
      const ind = m[1].length;
      const buf = [];
      let j = i + 1;
      while (j < lines.length && !/^ *```\s*$/.test(lines[j])) {
        const s = lines[j];
        buf.push(s.slice(0, ind).trim() === '' ? s.slice(ind) : s.trimStart());
        j++;
      }
      i = j;
      const info = m[2].trim();
      const k = info.indexOf(':');
      const lang = k >= 0 ? info.slice(0, k) : info;
      const label = k >= 0 ? info.slice(k + 1) : '';
      const code = buf.join('\n').replace(/\s+$/, '') + '\n';
      const s = { lang, label, code };
      const fm = label.match(/^(ch\d\d\/[\w/]+\.java)(.*)$/);
      const wm = label.match(/^(ch\d\d\/[\w/.-]+\.(?:html|css))(.*)$/);
      if ((lang === 'html' || lang === 'css') && wm) {
        s.file = wm[1];
        s.web = true;
        s.note = wm[2].trim();
        const cl = code.replace(/\n$/, '').split('\n');
        const complete = lang === 'html' ? /^<!DOCTYPE/i.test(cl[0]) && /^<\/html>\s*$/i.test(cl[cl.length - 1]) : /^@charset/.test(cl[0]);
        s.partial = !complete;
        const prev = state[s.file];
        // 部分のコードの s.full は表示 (緑の行) のためのもの。「エディターに反映」は、今のファイルに差し込む
        s.full = s.partial ? (prev ? mergeWeb(prev, code, s.note) : null) : code;
        s.added = addedLines(prev, code, s.partial);
        if (s.full) state[s.file] = s.full;
      } else if (lang === 'java' && fm) {
        s.file = fm[1];
        s.note = fm[2].trim();
        const cl = code.replace(/\n$/, '').split('\n');
        const complete = /^package /.test(cl[0]) && cl[cl.length - 1] === '}';
        s.partial = (!!s.note && !s.note.includes('作成直後')) || !complete;
        const prev = state[s.file];
        if (s.partial) s.full = prev ? merge(prev, code, s.note) : null;
        else s.full = code;
        s.added = addedLines(prev, code, s.partial);
        if (s.full) state[s.file] = s.full;
      } else if (lang === 'text' && /^コンソール/.test(label)) {
        s.console = true;
        s.note = label.replace(/^コンソール/, '').replace(/[（）()]/g, '').trim();
      } else if (lang === 'sql' && /ワークシート[（(](\w+)[）)]/.test(label)) {
        // DB入門: どの接続のワークシートで実行するか。後ろに結果の表があれば、比べられるようにする
        s.sql = true;
        s.conn = label.match(/ワークシート[（(](\w+)[）)]/)[1];
        s.expect = tableAfter(lines, j + 1);
      } else if (lang === 'text' && /^スクリプト出力/.test(label)) {
        s.dbout = true;
      }
      out.push(s);
    }
    return out;
  }

  /** コードブロックの後ろ (次のコードブロックか見出しまで) にある、最初の表 {cols, rows} */
  function tableAfter(lines, from) {
    const cells = s => s.trim().replace(/^\|\s*|\s*\|$/g, '').split(/\s*\|\s*/).map(x => x.replace(/<\/?strong>|\*\*/g, '').trim());
    for (let k = from; k < lines.length; k++) {
      const l = lines[k];
      if (/^ *```/.test(l) || /^#{1,4} /.test(l)) return null;
      if (/^\s*\|/.test(l) && /^\s*\|\s*:?-{3}/.test(lines[k + 1] || '')) {
        const t = { cols: cells(l), rows: [] };
        for (let r = k + 2; r < lines.length && /^\s*\|/.test(lines[r]); r++) t.rows.push(cells(lines[r]));
        return t;
      }
    }
    return null;
  }

  /** 前の全体コードに部分コードを差し込む (tools 側の抽出スクリプトと同じ考え方) */
  function merge(base, part, note) {
    const r = merge0(base, part, note);
    return r ? addMissingImports(r) : r;
  }

  /** 部分コードで新しく使ったクラスの import を補う (教材では補完で自動的に入るもの) */
  function addMissingImports(src) {
    try {
      const info = Assist.organizeImports(src);
      if (!info.need.length) return src;
      const keepAll = Object.assign({}, info, { keep: info.parsed.imports.filter(i => !i.static).map(i => i.name) });
      return Assist.applyImports(src, keepAll, []);
    } catch (e) { return src; }
  }

  /** HTML・CSS の部分のコードを差し込む。1 行だけの書き換え (「form の行」など) は、似た行と置き換える */
  function mergeWeb(base, part, note) {
    const P = part.replace(/\n$/, '').split('\n');
    // 「…」をはさんだ部分は、前と後ろを別々に差し込む (第9章の checked と selected など)
    if (P.some(x => /^\s*…/.test(x))) {
      let r = base;
      for (const seg of P.join('\n').split(/^\s*….*$/m)) {
        if (!seg.trim()) continue;
        r = mergeWeb(r, seg.replace(/^\n+/, '') + '\n', note);
        if (r == null) return null;
      }
      return r;
    }
    const r = insertAddedBlock(base, part) || merge0(base, part, note) || replaceSimilarLine(base, part, note);
    if (r) return r;
    // 説明のために抜き出しただけの部分 (すでにファイルにある) なら、そのまま
    const lines = P.map(x => x.trim()).filter(Boolean);
    return lines.length && lines.every(x => base.includes(x)) ? base : null;
  }
  /**
   * 書き足すブロック (第9章の「追加する行」の <tr>〜</tr> など) なら、同じ形の最後のブロックの後ろに入れる。
   * 中身の行 (タグだけの行を除く) が 1 つもファイルに無く、同じ形のブロックがすでに中身を持っているときを、書き足しとみなす
   */
  function insertAddedBlock(base, part) {
    const t = x => x.trim();
    const P = part.replace(/\n$/, '').split('\n');
    while (P.length && !t(P[0])) P.shift();
    if (P.length < 3) return null;
    const B = base.replace(/\n$/, '').split('\n');
    const first = t(P[0]), last = t(P[P.length - 1]);
    const inner = P.slice(1, -1).map(t).filter(x => x && !/^<\/?[\w-]+>$/.test(x));
    if (!inner.length || inner.some(x => B.some(b => t(b) === x))) return null;   // 一部がすでにある → 書き換え
    let z = -1;
    for (let i = B.length - 1; i >= 0; i--) if (t(B[i]) === last) { z = i; break; }
    let a = -1;
    for (let i = z - 1; i >= 0; i--) if (t(B[i]) === first) { a = i; break; }
    if (z < 0 || a < 0 || !B.slice(a + 1, z).some(x => t(x))) return null;   // 空の枠 → 中身を入れる (書き換え)
    return B.slice(0, z + 1).concat(P, B.slice(z + 1)).join('\n') + '\n';
  }
  /**
   * 1 行だけの部分のコードを、元の似た行 (同じタグで始まる行) と置き換える。
   * 候補が複数あるときは、説明 (「住所の行」など) の言葉が近くに書かれている行を選ぶ。決められなければ null
   */
  function replaceSimilarLine(base, part, note) {
    const lines = part.split('\n').filter(x => x.trim());
    if (lines.length !== 1) return null;
    const t = lines[0].trim();
    const B = base.replace(/\n$/, '').split('\n');
    if (B.some(x => x.trim() === t)) return base;   // すでに同じ行がある
    const key = (t.match(/^<\/?[\w-]+/) || [t.split(/\s+/)[0]])[0];
    const cands = B.map((x, i) => i).filter(i => B[i].trim().startsWith(key));
    if (!cands.length) return null;
    const words = (note || '').replace(/[（）()]/g, '').replace(/の(行|部分)$/, '').split(/[、・\s]+/).filter(Boolean);
    // 前後が同じ文字の長さ (似ているほど長い)
    const same = (a, b) => { let i = 0; while (i < a.length && a[i] === b[i]) i++; let j = 0; while (j < a.length - i && j < b.length - i && a[a.length - 1 - j] === b[b.length - 1 - j]) j++; return i + j; };
    const scored = cands.map(i => {
      const near = B.slice(Math.max(0, i - 2), i + 3).join('\n');
      return { i, kw: words.filter(w => near.includes(w)).length, sim: same(B[i].trim(), t) };
    }).sort((a, b) => b.kw - a.kw || b.sim - a.sim);
    if (scored.length > 1 && scored[0].kw === scored[1].kw && scored[0].sim === scored[1].sim) return null;
    const i = scored[0].i;
    B[i] = B[i].match(/^\s*/)[0] + t;
    return B.join('\n') + '\n';
  }

  function merge0(base, part, note) {
    const B = base.replace(/\n$/, '').split('\n');
    const P = part.replace(/\n$/, '').split('\n');
    // 「…（これまでの getter と setter）…」のような省略があるときは、前と後ろに分けて差し込む
    const ell = P.findIndex(x => /^\s*…/.test(x));
    if (ell >= 0) {
      const head = P.slice(0, ell), tail = P.slice(ell + 1);
      while (head.length && !head[head.length - 1].trim()) head.pop();
      while (tail.length && !tail[0].trim()) tail.shift();
      let r = head.length ? merge0(base, head.join('\n') + '\n', '') : base;
      if (r && tail.length) r = merge0(r, tail.join('\n') + '\n', '');
      return r;
    }
    while (P.length && !P[0].trim()) P.shift();
    const t = s => s.trim();
    const runFwd = i => { let n = 0; while (i + n < B.length && n < P.length && t(B[i + n]) === t(P[n])) n++; return n; };
    const cands = [];
    for (let i = 0; i < B.length; i++) if (t(B[i]) && t(B[i]) === t(P[0])) cands.push(i);
    if (!cands.length) {
      let lastClose = -1;
      for (let i = 0; i < B.length; i++) if (B[i] === '}') lastClose = i;
      if (lastClose < 0) return null;
      if (P[P.length - 1] === '}') {
        const head = B.slice(0, lastClose);
        while (head.length && !head[head.length - 1].trim()) head.pop();
        return head.concat([''], P).join('\n') + '\n';
      }
      if (/main/.test(note || '')) {
        let mclose = -1;
        for (let i = 0; i < lastClose; i++) if (B[i] === '    }') mclose = i;
        if (mclose < 0) return null;
        let add = P.map(p => p.trim() ? '        ' + p.trim() : '');
        if (B[mclose - 1].trim() && P[0].startsWith(' ')) add = [''].concat(add);
        return B.slice(0, mclose).concat(add, B.slice(mclose)).join('\n') + '\n';
      }
      return null;
    }
    let a = cands[0], best = -1;
    // 同じ長さで一致する候補が複数あるとき、「最後」「後半」の部分コードなら後ろ側を選ぶ
    const preferLast = /最後|後半/.test(note || '');
    for (const i of cands) { const r = runFwd(i); if (r > best || (r === best && preferLast)) { best = r; a = i; } }
    const last = P[P.length - 1];
    const runBwd = j => { let n = 0; while (j - n >= a && n < P.length && t(B[j - n]) === t(P[P.length - 1 - n])) n++; return n; };
    let z = -1, bestR = -1;
    // 閉じ括弧などはインデントまで同じ行を優先する (別の } に当てないため)
    for (const exact of [true, false]) {
      for (let j = a; j < B.length; j++) {
        if (exact ? B[j] !== last : t(B[j]) !== t(last)) continue;
        const r = runBwd(j);
        if (r > bestR || (r === bestR && last === '}')) { bestR = r; z = j; }
      }
      if (z >= 0) break;
    }
    if (z < 0) {
      // 末尾が新しく足した行のとき: 部分コードの中で、元にもある最後の行までを置き換える
      for (let k = P.length - 2; k > 0 && z < 0; k--) {
        if (!t(P[k])) continue;
        for (let j = B.length - 1; j >= a; j--) if (t(B[j]) === t(P[k])) { z = j; break; }
      }
    }
    if (z < 0) return null;
    return B.slice(0, a).concat(P, B.slice(z + 1)).join('\n') + '\n';
  }

  /** 前の版と比べて「足した行」(教材の緑の行) の番号を返す */
  function addedLines(prev, code, partial) {
    const C = code.replace(/\n$/, '').split('\n');
    if (!prev) return [];
    const Pv = prev.replace(/\n$/, '').split('\n');
    // LCS で差分を取る
    const n = Pv.length, m = C.length;
    const dp = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) dp[i][j] = Pv[i].trim() === C[j].trim() ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    const added = [];
    let i = 0, j = 0;
    while (j < m) {
      if (i < n && Pv[i].trim() === C[j].trim()) { i++; j++; }
      else if (i < n && dp[i + 1][j] >= dp[i][j + 1]) i++;
      else { if (C[j].trim()) added.push(j); j++; }
    }
    // 全部が新しい (新規ファイル) ときは色を付けない
    return added.length >= C.filter(x => x.trim()).length ? [] : added;
  }

  function highlight(code, lang, added) {
    const lines = code.replace(/\n$/, '').split('\n');
    const addSet = new Set(added || []);
    const mode = { java: 'text/x-java', html: 'htmlmixed', css: 'css', sql: 'text/x-plsql' }[lang] || null;
    return lines.map((ln, i) => {
      let html = '';
      if (mode && CodeMirror.runMode) {
        const parts = [];
        CodeMirror.runMode(ln, mode, (text, style) => {
          parts.push(style ? `<span class="cm-${style.replace(/ +/g, ' cm-')}">${esc(text)}</span>` : esc(text));
        });
        html = parts.join('');
      } else html = esc(ln);
      return addSet.has(i) ? `<span class="hl-add">${html || ' '}</span>` : html;
    }).join('\n');
  }

  function codeBlockHtml(s, idx) {
    const isConsole = !!s.console;
    // Qiita の見た目では、ファイル名などの指定がないコードにラベルを出さない
    let label = s.label || (source === 'qiita' ? '' : (s.lang === 'java' ? 'Java' : ''));
    let btns = `<button class="lbtn" data-act="copy" data-i="${idx}" title="クリップボードにコピー">コピー</button>`;
    if (s.file) {
      btns += ` <button class="lbtn primary" data-act="apply" data-i="${idx}" title="${s.full ? 'この時点のコード全体をエディターに入れる' : 'このコードを、今のファイルの同じ場所に差し込む'}" ${s.full || (s.web && s.partial) ? '' : 'disabled'}>エディターに反映</button>`;
      if (s.web) btns += ` <button class="lbtn" data-act="browse" data-i="${idx}" title="${/\.css$/.test(s.file) ? '保存してから、この CSS を読み込んでいるページを' : '保存してから、このページを'} Chrome の別のタブで開く (サーバーで実行)">ブラウザで開く</button>`;
      if (s.partial) label += '　(部分)';
    }
    if (isConsole) {
      btns = `<button class="lbtn primary" data-act="compare" data-i="${idx}" title="コンソールの表示と比べる">実行結果と比較</button>`;
    }
    if (s.sql) {
      btns += ` <button class="lbtn primary" data-act="applysql" data-i="${idx}" title="${esc(s.conn)} のワークシートを開いて、この SQL に置き換える">ワークシートに反映</button>`;
      if (s.expect) btns += ` <button class="lbtn" data-act="dbcompare" data-i="${idx}" title="最後に実行した SELECT の結果と、教材の表を比べる">実行結果と比較</button>`;
    }
    if (s.dbout) btns = `<button class="lbtn primary" data-act="dboutcompare" data-i="${idx}" title="スクリプト出力と比べる">実行結果と比較</button>`;
    const added = s.added && s.added.length && !s.partial ? s.added : (s.partial && s.added ? partialAdded(s) : []);
    return `<div class="code-block ${isConsole ? 'console' : ''}" data-i="${idx}">
      <div class="cb-head"><span class="cb-label">${esc(label)}</span>${btns}</div>
      <pre class="cm-s-default"><code>${highlight(s.code, s.lang, added)}</code></pre>
      <div class="cb-result" hidden></div></div>`;
  }
  function partialAdded(s) {
    // 部分コードは、前の全体に無かった行を緑にする
    if (!s.full) return [];
    return s.added || [];
  }

  function wire(body) {
    body.addEventListener('click', async (e) => {
      const a = e.target.closest('a');
      if (a && a.href) {
        const m = a.href.match(/qiita\.com\/chida0818\/items\/([0-9a-f]+)(?:#(.*))?/);
        const i = m ? lessons.findIndex(x => x.id === m[1]) : -1;
        e.preventDefault();
        if (i >= 0) { go(i, m[2] ? decodeURIComponent(m[2]) : null); return; }
        const other = m && Object.keys(COURSES).find(k => k !== course && courseHas(k, m[1]));
        if (other) { setCourse(other, m[1], m[2] ? decodeURIComponent(m[2]) : null); return; }
        if (a.getAttribute('href').startsWith('#')) {
          const t = body.querySelector('[id="' + CSS.escape(decodeURIComponent(a.getAttribute('href').slice(1))) + '"]');
          if (t) {
            pushHistory();
            const bb = document.getElementById('ls-back');
            if (bb) { bb.disabled = false; bb.title = '戻る (この章の前の位置)'; }
            t.scrollIntoView();
          }
          return;
        }
        host.openExternal(a.href);
        return;
      }
      const b = e.target.closest('button[data-act]');
      if (!b) return;
      const s = steps[+b.dataset.i];
      const resEl = b.closest('.code-block').querySelector('.cb-result');
      if (b.dataset.act === 'copy') {
        try { await navigator.clipboard.writeText(s.code); host.notify('コピーしました'); } catch (err) { host.notify('コピーできませんでした'); }
      } else if (b.dataset.act === 'apply') {
        // 教材の中に元になる全体が無い部分のコード (前の章からコピーしたファイル) は、今のファイルに差し込む
        // HTML・CSS の部分のコードは、教材の前の手順ではなく今のファイルに差し込む (書き戻しなどの手作業を生かすため)。
        // Java で元になる全体が無い部分のコードも同じ
        const live = s.web && s.partial;
        await host.applyCode(s.file, live ? null : s.full, s.web ? 'web' : 'java', live || !s.full ? { code: s.code, note: s.note } : null);
      } else if (b.dataset.act === 'browse') {
        // CSS は、同じ章でこの CSS を読み込むページ (教材に出てくる順) を開く
        await host.openInBrowser(s.file, steps.filter(x => x.web && /\.html$/.test(x.file)).map(x => x.file));
      } else if (b.dataset.act === 'compare' || b.dataset.act === 'dbcompare' || b.dataset.act === 'dboutcompare') {
        const r = b.dataset.act === 'compare' ? compare(host.consoleText(), s.code, s.note)
          : b.dataset.act === 'dbcompare' ? compareTable(host.lastQuery(), s.expect, s.code) : compareScript(host.scriptText(), s.code);
        resEl.hidden = false;
        resEl.className = 'cb-result ' + (r.ok ? 'ok' : 'ng');
        resEl.innerHTML = r.html;
      } else if (b.dataset.act === 'applysql') {
        if (document.body.dataset.perspective !== 'db') host.showDb();
        await host.applySql(s.conn, s.code);
      }
    });
  }

  /** コンソールの表示と、教材の表示を比べる */
  function compare(actual, expected, note) {
    const norm = s => s.replace(/\r/g, '').split('\n').map(x => x.replace(/\s+$/, '')).join('\n').replace(/\n+$/, '');
    const a = norm(actual || ''), e = norm(expected || '');
    if (!a) return { ok: false, html: 'コンソールに表示がありません。先にプログラムを実行してください (' + (IS_MAC ? '<kbd>⌘F11</kbd>' : '<kbd>Ctrl</kbd>+<kbd>F11</kbd>') + ')。' };
    const suffix = /後半|最後/.test(note || '');
    const random = /変わります/.test(note || '');
    const toRe = s => new RegExp('^' + s.split(/\d+/).map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('\\d+') + '$');
    let ok;
    // スタックトレースの Java 標準ライブラリ内の行は、JDK によって行数が違うので比べない
    const jdkFrame = /^\s+at (java\.base\/|java\.|jdk\.|sun\.)/;
    const aLines = a.split('\n').filter(x => !jdkFrame.test(x)), eLines = e.split('\n').filter(x => !jdkFrame.test(x));
    // オブジェクトのハッシュ値 (Employee@6d06d69c) は実行するたびに変わる
    const hashRe = /@[0-9a-f]{3,8}\b/g;
    const lineEq = (x, y) => (random ? toRe(y).test(x) : x === y) || (/@[0-9a-f]{3,8}\b/.test(y) && x.replace(hashRe, '@*') === y.replace(hashRe, '@*'));
    // 例外のスタックトレースは行番号の違い (Unknown Source) を許す
    const dateRe = /\d{1,2}:\d{2}:\d{2}|\d{4}[-/]\d{1,2}[-/]\d{1,2}/;
    const loose = (x, y) => lineEq(x, y)
      // スタックトレースの行番号 (ブラウザ版では Unknown Source になる)
      || (/^\s+at /.test(y) && x.replace(/\(.*\)/, '') === y.replace(/\(.*\)/, ''))
      // 例外の説明文 (ブラウザ版では付かないことがある)
      || (/^Exception in thread/.test(y) && x === y.split(': ').slice(0, 1).join(''))
      || (/^Exception in thread/.test(y) && y.startsWith(x + ':'))
      // 実行するたびに変わる日時
      || (dateRe.test(y) && dateRe.test(x) && x.split(/[：:]/)[0] === y.split(/[：:]/)[0]);
    const suffixOk = aLines.length >= eLines.length && eLines.every((y, k) => loose(aLines[aLines.length - eLines.length + k], y));
    ok = suffix ? suffixOk : (aLines.length === eLines.length && eLines.every((y, k) => loose(aLines[k], y)));
    if (ok) return { ok: true, html: '✔ 教材と同じ表示になりました。' };
    // 教材が表示の最後の部分だけを載せている場合
    if (!suffix && suffixOk) return { ok: true, html: '✔ 教材と同じ表示になりました (教材には表示の最後の部分が載っています)。' };
    // 違う行を示す
    const rows = [];
    const off = suffix ? Math.max(0, aLines.length - eLines.length) : 0;
    const max = Math.max(eLines.length, (suffix ? eLines.length : aLines.length));
    for (let k = 0; k < max; k++) {
      const y = eLines[k], x = aLines[k + off];
      if (y !== undefined && x !== undefined && loose(x, y)) rows.push('  ' + esc(x));
      else {
        if (y !== undefined) rows.push(`<span class="diff-add">＋${esc(y)}</span>  ← 教材`);
        if (x !== undefined) rows.push(`<span class="diff-del">－${esc(x)}</span>  ← あなた`);
      }
    }
    return { ok: false, html: '✖ 教材と違うところがあります。保存 (' + (IS_MAC ? '<kbd>⌘S</kbd>' : '<kbd>Ctrl</kbd>+<kbd>S</kbd>') + ') してから実行したか、打ち間違いがないか確かめましょう。<pre>' + rows.join('\n') + '</pre>' };
  }

  /** DB入門: 最後の SELECT の結果 (問合せ結果) と、教材の結果の表を比べる */
  function compareTable(last, expect, sql) {
    const keys = IS_MAC ? '<kbd>⌘</kbd>+<kbd>Enter</kbd>' : '<kbd>Ctrl</kbd>+<kbd>Enter</kbd>';
    if (!last) return { ok: false, html: `まだ SELECT を実行していません。「ワークシートに反映」してから、文の実行 (${keys}) で実行してください。` };
    const norm = v => v == null ? '(null)' : String(v).trim();
    const want = expect.rows.map(r => r.map(norm).join(' | '));
    const got = last.rows.map(r => r.map(norm).join(' | '));
    const sameCols = expect.cols.length === last.cols.length;
    // SYSDATE など、実行するたびに変わる日時は比べない
    const dateRe = /^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/;
    const rowEq = (a, b) => a === b || (/SYSDATE|SYSTIMESTAMP|CURRENT_DATE/i.test(sql) && a.split(' | ').every((x, i) => x === b.split(' | ')[i] || (dateRe.test(x) && dateRe.test(b.split(' | ')[i] || ''))));
    if (sameCols && want.length === got.length && want.every((w, i) => rowEq(got[i], w))) return { ok: true, html: '✔ 教材と同じ結果になりました。' };
    // 同じ値の行の並び順は決まっていない (教材 第5章の問3)
    if (sameCols && want.length === got.length && [...want].sort().join('\n') === [...got].sort().join('\n')) {
      return { ok: true, html: '✔ 教材と同じ行が出ました。並び順が違う行は、ORDER BY の列の値が同じ行です (順番は決まっていません。教材 第5章の問3)。' };
    }
    const rows = [];
    const max = Math.max(want.length, got.length);
    for (let i = 0; i < max; i++) {
      if (want[i] !== undefined && got[i] !== undefined && rowEq(got[i], want[i])) rows.push('  ' + esc(got[i]));
      else {
        if (want[i] !== undefined) rows.push(`<span class="diff-add">＋${esc(want[i])}</span>  ← 教材`);
        if (got[i] !== undefined) rows.push(`<span class="diff-del">－${esc(got[i])}</span>  ← あなた`);
      }
    }
    return { ok: false, html: `✖ 教材と違うところがあります (教材 ${want.length} 行、あなた ${got.length} 行)。最後に実行した SELECT と比べています。<pre>${rows.join('\n')}</pre>` };
  }
  /** DB入門: スクリプト出力に、教材の行 (ORA- のエラーや「…は作成されました。」) がすべて出ているか */
  function compareScript(text, expected) {
    const norm = s => s.replace(/\r/g, '').split('\n').map(x => x.trim()).filter(Boolean);
    const out = norm(text || '');
    if (!out.length) return { ok: false, html: 'スクリプト出力に表示がありません。先に SQL を実行してください。' };
    const missing = norm(expected).filter(l => !out.includes(l));
    if (!missing.length) return { ok: true, html: '✔ 教材と同じ表示が出ています。' };
    return { ok: false, html: '✖ スクリプト出力に、教材の次の行が見つかりません。<pre>' + missing.map(esc).join('\n') + '</pre>' };
  }

  /** その教材 (コース) の目次か章か */
  function courseHas(k, id) {
    const c = COURSES[k];
    if (id === c.indexId || c.data().some(x => x.id === id)) return true;
    const index = loadCache()[c.indexId] || c.data().find(x => x.id === c.indexId);
    return chaptersFromIndex(index && index.body).some(x => x.id === id);
  }

  function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

  return {
    init, go, goId, render, setSource, setCourse,
    get currentId() { return currentId; }, get source() { return source; }, get course() { return course; },
    get lessons() { return lessons; },
    /** 章の本文 (内蔵、または Qiita モードなら取得済みの最新) */
    bodyOf: id => { const c = withPatches(source === 'qiita' ? contentFor(id) : builtinById(id)); return c ? c.body : ''; },
    compare, merge, buildSteps,
    /** 部分のコードを、全体のコードの同じ場所に差し込む (差し込めないときは null) */
    mergePartial: (base, part, note) => mergeWeb(base, part, note),
  };
})();
