// お手軽Java - Eclipse (Pleiades) 風 IDE 本体
'use strict';

const App = (() => {
  // =================================================================
  // 状態
  // =================================================================
  const files = new Map();      // パス -> 保存済みの内容
  const dirs = new Set();       // フォルダのパス
  const editors = [];           // {path, cm, pane, tab, gen}
  let active = null;
  const problems = new Map();   // プロジェクト名 -> [{path, kind, line, col, start, end, msg, code}]
  const building = new Map();   // プロジェクト名 -> {running: Promise, again: bool}
  const builtVersion = new Map(); // プロジェクト名 -> 最後にビルドした内容の版
  let fileVersion = 0;
  const projVersion = new Map();
  let selected = null;          // エクスプローラーで選んでいるノード id
  const expanded = new Set();
  let ui = {};
  let settings = {};
  let javaReady = false;
  const run = { running: false, inputQueue: [], waiting: null, title: '', start: null, text: '', className: '', project: '' };

  const SETTINGS_KEY = 'otekaru.settings.v1';
  const UI_KEY = 'otekaru.ui.v1';
  const DEFAULT_SETTINGS = {
    theme: 'light', fontSize: 14, indentSpaces: true, indentUnit: 4,
    autoActivation: true, autoActivationDelay: 200, autoActivationTriggers: '.',
    autoBuild: true, saveBeforeLaunch: 'prompt', launchWithErrors: 'prompt', markOccurrences: true,
  };

  // Mac では、Eclipse (mac 版) と同じく Ctrl の代わりに ⌘ を使う (補完の Control + Space はそのまま)
  const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent || '');
  /** "Ctrl+Shift+F" のようなキーの表記を、Mac では "⇧⌘F" にする */
  function keyLabel(s) {
    if (!IS_MAC || !s) return s;
    return s.replace(/((?:Ctrl|Shift|Alt)\+)+([A-Za-z0-9]+|[^\s()（）,、A-Za-z0-9])/g, (m, x, key) => {
      const mods = m.slice(0, m.length - key.length);
      const ctrl = /Ctrl\+/.test(mods);
      return (ctrl && key === 'Space' ? '⌃' : '') + (/Alt\+/.test(mods) ? '⌥' : '') + (/Shift\+/.test(mods) ? '⇧' : '') + (ctrl && key !== 'Space' ? '⌘' : '') + key;
    }).replace(/Ctrl\+クリック/g, '⌘+クリック');
  }
  /** キーの表記を <kbd> で囲んだ HTML にする */
  function kbdHtml(s) {
    const l = keyLabel(s);
    if (IS_MAC) return `<kbd>${l.replace(/[<>&]/g, '')}</kbd>`;
    return l.split('+').map(p => `<kbd>${p}</kbd>`).join('+');
  }
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // =================================================================
  // パスの扱い  (プロジェクト/src/パッケージ/クラス.java)
  // =================================================================
  const projectOf = p => p.split('/')[0];
  const baseName = p => p.split('/').pop();
  const parentOf = p => p.split('/').slice(0, -1).join('/');
  const isJava = p => /\.java$/.test(p);
  const isHidden = p => p.split('/').some(s => s.startsWith('.'));
  function srcRoot(project) { return project + '/src'; }
  function srcRel(p) { const r = srcRoot(projectOf(p)) + '/'; return p.startsWith(r) ? p.slice(r.length) : null; }
  function pkgOfDir(dir) { const r = srcRoot(projectOf(dir)); return dir === r ? '' : dir.slice(r.length + 1).replace(/\//g, '.'); }
  function fqnOf(p) { const rel = srcRel(p); return rel ? rel.replace(/\.java$/, '').replace(/\//g, '.') : null; }
  function projects() {
    const set = new Set();
    for (const d of dirs) if (!d.includes('/') && !d.startsWith('.')) set.add(d);
    for (const f of files.keys()) if (f.includes('/')) set.add(projectOf(f));
    const hidden = new Set(ui.hiddenProjects || []);
    return [...set].filter(p => !hidden.has(p)).sort((a, b) => a.localeCompare(b));
  }
  function projectJre(project) {
    const cp = files.get(project + '/.classpath') || '';
    const m = cp.match(/JavaSE-(\d+)/);
    return m ? +m[1] : 17;
  }
  function javaFilesOf(project) {
    const r = srcRoot(project) + '/';
    return [...files.keys()].filter(f => f.startsWith(r) && isJava(f)).sort();
  }
  function packagesOf(project) {
    const r = srcRoot(project);
    const set = new Set();
    for (const d of dirs) if (d.startsWith(r + '/')) set.add(d);
    for (const f of javaFilesOf(project)) set.add(parentOf(f));
    // Eclipse と同じく、.java を持たず子パッケージだけを持つフォルダは表示しない
    const list = [...set].filter(d => d !== r);
    return list.filter(d => {
      const hasJava = javaFilesOf(project).some(f => parentOf(f) === d);
      const hasChild = list.some(x => x.startsWith(d + '/'));
      return hasJava || !hasChild;
    }).sort((a, b) => pkgOfDir(a).localeCompare(pkgOfDir(b)));
  }
  function contentOf(p) {
    const ed = editors.find(e => e.path === p);
    return ed ? ed.cm.getValue() : files.get(p);
  }

  // =================================================================
  // 起動
  // =================================================================
  async function boot() {
    loadSettings();
    applyTheme();
    const splash = document.createElement('div');
    splash.className = 'boot';
    splash.innerHTML = `<div class="box"><div class="splash"><h1>お手軽Java</h1><div class="ver">Eclipse 風 Java 独習環境 ・ CheerpJ ・ Java 17</div>
      <svg class="cup" viewBox="0 0 64 64"><path d="M14 26h30v14a14 14 0 0 1-14 14h-2a14 14 0 0 1-14-14z" fill="#fff" opacity=".92"/><path d="M44 30h4a6 6 0 0 1 0 12h-4" fill="none" stroke="#fff" stroke-width="3" opacity=".92"/><path d="M24 8c-3 4 3 6 0 10M32 6c-3 4 3 6 0 10" stroke="#fff" stroke-width="2.5" fill="none" opacity=".8"/></svg></div>
      <div class="msg" id="boot-msg">ワークスペースを読み込み中…</div><div class="bar"></div></div>`;
    document.body.appendChild(splash);

    const w = await Storage.load();
    for (const d of w.dirs) dirs.add(d);
    for (const [p, c] of Object.entries(w.files)) files.set(p, c.replace(/\r\n/g, '\n'));
    loadUi();

    buildMenus();
    buildToolbar();
    initLayout();
    initViews();
    Assist.setContext({ projectTypes: currentProjectTypes, currentPkg: () => active ? (JavaSrc.parse(active.cm.getValue()).pkg) : '' });
    Lesson.init({ applyCode: applyLessonCode, consoleText: () => run.text, openExternal: url => window.open(url, '_blank', 'noopener'), notify: status });
    renderExplorer();
    for (const p of (ui.openEditors || [])) if (files.has(p)) openEditor(p, { noFocus: true });
    if (ui.activeEditor && files.has(ui.activeEditor)) openEditor(ui.activeEditor);
    updateWelcome();
    restoreTerminated();
    splash.remove();
    document.addEventListener('keydown', globalKeys, true);
    window.addEventListener('beforeunload', e => { if (editors.some(isDirty)) { e.preventDefault(); e.returnValue = ''; } saveUi(); });
    if (Storage.mode !== 'server') status('ブラウザ保存モード: start.bat (Mac は start.command) から起動すると work フォルダにファイルとして保存されます');

    // Java (CheerpJ) の準備は裏で行う
    const ver = projects().length ? Math.max(...projects().map(projectJre)) : 17;
    const runtimeVer = +(sessionStorage.getItem('otekaru.runtime') || (ver >= 21 ? 21 : 17));
    setJavaStatus('Java を準備中…', true);
    try {
      await JavaRT.init(runtimeVer, msg => setJavaStatus(msg || 'Java を準備中…', true));
      javaReady = true;
      setJavaStatus('JavaSE-' + JavaRT.version, false);
      for (const p of projects()) requestBuild(p);
    } catch (e) {
      setJavaStatus('Java を起動できません', false);
      showError('Java を起動できません', e.message + '\n\nインターネットに接続されているか確認して、ページを読み込み直してください。');
    }
  }

  function loadSettings() {
    try { settings = Object.assign({}, DEFAULT_SETTINGS, JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')); } catch (e) { settings = Object.assign({}, DEFAULT_SETTINGS); }
  }
  function saveSettings() { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (e) { /* 無視 */ } }
  function loadUi() {
    try { ui = JSON.parse(localStorage.getItem(UI_KEY) || '{}'); } catch (e) { ui = {}; }
    (ui.expanded || []).forEach(x => expanded.add(x));
  }
  function saveUi() {
    ui.expanded = [...expanded];
    ui.openEditors = editors.map(e => e.path);
    ui.activeEditor = active ? active.path : null;
    try { localStorage.setItem(UI_KEY, JSON.stringify(ui)); } catch (e) { /* 無視 */ }
  }
  function applyTheme() {
    document.documentElement.dataset.theme = settings.theme === 'dark' ? 'dark' : 'light';
    document.documentElement.style.setProperty('--code-size', settings.fontSize + 'px');
    for (const e of editors) { e.cm.setOption('indentWithTabs', !settings.indentSpaces); e.cm.refresh(); }
  }

  // =================================================================
  // ステータス
  // =================================================================
  let statusTimer = null;
  function status(msg, keep) {
    const el = $('#st-msg');
    el.textContent = msg || '';
    clearTimeout(statusTimer);
    if (msg && !keep) statusTimer = setTimeout(() => { el.textContent = ''; }, 6000);
  }
  function setJavaStatus(msg, busy) {
    const el = $('#st-java');
    el.textContent = msg;
    el.classList.toggle('busy', !!busy);
  }
  function progress(on) { $('#st-progress').hidden = !on; }

  // =================================================================
  // メニュー
  // =================================================================
  const MENUS = [
    { label: 'ファイル', key: 'F', items: [
      { label: '新規', sub: [
        { label: 'Java プロジェクト', cmd: 'newProject', icon: 'project' },
        { label: 'パッケージ', cmd: 'newPackage', icon: 'package' },
        { label: 'クラス', cmd: 'newClass', icon: 'class' },
        { label: 'インターフェース', cmd: 'newInterface', icon: 'interface' },
      ] },
      '-',
      { label: '閉じる', cmd: 'closeEditor', key: 'Ctrl+F4', enabled: () => !!active },
      { label: 'すべて閉じる', cmd: 'closeAll', key: 'Ctrl+Shift+F4', enabled: () => editors.length > 0 },
      '-',
      { label: '保存', cmd: 'save', key: 'Ctrl+S', icon: 'save', enabled: () => active && isDirty(active) },
      { label: 'すべて保存', cmd: 'saveAll', key: 'Ctrl+Shift+S', icon: 'saveall', enabled: () => editors.some(isDirty) },
      { label: '前回保存した状態に戻す', cmd: 'revert', enabled: () => active && isDirty(active) },
      '-',
      { label: '名前変更...', cmd: 'rename', key: 'F2' },
      { label: 'リフレッシュ', cmd: 'refresh', key: 'F5' },
      '-',
      { label: 'インポート (ワークスペースから外したプロジェクト)...', cmd: 'importProject' },
      { label: 'ワークスペースのフォルダーを開く', cmd: 'openFolder', enabled: () => Storage.mode === 'server' },
      '-',
      { label: '終了', cmd: 'exit' },
    ] },
    { label: '編集', key: 'E', items: [
      { label: '元に戻す', cmd: 'undo', key: 'Ctrl+Z', enabled: () => !!active },
      { label: 'やり直し', cmd: 'redo', key: 'Ctrl+Y', enabled: () => !!active },
      '-',
      { label: '切り取り', cmd: 'cut', key: 'Ctrl+X', enabled: () => !!active },
      { label: 'コピー', cmd: 'copy', key: 'Ctrl+C', enabled: () => !!active },
      { label: '貼り付け', cmd: 'paste', key: 'Ctrl+V', enabled: () => !!active },
      '-',
      { label: 'すべて選択', cmd: 'selectAll', key: 'Ctrl+A', enabled: () => !!active },
      '-',
      { label: '検索/置換...', cmd: 'find', key: 'Ctrl+F', enabled: () => !!active },
      { label: '次を検索', cmd: 'findNext', key: 'Ctrl+K', enabled: () => !!active },
      { label: '前を検索', cmd: 'findPrev', key: 'Ctrl+Shift+K', enabled: () => !!active },
      '-',
      { label: 'コンテンツ・アシスト', cmd: 'contentAssist', key: 'Ctrl+Space', enabled: () => !!active },
      { label: 'ワード補完', cmd: 'wordComplete', key: 'Alt+/', enabled: () => !!active },
      { label: 'クイック・フィックス', cmd: 'quickFix', key: 'Ctrl+1', enabled: () => !!active },
    ] },
    { label: 'ソース', key: 'S', items: [
      { label: 'コメントの切り替え', cmd: 'toggleComment', key: 'Ctrl+/', enabled: () => !!active },
      { label: 'ブロック・コメントの追加', cmd: 'blockComment', key: 'Ctrl+Shift+/', enabled: () => !!active },
      { label: 'ブロック・コメントの除去', cmd: 'blockUncomment', key: 'Ctrl+Shift+\\', enabled: () => !!active },
      '-',
      { label: 'シフト右', cmd: 'shiftRight', enabled: () => !!active },
      { label: 'シフト左', cmd: 'shiftLeft', enabled: () => !!active },
      { label: 'インデントの訂正', cmd: 'correctIndent', key: 'Ctrl+I', enabled: () => !!active },
      { label: 'フォーマット', cmd: 'format', key: 'Ctrl+Shift+F', enabled: () => !!active },
      '-',
      { label: 'インポートの追加', cmd: 'addImport', key: 'Ctrl+Shift+M', enabled: () => !!active },
      { label: 'インポートの編成', cmd: 'organizeImports', key: 'Ctrl+Shift+O', enabled: () => !!active },
      '-',
      { label: 'getter および setter の生成...', cmd: 'genGetSet', enabled: () => !!active },
      { label: 'toString() の生成...', cmd: 'genToString', enabled: () => !!active },
      { label: 'フィールドを使用してコンストラクターを生成...', cmd: 'genCtor', enabled: () => !!active },
    ] },
    { label: 'リファクタリング', key: 'T', items: [
      { label: '名前変更...', cmd: 'renameSymbol', key: 'Alt+Shift+R', enabled: () => !!active },
    ] },
    { label: 'ナビゲート', key: 'N', items: [
      { label: '宣言を開く', cmd: 'openDecl', key: 'F3', enabled: () => !!active },
      { label: '行へ移動...', cmd: 'gotoLine', key: 'Ctrl+L', enabled: () => !!active },
      '-',
      { label: '次の注釈', cmd: 'nextAnnotation', key: 'Ctrl+.', enabled: () => !!active },
      { label: '前の注釈', cmd: 'prevAnnotation', key: 'Ctrl+,', enabled: () => !!active },
      { label: '対応する大括弧へ移動', cmd: 'matchBracket', key: 'Ctrl+Shift+P', enabled: () => !!active },
    ] },
    { label: '検索', key: 'A', items: [
      { label: '検索...', cmd: 'searchWorkspace', key: 'Ctrl+H' },
      { label: 'ファイル内の出現箇所', cmd: 'markOccurrencesNow', key: 'Ctrl+Shift+U', enabled: () => !!active },
    ] },
    { label: 'プロジェクト', key: 'P', items: [
      { label: 'すべてビルド', cmd: 'buildAll', key: 'Ctrl+B' },
      { label: 'クリーン...', cmd: 'clean' },
      { label: '自動的にビルド', cmd: 'toggleAutoBuild', checked: () => settings.autoBuild },
    ] },
    { label: '実行', key: 'R', items: [
      { label: '実行', cmd: 'run', key: 'Ctrl+F11', icon: 'run' },
      { label: '実行 → Java アプリケーション', cmd: 'runSelected', key: 'Alt+Shift+X, J', icon: 'run' },
      '-',
      { label: '終了', cmd: 'terminate', icon: 'terminate', enabled: () => run.running },
    ] },
    { label: 'ウィンドウ', key: 'W', items: [
      { label: 'ビューの表示', sub: [
        { label: 'パッケージ・エクスプローラー', cmd: 'showExplorer' },
        { label: 'アウトライン', cmd: 'showOutline' },
        { label: 'マーカー', cmd: 'showMarkers' },
        { label: 'コンソール', cmd: 'showConsole' },
        { label: '検索', cmd: 'showSearch' },
        { label: 'レッスン', cmd: 'showLesson' },
      ] },
      { label: 'アクティブなビューまたはエディターの最大化', cmd: 'maximize', key: 'Ctrl+M' },
      { label: 'パースペクティブのリセット...', cmd: 'resetPerspective' },
      '-',
      { label: 'テーマの切り替え (ライト/ダーク)', cmd: 'toggleTheme' },
      { label: '設定', cmd: 'preferences' },
    ] },
    { label: 'ヘルプ', key: 'H', items: [
      { label: 'ようこそ', cmd: 'welcome' },
      { label: 'Java入門 (Qiita) の目次を開く', cmd: 'lessonIndex' },
      '-',
      { label: 'キー・アシスト...', cmd: 'keyAssist', key: 'Ctrl+Shift+L' },
      '-',
      { label: 'お手軽Java について', cmd: 'about' },
    ] },
  ];

  const ICON_SVG = {
    project: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/><text x="10.5" y="13" font-size="7" font-family="Arial" font-weight="bold" fill="#3060b0">J</text></svg>',
    srcfolder: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/><path d="M8 7 L12.5 9.2 L12.5 12.8 L8 15 L3.5 12.8 L3.5 9.2 Z" transform="translate(1,-2) scale(.75)" fill="#c8a165" stroke="#8a6a35"/></svg>',
    package: Assist.ICONS.package,
    packageEmpty: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 5 L8 2 L14 5 L14 11.5 L8 14.5 L2 11.5 Z" fill="#f4ecdc" stroke="#a89070"/><path d="M2 5 L8 8 L14 5 M8 8 L8 14.5" fill="none" stroke="#a89070"/></svg>',
    jfile: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#7a8aa0"/><path d="M10 1.5v3h3" fill="none" stroke="#7a8aa0"/><text x="8" y="12.5" font-size="8" font-family="Arial" font-weight="bold" fill="#3060b0" text-anchor="middle">J</text></svg>',
    file: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#888"/><path d="M10 1.5v3h3" fill="none" stroke="#888"/><path d="M5 8h6M5 10h6M5 12h4" stroke="#aaa"/></svg>',
    jre: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2" y="4" width="12" height="9" rx="1" fill="#d9c7a0" stroke="#8a7650"/><rect x="4" y="2" width="8" height="3" fill="#b9a780" stroke="#8a7650"/></svg>',
    save: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 2h10l2 2v10H2z" fill="#4a7fc1" stroke="#2c5a94"/><rect x="4.5" y="2.5" width="6" height="4" fill="#fff"/><rect x="4" y="9" width="8" height="4.5" fill="#dfe8f5"/></svg>',
    saveall: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M4 1h9l2 2v9H4z" fill="#8fb0dc" stroke="#2c5a94"/><path d="M1 4h9l2 2v9H1z" fill="#4a7fc1" stroke="#2c5a94"/><rect x="3" y="4.5" width="5" height="3" fill="#fff"/></svg>',
    run: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="7" fill="#2fa52f" stroke="#1d7a1d"/><path d="M6 4.5 L11.5 8 L6 11.5 Z" fill="#fff"/></svg>',
    terminate: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="3" y="3" width="10" height="10" fill="#d9302c" stroke="#a11c19"/></svg>',
    newwiz: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#888"/><path d="M10 1.5v3h3" fill="none" stroke="#888"/><path d="M11.5 9v6M8.5 12h6" stroke="#d48b1a" stroke-width="1.8"/></svg>',
    build: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 12 L9 5" stroke="#777" stroke-width="2.5"/><rect x="8" y="1.5" width="6" height="6" transform="rotate(45 11 4.5)" fill="#9a9a9a" stroke="#555"/></svg>',
    lesson: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3c2.5-1 4.5-1 6.5.5v10.5c-2-1.5-4-1.5-6.5-.5z" fill="#55a4e8" stroke="#2b6cb0"/><path d="M14.5 3c-2.5-1-4.5-1-6.5.5v10.5c2-1.5 4-1.5 6.5-.5z" fill="#8cc4f2" stroke="#2b6cb0"/></svg>',
    search: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="6.5" cy="6.5" r="4.5" fill="#fff" stroke="#555" stroke-width="1.5"/><path d="M10 10 L14.5 14.5" stroke="#555" stroke-width="2"/></svg>',
    console: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="1.5" y="2.5" width="13" height="11" fill="#fff" stroke="#555"/><rect x="1.5" y="2.5" width="13" height="2.5" fill="#4a7fc1"/><path d="M4 8 L6 9.5 L4 11 M7.5 11h3.5" stroke="#333" fill="none"/></svg>',
    markers: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2" y="2" width="12" height="12" fill="#fff" stroke="#777"/><circle cx="5.5" cy="6" r="1.8" fill="#e51400"/><path d="M8 6h4.5" stroke="#555"/><path d="M5.5 9 L7.3 12 L3.7 12 Z" fill="#f5a623"/><path d="M8 11h4.5" stroke="#555"/></svg>',
    outline: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 3h10M5 6h8M5 9h8M3 12h10" stroke="#555" stroke-width="1.5"/><circle cx="3" cy="6" r="1" fill="#3fae3f"/><circle cx="3" cy="9" r="1" fill="#d94a4a"/></svg>',
    explorer: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/></svg>',
    collapse: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2.5" y="2.5" width="11" height="11" fill="#fff" stroke="#777"/><path d="M5 8h6" stroke="#333" stroke-width="1.5"/></svg>',
    link: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 11 L13 5 M3 5 L13 11" stroke="#d5a33a" stroke-width="1.8"/></svg>',
    clear: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2.5" y="2.5" width="11" height="11" fill="#fff" stroke="#777"/><path d="M5 5 L11 11 M11 5 L5 11" stroke="#999"/></svg>',
    scrolllock: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="3.5" y="7" width="9" height="7" fill="#e8c46a" stroke="#a8822a"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2" fill="none" stroke="#777" stroke-width="1.5"/></svg>',
    error: '<svg viewBox="0 0 16 16" width="14" height="14"><circle cx="8" cy="8" r="7" fill="#e51400"/><path d="M5.2 5.2 L10.8 10.8 M10.8 5.2 L5.2 10.8" stroke="#fff" stroke-width="1.8"/></svg>',
    warning: '<svg viewBox="0 0 16 16" width="14" height="14"><path d="M8 1.5 L15 14.5 L1 14.5 Z" fill="#f5c623" stroke="#b58a00"/><path d="M8 6v4.5" stroke="#000" stroke-width="1.6"/><circle cx="8" cy="12.5" r=".9" fill="#000"/></svg>',
    info: '<svg viewBox="0 0 16 16" width="14" height="14"><circle cx="8" cy="8" r="7" fill="#3f7fd9"/><text x="8" y="12" font-size="10" font-family="Georgia" font-weight="bold" fill="#fff" text-anchor="middle">i</text></svg>',
    decoError: '<svg viewBox="0 0 9 9" width="9" height="9"><rect x="0" y="0" width="9" height="9" fill="#fff"/><circle cx="4.5" cy="4.5" r="4" fill="#e51400"/><path d="M2.7 2.7 L6.3 6.3 M6.3 2.7 L2.7 6.3" stroke="#fff" stroke-width="1.3"/></svg>',
    decoWarning: '<svg viewBox="0 0 9 9" width="9" height="9"><path d="M4.5 0.5 L8.7 8.5 L0.3 8.5 Z" fill="#f5c623" stroke="#b58a00" stroke-width=".7"/></svg>',
    bulb: '<svg viewBox="0 0 16 16" width="14" height="14"><path d="M8 1.5a4.5 4.5 0 0 0-2.6 8.2V12h5.2V9.7A4.5 4.5 0 0 0 8 1.5z" fill="#ffd94a" stroke="#b58a00"/><rect x="5.5" y="12.5" width="5" height="2" fill="#999"/></svg>',
    wizard: '<svg viewBox="0 0 56 48" width="56" height="48"><rect x="6" y="6" width="34" height="28" fill="#eef3fa" stroke="#7d93b2"/><path d="M10 12h26M10 17h20M10 22h24" stroke="#9cb0cc" stroke-width="2"/><circle cx="42" cy="32" r="10" fill="#3fa53f" stroke="#2c6e2c"/><text x="42" y="36.5" font-size="12" font-family="Arial" font-weight="bold" fill="#fff" text-anchor="middle">J</text></svg>',
  };
  function icon(name) { return ICON_SVG[name] || Assist.ICONS[name] || ''; }

  let openMenu = null;
  function buildMenus() {
    const bar = $('#menubar');
    bar.innerHTML = '';
    MENUS.forEach((m, i) => {
      const el = document.createElement('div');
      el.className = 'menu-top';
      el.innerHTML = `${esc(m.label)}(<u>${m.key}</u>)`;
      el.addEventListener('mousedown', e => { e.preventDefault(); if (openMenu && openMenu.top === el) closeMenus(); else showMenu(m.items, el); });
      el.addEventListener('mouseenter', () => { if (openMenu && openMenu.top !== el) showMenu(m.items, el); });
      bar.appendChild(el);
    });
    document.addEventListener('mousedown', e => { if (openMenu && !e.target.closest('.menu-popup') && !e.target.closest('.menu-top')) closeMenus(); });
  }
  function closeMenus() {
    $$('.menu-popup.dyn').forEach(x => x.remove());
    $$('.menu-top.open').forEach(x => x.classList.remove('open'));
    openMenu = null;
  }
  function showMenu(items, top, x, y) {
    closeMenus();
    let rect = top ? top.getBoundingClientRect() : { left: x, bottom: y };
    if (top) top.classList.add('open');
    const pop = renderMenu(items, rect.left, rect.bottom, 0);
    openMenu = { top, pop };
  }
  function renderMenu(items, x, y, level) {
    const pop = document.createElement('div');
    pop.className = 'menu-popup dyn';
    pop.dataset.level = level;
    for (const it of items) {
      if (it === '-') { const s = document.createElement('div'); s.className = 'menu-sep'; pop.appendChild(s); continue; }
      const el = document.createElement('div');
      const enabled = it.enabled ? it.enabled() : true;
      const checked = it.checked ? it.checked() : false;
      el.className = 'menu-item' + (it.sub ? ' sub' : '') + (enabled ? '' : ' disabled') + (checked ? ' checked' : '');
      el.innerHTML = `<span class="mi-icon">${it.icon ? icon(it.icon) : ''}</span><span class="mi-label">${esc(it.label)}</span><span class="mi-key">${esc(keyLabel(it.key || ''))}</span>`;
      if (it.sub) {
        el.addEventListener('mouseenter', () => {
          $$('.menu-popup.dyn').filter(p => +p.dataset.level > level).forEach(p => p.remove());
          $$('.menu-item.open', pop).forEach(x => x.classList.remove('open'));
          el.classList.add('open');
          const r = el.getBoundingClientRect();
          renderMenu(it.sub, r.right - 2, r.top - 3, level + 1);
        });
      } else {
        el.addEventListener('mouseenter', () => { $$('.menu-popup.dyn').filter(p => +p.dataset.level > level).forEach(p => p.remove()); $$('.menu-item.open', pop).forEach(x => x.classList.remove('open')); });
        el.addEventListener('mouseup', e => { if (!enabled) return; closeMenus(); hideCtx(); if (it.action) it.action(); else command(it.cmd); });
      }
      pop.appendChild(el);
    }
    document.body.appendChild(pop);
    const r = pop.getBoundingClientRect();
    pop.style.left = Math.min(x, window.innerWidth - r.width - 4) + 'px';
    pop.style.top = Math.min(y, window.innerHeight - r.height - 4) + 'px';
    return pop;
  }
  function hideCtx() { closeMenus(); }
  function showContextMenu(items, x, y) { closeMenus(); renderMenu(items, x, y, 0); openMenu = { top: null }; }

  // =================================================================
  // ツールバー
  // =================================================================
  function buildToolbar() {
    const tb = $('#toolbar');
    const btn = (ic, title, cmd, opts = {}) => `<button class="tb-btn" data-cmd="${cmd}" title="${esc(title)}" ${opts.id ? `id="${opts.id}"` : ''}>${icon(ic)}${opts.drop ? '<span class="drop">▼</span>' : ''}</button>`;
    tb.innerHTML = [
      btn('newwiz', '新規 (Java プロジェクト・パッケージ・クラス)', 'newMenu', { drop: true }),
      btn('save', '保存 (Ctrl+S)', 'save', { id: 'tb-save' }),
      btn('saveall', 'すべて保存 (Ctrl+Shift+S)', 'saveAll', { id: 'tb-saveall' }),
      '<span class="tb-sep"></span>',
      btn('project', '新規 Java プロジェクト', 'newProject'),
      btn('package', '新規 Java パッケージ', 'newPackage'),
      btn('class', '新規 Java クラス', 'newClass'),
      btn('interface', '新規 Java インターフェース', 'newInterface'),
      '<span class="tb-sep"></span>',
      btn('build', 'すべてビルド (Ctrl+B)', 'buildAll'),
      btn('run', '実行 (Ctrl+F11)', 'run', { id: 'tb-run' }),
      btn('terminate', '終了', 'terminate', { id: 'tb-terminate' }),
      '<span class="tb-sep"></span>',
      btn('search', '検索 (Ctrl+H)', 'searchWorkspace'),
      btn('lesson', 'レッスンを表示', 'showLesson'),
      `<span class="tb-label" id="tb-mode"></span>`,
    ].join('');
    tb.addEventListener('click', e => {
      const b = e.target.closest('[data-cmd]');
      if (!b || b.disabled) return;
      if (b.dataset.cmd === 'newMenu') { const r = b.getBoundingClientRect(); showContextMenu(MENUS[0].items[0].sub, r.left, r.bottom); return; }
      command(b.dataset.cmd);
    });
    $('#tb-mode').textContent = Storage.mode === 'server' ? 'ワークスペース: work フォルダー' : 'ワークスペース: ブラウザ保存';
    updateToolbar();
  }
  function updateToolbar() {
    const s = $('#tb-save'); if (s) s.disabled = !(active && isDirty(active));
    const sa = $('#tb-saveall'); if (sa) sa.disabled = !editors.some(isDirty);
    const t = $('#tb-terminate'); if (t) t.disabled = !run.running;
    const bt = $('#btn-terminate'); if (bt) bt.disabled = !run.running;
  }

  // =================================================================
  // レイアウト (サッシでサイズ変更、ビューのタブ)
  // =================================================================
  function initLayout() {
    const L = ui.layout || {};
    if (L.left) $('#left').style.width = L.left + 'px';
    if (L.right) $('#right').style.width = L.right + 'px';
    if (L.bottom) $('#view-bottom').style.height = L.bottom + 'px';
    if (L.rightHidden) $('#right').style.display = 'none';
    for (const sash of $$('.sash')) {
      sash.addEventListener('mousedown', e => {
        e.preventDefault();
        const kind = sash.dataset.sash;
        const startX = e.clientX, startY = e.clientY;
        const el = kind === 'left' ? $('#left') : kind === 'right' ? $('#right') : $('#view-bottom');
        const start = kind === 'bottom' ? el.getBoundingClientRect().height : el.getBoundingClientRect().width;
        const move = ev => {
          let v;
          if (kind === 'left') v = start + (ev.clientX - startX);
          else if (kind === 'right') v = start - (ev.clientX - startX);
          else v = start - (ev.clientY - startY);
          v = Math.max(120, Math.min(kind === 'bottom' ? window.innerHeight - 200 : window.innerWidth - 400, v));
          if (kind === 'bottom') el.style.height = v + 'px'; else el.style.width = v + 'px';
          refreshEditors();
        };
        const up = () => {
          document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up);
          ui.layout = ui.layout || {};
          ui.layout[kind] = Math.round(kind === 'bottom' ? el.getBoundingClientRect().height : el.getBoundingClientRect().width);
          saveUi();
        };
        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
      });
    }
    window.addEventListener('resize', refreshEditors);
  }
  function refreshEditors() { if (active) active.cm.refresh(); }

  function initViews() {
    // 下のビュー
    for (const t of $$('#bottom-tabs .view-tab')) t.addEventListener('mousedown', () => showBottom(t.dataset.view));
    for (const t of $$('#right-tabs .view-tab')) t.addEventListener('mousedown', () => showRight(t.dataset.view));
    for (const t of $$('.view-tabs')) t.addEventListener('dblclick', e => { if (e.target.closest('.view-tab')) toggleMaximize(t.closest('.view')); });
    $$('.view-tools [data-cmd], .view-tabs [data-cmd]').forEach(b => b.addEventListener('click', () => command(b.dataset.cmd)));
    $('#view-explorer .vt-close').addEventListener('click', e => { e.stopPropagation(); });
    showBottom(ui.bottomView === 'console' ? 'ide-console' : (ui.bottomView || 'ide-console'));
    showRight(ui.rightView || 'lesson');
    renderMarkers();
    renderOutline();
    initExplorerEvents();
    initConsole();
    initTooltips();
    $('#editor-tabs').addEventListener('dblclick', e => { if (e.target.closest('.editor-tab')) toggleMaximize($('#editor-area')); });
  }
  function showBottom(v) {
    $$('#bottom-tabs .view-tab').forEach(t => t.classList.toggle('active', t.dataset.view === v));
    $$('#bottom-body .panel').forEach(p => p.classList.toggle('active', p.id === v));
    $('#console-tools').style.visibility = v === 'ide-console' ? 'visible' : 'hidden';
    ui.bottomView = v; saveUi();
  }
  function showRight(v) {
    $('#right').style.display = '';
    $$('#right-tabs .view-tab').forEach(t => t.classList.toggle('active', t.dataset.view === v));
    $$('#right-body .panel').forEach(p => p.classList.toggle('active', p.id === v));
    ui.rightView = v;
    if (ui.layout) ui.layout.rightHidden = false;
    saveUi();
    refreshEditors();
  }
  let maximized = null;
  function toggleMaximize(view) {
    if (maximized) { maximized.classList.remove('maximized'); const was = maximized; maximized = null; refreshEditors(); if (was === view) return; }
    if (!view) return;
    view.classList.add('maximized');
    maximized = view;
    refreshEditors();
  }

  // =================================================================
  // パッケージ・エクスプローラー
  // =================================================================
  function nodeIdFor(path) {
    if (!path.includes('/')) return 'P:' + path;
    const proj = projectOf(path);
    if (path === srcRoot(proj)) return 'S:' + path;
    if (files.has(path)) return 'F:' + path;
    return 'K:' + path;
  }
  function problemCount(prefix) {
    let e = 0, w = 0;
    for (const list of problems.values()) for (const p of list) {
      if (p.path === prefix || p.path.startsWith(prefix + '/') || (prefix.startsWith('K:'))) { /* no */ }
    }
    return { e, w };
  }
  function severityUnder(test) {
    let sev = 0;
    for (const list of problems.values()) for (const p of list) if (test(p.path)) { if (p.kind === 'ERROR') return 2; if (p.kind === 'WARNING') sev = 1; }
    return sev;
  }
  function deco(sev) { return sev === 2 ? `<span class="deco">${ICON_SVG.decoError}</span>` : sev === 1 ? `<span class="deco">${ICON_SVG.decoWarning}</span>` : ''; }

  function renderExplorer() {
    const el = $('#explorer');
    const rows = [];
    const add = (id, depth, iconHtml, label, opts = {}) => {
      const tw = opts.leaf ? '' : (expanded.has(id) ? '⌄' : '›');
      rows.push(`<div class="tree-row${selected === id ? ' selected' : ''}" data-id="${esc(id)}" style="padding-left:${depth * 14 + 2}px"><span class="tree-twisty">${tw}</span><span class="tree-icon">${iconHtml}${opts.deco || ''}</span><span class="tree-label">${opts.dirty ? '<span class="dirty">&gt;</span>' : ''}${label}</span></div>`);
    };
    const ps = projects();
    if (!ps.length) {
      el.innerHTML = `<div class="tree-empty">ワークスペースにプロジェクトがありません。<br>
        <a data-cmd="newProject">Java プロジェクトの作成</a><br>
        <a data-cmd="lessonStart">教材 (第2章) を見ながら始める</a></div>`;
      $$('[data-cmd]', el).forEach(a => a.onclick = () => command(a.dataset.cmd));
      return;
    }
    for (const p of ps) {
      const pid = 'P:' + p;
      add(pid, 0, icon('project'), esc(p), { deco: deco(severityUnder(x => projectOf(x) === p)) });
      if (!expanded.has(pid)) continue;
      const sid = 'S:' + srcRoot(p);
      add(sid, 1, icon('srcfolder'), 'src', { deco: deco(severityUnder(x => x.startsWith(srcRoot(p) + '/'))) });
      if (expanded.has(sid)) {
        const pkgs = packagesOf(p);
        const defFiles = javaFilesOf(p).filter(f => parentOf(f) === srcRoot(p));
        if (defFiles.length) {
          const did = 'K:' + srcRoot(p);
          add(did, 2, icon('package'), '(デフォルト・パッケージ)', { deco: deco(severityUnder(x => parentOf(x) === srcRoot(p))) });
          if (expanded.has(did)) for (const f of defFiles) addFile(f, 3);
        }
        for (const d of pkgs) {
          const kid = 'K:' + d;
          const fs = javaFilesOf(p).filter(f => parentOf(f) === d);
          add(kid, 2, fs.length ? icon('package') : icon('packageEmpty'), esc(pkgOfDir(d)), { leaf: !fs.length, deco: deco(severityUnder(x => parentOf(x) === d)) });
          if (expanded.has(kid)) for (const f of fs) addFile(f, 3);
        }
      }
      add('J:' + p, 1, icon('jre'), 'JRE システム・ライブラリー <span class="dim">[JavaSE-' + projectJre(p) + ']</span>', { leaf: true });
      // src 以外のファイル
      for (const f of [...files.keys()].filter(f => projectOf(f) === p && !f.startsWith(srcRoot(p) + '/') && !isHidden(f) && parentOf(f) === p).sort()) {
        add('F:' + f, 1, icon('file'), esc(baseName(f)), { leaf: true });
      }
    }
    function addFile(f, depth) {
      const ed = editors.find(e => e.path === f);
      const sev = severityUnder(x => x === f);
      add('F:' + f, depth, icon('jfile'), esc(baseName(f)), { leaf: true, deco: deco(sev), dirty: ed && isDirty(ed) });
    }
    el.innerHTML = rows.join('');
  }

  function initExplorerEvents() {
    const el = $('#explorer');
    el.addEventListener('mousedown', e => {
      const row = e.target.closest('.tree-row');
      if (!row) return;
      const id = row.dataset.id;
      selected = id;
      if (e.target.closest('.tree-twisty') && e.button === 0) toggleNode(id);
      renderExplorer();
      el.focus();
    });
    el.addEventListener('dblclick', e => {
      const row = e.target.closest('.tree-row');
      if (!row) return;
      const id = row.dataset.id;
      if (id.startsWith('F:')) openEditor(id.slice(2));
      else toggleNode(id);
    });
    el.addEventListener('contextmenu', e => {
      e.preventDefault();
      const row = e.target.closest('.tree-row');
      if (row) { selected = row.dataset.id; renderExplorer(); }
      showContextMenu(explorerMenu(row ? row.dataset.id : null), e.clientX, e.clientY);
    });
    el.addEventListener('keydown', e => {
      const rows = $$('.tree-row', el);
      const idx = rows.findIndex(r => r.dataset.id === selected);
      if (e.key === 'ArrowDown' && idx < rows.length - 1) { selected = rows[idx + 1].dataset.id; renderExplorer(); e.preventDefault(); }
      else if (e.key === 'ArrowUp' && idx > 0) { selected = rows[idx - 1].dataset.id; renderExplorer(); e.preventDefault(); }
      else if (e.key === 'ArrowRight' && selected && !expanded.has(selected)) { toggleNode(selected); e.preventDefault(); }
      else if (e.key === 'ArrowLeft' && selected && expanded.has(selected)) { toggleNode(selected); e.preventDefault(); }
      else if (e.key === 'Enter' && selected) { if (selected.startsWith('F:')) openEditor(selected.slice(2)); else toggleNode(selected); }
      else if (e.key === 'Delete' && selected) { command('delete'); }
      else if (e.key === 'F2' && selected) { e.preventDefault(); command('rename'); }
    });
  }
  function toggleNode(id) {
    if (expanded.has(id)) expanded.delete(id); else expanded.add(id);
    saveUi();
    renderExplorer();
  }
  function revealInExplorer(path) {
    const p = projectOf(path);
    expanded.add('P:' + p);
    expanded.add('S:' + srcRoot(p));
    if (files.has(path)) expanded.add('K:' + parentOf(path)); else expanded.add('K:' + path);
    selected = nodeIdFor(path);
    renderExplorer();
    const row = $(`#explorer .tree-row[data-id="${CSS.escape(selected)}"]`);
    if (row) row.scrollIntoView({ block: 'nearest' });
  }
  /** 選択中のノードから、プロジェクト・パッケージ・ファイルを求める */
  function selectionContext() {
    let id = selected;
    if (!id && active) id = 'F:' + active.path;
    const c = { project: null, pkgDir: null, file: null };
    if (!id) { c.project = projects()[0] || null; return c; }
    const path = id.slice(2);
    c.project = projectOf(path);
    if (id.startsWith('K:')) c.pkgDir = path;
    if (id.startsWith('F:')) { c.file = path; if (srcRel(path)) c.pkgDir = parentOf(path); }
    return c;
  }
  function explorerMenu(id) {
    const newSub = [
      { label: 'Java プロジェクト', cmd: 'newProject', icon: 'project' },
      { label: 'パッケージ', cmd: 'newPackage', icon: 'package' },
      { label: 'クラス', cmd: 'newClass', icon: 'class' },
      { label: 'インターフェース', cmd: 'newInterface', icon: 'interface' },
    ];
    if (!id) return [{ label: '新規', sub: newSub }];
    const path = id.slice(2);
    const items = [{ label: '新規', sub: newSub }];
    if (id.startsWith('F:')) {
      items.unshift({ label: '開く', cmd: 'openSelected', key: 'F3' });
      const runSub = isJava(path) && JavaSrc.hasMain(contentOf(path) || '') ? [{ label: '1 Java アプリケーション', cmd: 'runSelected', key: 'Alt+Shift+X, J', icon: 'run' }] : [{ label: '(該当なし)', enabled: () => false }];
      items.push('-', { label: '実行', sub: runSub, icon: 'run' });
    }
    if (id.startsWith('J:')) return [{ label: '(JRE システム・ライブラリー)', enabled: () => false }];
    items.push('-');
    if (!id.startsWith('S:')) {
      items.push({ label: '削除', cmd: 'delete', key: 'Delete' });
      items.push({ label: '名前変更...', cmd: 'rename', key: 'F2' });
    }
    items.push('-', { label: 'リフレッシュ', cmd: 'refresh', key: 'F5' });
    if (Storage.mode === 'server') items.push({ label: '表示方法 → システム・エクスプローラー', cmd: 'openSelectedFolder' });
    return items;
  }

  // =================================================================
  // エディター
  // =================================================================
  const isDirty = e => !e.cm.isClean(e.gen);

  // Java モードを包んで、Javadoc (/** ... */) を通常のコメントと色分けする
  CodeMirror.defineMode('otekaru-java', (config) => {
    const base = CodeMirror.getMode(config, 'text/x-java');
    return Object.assign({}, base, {
      name: 'otekaru-java',
      startState: () => ({ b: CodeMirror.startState(base), doc: false }),
      copyState: s => ({ b: CodeMirror.copyState(base, s.b), doc: s.doc }),
      token(stream, s) {
        const style = base.token(stream, s.b);
        if (style && /comment/.test(style)) {
          const cur = stream.current();
          if (cur.startsWith('/**') && !cur.startsWith('/**/')) s.doc = true;
          const isDoc = s.doc;
          if (/\*\/$/.test(cur)) s.doc = false;
          if (isDoc) return style + ' javadoc';
          if (/TODO/.test(cur)) return style + ' todo';
        }
        return style;
      },
      indent: (s, textAfter, line) => base.indent(s.b, textAfter, line),
      innerMode: s => ({ state: s.b, mode: base }),
    });
  });

  function openEditor(path, opts = {}) {
    let ed = editors.find(e => e.path === path);
    if (!ed) {
      const pane = document.createElement('div');
      pane.className = 'editor-pane';
      $('#editors').appendChild(pane);
      const cm = CodeMirror(pane, {
        value: files.get(path) || '',
        mode: isJava(path) ? 'otekaru-java' : 'text/plain',
        lineNumbers: true,
        gutters: ['markers', 'CodeMirror-linenumbers'],
        indentUnit: settings.indentUnit,
        tabSize: 4,
        indentWithTabs: !settings.indentSpaces,
        smartIndent: true,
        electricChars: true,
        matchBrackets: true,
        autoCloseBrackets: { pairs: '()[]{}""\'\'', explode: '[]{}()' },
        styleActiveLine: true,
        lineWrapping: false,
        dragDrop: true,
        extraKeys: editorKeys(),
        hintOptions: { hint: Assist.hint, completeSingle: true, closeCharacters: /[\s()\[\]{};:>,=+\-*/!&|]/, alignWithWord: true },
        inputStyle: 'contenteditable',
        spellcheck: false,
      });
      const ruler = document.createElement('div');
      ruler.className = 'overview-ruler';
      pane.appendChild(ruler);
      ed = { path, cm, pane, ruler, gen: cm.changeGeneration(true), marks: [] };
      cm.on('change', (c, ch) => { onEditorChange(ed, ch); });
      cm.on('cursorActivity', () => { updateStatusPos(ed); scheduleOccurrences(ed); scheduleOutlineSync(); });
      cm.on('inputRead', (c, ch) => maybeAutoActivate(ed, ch));
      cm.on('mousedown', (c, e) => { if ((e.ctrlKey || (IS_MAC && e.metaKey)) && e.button === 0) { setTimeout(() => openDeclaration(ed, cm.coordsChar({ left: e.clientX, top: e.clientY })), 0); } });
      cm.on('gutterClick', (c, line, gutter) => { if (gutter === 'markers') quickFix(ed, line); });
      editors.push(ed);
      applyMarkers(ed);
    }
    activate(ed, opts.noFocus);
    if (opts.line != null) gotoPos(ed, opts.line, opts.col || 0, opts.flash);
    return ed;
  }

  function activate(ed, noFocus) {
    active = ed;
    for (const e of editors) e.pane.classList.toggle('active', e === ed);
    renderTabs();
    updateWelcome();
    setTimeout(() => { ed.cm.refresh(); if (!noFocus) ed.cm.focus(); }, 0);
    updateStatusPos(ed);
    renderOutline();
    if (ui.linkEditor) revealInExplorer(ed.path);
    saveUi();
  }

  function renderTabs() {
    const bar = $('#editor-tabs');
    bar.innerHTML = '';
    for (const e of editors) {
      const t = document.createElement('div');
      t.className = 'editor-tab' + (e === active ? ' active' : '');
      const dirty = isDirty(e);
      const sev = severityUnder(x => x === e.path);
      t.innerHTML = `<span class="tree-icon">${icon(isJava(e.path) ? 'jfile' : 'file')}${deco(sev)}</span><span class="et-name">${esc(baseName(e.path))}</span><span class="et-close" title="閉じる">${dirty ? '●' : '×'}</span>`;
      t.title = e.path;
      t.addEventListener('mousedown', ev => {
        if (ev.target.closest('.et-close')) return;
        if (ev.button === 1) { ev.preventDefault(); closeEditor(e); return; }
        activate(e);
      });
      const close = $('.et-close', t);
      close.addEventListener('mouseenter', () => { close.textContent = '×'; });
      close.addEventListener('mouseleave', () => { close.textContent = isDirty(e) ? '●' : '×'; });
      close.addEventListener('click', ev => { ev.stopPropagation(); closeEditor(e); });
      t.addEventListener('contextmenu', ev => {
        ev.preventDefault();
        showContextMenu([
          { label: '閉じる', action: () => closeEditor(e) },
          { label: 'その他を閉じる', action: () => editors.filter(x => x !== e).forEach(x => closeEditor(x)) },
          { label: 'すべて閉じる', action: () => command('closeAll') },
          '-',
          { label: 'パッケージ・エクスプローラーで表示', action: () => revealInExplorer(e.path) },
        ], ev.clientX, ev.clientY);
      });
      bar.appendChild(t);
    }
    updateToolbar();
  }

  async function closeEditor(ed) {
    if (!ed) return;
    if (isDirty(ed)) {
      const r = await dialog({
        title: 'リソースの保存', message: `'${baseName(ed.path)}' は変更されています。変更を保存しますか?`,
        buttons: [{ label: '保存', value: 'save', default: true }, { label: '保存しない', value: 'discard' }, { label: '取り消し', value: null }],
      });
      if (r === null || r === undefined) return;
      if (r === 'save') await saveEditor(ed);
    }
    const i = editors.indexOf(ed);
    editors.splice(i, 1);
    ed.pane.remove();
    if (active === ed) {
      active = editors[Math.min(i, editors.length - 1)] || null;
      if (active) activate(active); else { renderTabs(); updateWelcome(); renderOutline(); }
    } else renderTabs();
    renderExplorer();
    saveUi();
  }

  function updateWelcome() {
    const w = $('#welcome');
    if (editors.length) { w.hidden = true; return; }
    w.hidden = false;
    const hasProj = projects().length > 0;
    w.innerHTML = `<h1>ようこそ お手軽Java へ</h1>
      <div class="sub">インストール不要の Java 独習環境です。Eclipse (Pleiades) と同じ操作で、Qiita「Java入門」の教材を進められます。</div>
      <div class="cards">
        <div class="card" data-cmd="lessonStart"><b>📘 教材を始める</b><span>第2章「開発環境の構築」を右のレッスンに表示します</span></div>
        <div class="card" data-cmd="newProject"><b>🆕 Java プロジェクトを作る</b><span>ファイル → 新規 → Java プロジェクト</span></div>
        ${hasProj ? '<div class="card" data-cmd="newClass"><b>☕ クラスを作る</b><span>パッケージを選んでから 新規 → クラス</span></div>' : ''}
        <div class="card" data-cmd="lessonIndex"><b>📑 教材の目次</b><span>【Java入門】目次 (全14章＋付録)</span></div>
        <div class="card" data-cmd="keyAssist"><b>⌨ キー・アシスト</b><span>使えるショートカットの一覧 (Ctrl+Shift+L)</span></div>
      </div>
      <table>
        <tr><td>${kbdHtml('Ctrl+S')}</td><td>保存 (保存すると自動でコンパイルされます)</td></tr>
        <tr><td>${kbdHtml('Ctrl+F11')}</td><td>実行</td></tr>
        <tr><td>${kbdHtml('Ctrl+Space')}</td><td>補完 (sysout, main など)</td></tr>
        <tr><td>${kbdHtml('Ctrl+Shift+F')}</td><td>フォーマット</td></tr>
      </table>
      <p class="sub" style="margin-top:18px">保存場所: ${Storage.mode === 'server' ? esc(Storage.rootPath || 'work フォルダー') : 'このブラウザ (localStorage)'}</p>`;
    $$('[data-cmd]', w).forEach(c => c.onclick = () => command(c.dataset.cmd));
  }

  function onEditorChange(ed, change) {
    renderTabsDebounced();
    scheduleOutline();
    // 編集した行のマーカーは、保存してビルドし直すまで残す (Eclipse と同じ)
  }
  let tabTimer = null;
  function renderTabsDebounced() { clearTimeout(tabTimer); tabTimer = setTimeout(() => { renderTabs(); renderExplorer(); }, 120); }

  function updateStatusPos(ed) {
    const c = ed.cm.getCursor();
    $('#st-pos').textContent = `${c.line + 1} : ${c.ch + 1} : ${ed.cm.indexFromPos(c)}`;
  }

  function gotoPos(ed, line, col, flash) {
    const cm = ed.cm;
    cm.setCursor({ line, ch: col || 0 });
    cm.scrollIntoView({ line, ch: col || 0 }, 120);
    if (flash) {
      const h = cm.addLineClass(line, 'background', 'flash-line');
      setTimeout(() => cm.removeLineClass(h, 'background', 'flash-line'), 1500);
    }
    cm.focus();
  }

  // 自動有効化 ("." を入力したら候補を出す)
  let autoTimer = null;
  function maybeAutoActivate(ed, change) {
    if (!settings.autoActivation || !isJava(ed.path)) return;
    const ch = change.text.join('');
    if (ch.length !== 1 || !settings.autoActivationTriggers.includes(ch)) return;
    const tok = ed.cm.getTokenAt(ed.cm.getCursor());
    if (/comment|string/.test(tok.type || '')) return;
    if (ch === '.' && /\d\.$/.test(ed.cm.getLine(ed.cm.getCursor().line).slice(0, ed.cm.getCursor().ch))) return;
    clearTimeout(autoTimer);
    autoTimer = setTimeout(() => { if (active === ed) ed.cm.showHint({ completeSingle: false }); }, settings.autoActivationDelay);
  }

  // 出現箇所のマーク (Eclipse の「出現箇所のマーク」)
  let occTimer = null;
  function scheduleOccurrences(ed) {
    clearTimeout(occTimer);
    if (!settings.markOccurrences || !isJava(ed.path)) return;
    occTimer = setTimeout(() => markOccurrences(ed), 350);
  }
  function markOccurrences(ed) {
    const cm = ed.cm;
    (ed.occ || []).forEach(m => m.clear());
    ed.occ = [];
    if (cm.somethingSelected()) return;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch, e = c.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    while (e < line.length && /[\w$]/.test(line[e])) e++;
    const word = line.slice(s, e);
    if (!word || /^\d/.test(word) || Assist.LIB[word] === undefined && ['public', 'private', 'static', 'void', 'int', 'class', 'return', 'new', 'if', 'else', 'for', 'while', 'String'].includes(word)) return;
    const tok = cm.getTokenAt({ line: c.line, ch: s + 1 });
    if (/comment|string|keyword/.test(tok.type || '')) return;
    const b = JavaSrc.blank(cm.getValue());
    const re = new RegExp('(?<![\\w$])' + word.replace(/\$/g, '\\$') + '(?![\\w$])', 'g');
    let m, n = 0;
    while ((m = re.exec(b)) && n < 500) {
      ed.occ.push(cm.markText(cm.posFromIndex(m.index), cm.posFromIndex(m.index + word.length), { className: 'occurrence' }));
      n++;
    }
    if (ed.occ.length < 2) { ed.occ.forEach(x => x.clear()); ed.occ = []; }
  }

  // ---------- エディターのキー割り当て ----------
  function editorKeys() {
    const ifLinked = (key, fallback) => cm => { if (Assist.linkedKey(cm, key)) return; if (fallback) return fallback(cm); return CodeMirror.Pass; };
    const map = {
      'Ctrl-Space': cm => cm.showHint({ completeSingle: true }),
      'Ctrl-/': cm => toggleLineComment(cm),
      'Ctrl-7': cm => toggleLineComment(cm),
      'Shift-Ctrl-/': cm => cm.blockComment(cm.getCursor('from'), cm.getCursor('to'), { fullLines: false }),
      'Shift-Ctrl-\\': cm => cm.uncomment(cm.getCursor('from'), cm.getCursor('to')),
      'Shift-Ctrl-F': () => command('format'),
      'Ctrl-I': () => command('correctIndent'),
      'Shift-Ctrl-O': () => command('organizeImports'),
      'Shift-Ctrl-M': () => command('addImport'),
      'Ctrl-D': cm => deleteLines(cm),
      'Alt-Up': cm => moveLines(cm, -1),
      'Alt-Down': cm => moveLines(cm, 1),
      'Ctrl-Alt-Down': cm => duplicateLines(cm, 1),
      'Ctrl-Alt-Up': cm => duplicateLines(cm, 0),
      'Shift-Enter': cm => { const l = cm.getCursor().line; cm.setCursor({ line: l, ch: cm.getLine(l).length }); cm.execCommand('newlineAndIndent'); },
      'Shift-Ctrl-Enter': cm => { const l = cm.getCursor().line; cm.replaceRange('\n', { line: l, ch: 0 }); cm.setCursor({ line: l, ch: 0 }); cm.indentLine(l, 'smart'); cm.setCursor({ line: l, ch: cm.getLine(l).length }); },
      'Ctrl-L': () => command('gotoLine'),
      'Ctrl-F': () => command('find'),
      'Ctrl-K': () => command('findNext'),
      'Shift-Ctrl-K': () => command('findPrev'),
      'F3': () => command('openDecl'),
      'Ctrl-1': () => command('quickFix'),
      'Ctrl-.': () => command('nextAnnotation'),
      'Ctrl-,': () => command('prevAnnotation'),
      'Shift-Ctrl-P': cm => cm.execCommand('goToBracket') ,
      'Shift-Alt-R': () => command('renameSymbol'),
      'Alt-/': () => command('wordComplete'),
      'Ctrl-Y': cm => cm.redo(),
      'Shift-Ctrl-Z': cm => cm.redo(),
      'Tab': ifLinked('Tab', cm => { if (cm.somethingSelected() && cm.getSelection().includes('\n')) cm.indentSelection('add'); else cm.replaceSelection(settings.indentSpaces ? ' '.repeat(settings.indentUnit - (cm.getCursor().ch % settings.indentUnit)) : '\t'); }),
      'Shift-Tab': ifLinked('Shift-Tab', cm => cm.indentSelection('subtract')),
      'Enter': ifLinked('Enter', cm => cm.execCommand('newlineAndIndent')),
      'Esc': ifLinked('Esc', () => CodeMirror.Pass),
      'Ctrl-S': () => command('save'),
      'Shift-Ctrl-S': () => command('saveAll'),
      'Ctrl-F11': () => command('run'),
      'Ctrl-B': () => command('buildAll'),
      'Shift-Ctrl-L': () => command('keyAssist'),
      'Shift-Ctrl-U': () => command('markOccurrencesNow'),
      'Ctrl-M': () => toggleMaximize($('#editor-area')),
      'Ctrl-H': () => command('searchWorkspace'),
      'Ctrl-F4': () => command('closeEditor'),
    };
    // Mac では同じ操作を ⌘ でも行えるようにする (Control + Space の補完はそのまま)
    if (IS_MAC) {
      for (const k of Object.keys(map)) {
        if (!/(^|-)Ctrl-/.test(k) || k === 'Ctrl-Space') continue;
        const mk = k.replace(/(^|-)Ctrl-/, '$1Cmd-');
        if (!(mk in map)) map[mk] = map[k];
      }
    }
    return map;
  }
  function toggleLineComment(cm) {
    const from = cm.getCursor('from'), to = cm.getCursor('to');
    let endLine = to.line;
    if (to.ch === 0 && to.line > from.line) endLine--;
    const lines = [];
    for (let l = from.line; l <= endLine; l++) lines.push(cm.getLine(l));
    const allCommented = lines.every(t => /^\s*\/\//.test(t) || !t.trim());
    cm.operation(() => {
      for (let l = from.line; l <= endLine; l++) {
        const t = cm.getLine(l);
        if (allCommented) {
          const m = t.match(/^(\s*)\/\/ ?/);
          if (m) cm.replaceRange(m[1], { line: l, ch: 0 }, { line: l, ch: m[0].length });
        } else {
          // Eclipse は行頭 (0 桁目) に // を付ける
          cm.replaceRange('//', { line: l, ch: 0 });
        }
      }
    });
    if (from.line === endLine && !cm.somethingSelected()) cm.setCursor({ line: Math.min(from.line + 1, cm.lineCount() - 1), ch: cm.getCursor().ch });
  }
  function deleteLines(cm) {
    const from = cm.getCursor('from').line, to = cm.getCursor('to').line;
    cm.operation(() => {
      if (to + 1 < cm.lineCount()) cm.replaceRange('', { line: from, ch: 0 }, { line: to + 1, ch: 0 });
      else cm.replaceRange('', { line: Math.max(0, from - 1), ch: from > 0 ? cm.getLine(from - 1).length : 0 }, { line: to, ch: cm.getLine(to).length });
    });
  }
  function moveLines(cm, dir) {
    const from = cm.getCursor('from'), to = cm.getCursor('to');
    let s = from.line, e = to.line;
    if (to.ch === 0 && e > s) e--;
    if ((dir < 0 && s === 0) || (dir > 0 && e >= cm.lineCount() - 1)) return;
    cm.operation(() => {
      const text = cm.getRange({ line: s, ch: 0 }, { line: e, ch: cm.getLine(e).length });
      if (dir < 0) {
        const prev = cm.getLine(s - 1);
        cm.replaceRange(text + '\n' + prev, { line: s - 1, ch: 0 }, { line: e, ch: cm.getLine(e).length });
      } else {
        const next = cm.getLine(e + 1);
        cm.replaceRange(next + '\n' + text, { line: s, ch: 0 }, { line: e + 1, ch: cm.getLine(e + 1).length });
      }
      cm.setSelection({ line: from.line + dir, ch: from.ch }, { line: to.line + dir, ch: to.ch });
    });
  }
  function duplicateLines(cm, below) {
    const from = cm.getCursor('from'), to = cm.getCursor('to');
    let s = from.line, e = to.line;
    if (to.ch === 0 && e > s) e--;
    const text = cm.getRange({ line: s, ch: 0 }, { line: e, ch: cm.getLine(e).length });
    cm.operation(() => {
      cm.replaceRange(text + '\n', { line: s, ch: 0 });
      if (below) cm.setSelection({ line: from.line + (e - s + 1), ch: from.ch }, { line: to.line + (e - s + 1), ch: to.ch });
      else cm.setSelection(from, to);
    });
  }

  // =================================================================
  // 保存とビルド
  // =================================================================
  async function saveEditor(ed) {
    if (!ed) return;
    const text = ed.cm.getValue();
    try {
      await Storage.writeFile(ed.path, text);
    } catch (e) {
      showError('保存できませんでした', e.message);
      return;
    }
    files.set(ed.path, text);
    ed.gen = ed.cm.changeGeneration(true);
    fileChanged(ed.path);
    renderTabs();
    renderExplorer();
    status(`'${baseName(ed.path)}' を保存しました`);
  }
  function fileChanged(path) {
    fileVersion++;
    const p = projectOf(path);
    projVersion.set(p, fileVersion);
    if (settings.autoBuild && isJava(path)) requestBuild(p);
  }
  async function saveAll() {
    for (const e of editors.filter(isDirty)) await saveEditor(e);
  }

  function requestBuild(project) {
    if (!javaReady || !projects().includes(project)) return Promise.resolve();
    let b = building.get(project);
    if (b && b.running) { b.again = true; return b.done; }
    b = { running: true, again: false };
    building.set(project, b);
    b.done = (async () => {
      do {
        b.again = false;
        await buildProject(project);
      } while (b.again);
      b.running = false;
    })();
    return b.done;
  }

  async function buildProject(project) {
    const version = projVersion.get(project) || 0;
    const srcPrefix = srcRoot(project) + '/';
    const map = {};
    for (const f of javaFilesOf(project)) map[f.slice(srcPrefix.length)] = files.get(f);
    status(`ビルド中: ${project}`, true);
    progress(true);
    setJavaStatus('ビルド中…', true);
    const t0 = performance.now();
    try {
      const release = Math.min(projectJre(project), JavaRT.version);
      const r = await JavaRT.compile(project, map, String(release));
      const list = r.diags.filter(d => d.kind === 'ERROR' || d.kind === 'WARNING' || d.kind === 'MANDATORY_WARNING').map(d => ({
        path: d.file ? srcPrefix + d.file : project,
        kind: d.kind === 'ERROR' ? 'ERROR' : 'WARNING',
        line: Math.max(0, d.line - 1), col: Math.max(0, d.col - 1), start: d.start, end: d.end,
        msg: d.msg, code: d.code,
      }));
      problems.set(project, list);
      builtVersion.set(project, version);
      const ne = list.filter(x => x.kind === 'ERROR').length, nw = list.length - ne;
      status(`ビルド完了: ${project} (${((performance.now() - t0) / 1000).toFixed(1)} 秒)` + (ne || nw ? ` エラー ${ne}、警告 ${nw}` : ''));
    } catch (e) {
      status('ビルドに失敗しました: ' + e.message);
    } finally {
      progress(false);
      setJavaStatus('JavaSE-' + JavaRT.version, false);
      for (const ed of editors) if (projectOf(ed.path) === project) applyMarkers(ed);
      renderMarkers();
      renderExplorer();
      renderTabs();
    }
  }
  async function ensureBuilt(project) {
    const b = building.get(project);
    if (b && b.running) await b.done;
    if ((builtVersion.get(project) ?? -1) !== (projVersion.get(project) || 0) || !problems.has(project)) await requestBuild(project);
  }

  // ---------- マーカー (エディター内の × と波線) ----------
  function applyMarkers(ed) {
    const cm = ed.cm;
    cm.operation(() => {
      for (const m of ed.marks) m.clear();
      ed.marks = [];
      cm.clearGutter('markers');
      const list = (problems.get(projectOf(ed.path)) || []).filter(p => p.path === ed.path);
      const byLine = new Map();
      for (const p of list) {
        const prev = byLine.get(p.line);
        if (!prev || (p.kind === 'ERROR' && prev.kind !== 'ERROR')) byLine.set(p.line, p);
        // 波線
        let from, to;
        const doc = files.get(ed.path) || '';
        if (p.start >= 0 && p.end >= p.start && cm.getValue() === doc) {
          from = cm.posFromIndex(p.start); to = cm.posFromIndex(p.end + 1);
        } else {
          from = { line: p.line, ch: p.col }; to = { line: p.line, ch: p.col + 1 };
          const t = cm.getLine(p.line) || '';
          let e = p.col; while (e < t.length && /[\w$]/.test(t[e])) e++;
          if (e > p.col) to.ch = e;
        }
        if (CodeMirror.cmpPos(from, to) === 0) to = { line: to.line, ch: to.ch + 1 };
        ed.marks.push(cm.markText(from, to, { className: p.kind === 'ERROR' ? 'squiggly-error' : 'squiggly-warning', attributes: { 'data-msg': p.msg, 'data-kind': p.kind } }));
      }
      for (const [line, p] of byLine) {
        const all = list.filter(x => x.line === line);
        const el = document.createElement('div');
        el.className = 'marker';
        el.innerHTML = p.kind === 'ERROR' ? ICON_SVG.error : ICON_SVG.warning;
        el.dataset.msg = all.map(x => x.msg).join('\n');
        el.dataset.kind = p.kind;
        cm.setGutterMarker(line, 'markers', el);
      }
      // 概要ルーラー (右端)
      const lc = Math.max(1, cm.lineCount());
      const hasErr = list.some(x => x.kind === 'ERROR'), hasWarn = list.length > 0;
      ed.ruler.innerHTML = `<div class="om-top ${hasErr ? 'error' : hasWarn ? 'warning' : ''}" title="${hasErr ? 'エラーがあります' : hasWarn ? '警告があります' : '問題なし'}"></div>` +
        list.map(p => `<div class="om ${p.kind === 'ERROR' ? 'error' : 'warning'}" style="top:${14 + (p.line / lc) * (ed.pane.clientHeight - 30)}px" data-line="${p.line}" title="${esc(p.msg)}"></div>`).join('');
      $$('.om', ed.ruler).forEach(o => o.onclick = () => gotoPos(ed, +o.dataset.line, 0, true));
    });
  }

  // ---------- マーカー・ビュー ----------
  function renderMarkers() {
    const el = $('#markers');
    const all = [];
    for (const [proj, list] of problems) if (projects().includes(proj)) all.push(...list);
    const errs = all.filter(p => p.kind === 'ERROR'), warns = all.filter(p => p.kind !== 'ERROR');
    const row = (p, i) => {
      const rel = p.path.includes('/') ? p.path : p.path;
      return `<tr class="row" data-i="${i}"><td><div class="mk-desc">${p.kind === 'ERROR' ? ICON_SVG.error : ICON_SVG.warning}<span>${esc(p.msg)}</span></div></td><td>${esc(baseName(rel))}</td><td>${esc('/' + parentOf(rel))}</td><td>行 ${p.line + 1}</td><td>Java の問題</td></tr>`;
    };
    const sorted = errs.concat(warns);
    el._items = sorted;
    const groupRow = (label, n, open) => `<tr class="group"><td colspan="5">${open ? '⌄' : '›'} ${label} (${n} 項目)</td></tr>`;
    el.innerHTML = `<div class="mk-summary">エラー ${errs.length}、警告 ${warns.length}、その他 0</div>
      <table class="mk-table"><colgroup><col style="width:52%"><col style="width:14%"><col style="width:16%"><col style="width:8%"><col style="width:10%"></colgroup>
      <thead><tr><th>説明</th><th>リソース</th><th>パス</th><th>ロケーション</th><th>型</th></tr></thead><tbody>
      ${errs.length ? groupRow('Java の問題 (エラー)', errs.length, true) + errs.map((p, i) => row(p, i)).join('') : ''}
      ${warns.length ? groupRow('Java の問題 (警告)', warns.length, true) + warns.map((p, i) => row(p, errs.length + i)).join('') : ''}
      </tbody></table>`;
    $$('tr.row', el).forEach(tr => {
      tr.addEventListener('mousedown', () => { $$('tr.row.selected', el).forEach(x => x.classList.remove('selected')); tr.classList.add('selected'); });
      tr.addEventListener('dblclick', () => { const p = el._items[+tr.dataset.i]; if (files.has(p.path)) openEditor(p.path, { line: p.line, col: p.col, flash: true }); });
    });
    // タブに件数
    const tab = $('#bottom-tabs .view-tab[data-view="markers"]');
    tab.innerHTML = `<span class="vi">${icon('markers')}</span>マーカー${all.length ? ` <span style="color:var(--text-dim)">(${all.length})</span>` : ''}`;
  }

  // ---------- ツールチップ ----------
  function initTooltips() {
    const tt = $('#tooltip');
    document.addEventListener('mouseover', e => {
      const t = e.target.closest('.marker, [data-msg]');
      if (!t || !t.dataset.msg) { tt.hidden = true; return; }
      const kind = t.dataset.kind;
      tt.innerHTML = t.dataset.msg.split('\n').map(m => `<div class="tt-row">${kind === 'ERROR' ? ICON_SVG.error : ICON_SVG.warning}<span>${esc(m)}</span></div>`).join('');
      tt.hidden = false;
      const r = t.getBoundingClientRect();
      tt.style.left = Math.min(r.left, window.innerWidth - 420) + 'px';
      tt.style.top = (r.bottom + 4) + 'px';
    });
  }

  // =================================================================
  // アウトライン
  // =================================================================
  let outlineTimer = null, outlineSyncTimer = null;
  function scheduleOutline() { clearTimeout(outlineTimer); outlineTimer = setTimeout(renderOutline, 500); }
  function scheduleOutlineSync() { clearTimeout(outlineSyncTimer); outlineSyncTimer = setTimeout(syncOutline, 300); }
  function renderOutline() {
    const el = $('#outline');
    if (!active || !isJava(active.path)) { el.innerHTML = '<div class="ol-empty">アウトラインは使用できません。</div>'; return; }
    const parsed = JavaSrc.parse(active.cm.getValue());
    const rows = [];
    if (parsed.pkg) rows.push({ html: `${Assist.ICONS.package}<span>${esc(parsed.pkg)}</span>`, line: parsed.pkgLine, depth: 0 });
    if (parsed.imports.length) rows.push({ html: `<span style="width:16px;text-align:center">⇲</span><span>import 宣言</span>`, line: parsed.imports[0].line, depth: 0 });
    const walk = (types, depth) => {
      for (const t of types) {
        rows.push({ html: `${Assist.typeIcon(t.kind)}<span>${esc(t.name)}</span>`, line: t.line, depth });
        for (const m of t.members) {
          if (m.kind === 'type') { walk([m.type], depth + 1); continue; }
          if (m.kind === 'init') continue;
          const sig = JavaSrc.signature(m);
          const k = sig.indexOf(' : ');
          const label = k >= 0 ? `${esc(sig.slice(0, k))} <span class="type">: ${esc(sig.slice(k + 3))}</span>` : esc(sig);
          const st = m.mods.includes('static') ? '<sup style="font-size:8px;color:#b58a00;margin-left:-6px">S</sup>' : '';
          rows.push({ html: `${Assist.memberIcon(m)}${st}<span>${label}</span>`, line: m.line, depth: depth + 1 });
        }
      }
    };
    walk(parsed.types, 0);
    el.innerHTML = rows.map((r, i) => `<div class="ol-row" data-line="${r.line}" style="padding-left:${6 + r.depth * 16}px">${r.html}</div>`).join('') || '<div class="ol-empty">(要素なし)</div>';
    $$('.ol-row', el).forEach(r => r.addEventListener('click', () => { gotoPos(active, +r.dataset.line, 0); }));
    syncOutline();
  }
  function syncOutline() {
    if (!active) return;
    const line = active.cm.getCursor().line;
    let best = null;
    for (const r of $$('#outline .ol-row')) { if (+r.dataset.line <= line) best = r; r.classList.remove('selected'); }
    if (best) best.classList.add('selected');
  }

  // =================================================================
  // コンソールと実行
  // =================================================================
  function initConsole() {
    const c = $('#ide-console');
    c.addEventListener('click', e => {
      const a = e.target.closest('a.trace');
      if (a) { e.preventDefault(); openTrace(a.dataset.cls, a.dataset.method, a.dataset.line ? +a.dataset.line : null); return; }
      const inp = $('.console-input', c);
      if (inp && !window.getSelection().toString()) inp.focus();
    });
    setConsoleTitle('');
  }
  function setConsoleTitle(t) { $('#console-title').textContent = t || 'コンソールを表示するものは現在ありません。'; }
  function consoleClear() { $('#console-out').innerHTML = ''; run.text = ''; }
  function consoleAppend(text, cls) {
    const out = $('#console-out');
    const inp = $('.console-input', out);
    const frag = document.createDocumentFragment();
    if (cls === 'err') {
      // スタックトレースの行をリンクにする
      for (const part of text.split(/(\n)/)) {
        if (part === '\n') { frag.appendChild(document.createTextNode('\n')); continue; }
        const m = part.match(/^(\s*at )([\w.$]+)\.([\w$<>]+)\(([^)]*)\)(.*)$/);
        const span = document.createElement('span');
        span.className = 'err';
        if (m) {
          span.appendChild(document.createTextNode(m[1] + m[2] + '.' + m[3] + '('));
          const cls2 = m[2].replace(/\$.*$/, '');
          const loc = m[4];
          const lm = loc.match(/^(\w+\.java):(\d+)$/);
          const path = pathForClass(cls2);
          if (lm && path) {
            const a = document.createElement('a'); a.className = 'trace'; a.textContent = loc; a.dataset.cls = cls2; a.dataset.method = m[3]; a.dataset.line = lm[2];
            span.appendChild(a);
            span.appendChild(document.createTextNode(')' + m[5]));
          } else if (path) {
            const a = document.createElement('a'); a.className = 'trace'; a.textContent = loc || 'Unknown Source'; a.dataset.cls = cls2; a.dataset.method = m[3]; a.title = 'クリックするとメソッドの位置を開きます (ブラウザ版では行番号が分かりません)';
            span.appendChild(a);
            span.appendChild(document.createTextNode(')' + m[5]));
          } else span.appendChild(document.createTextNode(loc + ')' + m[5]));
        } else span.textContent = part;
        frag.appendChild(span);
      }
    } else {
      const span = document.createElement('span');
      if (cls) span.className = cls;
      span.textContent = text;
      frag.appendChild(span);
    }
    if (inp) out.insertBefore(frag, inp); else out.appendChild(frag);
    if (cls !== 'sys' && cls !== 'in') run.text += text;
    if (cls === 'in') run.text += text;
    if (!$('#btn-scrolllock').classList.contains('on')) $('#ide-console').scrollTop = $('#ide-console').scrollHeight;
  }
  function pathForClass(fqn) {
    for (const p of projects()) {
      const f = srcRoot(p) + '/' + fqn.replace(/\./g, '/') + '.java';
      if (files.has(f)) return f;
    }
    // ネストしたクラスなど: 最後の要素を落として探す
    const parts = fqn.split('.');
    for (let i = parts.length - 1; i > 0; i--) {
      for (const p of projects()) {
        const f = srcRoot(p) + '/' + parts.slice(0, i).join('/') + '.java';
        if (files.has(f)) return f;
      }
    }
    return null;
  }
  function openTrace(cls, method, line) {
    const path = pathForClass(cls);
    if (!path) return;
    if (line) { openEditor(path, { line: line - 1, flash: true }); return; }
    const parsed = JavaSrc.parse(contentOf(path));
    let target = 0;
    const sn = cls.split('.').pop();
    const walk = types => { for (const t of types) { if (t.name === sn || method === '<init>') { const m = t.members.find(x => (x.kind === 'method' && x.name === method) || (method === '<init>' && x.kind === 'ctor')); if (m) target = m.line; else target = t.line; } walk(t.members.filter(x => x.kind === 'type').map(x => x.type)); } };
    walk(parsed.types);
    openEditor(path, { line: target, flash: true });
  }
  function addConsoleInput() {
    const out = $('#console-out');
    if ($('.console-input', out)) return;
    const inp = document.createElement('input');
    inp.className = 'console-input';
    inp.spellcheck = false;
    inp.setAttribute('aria-label', 'コンソールへの入力');
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const v = inp.value;
        inp.value = '';
        consoleAppend(v + '\n', 'in');
        if (run.waiting) { const w = run.waiting; run.waiting = null; w(v); } else run.inputQueue.push(v);
      } else if (e.key === 'z' && e.ctrlKey) {
        // Ctrl+Z: 入力の終わり (EOF)
        e.preventDefault();
        if (run.waiting) { const w = run.waiting; run.waiting = null; w(null); } else run.inputQueue.push(null);
      }
    });
    out.appendChild(inp);
  }
  function removeConsoleInput() { const i = $('.console-input'); if (i) i.remove(); }

  function fmtTime(d) {
    const p = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }

  /** クラスを Java アプリケーションとして実行する */
  async function runFile(path) {
    if (run.running) { status('プログラムを実行中です。終了してから実行してください (コンソールの赤い■で終了)'); showBottom('ide-console'); return; }
    if (!path || !isJava(path) || !srcRel(path)) { await dialog({ title: '起動できません', message: '選択にはメイン型が含まれていません。', icon: 'error' }); return; }
    const project = projectOf(path);
    // 保存していないエディター
    const dirty = editors.filter(isDirty);
    if (dirty.length) {
      if (settings.saveBeforeLaunch === 'always') await saveAll();
      else {
        const r = await saveResourcesDialog(dirty);
        if (!r) return;
        if (r.always) { settings.saveBeforeLaunch = 'always'; saveSettings(); }
        await saveAll();
      }
    }
    const src = files.get(path) || '';
    if (!JavaSrc.hasMain(src)) { await dialog({ title: '起動できません', message: '選択にはメイン型が含まれていません。', icon: 'error' }); return; }
    if (!javaReady) { status('Java を準備中です。準備ができるまでお待ちください…', true); try { await JavaRT.init(); } catch (e) { return; } }
    // JRE のバージョンが違うときは、ランタイムを切り替える
    const jre = projectJre(project);
    if (jre > JavaRT.version) {
      const ok = await dialog({ title: 'Java ランタイムの切り替え', message: `プロジェクト '${project}' は JavaSE-${jre} を使います。\nJava ランタイムを JavaSE-${jre} に切り替えるため、画面を読み込み直します。`, buttons: [{ label: '切り替える', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!ok) return;
      sessionStorage.setItem('otekaru.runtime', String(jre >= 21 ? 21 : 17));
      saveUi(); location.reload(); return;
    }
    // Java が止まっていた (System.exit など) ときは、コンパイルからやり直す
    if (!JavaRT.alive) builtVersion.clear();
    await ensureBuilt(project);
    const errs = (problems.get(project) || []).filter(p => p.kind === 'ERROR');
    if (errs.length && settings.launchWithErrors !== 'always') {
      const r = await dialog({
        title: 'エラーが存在します', icon: 'error',
        message: `必須プロジェクトにエラーが存在します:\n\n${project}\n\n起動を続行しますか?`,
        check: '常にエラーを伴って起動',
        buttons: [{ label: '続行', value: 'go' }, { label: '取り消し', value: null, default: true }],
      });
      if (!r || r.value !== 'go') { showBottom('markers'); return; }
      if (r.checked) { settings.launchWithErrors = 'always'; saveSettings(); }
    }
    const fqn = fqnOf(path);
    const name = baseName(path).replace(/\.java$/, '');
    run.running = true; run.inputQueue = []; run.waiting = null; run.start = new Date(); run.className = name; run.project = project;
    run.title = `${name} [Java アプリケーション] `;
    consoleClear();
    showBottom('ide-console');
    setConsoleTitle(run.title + '(' + fmtTime(run.start) + ')');
    addConsoleInput();
    updateToolbar();
    setJavaStatus('実行中: ' + name, true);
    const inp = $('.console-input'); if (inp) setTimeout(() => inp.focus(), 50);
    let code = -1;
    try {
      code = await JavaRT.run(project, fqn, [], {
        out: s => consoleAppend(s),
        err: s => consoleAppend(s, 'err'),
        readLine: () => new Promise(res => {
          if (run.inputQueue.length) res(run.inputQueue.shift());
          else { run.waiting = res; const i = $('.console-input'); if (i) i.focus(); }
        }),
      });
    } catch (e) {
      consoleAppend('\n' + e.message + '\n', 'err');
    } finally {
      run.running = false;
      run.waiting = null;
      removeConsoleInput();
      const end = new Date();
      setConsoleTitle(`<終了> ${run.title}(${fmtTime(run.start)} – ${fmtTime(end).slice(11)})`);
      updateToolbar();
      setJavaStatus('JavaSE-' + JavaRT.version, false);
    }
  }

  async function saveResourcesDialog(dirty) {
    const r = await dialog({
      title: 'リソースの保存',
      message: '保存されていない変更があります。起動する前に、次のリソースを保存しますか?',
      list: dirty.map(e => ({ label: baseName(e.path) + '  (' + parentOf(e.path) + ')', checked: true })),
      check: '起動前に常に変更を保存',
      buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取り消し', value: null }],
    });
    if (!r || r.value !== 'ok') return null;
    return { always: r.checked };
  }

  function terminate() {
    if (!run.running) return;
    // 入力待ちなら EOF を送り、それでも終わらなければ画面を読み込み直して止める
    if (run.waiting) { const w = run.waiting; run.waiting = null; w(null); }
    setTimeout(() => {
      if (!run.running) return;
      const state = { html: $('#console-out').innerHTML, title: run.title, start: run.start.getTime(), text: run.text };
      try { sessionStorage.setItem('otekaru.terminated', JSON.stringify(state)); } catch (e) { /* 無視 */ }
      saveUi();
      location.reload();
    }, 400);
  }
  function restoreTerminated() {
    let s = null;
    try { s = JSON.parse(sessionStorage.getItem('otekaru.terminated') || 'null'); sessionStorage.removeItem('otekaru.terminated'); } catch (e) { s = null; }
    if (!s) return;
    $('#console-out').innerHTML = s.html;
    removeConsoleInput();
    run.text = s.text || '';
    consoleAppend('\n(プログラムを終了しました)\n', 'sys');
    setConsoleTitle(`<終了> ${s.title}(${fmtTime(new Date(s.start))} – ${fmtTime(new Date()).slice(11)})`);
    showBottom('ide-console');
  }

  // =================================================================
  // ダイアログ
  // =================================================================
  // ダイアログはモーダル (後ろの IDE は触れない)。ただしレッスン・ビューだけは読めるように、
  // 幕 (#overlay) より手前に出す (body.modal-open)。ダイアログは幕とは別の要素として重ねる。
  const dialogStack = [];

  /** ダイアログを、レッスン・ビューに重ならない位置 (エディター側の中央) に置く */
  function placeDialog(d) {
    const r = d.getBoundingClientRect();
    const right = $('#right');
    const rr = right && right.offsetParent ? right.getBoundingClientRect() : null;
    const areaRight = rr && rr.width ? rr.left : window.innerWidth;
    let left = (areaRight - r.width) / 2;
    if (left < 8) left = (window.innerWidth - r.width) / 2; // 入りきらないときは画面の中央
    let top = (window.innerHeight - r.height) / 2 - 20;
    const n = dialogStack.length - 1; // 重ねて開いたダイアログは少しずらす
    left += n * 24; top += n * 24;
    moveDialog(d, left, top);
  }
  /** 画面の外に出ないように動かす (タイトルバーが必ず見えるようにする) */
  function moveDialog(d, left, top) {
    const r = d.getBoundingClientRect();
    left = Math.min(Math.max(8 - r.width + 120, left), window.innerWidth - 120);
    top = Math.min(Math.max(0, top), window.innerHeight - 40);
    d.style.left = Math.round(left) + 'px';
    d.style.top = Math.round(top) + 'px';
  }
  /** タイトルバーをドラッグして動かせるようにする */
  function makeDraggable(d) {
    const bar = $('.dlg-titlebar', d);
    bar.addEventListener('mousedown', e => {
      if (e.button !== 0 || e.target.closest('button')) return;
      e.preventDefault();
      const r = d.getBoundingClientRect();
      const dx = e.clientX - r.left, dy = e.clientY - r.top;
      document.body.classList.add('dragging-dialog');
      const move = ev => moveDialog(d, ev.clientX - dx, ev.clientY - dy);
      const up = () => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        document.body.classList.remove('dragging-dialog');
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
    });
  }
  window.addEventListener('resize', () => {
    for (const d of dialogStack) { const r = d.getBoundingClientRect(); moveDialog(d, r.left, r.top); }
  });

  function dialog(opts) {
    return new Promise(resolve => {
      const ov = $('#overlay');
      ov.hidden = false;
      document.body.classList.add('modal-open');
      const d = document.createElement('div');
      d.className = 'dialog';
      d.style.minWidth = (opts.width || 440) + 'px';
      d.style.zIndex = String(700 + dialogStack.length * 10);
      const iconHtml = opts.icon === 'error' ? ICON_SVG.error : opts.icon === 'warning' ? ICON_SVG.warning : opts.icon === 'info' ? ICON_SVG.info : '';
      const buttons = opts.buttons || [{ label: 'OK', value: true, default: true }];
      d.innerHTML = `<div class="dlg-titlebar"><span class="t">${esc(opts.title || '')}</span><button class="x" data-x>×</button></div>
        ${opts.banner ? `<div class="dlg-banner"><div><div class="bt">${esc(opts.banner.title)}</div><div class="bm" id="dlg-msg">${opts.banner.html || esc(opts.banner.message || '')}</div></div><div class="bimg">${ICON_SVG.wizard}</div></div>` : ''}
        <div class="dlg-body">${opts.message ? `<div style="display:flex;gap:10px;align-items:flex-start">${iconHtml ? `<div style="transform:scale(1.8);margin:6px 8px">${iconHtml}</div>` : ''}<div style="white-space:pre-wrap">${esc(opts.message)}</div></div>` : ''}
        ${opts.list ? `<div class="dlg-list" style="height:auto;max-height:180px;margin-top:10px">${opts.list.map((x, i) => `<label class="li"><input type="checkbox" data-li="${i}" ${x.checked ? 'checked' : ''}>${esc(x.label)}</label>`).join('')}</div>` : ''}
        ${opts.html || ''}
        ${opts.check ? `<label class="chk" style="margin-top:12px"><input type="checkbox" id="dlg-check">${esc(opts.check)}</label>` : ''}
        </div>
        <div class="dlg-buttons">${opts.help ? '<button class="help" title="ヘルプ">?</button>' : ''}${buttons.map((b, i) => `<button class="dlg-btn${b.default ? ' default' : ''}" data-b="${i}">${esc(b.label)}</button>`).join('')}</div>`;
      // 親のダイアログ (クラス作成の「参照...」など) は、子を閉じるまで触れなくする
      const parent = dialogStack[dialogStack.length - 1];
      if (parent) parent.classList.add('blocked');
      document.body.appendChild(d);
      dialogStack.push(d);
      placeDialog(d);
      makeDraggable(d);
      const close = (val) => {
        d.remove();
        dialogStack.splice(dialogStack.indexOf(d), 1);
        if (parent) parent.classList.remove('blocked');
        if (!dialogStack.length) { ov.hidden = true; document.body.classList.remove('modal-open'); }
        document.removeEventListener('keydown', onKey, true);
        resolve(val);
        if (!dialogStack.length && active) setTimeout(() => active.cm.focus(), 0);
      };
      const result = (b) => {
        if (opts.check || opts.collect) {
          const out = { value: b.value, checked: !!($('#dlg-check', d) || {}).checked };
          if (opts.collect) Object.assign(out, opts.collect(d));
          return out;
        }
        return b.value;
      };
      const onKey = e => {
        // いちばん手前のダイアログだけが反応する。レッスン・ビューでのキー操作は邪魔しない
        if (dialogStack[dialogStack.length - 1] !== d) return;
        if (e.target.closest && e.target.closest('#view-right')) return;
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(opts.check || opts.collect ? null : (buttons.find(b => b.value === null || b.value === false) || {}).value ?? null); }
        else if (e.key === 'Enter' && !e.target.matches('textarea')) {
          const def = buttons.find(b => b.default);
          if (def) {
            const btn = $(`[data-b="${buttons.indexOf(def)}"]`, d);
            if (btn && !btn.disabled) { e.preventDefault(); e.stopPropagation(); if (def.validate && !def.validate(d)) return; close(result(def)); }
          }
        }
      };
      document.addEventListener('keydown', onKey, true);
      $$('[data-b]', d).forEach(btn => btn.addEventListener('click', () => {
        const b = buttons[+btn.dataset.b];
        if (b.validate && !b.validate(d)) return;
        close(result(b));
      }));
      $('[data-x]', d).onclick = () => close(opts.check || opts.collect ? null : null);
      if (opts.onOpen) opts.onOpen(d, { close: v => close(v) });
      // 読み取り専用の欄 (ソース・フォルダーなど) は飛ばして、入力できる最初の欄にフォーカスする
      const first = $('input[type=text]:not([readonly]):not([disabled])', d);
      if (first) { first.focus(); first.select(); } else { const def = $('.dlg-btn.default', d); if (def) def.focus(); }
    });
  }
  function showError(title, msg) { return dialog({ title, message: msg, icon: 'error' }); }

  function validIdent(s) { return /^[A-Za-z_$][\w$]*$/.test(s) && !['abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char', 'class', 'const', 'continue', 'default', 'do', 'double', 'else', 'enum', 'extends', 'final', 'finally', 'float', 'for', 'goto', 'if', 'implements', 'import', 'instanceof', 'int', 'interface', 'long', 'native', 'new', 'package', 'private', 'protected', 'public', 'return', 'short', 'static', 'strictfp', 'super', 'switch', 'synchronized', 'this', 'throw', 'throws', 'transient', 'try', 'void', 'volatile', 'while', 'true', 'false', 'null', 'var', 'record', 'yield'].includes(s); }

  // ---------- 新規 Java プロジェクト ----------
  async function newProjectWizard() {
    const exists = n => projects().includes(n) || dirs.has(n);
    const r = await dialog({
      title: '新規 Java プロジェクト', width: 560, help: true,
      banner: { title: 'Java プロジェクトの作成', message: 'ワークスペースまたは外部ロケーションに Java プロジェクトを作成します。' },
      html: `<div class="row"><label>プロジェクト名(<u>P</u>):</label><input type="text" id="np-name" spellcheck="false"><span></span></div>
        <label class="chk"><input type="checkbox" checked disabled>デフォルト・ロケーションを使用(<u>D</u>)</label>
        <div class="row"><label style="padding-left:18px">ロケーション(<u>L</u>):</label><input type="text" id="np-loc" readonly><span></span></div>
        <fieldset><legend>JRE</legend>
          <label class="chk"><input type="radio" name="jre" checked>実行環境 JRE の使用(<u>V</u>):
            <select id="np-jre" style="width:auto;margin-left:6px"><option>JavaSE-21</option><option>JavaSE-17</option></select></label>
          <label class="chk"><input type="radio" name="jre" disabled>プロジェクト固有の JRE を使用(<u>S</u>)</label>
          <label class="chk"><input type="radio" name="jre" disabled>デフォルト JRE を使用 (現在は 'JavaSE-21')</label>
        </fieldset>
        <fieldset><legend>プロジェクト・レイアウト</legend>
          <label class="chk"><input type="radio" name="lay" disabled>プロジェクト・フォルダーをソースおよびクラス・ファイルのルートとして使用(<u>U</u>)</label>
          <label class="chk"><input type="radio" name="lay" checked>ソースおよびクラス・ファイルのために別のフォルダーを作成(<u>C</u>)</label>
        </fieldset>
        <fieldset><legend>モジュール</legend>
          <label class="chk"><input type="checkbox" id="np-mod">module-info.java ファイルの作成</label>
        </fieldset>`,
      buttons: [{ label: '< 戻る(B)', value: 'back' }, { label: '次へ(N) >', value: 'next' }, {
        label: '完了(F)', value: 'ok', default: true,
        validate: d => !$('[data-b="2"]', d).disabled,
      }, { label: '取り消し', value: null }],
      collect: d => ({ name: $('#np-name', d).value.trim(), jre: $('#np-jre', d).value, module: $('#np-mod', d).checked }),
      onOpen: (d) => {
        $('[data-b="0"]', d).disabled = true; $('[data-b="1"]', d).disabled = true;
        const upd = () => {
          const n = $('#np-name', d).value.trim();
          $('#np-loc', d).value = (Storage.rootPath ? Storage.rootPath.replace(/\\/g, '/') + '/' : 'work/') + n;
          let msg = '', bad = false;
          if (!n) { msg = 'プロジェクト名を入力してください。'; bad = true; }
          else if (!/^[A-Za-z0-9_\-.]+$/.test(n) || n.startsWith('.')) { msg = 'お手軽Java では、プロジェクト名に半角の英数字と _ - . だけが使えます。'; bad = true; }
          else if (exists(n)) { msg = '同じ名前のプロジェクトがすでに存在します。'; bad = true; }
          $('#dlg-msg', d).innerHTML = msg ? (n ? ICON_SVG.error : '') + ' ' + esc(msg) : 'ワークスペースまたは外部ロケーションに Java プロジェクトを作成します。';
          $('[data-b="2"]', d).disabled = bad;
        };
        $('#np-name', d).addEventListener('input', upd);
        upd();
      },
    });
    if (!r || r.value !== 'ok') return;
    await createProject(r.name, +r.jre.replace('JavaSE-', ''), r.module);
  }
  async function createProject(name, jre, module) {
    const proj = `<?xml version="1.0" encoding="UTF-8"?>\n<projectDescription>\n\t<name>${name}</name>\n\t<comment></comment>\n\t<projects>\n\t</projects>\n\t<buildSpec>\n\t\t<buildCommand>\n\t\t\t<name>org.eclipse.jdt.core.javabuilder</name>\n\t\t\t<arguments>\n\t\t\t</arguments>\n\t\t</buildCommand>\n\t</buildSpec>\n\t<natures>\n\t\t<nature>org.eclipse.jdt.core.javanature</nature>\n\t</natures>\n</projectDescription>\n`;
    const cp = `<?xml version="1.0" encoding="UTF-8"?>\n<classpath>\n\t<classpathentry kind="con" path="org.eclipse.jdt.launching.JRE_CONTAINER/org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType/JavaSE-${jre}">\n\t\t<attributes>\n\t\t\t<attribute name="module" value="true"/>\n\t\t</attributes>\n\t</classpathentry>\n\t<classpathentry kind="src" path="src"/>\n\t<classpathentry kind="output" path="bin"/>\n</classpath>\n`;
    const prefs = `eclipse.preferences.version=1\norg.eclipse.jdt.core.compiler.codegen.targetPlatform=${jre}\norg.eclipse.jdt.core.compiler.compliance=${jre}\norg.eclipse.jdt.core.compiler.source=${jre}\norg.eclipse.jdt.core.compiler.release=enabled\n`;
    try {
      await Storage.mkdir(name); dirs.add(name);
      await Storage.mkdir(name + '/src'); dirs.add(name + '/src');
      await writeNew(name + '/.project', proj);
      await writeNew(name + '/.classpath', cp);
      await writeNew(name + '/.settings/org.eclipse.jdt.core.prefs', prefs);
      if (module) await writeNew(name + '/src/module-info.java', `module ${name.replace(/[^\w]/g, '_')} {\n}\n`);
      ui.hiddenProjects = (ui.hiddenProjects || []).filter(p => p !== name);
      expanded.add('P:' + name);
      expanded.add('S:' + name + '/src');
      selected = 'P:' + name;
      renderExplorer(); updateWelcome();
      status(`プロジェクト '${name}' を作成しました`);
      requestBuild(name);
    } catch (e) { showError('プロジェクトを作成できません', e.message); }
  }
  async function writeNew(path, content) {
    await Storage.writeFile(path, content);
    files.set(path, content);
    let d = parentOf(path);
    while (d) { dirs.add(d); d = parentOf(d); }
  }

  // ---------- 新規 Java パッケージ ----------
  async function newPackageWizard() {
    const c = selectionContext();
    if (!c.project) { await dialog({ title: '新規 Java パッケージ', message: '先に Java プロジェクトを作成してください。\n(ファイル → 新規 → Java プロジェクト)', icon: 'info' }); return; }
    const initial = c.pkgDir ? pkgOfDir(c.pkgDir) : '';
    const r = await dialog({
      title: '新規 Java パッケージ', width: 520, help: true,
      banner: { title: 'Java パッケージ', message: '新規 Java パッケージを作成します。' },
      html: `<div class="hint" style="margin-bottom:8px">パッケージに対応するフォルダーを作成します。</div>
        <div class="row"><label>ソース・フォルダー(<u>D</u>):</label><input type="text" id="pk-src" value="${esc(srcRoot(c.project))}" readonly><button class="dlg-btn" disabled>参照(<u>O</u>)...</button></div>
        <div class="row"><label>名前(<u>M</u>):</label><input type="text" id="pk-name" value="${esc(initial)}" spellcheck="false"><span></span></div>
        <label class="chk"><input type="checkbox" disabled>package-info.java を作成(<u>C</u>)</label>`,
      buttons: [{ label: '完了(F)', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({ name: $('#pk-name', d).value.trim() }),
      onOpen: d => {
        const upd = () => {
          const n = $('#pk-name', d).value.trim();
          let msg = '', level = '';
          if (!n) { msg = 'パッケージ名が空です。'; level = 'error'; }
          else if (!n.split('.').every(validIdent)) { msg = `'${n}' は有効な Java 識別子ではありません。`; level = 'error'; }
          else if (dirs.has(srcRoot(c.project) + '/' + n.replace(/\./g, '/')) && (packagesOf(c.project).includes(srcRoot(c.project) + '/' + n.replace(/\./g, '/')))) { msg = 'パッケージはすでに存在します。'; level = 'error'; }
          else if (/[A-Z]/.test(n)) { msg = '規則により、パッケージ名は小文字で始まります。'; level = 'warning'; }
          $('#dlg-msg', d).innerHTML = msg ? (level === 'error' ? ICON_SVG.error : ICON_SVG.warning) + ' ' + esc(msg) : '新規 Java パッケージを作成します。';
          $('[data-b="0"]', d).disabled = level === 'error';
        };
        $('#pk-name', d).addEventListener('input', upd);
        upd();
      },
    });
    if (!r || r.value !== 'ok') return;
    const dir = srcRoot(c.project) + '/' + r.name.replace(/\./g, '/');
    try {
      await Storage.mkdir(dir);
      let x = dir; while (x) { dirs.add(x); x = parentOf(x); }
      expanded.add('P:' + c.project); expanded.add('S:' + srcRoot(c.project));
      selected = 'K:' + dir;
      renderExplorer();
      status(`パッケージ '${r.name}' を作成しました`);
    } catch (e) { showError('パッケージを作成できません', e.message); }
  }

  // ---------- 新規 Java クラス / インターフェース ----------
  async function newTypeWizard(kind) {
    const c = selectionContext();
    if (!c.project) { await dialog({ title: kind === 'class' ? '新規 Java クラス' : '新規 Java インターフェース', message: '先に Java プロジェクトを作成してください。\n(ファイル → 新規 → Java プロジェクト)', icon: 'info' }); return; }
    const isClass = kind === 'class';
    const pkg = c.pkgDir ? pkgOfDir(c.pkgDir) : '';
    const title = isClass ? '新規 Java クラス' : '新規 Java インターフェース';
    const r = await dialog({
      title, width: 600, help: true,
      banner: { title: isClass ? 'Java クラス' : 'Java インターフェース', message: isClass ? '新規 Java クラスを作成します。' : '新規インターフェースを作成します。' },
      html: `<div class="row"><label>ソース・フォルダー(<u>D</u>):</label><input type="text" value="${esc(srcRoot(c.project))}" readonly><button class="dlg-btn" disabled>参照(<u>O</u>)...</button></div>
        <div class="row"><label>パッケージ(<u>K</u>):</label><input type="text" id="nt-pkg" value="${esc(pkg)}" spellcheck="false"><button class="dlg-btn" id="nt-pkgbtn">参照(<u>W</u>)...</button></div>
        <div class="row"><label><input type="checkbox" disabled> エンクロージング型(<u>Y</u>):</label><input type="text" readonly><button class="dlg-btn" disabled>参照(<u>W</u>)...</button></div>
        <hr style="border:none;border-top:1px solid var(--border-light)">
        <div class="row"><label>名前(<u>M</u>):</label><input type="text" id="nt-name" spellcheck="false"><span></span></div>
        <div class="row"><label>修飾子:</label><div>
          <label><input type="radio" name="vis" value="public" checked> public(<u>P</u>)</label>&nbsp;
          <label><input type="radio" name="vis" value=""> パッケージ(<u>C</u>)</label>&nbsp;
          <label style="color:#999"><input type="radio" disabled> private(<u>V</u>)</label>&nbsp;
          <label style="color:#999"><input type="radio" disabled> protected(<u>T</u>)</label><br>
          ${isClass ? `<label><input type="checkbox" id="nt-abstract"> abstract(<u>T</u>)</label>&nbsp; <label><input type="checkbox" id="nt-final"> final(<u>L</u>)</label>&nbsp; <label style="color:#999"><input type="checkbox" disabled> static(<u>C</u>)</label>` : ''}
        </div><span></span></div>
        ${isClass ? `<div class="row"><label>スーパークラス(<u>S</u>):</label><input type="text" id="nt-super" value="java.lang.Object" spellcheck="false"><button class="dlg-btn" disabled>参照(<u>E</u>)...</button></div>` : ''}
        <div class="row"><label>${isClass ? 'インターフェース(<u>I</u>):' : '拡張インターフェース(<u>I</u>):'}</label><input type="text" id="nt-ifaces" placeholder="(カンマ区切りで入力)" spellcheck="false"><span></span></div>
        ${isClass ? `<div style="margin:8px 0 2px">どのメソッド・スタブを作成しますか?</div>
          <div style="padding-left:16px">
            <label class="chk"><input type="checkbox" id="nt-main">public static void main(String[] args)(<u>V</u>)</label>
            <label class="chk"><input type="checkbox" id="nt-ctors">スーパークラスからのコンストラクター(<u>U</u>)</label>
            <label class="chk"><input type="checkbox" id="nt-inherit" checked>継承された抽象メソッド(<u>H</u>)</label>
          </div>` : ''}
        <div style="margin:8px 0 2px">コメントを追加しますか? (テンプレートの構成およびデフォルト値については<span style="color:var(--link)">ここ</span>を参照)</div>
        <div style="padding-left:16px"><label class="chk"><input type="checkbox" id="nt-comment">コメントの生成(<u>G</u>)</label></div>`,
      buttons: [{ label: '完了(F)', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({
        pkg: $('#nt-pkg', d).value.trim(), name: $('#nt-name', d).value.trim(),
        vis: ($('input[name=vis]:checked', d) || {}).value,
        abstract: isClass && $('#nt-abstract', d).checked, final: isClass && $('#nt-final', d).checked,
        sup: isClass ? $('#nt-super', d).value.trim() : '', ifaces: $('#nt-ifaces', d).value.trim(),
        main: isClass && $('#nt-main', d).checked, ctors: isClass && $('#nt-ctors', d).checked,
        comment: $('#nt-comment', d).checked,
      }),
      onOpen: d => {
        const upd = () => {
          const p = $('#nt-pkg', d).value.trim(), n = $('#nt-name', d).value.trim();
          let msg = '', level = '';
          const path = srcRoot(c.project) + '/' + (p ? p.replace(/\./g, '/') + '/' : '') + n + '.java';
          if (p && !p.split('.').every(validIdent)) { msg = `'${p}' は有効な Java 識別子ではありません。`; level = 'error'; }
          else if (!n) { msg = '型名が空です。'; level = 'error'; }
          else if (!validIdent(n)) { msg = n.includes('.') ? '型名は修飾できません。' : `'${n}' は有効な Java 識別子ではありません。`; level = 'error'; }
          else if (files.has(path)) { msg = '型はすでに存在します。'; level = 'error'; }
          else if (!p) { msg = 'デフォルト・パッケージの使用は推奨されません。'; level = 'warning'; }
          else if (/^[a-z]/.test(n)) { msg = '規則により、Java 型名は大文字で始まります。'; level = 'warning'; }
          $('#dlg-msg', d).innerHTML = msg ? (level === 'error' ? ICON_SVG.error : ICON_SVG.warning) + ' ' + esc(msg) : (isClass ? '新規 Java クラスを作成します。' : '新規インターフェースを作成します。');
          $('[data-b="0"]', d).disabled = level === 'error';
        };
        $('#nt-pkg', d).addEventListener('input', upd);
        $('#nt-name', d).addEventListener('input', upd);
        $('#nt-pkgbtn', d).onclick = async () => {
          const pk = packagesOf(c.project).map(pkgOfDir);
          const sel = await pickFromList('パッケージの選択', 'パッケージを選択してください:', pk.length ? pk : ['(デフォルト・パッケージ)']);
          if (sel != null) { $('#nt-pkg', d).value = sel === '(デフォルト・パッケージ)' ? '' : sel; upd(); }
          setTimeout(() => $('#nt-name', d).focus(), 0);
        };
        upd();
        setTimeout(() => $('#nt-name', d).focus(), 0);
      },
    });
    if (!r || r.value !== 'ok') return;
    const ind = settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t';
    const mods = [r.vis, r.abstract ? 'abstract' : '', r.final ? 'final' : ''].filter(Boolean).join(' ');
    let header = '';
    if (r.pkg) header += `package ${r.pkg};\n\n`;
    let decl = (mods ? mods + ' ' : '') + (isClass ? 'class ' : 'interface ') + r.name;
    if (isClass && r.sup && r.sup !== 'java.lang.Object' && r.sup !== 'Object') decl += ' extends ' + r.sup.split('.').pop();
    if (r.ifaces) decl += (isClass ? ' implements ' : ' extends ') + r.ifaces.split(',').map(s => s.trim().split('.').pop()).filter(Boolean).join(', ');
    const imports = [];
    if (isClass && r.sup && r.sup.includes('.') && !r.sup.startsWith('java.lang.')) imports.push(r.sup);
    for (const i of (r.ifaces || '').split(',').map(s => s.trim())) if (i.includes('.') && !i.startsWith('java.lang.')) imports.push(i);
    if (imports.length) header += imports.map(i => `import ${i};`).join('\n') + '\n\n';
    let body = '';
    if (r.ctors && isClass) body += `\n${ind}public ${r.name}() {\n${ind}${ind}// TODO 自動生成されたコンストラクター・スタブ\n${ind}}\n`;
    if (r.main) body += `\n${ind}public static void main(String[] args) {\n${ind}${ind}// TODO 自動生成されたメソッド・スタブ\n\n${ind}}\n`;
    const comment = r.comment ? '/**\n * \n */\n' : '';
    const code = `${header}${comment}${decl} {\n${body}\n}\n`;
    const path = srcRoot(c.project) + '/' + (r.pkg ? r.pkg.replace(/\./g, '/') + '/' : '') + r.name + '.java';
    try {
      if (r.pkg) { const dir = parentOf(path); await Storage.mkdir(dir); let x = dir; while (x) { dirs.add(x); x = parentOf(x); } }
      await writeNew(path, code);
      fileChanged(path);
      revealInExplorer(path);
      const ed = openEditor(path);
      // カーソルを main の中 (または本体) に置く
      const lines = code.split('\n');
      const li = lines.findIndex(l => l.includes('TODO 自動生成されたメソッド・スタブ'));
      if (li >= 0) gotoPos(ed, li + 1, (ind + ind).length);
      else gotoPos(ed, lines.findIndex(l => l.includes('{')) + 1, ind.length);
    } catch (e) { showError('作成できません', e.message); }
  }

  async function pickFromList(title, message, items) {
    let picked = null;
    const r = await dialog({
      title, width: 420, message,
      html: `<input type="text" id="pl-filter" placeholder="絞り込み" style="width:100%;margin:8px 0 4px;padding:3px"><div class="dlg-list" id="pl-list">${items.map((x, i) => `<div class="li" data-i="${i}" tabindex="0">${Assist.ICONS.package} ${esc(x)}</div>`).join('')}</div>`,
      buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: () => ({ picked }),
      onOpen: (d, api) => {
        const list = $('#pl-list', d);
        const select = el => { $$('.li', list).forEach(x => x.style.background = ''); el.style.background = 'var(--sel)'; picked = items[+el.dataset.i]; };
        $$('.li', list).forEach(el => { el.onclick = () => select(el); el.ondblclick = () => { select(el); api.close({ value: 'ok', picked }); }; });
        const first = $('.li', list); if (first) select(first);
        $('#pl-filter', d).addEventListener('input', e => { const q = e.target.value.toLowerCase(); $$('.li', list).forEach(el => el.style.display = items[+el.dataset.i].toLowerCase().includes(q) ? '' : 'none'); });
      },
    });
    return r && r.value === 'ok' ? r.picked : null;
  }

  // ---------- 削除・名前変更 ----------
  async function deleteSelected() {
    const id = selected;
    if (!id || id.startsWith('S:') || id.startsWith('J:')) return;
    const path = id.slice(2);
    if (id.startsWith('P:')) {
      const r = await dialog({
        title: 'リソースの削除', icon: 'warning',
        message: `プロジェクト '${path}' をワークスペースから削除してもよろしいですか?`,
        check: 'ディスク上からプロジェクト・コンテンツを削除 (元に戻せません)',
        buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取り消し', value: null }],
      });
      if (!r || r.value !== 'ok') return;
      for (const e of editors.filter(e => projectOf(e.path) === path)) { e.gen = e.cm.changeGeneration(true); await closeEditor(e); }
      if (r.checked) {
        try { await Storage.deleteDir(path); } catch (e) { showError('削除できません', e.message); return; }
        for (const f of [...files.keys()]) if (projectOf(f) === path) files.delete(f);
        for (const d of [...dirs]) if (d === path || d.startsWith(path + '/')) dirs.delete(d);
        if (Storage.mode === 'server') status(`'${path}' をごみ箱に移動しました`);
      } else {
        ui.hiddenProjects = [...new Set([...(ui.hiddenProjects || []), path])];
        saveUi();
        status(`'${path}' をワークスペースから外しました (ファイルは残っています。ファイル → インポート で戻せます)`);
      }
      problems.delete(path);
    } else {
      const isFile = id.startsWith('F:');
      const name = isFile ? baseName(path) : pkgOfDir(path);
      const r = await dialog({ title: 'リソースの削除', icon: 'warning', message: `'${name}' を削除してもよろしいですか?` + (Storage.mode === 'server' ? '\n(ファイルはごみ箱に移動します)' : ''), buttons: [{ label: 'OK', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!r) return;
      try {
        if (isFile) {
          const ed = editors.find(e => e.path === path);
          if (ed) { ed.gen = ed.cm.changeGeneration(true); await closeEditor(ed); }
          await Storage.deleteFile(path);
          files.delete(path);
        } else {
          for (const e of editors.filter(e => e.path.startsWith(path + '/') && parentOf(e.path) === path)) { e.gen = e.cm.changeGeneration(true); await closeEditor(e); }
          // パッケージの削除は、そのフォルダーの .java だけ (子パッケージは残す)
          const own = [...files.keys()].filter(f => parentOf(f) === path);
          for (const f of own) { await Storage.deleteFile(f); files.delete(f); }
          const hasChild = [...dirs].some(d => d.startsWith(path + '/')) || [...files.keys()].some(f => f.startsWith(path + '/'));
          if (!hasChild) { await Storage.deleteDir(path); dirs.delete(path); }
        }
      } catch (e) { showError('削除できません', e.message); return; }
      fileChanged(path);
    }
    selected = null;
    renderExplorer(); renderMarkers(); updateWelcome();
  }

  async function renameSelected() {
    const id = selected || (active ? 'F:' + active.path : null);
    if (!id || id.startsWith('S:') || id.startsWith('J:')) return;
    const path = id.slice(2);
    if (id.startsWith('P:')) { await dialog({ title: '名前変更', message: 'お手軽Java では、プロジェクトの名前は変更できません。', icon: 'info' }); return; }
    if (id.startsWith('F:') && isJava(path)) {
      const old = baseName(path).replace(/\.java$/, '');
      const nn = await promptText('コンパイル単位の名前変更', '新しい名前(M):', old, v => !validIdent(v) ? `'${v}' は有効な Java 識別子ではありません。` : (files.has(parentOf(path) + '/' + v + '.java') && v !== old ? '型はすでに存在します。' : ''));
      if (!nn || nn === old) return;
      await saveAll();
      const to = parentOf(path) + '/' + nn + '.java';
      const re = new RegExp('(?<![\\w$])' + old + '(?![\\w$])', 'g');
      try {
        await Storage.rename(path, to);
        const content = (files.get(path) || '').replace(re, nn);
        files.delete(path);
        await Storage.writeFile(to, content); files.set(to, content);
        // 同じプロジェクトで、この型を使っているファイルの参照も直す
        const project = projectOf(path);
        const pkg = pkgOfDir(parentOf(path));
        for (const f of javaFilesOf(project)) {
          if (f === to) continue;
          const src = files.get(f);
          const samePkg = parentOf(f) === parentOf(path);
          const imports = new RegExp('import\\s+' + (pkg ? pkg.replace(/\./g, '\\.') + '\\.' : '') + old + '\\s*;').test(src);
          if ((samePkg || imports) && re.test(src)) { re.lastIndex = 0; const n = src.replace(re, nn); await Storage.writeFile(f, n); files.set(f, n); const e2 = editors.find(e => e.path === f); if (e2) { e2.cm.setValue(n); e2.gen = e2.cm.changeGeneration(true); } }
          re.lastIndex = 0;
        }
        const ed = editors.find(e => e.path === path);
        if (ed) { ed.path = to; ed.cm.setValue(content); ed.gen = ed.cm.changeGeneration(true); }
        fileChanged(to);
        selected = 'F:' + to;
        renderExplorer(); renderTabs();
      } catch (e) { showError('名前を変更できません', e.message); }
      return;
    }
    if (id.startsWith('K:')) {
      const oldPkg = pkgOfDir(path);
      const project = projectOf(path);
      const nn = await promptText('パッケージの名前変更', '新しい名前(M):', oldPkg, v => !v.split('.').every(validIdent) ? `'${v}' は有効な Java 識別子ではありません。` : '');
      if (!nn || nn === oldPkg) return;
      await saveAll();
      const toDir = srcRoot(project) + '/' + nn.replace(/\./g, '/');
      try {
        const own = [...files.keys()].filter(f => parentOf(f) === path);
        await Storage.mkdir(toDir);
        for (const f of own) {
          const to = toDir + '/' + baseName(f);
          const c = files.get(f).replace(new RegExp('^(\\s*package\\s+)' + oldPkg.replace(/\./g, '\\.') + '(\\s*;)', 'm'), '$1' + nn + '$2');
          await Storage.writeFile(to, c); files.set(to, c);
          await Storage.deleteFile(f); files.delete(f);
          const ed = editors.find(e => e.path === f);
          if (ed) { ed.path = to; ed.cm.setValue(c); ed.gen = ed.cm.changeGeneration(true); }
        }
        // import の書き換え
        for (const f of javaFilesOf(project)) {
          const s = files.get(f);
          const n = s.replace(new RegExp('(import\\s+)' + oldPkg.replace(/\./g, '\\.') + '\\.', 'g'), '$1' + nn + '.');
          if (n !== s) { await Storage.writeFile(f, n); files.set(f, n); const ed = editors.find(e => e.path === f); if (ed) { ed.cm.setValue(n); ed.gen = ed.cm.changeGeneration(true); } }
        }
        const hasChild = [...dirs].some(d => d.startsWith(path + '/'));
        if (!hasChild) { try { await Storage.deleteDir(path); } catch (e) { /* 無視 */ } dirs.delete(path); }
        let x = toDir; while (x) { dirs.add(x); x = parentOf(x); }
        fileChanged(toDir + '/x.java');
        selected = 'K:' + toDir; expanded.add(selected);
        renderExplorer(); renderTabs();
      } catch (e) { showError('名前を変更できません', e.message); }
    }
  }

  function promptText(title, label, value, validate) {
    return dialog({
      title, width: 440,
      html: `<div class="row" style="grid-template-columns:120px 1fr"><label>${esc(label)}</label><input type="text" id="pt-v" value="${esc(value || '')}" spellcheck="false"></div><div id="pt-msg" class="hint" style="min-height:18px"></div>`,
      buttons: [{ label: 'OK', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({ text: $('#pt-v', d).value.trim() }),
      onOpen: d => {
        const upd = () => { const v = $('#pt-v', d).value.trim(); const m = validate ? validate(v) : ''; $('#pt-msg', d).textContent = m || ''; $('[data-b="0"]', d).disabled = !v || !!m; };
        $('#pt-v', d).addEventListener('input', upd); upd();
      },
    }).then(r => r && r.value === 'ok' ? r.text : null);
  }

  // ---------- getter / setter など ----------
  function currentTypeForGen() {
    if (!active || !isJava(active.path)) return null;
    const src = active.cm.getValue();
    const parsed = JavaSrc.parse(src);
    const t = JavaSrc.typeAt(parsed, active.cm.indexFromPos(active.cm.getCursor())) || parsed.types[0];
    return t && (t.kind === 'class' || t.kind === 'enum') ? { t, src } : null;
  }
  function insertBeforeClassEnd(t, text) {
    const cm = active.cm;
    const closePos = cm.posFromIndex(t.close);
    const lines = cm.getValue().split('\n');
    let end = closePos.line;
    // 閉じ括弧の前の空行を詰めて、メソッドを空行区切りで入れる
    let last = end - 1;
    while (last > 0 && !lines[last].trim()) last--;
    const from = { line: last, ch: lines[last].length };
    const to = { line: end, ch: closePos.ch };
    const ind = lines[end].match(/^\s*/)[0];
    cm.replaceRange('\n\n' + text + '\n\n' + ind, from, to, '+gen');
  }
  async function genGetSet() {
    const g = currentTypeForGen();
    if (!g) { status('クラスの中にカーソルを置いてください'); return; }
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    const existing = new Set(g.t.members.filter(m => m.kind === 'method').map(m => m.name));
    if (!fields.length) { await dialog({ title: 'getter および setter の生成', message: `型 '${g.t.name}' には getter または setter を必要とするフィールドがありません。`, icon: 'info' }); return; }
    const getName = f => (f.type === 'boolean' ? 'is' : 'get') + Assist.cap(f.name);
    const setName = f => 'set' + Assist.cap(f.name);
    const r = await dialog({
      title: 'getter および setter の生成', width: 520,
      html: `<div style="margin-bottom:4px">getter および setter を作成するフィールドを選択してください(<u>S</u>):</div>
        <div style="display:grid;grid-template-columns:1fr auto;gap:8px">
        <div class="dlg-list" id="gs-list">${fields.map((f, i) => {
          const fin = f.mods.includes('final');
          return `<label class="li"><input type="checkbox" data-f="${i}" class="gs-f">${Assist.memberIcon(f)} ${esc(f.name)}</label>
            <label class="li sub"><input type="checkbox" data-g="${i}" ${existing.has(getName(f)) ? 'disabled' : ''}>${Assist.ICONS.methodPublic} ${esc(getName(f))}()</label>
            ${fin ? '' : `<label class="li sub"><input type="checkbox" data-s="${i}" ${existing.has(setName(f)) ? 'disabled' : ''}>${Assist.ICONS.methodPublic} ${esc(setName(f))}(${esc(f.type)})</label>`}`;
        }).join('')}</div>
        <div class="dlg-side"><button class="dlg-btn" id="gs-all">すべて選択(<u>A</u>)</button><button class="dlg-btn" id="gs-none">選択をすべて解除(<u>D</u>)</button><button class="dlg-btn" id="gs-get">getter の選択(<u>G</u>)</button><button class="dlg-btn" id="gs-set">setter の選択(<u>T</u>)</button></div></div>
        <div class="row" style="margin-top:10px"><label>挿入ポイント(<u>I</u>):</label><select id="gs-pos"><option value="last">最後のメンバー</option><option value="cursor">カーソル位置</option></select><span></span></div>
        <div class="row"><label>アクセス修飾子:</label><div><label><input type="radio" checked> public</label> <label style="color:#999"><input type="radio" disabled> protected</label> <label style="color:#999"><input type="radio" disabled> パッケージ</label> <label style="color:#999"><input type="radio" disabled> private</label></div><span></span></div>
        <div id="gs-count" class="hint"></div>`,
      buttons: [{ label: '生成(G)', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: d => ({
        gets: $$('[data-g]', d).filter(x => x.checked && !x.disabled).map(x => +x.dataset.g),
        sets: $$('[data-s]', d).filter(x => x.checked && !x.disabled).map(x => +x.dataset.s),
        pos: $('#gs-pos', d).value,
      }),
      onOpen: d => {
        const count = () => { const n = $$('[data-g],[data-s]', d).filter(x => x.checked && !x.disabled).length; $('#gs-count', d).textContent = `${n} / ${$$('[data-g],[data-s]', d).filter(x => !x.disabled).length} 個選択されています。`; };
        const setAll = (sel, v) => { $$(sel, d).forEach(x => { if (!x.disabled) x.checked = v; }); sync(); };
        const sync = () => { $$('.gs-f', d).forEach(fb => { const i = fb.dataset.f; const subs = $$(`[data-g="${i}"],[data-s="${i}"]`, d).filter(x => !x.disabled); fb.checked = subs.length > 0 && subs.every(x => x.checked); fb.indeterminate = !fb.checked && subs.some(x => x.checked); }); count(); };
        $$('.gs-f', d).forEach(fb => fb.addEventListener('change', () => { $$(`[data-g="${fb.dataset.f}"],[data-s="${fb.dataset.f}"]`, d).forEach(x => { if (!x.disabled) x.checked = fb.checked; }); sync(); }));
        $$('[data-g],[data-s]', d).forEach(x => x.addEventListener('change', sync));
        $('#gs-all', d).onclick = () => setAll('[data-g],[data-s]', true);
        $('#gs-none', d).onclick = () => setAll('[data-g],[data-s]', false);
        $('#gs-get', d).onclick = () => { setAll('[data-s]', false); setAll('[data-g]', true); };
        $('#gs-set', d).onclick = () => { setAll('[data-g]', false); setAll('[data-s]', true); };
        sync();
      },
    });
    if (!r || r.value !== 'ok' || (!r.gets.length && !r.sets.length)) return;
    const ind = settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t';
    const parts = [];
    fields.forEach((f, i) => {
      if (r.gets.includes(i)) parts.push(Assist.genGetter(f, ind));
      if (r.sets.includes(i)) parts.push(Assist.genSetter(Object.assign({ owner: g.t.name }, f), ind, false));
    });
    if (r.pos === 'cursor') {
      const c = active.cm.getCursor();
      active.cm.replaceRange(parts.join('\n\n') + '\n\n', { line: c.line, ch: 0 }, null, '+gen');
    } else insertBeforeClassEnd(g.t, parts.join('\n\n'));
  }
  async function genToString() {
    const g = currentTypeForGen();
    if (!g) { status('クラスの中にカーソルを置いてください'); return; }
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    const r = await fieldPicker('toString() の生成', 'toString() に含めるフィールドとメソッドを選択してください(<u>S</u>):', fields, true);
    if (!r) return;
    if (g.t.members.some(m => m.kind === 'method' && m.name === 'toString' && !m.params.length)) {
      const ok = await dialog({ title: 'toString() の生成', message: `型 '${g.t.name}' のメソッド toString() はすでに存在します。置き換えますか?`, icon: 'warning', buttons: [{ label: 'はい', value: true, default: true }, { label: 'いいえ', value: false }] });
      if (!ok) return;
      removeMethod(g.t, 'toString');
      return genToStringAfterRemove(r);
    }
    insertBeforeClassEnd(g.t, Assist.genToString(g.t, fields.filter((f, i) => r.includes(i)), settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t'));
  }
  function genToStringAfterRemove(sel) {
    const g = currentTypeForGen();
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    insertBeforeClassEnd(g.t, Assist.genToString(g.t, fields.filter((f, i) => sel.includes(i)), settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t'));
  }
  function removeMethod(t, name) {
    const cm = active.cm;
    const m = t.members.find(x => x.kind === 'method' && x.name === name && !x.params.length);
    if (!m) return;
    const b = JavaSrc.blank(cm.getValue());
    let start = cm.indexFromPos({ line: m.line, ch: 0 });
    // 直前のアノテーション行も含める
    let ln = m.line;
    while (ln > 0 && /^\s*@\w+/.test(cm.getLine(ln - 1))) ln--;
    start = cm.indexFromPos({ line: ln, ch: 0 });
    let i = b.indexOf('{', cm.indexFromPos({ line: m.line, ch: 0 }));
    let depth = 0;
    for (; i < b.length; i++) { if (b[i] === '{') depth++; else if (b[i] === '}') { depth--; if (depth === 0) break; } }
    const endPos = cm.posFromIndex(i + 1);
    cm.replaceRange('', cm.posFromIndex(start), { line: endPos.line + 1, ch: 0 });
  }
  async function genCtor() {
    const g = currentTypeForGen();
    if (!g) { status('クラスの中にカーソルを置いてください'); return; }
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    let omit = false;
    const r = await fieldPicker('フィールドを使用してコンストラクターを生成', 'コンストラクターで初期化するフィールドを選択してください(<u>S</u>):', fields, true, '<label class="chk" style="margin-top:8px"><input type="checkbox" id="fp-omit">スーパー・コンストラクターの呼び出しを省略(<u>O</u>)</label>', d => { omit = $('#fp-omit', d).checked; });
    if (!r) return;
    const ind = settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t';
    const text = Assist.genCtor(g.t, fields.filter((f, i) => r.includes(i)), ind, omit);
    // 最後のフィールドの後ろに入れる
    const cm = active.cm;
    const lastField = fields[fields.length - 1];
    if (lastField) {
      const line = lastField.line;
      cm.replaceRange('\n\n' + text, { line, ch: cm.getLine(line).length }, null, '+gen');
    } else insertBeforeClassEnd(g.t, text);
  }
  async function fieldPicker(title, label, fields, all, extraHtml, onCollect) {
    const r = await dialog({
      title, width: 480,
      html: `<div style="margin-bottom:4px">${label}</div><div style="display:grid;grid-template-columns:1fr auto;gap:8px">
        <div class="dlg-list">${fields.map((f, i) => `<label class="li"><input type="checkbox" data-f="${i}" ${all ? 'checked' : ''}>${Assist.memberIcon(f)} ${esc(f.name)} : ${esc(f.type)}</label>`).join('') || '<div class="hint" style="padding:6px">(フィールドなし)</div>'}</div>
        <div class="dlg-side"><button class="dlg-btn" id="fp-all">すべて選択(<u>A</u>)</button><button class="dlg-btn" id="fp-none">選択をすべて解除(<u>D</u>)</button></div></div>${extraHtml || ''}`,
      buttons: [{ label: '生成(G)', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: d => { if (onCollect) onCollect(d); return { sel: $$('[data-f]', d).filter(x => x.checked).map(x => +x.dataset.f) }; },
      onOpen: d => { $('#fp-all', d).onclick = () => $$('[data-f]', d).forEach(x => x.checked = true); $('#fp-none', d).onclick = () => $$('[data-f]', d).forEach(x => x.checked = false); },
    });
    return r && r.value === 'ok' ? r.sel : null;
  }

  // ---------- インポートの編成 ----------
  async function organizeImports() {
    if (!active || !isJava(active.path)) return;
    const cm = active.cm;
    const src = cm.getValue();
    const info = Assist.organizeImports(src);
    const chosen = [];
    for (const a of info.ambiguous) {
      const sel = await pickFromList('インポートの編成', `インポートする型を選択してください: ${a.name}`, a.pkgs.map(p => p + '.' + a.name));
      if (sel) chosen.push(sel);
    }
    const out = Assist.applyImports(src, info, chosen);
    if (out !== src) {
      const cur = cm.getCursor();
      const scroll = cm.getScrollInfo();
      cm.operation(() => { cm.setValue(out); cm.setCursor(cur); cm.scrollTo(scroll.left, scroll.top); });
    }
    status('インポートを編成しました');
  }
  async function addImportAtCursor() {
    if (!active) return;
    const cm = active.cm;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch, e = c.ch;
    while (s > 0 && /\w/.test(line[s - 1])) s--;
    while (e < line.length && /\w/.test(line[e])) e++;
    const w = line.slice(s, e);
    const cands = (Assist.allClassNames().get(w) || []).filter(x => x.pkg !== 'java.lang');
    if (!cands.length) { status(`'${w}' のインポートは見つかりません`); return; }
    let pkg = cands[0].pkg;
    if (cands.length > 1) { const sel = await pickFromList('インポートの追加', 'インポートする型を選択してください:', cands.map(x => x.pkg + '.' + w)); if (!sel) return; pkg = sel.slice(0, sel.lastIndexOf('.')); }
    Assist.addImport(cm, w, pkg);
  }

  // ---------- 宣言を開く (F3 / Ctrl+クリック) ----------
  function openDeclaration(ed, pos) {
    const cm = ed.cm;
    pos = pos || cm.getCursor();
    const line = cm.getLine(pos.line);
    let s = pos.ch, e = pos.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    while (e < line.length && /[\w$]/.test(line[e])) e++;
    const w = line.slice(s, e);
    if (!w) return;
    const src = cm.getValue();
    const parsed = JavaSrc.parse(src);
    const before = line.slice(0, s);
    // 型
    const types = currentProjectTypes().filter(t => t.name === w);
    if (types.length && !/\.\s*$/.test(before)) {
      const t = types.find(x => x.pkg === parsed.pkg) || types[0];
      openEditor(t.path, { line: t.type.line, flash: true });
      return;
    }
    // メンバー (this. または修飾なし)
    const curT = JavaSrc.typeAt(parsed, cm.indexFromPos(pos));
    if (/\.\s*$/.test(before)) {
      const expr = before.replace(/\.\s*$/, '').match(/([\w$]+)\s*$/);
      if (expr) {
        const vt = JavaSrc.varType(src, cm.indexFromPos(pos), expr[1], parsed) || (types.length ? null : expr[1]);
        const tn = JavaSrc.simpleName(vt || '');
        const pt = currentProjectTypes().find(t => t.name === tn);
        if (pt) {
          const m = pt.type.members.find(x => x.name === w);
          openEditor(pt.path, { line: m ? m.line : pt.type.line, flash: true });
          return;
        }
      }
    }
    // ローカル変数の宣言
    const b = JavaSrc.blank(src).slice(0, cm.indexFromPos({ line: pos.line, ch: s }));
    const re = new RegExp('[\\w>\\]]\\s+' + w + '\\s*(?=[=;,):])', 'g');
    let m, last = null;
    while ((m = re.exec(b))) last = m;
    if (last) { const p = cm.posFromIndex(last.index + last[0].indexOf(w, 1)); gotoPos(ed, p.line, p.ch, true); return; }
    if (curT) {
      const mem = curT.members.find(x => x.name === w);
      if (mem) { gotoPos(ed, mem.line, 0, true); return; }
    }
    status(`'${w}' の宣言が見つかりません`);
  }

  function currentProjectTypes() {
    const proj = active ? projectOf(active.path) : (projects()[0] || '');
    const out = [];
    for (const f of javaFilesOf(proj)) {
      const src = contentOf(f) || '';
      let parsed;
      try { parsed = JavaSrc.parse(src); } catch (e) { continue; }
      for (const t of parsed.types) out.push({ name: t.name, pkg: parsed.pkg, kind: t.kind, type: t, path: f });
    }
    return out;
  }

  // ---------- クイック・フィックス (Ctrl+1) ----------
  function quickFix(ed, lineArg) {
    ed = ed || active;
    if (!ed) return;
    const cm = ed.cm;
    const line = lineArg != null ? lineArg : cm.getCursor().line;
    const list = (problems.get(projectOf(ed.path)) || []).filter(p => p.path === ed.path && p.line === line);
    const items = [];
    for (const p of list) {
      let m;
      if ((m = p.msg.match(/^(\w+) を型に解決できません/)) || (m = p.msg.match(/^(\w+) cannot be resolved to a type/))) {
        for (const c of (Assist.allClassNames().get(m[1]) || []).filter(x => x.pkg !== 'java.lang')) {
          items.push({ label: `'${m[1]}' をインポートします (${c.pkg})`, icon: 'bulb', action: () => Assist.addImport(cm, m[1], c.pkg) });
        }
        items.push({ label: `クラス '${m[1]}' を作成します`, icon: 'class', action: () => { selected = 'K:' + parentOf(ed.path); newTypeWizard('class').then(() => {}); } });
      } else if ((m = p.msg.match(/^(\w+) を解決できません/)) && /^[a-z]/.test(m[1])) {
        const cap = m[1].charAt(0).toUpperCase() + m[1].slice(1);
        if (Assist.allClassNames().has(cap)) items.push({ label: `'${cap}' に変更します`, icon: 'bulb', action: () => replaceWordAt(cm, p, m[1], cap) });
      } else if (/インポート .* は使用されていません|is never used/.test(p.msg) && /import/.test(cm.getLine(line))) {
        items.push({ label: 'インポートを除去します', icon: 'bulb', action: () => cm.replaceRange('', { line, ch: 0 }, { line: line + 1, ch: 0 }) });
        items.push({ label: 'インポートを編成します', icon: 'bulb', action: () => organizeImports() });
      } else if ((m = p.msg.match(/"(.+?)" を挿入して/))) {
        items.push({ label: `"${m[1]}" を挿入します`, icon: 'bulb', action: () => { const pos = p.end >= 0 && cm.getValue() === files.get(ed.path) ? cm.posFromIndex(p.end + 1) : { line, ch: cm.getLine(line).length }; cm.replaceRange(m[1], pos); } });
      } else if (/serialVersionUID/.test(p.msg)) {
        items.push({ label: 'デフォルトのシリアル・バージョン ID を追加します', icon: 'bulb', action: () => { const g = currentTypeForGen(); if (g) { const ind = ' '.repeat(settings.indentUnit); cm.replaceRange(`\n${ind}private static final long serialVersionUID = 1L;\n`, { line: cm.posFromIndex(g.t.open).line, ch: cm.getLine(cm.posFromIndex(g.t.open).line).length }); } } });
      } else if (/処理されない例外の型 (\w+)/.test(p.msg)) {
        const ex = p.msg.match(/処理されない例外の型 (\w+)/)[1];
        items.push({ label: `throws 宣言を追加します (${ex})`, icon: 'bulb', action: () => addThrows(cm, line, ex) });
      }
    }
    // 同じ行に同じ種類のエラーが複数あるときの重複を除く
    const seen = new Set();
    for (let i = items.length - 1; i >= 0; i--) { if (seen.has(items[i].label)) items.splice(i, 1); else seen.add(items[i].label); }
    items.reverse(); items.reverse();
    if (!items.length) { status(list.length ? 'この問題のクイック・フィックスはありません' : 'この行に問題はありません'); return; }
    const coords = cm.charCoords({ line, ch: 0 }, 'window');
    showContextMenu(items.map(i => ({ label: i.label, icon: i.icon, action: i.action })), coords.left + 40, coords.bottom + 2);
  }
  function replaceWordAt(cm, p, from, to) {
    const t = cm.getLine(p.line);
    const i = t.indexOf(from, Math.max(0, p.col - 1));
    if (i >= 0) cm.replaceRange(to, { line: p.line, ch: i }, { line: p.line, ch: i + from.length });
  }
  function addThrows(cm, line, ex) {
    for (let l = line; l >= 0; l--) {
      const t = cm.getLine(l);
      const m = t.match(/\)\s*(throws\s+[\w.,\s]+)?\s*\{\s*$/);
      if (m && /\w+\s*\(/.test(t)) {
        const idx = t.lastIndexOf('{');
        if (m[1]) cm.replaceRange(', ' + ex + ' ', { line: l, ch: t.lastIndexOf(m[1]) + m[1].trimEnd().length }, { line: l, ch: idx });
        else cm.replaceRange(' throws ' + ex + ' ', { line: l, ch: t.lastIndexOf(')') + 1 }, { line: l, ch: idx });
        Assist.addImport(cm, ex, (Assist.LIB[ex] || {}).pkg);
        return;
      }
    }
  }

  // ---------- 注釈の移動 ----------
  function gotoAnnotation(dir) {
    if (!active) return;
    const list = (problems.get(projectOf(active.path)) || []).filter(p => p.path === active.path).sort((a, b) => a.line - b.line || a.col - b.col);
    if (!list.length) { status('注釈はありません'); return; }
    const c = active.cm.getCursor();
    let t = dir > 0 ? list.find(p => p.line > c.line || (p.line === c.line && p.col > c.ch)) : [...list].reverse().find(p => p.line < c.line || (p.line === c.line && p.col < c.ch));
    if (!t) t = dir > 0 ? list[0] : list[list.length - 1];
    gotoPos(active, t.line, t.col);
    status(t.msg);
  }

  // ---------- 名前変更 (ファイル内のリンク編集) ----------
  function renameSymbol() {
    if (!active) return;
    const cm = active.cm;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch, e = c.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    while (e < line.length && /[\w$]/.test(line[e])) e++;
    const w = line.slice(s, e);
    if (!w) return;
    const b = JavaSrc.blank(cm.getValue());
    const re = new RegExp('(?<![\\w$])' + w + '(?![\\w$])', 'g');
    let m; const holes = [];
    while ((m = re.exec(b))) holes.push({ name: 'sym', from: cm.posFromIndex(m.index), to: cm.posFromIndex(m.index + w.length) });
    if (!holes.length) return;
    status(`名前変更: '${w}' を入力して Enter で確定 (ファイル内 ${holes.length} か所)`);
    // カーソル位置の欄を先頭にする
    holes.sort((a, b) => (CodeMirror.cmpPos(a.from, { line: c.line, ch: s }) === 0 ? -1 : 0) - (CodeMirror.cmpPos(b.from, { line: c.line, ch: s }) === 0 ? -1 : 0));
    window.__startLinked && window.__startLinked(cm, holes);
    // Assist のリンク・モードを使う
    const first = holes[0];
    cm.setSelection(first.from, first.to);
    linkedRename(cm, holes);
  }
  function linkedRename(cm, holes) {
    const marks = holes.map(h => cm.markText(h.from, h.to, { className: 'linked-ph', inclusiveLeft: true, inclusiveRight: true, clearWhenEmpty: false }));
    let syncing = false;
    const onChange = () => {
      if (syncing) return;
      const c = cm.getCursor();
      const curMark = marks.find(mk => { const r = mk.find(); return r && CodeMirror.cmpPos(c, r.from) >= 0 && CodeMirror.cmpPos(c, r.to) <= 0; });
      if (!curMark) return;
      const r0 = curMark.find();
      const val = cm.getRange(r0.from, r0.to);
      syncing = true;
      cm.operation(() => { for (const mk of marks) { if (mk === curMark) continue; const r = mk.find(); if (r && cm.getRange(r.from, r.to) !== val) cm.replaceRange(val, r.from, r.to, '+rename'); } });
      syncing = false;
    };
    const finish = () => { marks.forEach(m => m.clear()); cm.off('change', onChange); cm.off('cursorActivity', onCursor); cm.removeKeyMap(km); status('名前を変更しました'); };
    const onCursor = () => {
      if (syncing) return;
      const c = cm.getCursor();
      if (!marks.some(mk => { const r = mk.find(); return r && CodeMirror.cmpPos(c, r.from) >= 0 && CodeMirror.cmpPos(c, r.to) <= 0; })) finish();
    };
    const km = { Enter: () => finish(), Esc: () => finish() };
    cm.addKeyMap(km);
    cm.on('change', onChange);
    cm.on('cursorActivity', onCursor);
  }

  // ---------- ワード補完 (Alt+/) ----------
  function wordComplete() {
    if (!active) return;
    const cm = active.cm;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    const prefix = line.slice(s, c.ch);
    if (!prefix) return;
    const words = [...new Set((cm.getValue().match(/[A-Za-z_$][\w$]*/g) || []))].filter(w => w.startsWith(prefix) && w !== prefix);
    if (!words.length) return;
    cm.replaceRange(words[0], { line: c.line, ch: s }, c);
  }

  // ---------- ワークスペース内の検索 (Ctrl+H) ----------
  async function searchWorkspace() {
    const sel = active && active.cm.getSelection();
    const q = await promptText('検索', '含まれるテキスト(C):', sel && !sel.includes('\n') ? sel : (ui.lastSearch || ''), () => '');
    if (!q) return;
    ui.lastSearch = q; saveUi();
    const el = $('#search');
    const results = [];
    for (const p of projects()) for (const f of javaFilesOf(p)) {
      const lines = (contentOf(f) || '').split('\n');
      lines.forEach((l, i) => { const k = l.toLowerCase().indexOf(q.toLowerCase()); if (k >= 0) results.push({ f, i, l, k }); });
    }
    const byFile = new Map();
    for (const r of results) { if (!byFile.has(r.f)) byFile.set(r.f, []); byFile.get(r.f).push(r); }
    el.innerHTML = `<div class="search-head">'${esc(q)}' - ワークスペースで ${results.length} 件一致</div>` +
      [...byFile].map(([f, rs]) => `<div class="search-file">${icon('jfile')} ${esc(baseName(f))} <span style="font-weight:normal;color:var(--text-dim)">- ${esc(parentOf(f))} (${rs.length} 件)</span></div>` +
        rs.map(r => `<div class="search-hit" data-f="${esc(f)}" data-l="${r.i}" data-c="${r.k}"><span class="ln">${r.i + 1}:</span>${esc(r.l.slice(0, r.k).trimStart())}<mark>${esc(r.l.substr(r.k, q.length))}</mark>${esc(r.l.slice(r.k + q.length))}</div>`).join('')).join('');
    $$('.search-hit', el).forEach(h => h.addEventListener('dblclick', () => openEditor(h.dataset.f, { line: +h.dataset.l, col: +h.dataset.c, flash: true })));
    $$('.search-hit', el).forEach(h => h.addEventListener('click', () => openEditor(h.dataset.f, { line: +h.dataset.l, col: +h.dataset.c })));
    showBottom('search');
  }

  // ---------- 行へ移動 ----------
  async function gotoLineDialog() {
    if (!active) return;
    const n = active.cm.lineCount();
    const v = await promptText('行へ移動', `行番号を入力 (1..${n}):`, String(active.cm.getCursor().line + 1), x => (/^\d+$/.test(x) && +x >= 1 && +x <= n) ? '' : '1 から ' + n + ' までの数を入力してください');
    if (v) gotoPos(active, +v - 1, 0, true);
  }

  // ---------- 設定・キー・アシスト・バージョン情報 ----------
  async function preferences() {
    const r = await dialog({
      title: '設定', width: 560,
      html: `<fieldset><legend>一般 → 外観</legend>
          <div class="row"><label>テーマ:</label><select id="pf-theme"><option value="light">ライト (Eclipse 標準)</option><option value="dark">ダーク</option></select><span></span></div></fieldset>
        <fieldset><legend>Java → エディター</legend>
          <div class="row"><label>フォント・サイズ:</label><select id="pf-font">${[12, 13, 14, 15, 16, 18, 20, 22].map(s => `<option ${s === settings.fontSize ? 'selected' : ''}>${s}</option>`).join('')}</select><span></span></div>
          <div class="row"><label>インデント:</label><select id="pf-indent"><option value="spaces">スペース 4 つ (教材と同じ)</option><option value="tabs">タブ (Eclipse の既定)</option></select><span></span></div>
          <label class="chk"><input type="checkbox" id="pf-occ">出現箇所のマーク</label></fieldset>
        <fieldset><legend>Java → エディター → コンテンツ・アシスト</legend>
          <label class="chk"><input type="checkbox" id="pf-auto">自動有効化を使用可能にする</label>
          <div class="row"><label>自動有効化の遅延 (ミリ秒):</label><input type="text" id="pf-delay"><span></span></div>
          <div class="row"><label>Java の自動有効化トリガー:</label><input type="text" id="pf-trig"><span></span></div>
          <div class="hint">教材 第3章の注意のとおり、トリガーは既定の「.」のままがおすすめです。</div></fieldset>
        <fieldset><legend>実行/デバッグ → 起動</legend>
          <div class="row"><label>起動前に保存:</label><select id="pf-save"><option value="prompt">プロンプト</option><option value="always">常に</option></select><span></span></div>
          <div class="row"><label>エラーがあるときの起動:</label><select id="pf-err"><option value="prompt">プロンプト</option><option value="always">常に続行</option></select><span></span></div></fieldset>`,
      buttons: [{ label: '適用して閉じる', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: d => ({
        theme: $('#pf-theme', d).value, fontSize: +$('#pf-font', d).value, indentSpaces: $('#pf-indent', d).value === 'spaces',
        markOccurrences: $('#pf-occ', d).checked, autoActivation: $('#pf-auto', d).checked,
        autoActivationDelay: Math.max(0, +$('#pf-delay', d).value || 200), autoActivationTriggers: $('#pf-trig', d).value || '.',
        saveBeforeLaunch: $('#pf-save', d).value, launchWithErrors: $('#pf-err', d).value,
      }),
      onOpen: d => {
        $('#pf-theme', d).value = settings.theme; $('#pf-indent', d).value = settings.indentSpaces ? 'spaces' : 'tabs';
        $('#pf-occ', d).checked = settings.markOccurrences; $('#pf-auto', d).checked = settings.autoActivation;
        $('#pf-delay', d).value = settings.autoActivationDelay; $('#pf-trig', d).value = settings.autoActivationTriggers;
        $('#pf-save', d).value = settings.saveBeforeLaunch; $('#pf-err', d).value = settings.launchWithErrors;
      },
    });
    if (!r || r.value !== 'ok') return;
    delete r.value; delete r.checked;
    Object.assign(settings, r);
    saveSettings();
    applyTheme();
  }
  function keyAssist() {
    const groups = [
      ['ファイル', [['保存', 'Ctrl+S'], ['すべて保存', 'Ctrl+Shift+S'], ['閉じる', 'Ctrl+F4 (タブの × でも可)'], ['名前変更', 'F2'], ['リフレッシュ', 'F5']]],
      ['編集', [['コンテンツ・アシスト (補完)', 'Ctrl+Space'], ['ワード補完', 'Alt+/'], ['クイック・フィックス', 'Ctrl+1'], ['検索/置換', 'Ctrl+F'], ['次を検索 / 前を検索', 'Ctrl+K / Ctrl+Shift+K'], ['元に戻す / やり直し', 'Ctrl+Z / Ctrl+Y']]],
      ['ソース', [['コメントの切り替え', 'Ctrl+/'], ['ブロック・コメントの追加', 'Ctrl+Shift+/'], ['フォーマット', 'Ctrl+Shift+F'], ['インデントの訂正', 'Ctrl+I'], ['インポートの編成', 'Ctrl+Shift+O'], ['インポートの追加', 'Ctrl+Shift+M']]],
      ['行の操作', [['行の削除', 'Ctrl+D'], ['行を上/下へ移動', 'Alt+↑ / Alt+↓'], ['行の複製', 'Ctrl+Alt+↓'], ['下に行を挿入', 'Shift+Enter'], ['上に行を挿入', 'Ctrl+Shift+Enter']]],
      ['ナビゲート', [['宣言を開く', 'F3 / Ctrl+クリック'], ['行へ移動', 'Ctrl+L'], ['次の注釈 / 前の注釈', 'Ctrl+. / Ctrl+,'], ['対応する括弧', 'Ctrl+Shift+P'], ['名前変更 (ファイル内)', 'Alt+Shift+R']]],
      ['実行・ビルド', [['実行', 'Ctrl+F11'], ['すべてビルド', 'Ctrl+B'], ['検索 (ワークスペース)', 'Ctrl+H'], ['最大化', 'Ctrl+M / タブをダブルクリック'], ['キー・アシスト', 'Ctrl+Shift+L']]],
      ['テンプレート (入力して Ctrl+Space)', [['System.out.println();', 'sysout'], ['main メソッド', 'main'], ['for 文 / 拡張 for 文', 'for / foreach'], ['if / if else / while', 'if / ifelse / while'], ['try catch', 'try'], ['switch', 'switch']]],
    ];
    dialog({
      title: 'キー・アシスト', width: 680,
      html: `<div class="keyassist">${groups.map(([g, rows]) => `<h4>${esc(keyLabel(g))}</h4>` + rows.map(([a, k]) => `<div><span>${esc(a)}</span><kbd>${esc(keyLabel(k))}</kbd></div>`).join('')).join('')}</div>
        <p class="hint">${IS_MAC
    ? '※ ⌘N・⌘W・⌘T・⌘Q・⌘H・⌘M は macOS とブラウザーが使うため使えません。検索は ⌃H、最大化は ⌃M でも使えます。'
    : '※ ブラウザーの都合で Ctrl+N・Ctrl+W・Ctrl+T は使えません (ブラウザーの機能が動きます)。'}</p>`,
      buttons: [{ label: '閉じる', value: true, default: true }],
    });
  }
  function about() {
    dialog({
      title: 'お手軽Java について', width: 560,
      html: `<div style="display:flex;gap:14px"><div style="width:64px;height:64px;border-radius:8px;background:linear-gradient(135deg,#2c2255,#f7941e);flex:none"></div><div>
        <b style="font-size:15px">お手軽Java</b> - インストール不要の Eclipse 風 Java 独習環境<br><br>
        <table style="font-size:12px;border-collapse:collapse">
        <tr><td style="padding-right:12px">Java ランタイム</td><td>CheerpJ 5.0 (Leaning Technologies) / JavaSE-${JavaRT.version}<br><span class="hint">個人・教育・趣味の利用は無料 (商用は要ライセンス)</span></td></tr>
        <tr><td>コンパイラー</td><td>Eclipse Compiler for Java (ECJ) 3.45 / EPL-2.0</td></tr>
        <tr><td>エディター</td><td>CodeMirror 5.65 / MIT</td></tr>
        <tr><td>Markdown</td><td>marked 12 / MIT</td></tr>
        <tr><td>教材</td><td>Qiita「【Java入門】」シリーズ (chida0818)</td></tr>
        <tr><td>保存先</td><td>${Storage.mode === 'server' ? esc(Storage.rootPath) : 'ブラウザ (localStorage)'}</td></tr>
        </table></div></div>`,
      buttons: [{ label: '閉じる', value: true, default: true }],
    });
  }

  async function importProject() {
    const hidden = ui.hiddenProjects || [];
    if (!hidden.length) { await dialog({ title: 'インポート', message: 'ワークスペースから外したプロジェクトはありません。\n(work フォルダーに置いたプロジェクトは、F5 リフレッシュで表示されます)', icon: 'info' }); return; }
    const sel = await pickFromList('インポート', 'ワークスペースに戻すプロジェクトを選択してください:', hidden);
    if (!sel) return;
    ui.hiddenProjects = hidden.filter(p => p !== sel);
    saveUi();
    renderExplorer(); requestBuild(sel);
  }

  async function refresh() {
    const w = await Storage.load();
    for (const [p, c] of Object.entries(w.files)) {
      const t = c.replace(/\r\n/g, '\n');
      if (files.get(p) !== t) {
        files.set(p, t);
        const ed = editors.find(e => e.path === p);
        if (ed && !isDirty(ed)) { const cur = ed.cm.getCursor(); ed.cm.setValue(t); ed.gen = ed.cm.changeGeneration(true); ed.cm.setCursor(cur); }
        fileChanged(p);
      }
    }
    for (const p of [...files.keys()]) if (!(p in w.files) && !editors.some(e => e.path === p && isDirty(e))) files.delete(p);
    dirs.clear(); for (const d of w.dirs) dirs.add(d);
    renderExplorer();
    for (const p of projects()) requestBuild(p);
    status('リフレッシュしました');
  }

  // ---------- レッスンから「エディターに反映」 ----------
  async function applyLessonCode(rel, code) {
    if (dialogStack.length) { status('ダイアログを閉じてから「エディターに反映」してください'); return; }
    let project = projects().includes('java') ? 'java' : null;
    if (!project) {
      const ps = projects();
      const r = await dialog({
        title: 'エディターに反映', icon: 'info',
        message: ps.length ? `教材では 'java' という名前のプロジェクトを使います。\n'java' プロジェクト (JavaSE-17) を作成しますか?\n(「いいえ」を選ぶと '${ps[0]}' に入れます)` : `教材と同じ 'java' プロジェクト (JavaSE-17) を作成して、コードを入れますか?\n(教材 第2章の「Java プロジェクトを作る」と同じ内容です)`,
        buttons: ps.length ? [{ label: 'はい', value: 'create', default: true }, { label: 'いいえ', value: 'use' }, { label: '取り消し', value: null }] : [{ label: '作成する', value: 'create', default: true }, { label: '取り消し', value: null }],
      });
      if (!r) return;
      if (r === 'create') { await createProject('java', 17, false); project = 'java'; }
      else project = ps[0];
    }
    const path = srcRoot(project) + '/' + rel;
    const existing = editors.find(e => e.path === path);
    const cur = existing ? existing.cm.getValue() : files.get(path);
    if (cur != null && cur.trim() === code.trim()) { openEditor(path); status('すでに教材と同じ内容です'); return; }
    if (cur != null && cur.trim()) {
      const ok = await dialog({ title: 'エディターに反映', icon: 'warning', message: `'${rel}' はすでにあります。教材のこの時点のコードで置き換えますか?\n(元に戻すには、エディターで Ctrl+Z を押します)`, buttons: [{ label: '置き換える', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!ok) return;
    }
    const dir = parentOf(path);
    if (!dirs.has(dir)) { await Storage.mkdir(dir); let x = dir; while (x) { dirs.add(x); x = parentOf(x); } }
    if (existing) {
      existing.cm.setValue(code);
      await saveEditor(existing);
      activate(existing);
    } else {
      await writeNew(path, code);
      fileChanged(path);
      openEditor(path);
    }
    revealInExplorer(path);
    status(`教材のコードを '${rel}' に反映して保存しました。Ctrl+F11 で実行できます`);
  }

  // =================================================================
  // コマンド
  // =================================================================
  function command(cmd) {
    const cm = active && active.cm;
    switch (cmd) {
      case 'newProject': return newProjectWizard();
      case 'newPackage': return newPackageWizard();
      case 'newClass': return newTypeWizard('class');
      case 'newInterface': return newTypeWizard('interface');
      case 'save': return active && saveEditor(active);
      case 'saveAll': return saveAll();
      case 'revert': if (active) { active.cm.setValue(files.get(active.path) || ''); active.gen = active.cm.changeGeneration(true); renderTabs(); } return;
      case 'closeEditor': return closeEditor(active);
      case 'closeAll': return (async () => { for (const e of editors.slice()) await closeEditor(e); })();
      case 'rename': return renameSelected();
      case 'delete': return deleteSelected();
      case 'refresh': return refresh();
      case 'openFolder': return Storage.openFolder('').catch(e => showError('開けません', e.message));
      case 'openSelectedFolder': { const c = selectionContext(); const p = selected ? selected.slice(2) : ''; return Storage.openFolder(files.has(p) ? parentOf(p) : p).catch(e => showError('開けません', e.message)); }
      case 'importProject': return importProject();
      case 'exit': return (async () => {
        if (editors.some(isDirty)) { const r = await dialog({ title: '終了の確認', message: '保存されていない変更があります。保存して終了しますか?', buttons: [{ label: '保存して終了', value: 'save', default: true }, { label: '保存せずに終了', value: 'discard' }, { label: '取り消し', value: null }] }); if (!r) return; if (r === 'save') await saveAll(); else editors.forEach(e => e.gen = e.cm.changeGeneration(true)); }
        else { const r = await dialog({ title: '終了の確認', message: 'お手軽Java を終了しますか?\n(起動したときに開いたウィンドウのサーバーも終了します)', buttons: [{ label: '終了', value: true, default: true }, { label: '取り消し', value: false }] }); if (!r) return; }
        saveUi();
        await Storage.shutdown();
        document.body.innerHTML = '<div style="padding:40px;font:14px sans-serif">お手軽Java を終了しました。このタブを閉じてください。</div>';
      })();
      case 'undo': return cm && cm.undo();
      case 'redo': return cm && cm.redo();
      case 'cut': if (cm) { navigator.clipboard.writeText(cm.getSelection()).then(() => cm.replaceSelection('')); } return;
      case 'copy': if (cm) navigator.clipboard.writeText(cm.getSelection()); return;
      case 'paste': if (cm) navigator.clipboard.readText().then(t => cm.replaceSelection(t)).catch(() => status('貼り付けは Ctrl+V を使ってください')); return;
      case 'selectAll': return cm && cm.execCommand('selectAll');
      case 'find': return cm && cm.execCommand(cm.getSelection() || true ? 'replace' : 'find');
      case 'findNext': return cm && cm.execCommand('findPersistentNext');
      case 'findPrev': return cm && cm.execCommand('findPersistentPrev');
      case 'contentAssist': return cm && cm.showHint({ completeSingle: true });
      case 'wordComplete': return wordComplete();
      case 'quickFix': return quickFix(active);
      case 'toggleComment': return cm && toggleLineComment(cm);
      case 'blockComment': return cm && cm.blockComment(cm.getCursor('from'), cm.getCursor('to'));
      case 'blockUncomment': return cm && cm.uncomment(cm.getCursor('from'), cm.getCursor('to'));
      case 'shiftRight': return cm && cm.indentSelection('add');
      case 'shiftLeft': return cm && cm.indentSelection('subtract');
      case 'correctIndent': if (cm) { const f = cm.getCursor('from').line, t = cm.getCursor('to').line; cm.operation(() => { for (let l = f; l <= t; l++) cm.indentLine(l, 'smart'); }); } return;
      case 'format': if (cm && isJava(active.path)) {
        const src = cm.getValue();
        const out = Assist.format(src, settings.indentUnit, !settings.indentSpaces);
        if (out !== src) { const cur = cm.getCursor(); const sc = cm.getScrollInfo(); cm.operation(() => { cm.setValue(out); cm.setCursor(cur); cm.scrollTo(sc.left, sc.top); }); }
      } return;
      case 'organizeImports': return organizeImports();
      case 'addImport': return addImportAtCursor();
      case 'genGetSet': return genGetSet();
      case 'genToString': return genToString();
      case 'genCtor': return genCtor();
      case 'renameSymbol': return renameSymbol();
      case 'openDecl': return active && openDeclaration(active);
      case 'openSelected': if (selected && selected.startsWith('F:')) openEditor(selected.slice(2)); return;
      case 'gotoLine': return gotoLineDialog();
      case 'nextAnnotation': return gotoAnnotation(1);
      case 'prevAnnotation': return gotoAnnotation(-1);
      case 'matchBracket': return cm && cm.execCommand('goToBracket');
      case 'markOccurrencesNow': return active && markOccurrences(active);
      case 'searchWorkspace': return searchWorkspace();
      case 'buildAll': return Promise.all(projects().map(p => { projVersion.set(p, ++fileVersion); return requestBuild(p); }));
      case 'clean': return (async () => { const r = await dialog({ title: 'クリーン', message: 'すべてのプロジェクトをクリーンして、ビルドし直しますか?', buttons: [{ label: 'クリーン', value: true, default: true }, { label: '取り消し', value: false }] }); if (r) { problems.clear(); renderMarkers(); command('buildAll'); } })();
      case 'toggleAutoBuild': settings.autoBuild = !settings.autoBuild; saveSettings(); if (settings.autoBuild) command('buildAll'); return;
      case 'run': {
        // エディターで開いているクラス、または選択中のクラスを実行 (Eclipse と同じ)
        let path = active && isJava(active.path) ? active.path : null;
        if (selected && selected.startsWith('F:') && (!active || document.activeElement === $('#explorer'))) path = selected.slice(2);
        if (!path) { const c = selectionContext(); path = c.file; }
        return runFile(path);
      }
      case 'runSelected': { const p = selected && selected.startsWith('F:') ? selected.slice(2) : (active ? active.path : null); return runFile(p); }
      case 'terminate': return terminate();
      case 'clearConsole': if (!run.running) { consoleClear(); setConsoleTitle(''); } else { $$('#console-out > span').forEach(s => s.remove()); } return;
      case 'scrollLock': $('#btn-scrolllock').classList.toggle('on'); return;
      case 'collapseAll': expanded.clear(); saveUi(); renderExplorer(); return;
      case 'linkEditor': ui.linkEditor = !ui.linkEditor; $('[data-cmd="linkEditor"]').classList.toggle('on', ui.linkEditor); saveUi(); if (active && ui.linkEditor) revealInExplorer(active.path); return;
      case 'showExplorer': $('#left').style.display = ''; return;
      case 'showOutline': return showRight('outline');
      case 'showLesson': return showRight('lesson');
      case 'showMarkers': return showBottom('markers');
      case 'showConsole': return showBottom('ide-console');
      case 'showSearch': return showBottom('search');
      case 'maximize': return toggleMaximize(document.activeElement && document.activeElement.closest('.view') || $('#editor-area'));
      case 'resetPerspective': ui.layout = {}; saveUi(); $('#left').style.width = ''; $('#right').style.width = ''; $('#view-bottom').style.height = ''; if (maximized) toggleMaximize(null); showRight('lesson'); showBottom('ide-console'); refreshEditors(); return;
      case 'toggleTheme': settings.theme = settings.theme === 'dark' ? 'light' : 'dark'; saveSettings(); applyTheme(); return;
      case 'preferences': return preferences();
      case 'keyAssist': return keyAssist();
      case 'about': return about();
      case 'welcome': if (active) { for (const e of editors) e.pane.classList.remove('active'); } $('#welcome').hidden = false; updateWelcomeForce(); return;
      case 'lessonIndex': showRight('lesson'); Lesson.go(0); return;
      case 'lessonStart': showRight('lesson'); Lesson.go(2); return;
      default: console.warn('unknown command', cmd);
    }
  }
  function updateWelcomeForce() { const n = editors.length; const save = editors.splice(0); updateWelcome(); editors.push(...save); $('#welcome').hidden = false; $('#welcome').addEventListener('click', () => { if (editors.length && active) { $('#welcome').hidden = true; activate(active); } }, { once: true }); }

  // ---------- 全体のショートカット (エディター外でも有効) ----------
  function globalKeys(e) {
    if (!$('#overlay').hidden) return;
    // Mac では ⌘ を Ctrl と同じに扱う
    const ctrl = e.ctrlKey || (IS_MAC && e.metaKey);
    const k = (ctrl ? 'Ctrl+' : '') + (e.shiftKey ? 'Shift+' : '') + (e.altKey ? 'Alt+' : '') + (e.key.length === 1 ? e.key.toUpperCase() : e.key);
    const inEditor = e.target.closest && e.target.closest('.CodeMirror');
    const map = {
      'Ctrl+S': 'save', 'Ctrl+Shift+S': 'saveAll', 'Ctrl+F11': 'run', 'Ctrl+B': 'buildAll', 'Ctrl+Shift+L': 'keyAssist',
      'Ctrl+H': 'searchWorkspace', 'F5': inEditor ? null : 'refresh', 'Ctrl+M': 'maximize', 'Ctrl+F4': 'closeEditor', 'Ctrl+Shift+F4': 'closeAll',
      'Alt+Shift+X': 'runSelected',
    };
    if (e.key === 'F5') { e.preventDefault(); if (!inEditor) command('refresh'); return; }
    if (e.key === 'F11' && !ctrl) { e.preventDefault(); command('run'); return; }
    const cmd = map[k];
    if (cmd) { e.preventDefault(); e.stopPropagation(); command(cmd); return; }
    if (e.key === 'Escape') { closeMenus(); if (maximized && !inEditor) toggleMaximize(null); }
    if (e.altKey && !e.ctrlKey && !e.shiftKey && /^[a-z]$/i.test(e.key)) {
      const m = MENUS.find(x => x.key.toLowerCase() === e.key.toLowerCase());
      if (m) { e.preventDefault(); const top = $$('.menu-top')[MENUS.indexOf(m)]; showMenu(m.items, top); }
    }
  }

  return { boot, command, get settings() { return settings; }, files, editors, problems, runFile, openEditor };
})();

window.addEventListener('DOMContentLoaded', () => App.boot().catch(e => { console.error(e); alert('起動に失敗しました: ' + e.message); }));
