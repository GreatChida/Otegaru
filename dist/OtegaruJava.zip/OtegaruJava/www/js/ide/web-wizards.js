// お手軽Java - Web のウィザード (動的 Web プロジェクト・フォルダー・ファイル・HTML ファイル・CSS ファイル) と、ドロップしたファイルの取り込み
'use strict';

(() => {
  const { S, $, $$, ICON_SVG, baseName, binaries, dirs, esc, expanded, files, isHidden, parentOf } = IDE;
  const { dialog, fileChanged, gotoPos, openEditor, projects, renderExplorer, renderServers, revealInExplorer, selectionContext, showError, status,
    updateWelcome, writeNew } = IDE.fn;

  // お手軽Java のファイル名・フォルダー名は、半角の英数字と _ - . だけ (サーバーと同じ決まり)
  const NAME_RE = /^[A-Za-z0-9_\-.]+$/;
  const TEXT_EXT = /\.(java|txt|md|prefs|html|htm|css|js|json|xml|svg|mf|component|properties)$/i;
  const BINARY_EXT = /\.(png|jpg|jpeg|gif|webp|ico)$/i;
  const exists = path => files.has(path) || binaries.has(path) || dirs.has(path);
  const isFolder = path => projects().includes(path) || (dirs.has(path) && !isHidden(path));

  /** ウィザードのページを切り替える (data-page の要素を出し入れし、上の説明を書き換える) */
  function showPage(d, pages, page) {
    // Eclipse のウィザードと同じく、ページを切り替えても大きさは変えない (最初のページの高さに合わせる)
    const body = $('.dlg-body', d);
    if (!body.style.minHeight) body.style.minHeight = body.offsetHeight + 'px';
    $$('[data-page]', d).forEach(el => { el.hidden = +el.dataset.page !== page; });
    $('.dlg-banner .bt', d).textContent = pages[page].title;
    const first = $(`[data-page="${page}"] input[type=text]:not([readonly])`, d);
    if (first) setTimeout(() => first.focus(), 0);
  }
  /** 上の説明の欄に、エラー (または警告) を出す。msg が空なら通常の説明に戻す */
  function bannerMessage(d, msg, normal, level) {
    $('#dlg-msg', d).innerHTML = msg ? (level === 'warning' ? ICON_SVG.warning : ICON_SVG.error) + ' ' + esc(msg) : esc(normal);
  }

  // =================================================================
  // 新規動的 Web プロジェクト (Eclipse の WTP と同じ 3 ページ)
  // =================================================================
  const WEB_PAGES = [
    { title: '動的 Web プロジェクト', message: 'スタンドアロン動的 Web プロジェクトを作成するか、またはエンタープライズ・アプリケーションに追加します。' },
    { title: 'Java', message: 'Java アプリケーションのビルド用にプロジェクトを構成します。' },
    { title: 'Web モジュール', message: 'Web モジュール設定を構成します。' },
  ];
  async function newWebProjectWizard() {
    let page = 0, ctxEdited = false;
    let check = () => true;
    const go = (d, p) => { if (p < 0 || p >= WEB_PAGES.length) return; page = p; showPage(d, WEB_PAGES, page); check(); };
    const r = await dialog({
      title: '新規動的 Web プロジェクト', width: 600, help: true,
      banner: { title: WEB_PAGES[0].title, message: WEB_PAGES[0].message, icon: 'webwizard' },
      html: `<div data-page="0">
          <div class="row"><label>プロジェクト名(<u>P</u>):</label><input type="text" id="wp-name" spellcheck="false"><span></span></div>
          <fieldset><legend>プロジェクト・ロケーション</legend>
            <label class="chk"><input type="checkbox" checked disabled>デフォルト・ロケーションを使用(<u>D</u>)</label>
            <div class="row"><label>ロケーション(<u>L</u>):</label><input type="text" id="wp-loc" readonly><span></span></div></fieldset>
          <fieldset><legend>ターゲット・ランタイム</legend>
            <select id="wp-rt" style="width:100%"><option>Tomcat11 (Java25)</option></select></fieldset>
          <fieldset><legend>動的 Web モジュール バージョン</legend>
            <select style="width:100%" disabled><option>6.1</option></select></fieldset>
          <fieldset><legend>構成</legend>
            <select style="width:100%" disabled><option>Tomcat11 (Java25) のデフォルト構成</option></select>
            <div class="hint" style="margin-top:4px">ターゲット・ランタイムとして Tomcat11 (Java25) を使用して動的 Web プロジェクトを作成するためのデフォルト構成。</div></fieldset>
          <fieldset><legend>EAR メンバーシップ</legend>
            <label class="chk"><input type="checkbox" disabled>EAR にプロジェクトを追加(<u>A</u>)</label></fieldset>
        </div>
        <div data-page="1" hidden>
          <div style="margin-bottom:4px">ビルド・パス上のソース・フォルダー(<u>D</u>):</div>
          <div class="dlg-list" style="height:120px"><div class="li">${ICON_SVG.srcfolder} src/main/java</div></div>
          <div class="row" style="margin-top:10px"><label>デフォルト出力フォルダー(<u>O</u>):</label><input type="text" value="build/classes" readonly><span></span></div>
        </div>
        <div data-page="2" hidden>
          <div class="row"><label>コンテキスト・ルート(<u>C</u>):</label><input type="text" id="wp-ctx" spellcheck="false"><span></span></div>
          <div class="row"><label>コンテンツ・ディレクトリー(<u>M</u>):</label><input type="text" value="src/main/webapp" readonly><span></span></div>
          <label class="chk"><input type="checkbox" id="wp-webxml">web.xml デプロイメント記述子の生成(<u>G</u>)</label>
        </div>`,
      buttons: [
        { label: '< 戻る(B)', value: 'back', validate: d => { go(d, page - 1); return false; } },
        { label: '次へ(N) >', value: 'next', validate: d => { go(d, page + 1); return false; } },
        { label: '完了(F)', value: 'ok', default: true, validate: d => !$('[data-b="2"]', d).disabled },
        { label: '取り消し', value: null },
      ],
      collect: d => ({ name: $('#wp-name', d).value.trim(), ctx: $('#wp-ctx', d).value.trim(), webxml: $('#wp-webxml', d).checked }),
      onOpen: d => {
        check = () => {
          const n = $('#wp-name', d).value.trim();
          if (!ctxEdited) $('#wp-ctx', d).value = n;
          const ctx = $('#wp-ctx', d).value.trim();
          $('#wp-loc', d).value = (Storage.rootPath ? Storage.rootPath.replace(/\\/g, '/') + '/' : 'workspace/') + n;
          let msg = '';
          if (!n) msg = 'プロジェクト名を入力してください。';
          else if (!NAME_RE.test(n) || n.startsWith('.')) msg = 'お手軽Java では、プロジェクト名に半角の英数字と _ - . だけが使えます。';
          else if (projects().includes(n) || dirs.has(n)) msg = '同じ名前のプロジェクトがすでに存在します。';
          else if (!ctx) msg = 'コンテキスト・ルートを入力してください。';
          else if (!NAME_RE.test(ctx)) msg = 'お手軽Java では、コンテキスト・ルートに半角の英数字と _ - . だけが使えます。';
          bannerMessage(d, n || page > 0 ? msg : '', WEB_PAGES[page].message);
          $('[data-b="0"]', d).disabled = page === 0;
          $('[data-b="1"]', d).disabled = page === WEB_PAGES.length - 1 || !!msg;
          $('[data-b="2"]', d).disabled = !!msg;
        };
        $('#wp-name', d).addEventListener('input', check);
        $('#wp-ctx', d).addEventListener('input', () => { ctxEdited = true; check(); });
        check();
      },
    });
    if (!r || r.value !== 'ok') return;
    await createWebProject(r.name, r.ctx, r.webxml);
  }

  /** 動的 Web プロジェクトを作る (Eclipse で作ったものと同じ設定ファイルにして、Eclipse にインポートできるようにする) */
  async function createWebProject(name, ctx, webxml) {
    const proj = `<?xml version="1.0" encoding="UTF-8"?>
<projectDescription>
	<name>${name}</name>
	<comment></comment>
	<projects>
	</projects>
	<buildSpec>
		<buildCommand>
			<name>org.eclipse.jdt.core.javabuilder</name>
			<arguments>
			</arguments>
		</buildCommand>
		<buildCommand>
			<name>org.eclipse.wst.common.project.facet.core.builder</name>
			<arguments>
			</arguments>
		</buildCommand>
		<buildCommand>
			<name>org.eclipse.wst.validation.validationbuilder</name>
			<arguments>
			</arguments>
		</buildCommand>
	</buildSpec>
	<natures>
		<nature>org.eclipse.jem.workbench.JavaEMFNature</nature>
		<nature>org.eclipse.wst.common.modulecore.ModuleCoreNature</nature>
		<nature>org.eclipse.wst.common.project.facet.core.nature</nature>
		<nature>org.eclipse.jdt.core.javanature</nature>
	</natures>
</projectDescription>
`;
    // お手軽Java の Java は 21 まで。Eclipse では Tomcat11 (Java25) のランタイムに合わせて読み替えられる
    const cp = `<?xml version="1.0" encoding="UTF-8"?>
<classpath>
	<classpathentry kind="src" path="src/main/java"/>
	<classpathentry kind="con" path="org.eclipse.jdt.launching.JRE_CONTAINER/org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType/JavaSE-21">
		<attributes>
			<attribute name="module" value="true"/>
		</attributes>
	</classpathentry>
	<classpathentry kind="con" path="org.eclipse.jst.j2ee.internal.web.container"/>
	<classpathentry kind="con" path="org.eclipse.jst.j2ee.internal.module.container"/>
	<classpathentry kind="output" path="build/classes"/>
</classpath>
`;
    const component = `<?xml version="1.0" encoding="UTF-8"?><project-modules id="moduleCoreId" project-version="1.5.0">
    <wb-module deploy-name="${name}">
        <wb-resource deploy-path="/" source-path="/src/main/webapp" tag="defaultRootSource"/>
        <wb-resource deploy-path="/WEB-INF/classes" source-path="/src/main/java"/>
        <property name="context-root" value="${ctx}"/>
        <property name="java-output-path" value="/${name}/build/classes"/>
    </wb-module>
</project-modules>
`;
    const facets = `<?xml version="1.0" encoding="UTF-8"?>
<faceted-project>
  <installed facet="java" version="21"/>
  <installed facet="jst.web" version="6.1"/>
</faceted-project>
`;
    const prefs = 'eclipse.preferences.version=1\norg.eclipse.jdt.core.compiler.codegen.targetPlatform=21\norg.eclipse.jdt.core.compiler.compliance=21\norg.eclipse.jdt.core.compiler.source=21\norg.eclipse.jdt.core.compiler.release=enabled\n';
    const webXml = `<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://jakarta.ee/xml/ns/jakartaee" xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee https://jakarta.ee/xml/ns/jakartaee/web-app_6_1.xsd" id="WebApp_ID" version="6.1">
  <display-name>${name}</display-name>
  <welcome-file-list>
    <welcome-file>index.html</welcome-file>
    <welcome-file>index.jsp</welcome-file>
    <welcome-file>index.htm</welcome-file>
    <welcome-file>default.html</welcome-file>
    <welcome-file>default.jsp</welcome-file>
    <welcome-file>default.htm</welcome-file>
  </welcome-file-list>
</web-app>
`;
    try {
      for (const d of [name, name + '/src/main/java', name + '/src/main/webapp/META-INF', name + '/src/main/webapp/WEB-INF/lib']) {
        await Storage.mkdir(d);
        for (let x = d; x; x = parentOf(x)) dirs.add(x);
      }
      await writeNew(name + '/.project', proj);
      await writeNew(name + '/.classpath', cp);
      await writeNew(name + '/.settings/org.eclipse.wst.common.component', component);
      await writeNew(name + '/.settings/org.eclipse.wst.common.project.facet.core.xml', facets);
      await writeNew(name + '/.settings/org.eclipse.jdt.core.prefs', prefs);
      await writeNew(name + '/src/main/webapp/META-INF/MANIFEST.MF', 'Manifest-Version: 1.0\nClass-Path: \n\n');
      if (webxml) await writeNew(name + '/src/main/webapp/WEB-INF/web.xml', webXml);
      expanded.add('P:' + name);
      S.selected = 'P:' + name;
      renderExplorer(); updateWelcome(); renderServers();
      status(`動的 Web プロジェクト '${name}' を作成しました`);
    } catch (e) { showError('プロジェクトを作成できません', e.message); }
  }

  // =================================================================
  // 親フォルダーを選ぶ欄 (新規フォルダー・新規ファイルのウィザードで共通)
  // =================================================================
  function allFolders() {
    const list = [];
    for (const p of projects()) {
      list.push(p);
      for (const d of [...dirs].filter(d => d.startsWith(p + '/') && !isHidden(d)).sort()) list.push(d);
    }
    return list;
  }
  function parentPickerHtml(initial) {
    return `<div style="margin-bottom:3px">親フォルダーを入力または選択(<u>E</u>):</div>
      <input type="text" id="np-parent" value="${esc(initial || '')}" spellcheck="false" style="width:100%;box-sizing:border-box">
      <div class="dlg-list" id="np-tree" style="height:150px;margin-top:4px">${allFolders().map(f => {
        const depth = f.split('/').length - 1;
        return `<div class="li" data-folder="${esc(f)}" style="padding-left:${6 + depth * 14}px">${ICON_SVG[depth ? 'folder' : 'webproject']} ${esc(baseName(f))}</div>`;
      }).join('')}</div>`;
  }
  function wireParentPicker(d, onChange) {
    const input = $('#np-parent', d);
    const mark = () => $$('#np-tree .li', d).forEach(li => { li.style.background = li.dataset.folder === input.value.trim() ? 'var(--sel)' : ''; });
    $$('#np-tree .li', d).forEach(li => li.addEventListener('click', () => { input.value = li.dataset.folder; mark(); onChange(); }));
    input.addEventListener('input', () => { mark(); onChange(); });
    mark();
    const sel = $$('#np-tree .li', d).find(li => li.dataset.folder === input.value.trim());
    if (sel) setTimeout(() => sel.scrollIntoView({ block: 'nearest' }), 0);
  }

  // =================================================================
  // 新規フォルダー
  // =================================================================
  async function newFolderWizard() {
    const c = selectionContext();
    if (!c.project) { await dialog({ title: '新規フォルダー', message: '先にプロジェクトを作成してください。', icon: 'info' }); return; }
    const normal = '新規フォルダー・リソースを作成します。';
    const r = await dialog({
      title: '新規フォルダー', width: 520, help: true,
      banner: { title: 'フォルダー', message: normal },
      html: `${parentPickerHtml(c.folder)}
        <div class="row" style="margin-top:10px;grid-template-columns:120px 1fr"><label>フォルダー名(<u>N</u>):</label><input type="text" id="nf-name" spellcheck="false"></div>`,
      buttons: [{ label: '完了(F)', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({ parent: $('#np-parent', d).value.trim().replace(/\/+$/, ''), name: $('#nf-name', d).value.trim() }),
      onOpen: d => {
        const check = () => {
          const parent = $('#np-parent', d).value.trim().replace(/\/+$/, ''), n = $('#nf-name', d).value.trim();
          let msg = '';
          if (!isFolder(parent)) msg = '親フォルダーが存在しません。';
          else if (!n) msg = 'フォルダー名を入力してください。';
          else if (!NAME_RE.test(n)) msg = 'お手軽Java では、フォルダー名に半角の英数字と _ - . だけが使えます。';
          else if (exists(parent + '/' + n)) msg = `'${n}' はすでに存在します。`;
          bannerMessage(d, n ? msg : '', normal);
          $('[data-b="0"]', d).disabled = !!msg;
        };
        wireParentPicker(d, check);
        $('#nf-name', d).addEventListener('input', check);
        check();
        setTimeout(() => $('#nf-name', d).focus(), 0);
      },
    });
    if (!r || r.value !== 'ok') return;
    const path = r.parent + '/' + r.name;
    try {
      await Storage.mkdir(path);
      for (let x = path; x; x = parentOf(x)) dirs.add(x);
      revealInExplorer(path);
      status(`フォルダー '${r.name}' を作成しました`);
    } catch (e) { showError('フォルダーを作成できません', e.message); }
  }

  // =================================================================
  // 新規ファイル / HTML ファイル / CSS ファイル
  // =================================================================
  // テンプレートは Eclipse (WTP) と同じ。${encoding} は UTF-8 に置き換える
  const TEMPLATES = {
    html: [
      { name: '新規 HTML ファイル (4.01 strict)', desc: 'html 4.01 strict', text: '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">\n<html>\n<head>\n<meta http-equiv="Content-Type" content="text/html; charset=${encoding}">\n<title>Insert title here</title>\n</head>\n<body>\n\n</body>\n</html>\n' },
      { name: '新規 HTML ファイル (4.01 transitional)', desc: 'html 4.01 transitional', text: '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">\n<html>\n<head>\n<meta http-equiv="Content-Type" content="text/html; charset=${encoding}">\n<title>Insert title here</title>\n</head>\n<body>\n\n</body>\n</html>\n' },
      { name: '新規 HTML ファイル (5)', desc: 'html 5', text: '<!DOCTYPE html>\n<html>\n<head>\n<meta charset="${encoding}">\n<title>Insert title here</title>\n</head>\n<body>\n\n</body>\n</html>\n', default: true },
      { name: '新規 XHTML ファイル (1.0 strict)', desc: 'xhtml 1.0 strict', text: '<?xml version="1.0" encoding="${encoding}" ?>\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n<head>\n<meta http-equiv="Content-Type" content="text/html; charset=${encoding}" />\n<title>Insert title here</title>\n</head>\n<body>\n\n</body>\n</html>\n' },
    ],
    css: [
      { name: '新規 CSS ファイル', desc: '新規 CSS ファイル', text: '@charset "${encoding}";\n', default: true },
    ],
  };
  const FILE_KINDS = {
    file: { title: '新規ファイル', banner: 'ファイル', message: '新規ファイル・リソースを作成します。' },
    html: { title: '新規 HTML ファイル', banner: 'HTML', message: '新規 HTML ファイルを作成します。', ext: /\.(html|htm)$/i, add: '.html', extMsg: 'ファイル名の拡張子は html または htm にしてください。',
      tplTitle: 'HTML テンプレートの選択', tplMessage: '新規 HTML ファイルの作成に使用するテンプレートを選択します。', tplCheck: 'HTML テンプレートの使用(<u>U</u>)' },
    css: { title: '新規 CSS ファイル', banner: 'CSS', message: '新規 CSS ファイルを作成します。', ext: /\.css$/i, add: '.css', extMsg: 'ファイル名の拡張子は css にしてください。',
      tplTitle: 'CSS テンプレートの選択', tplMessage: '新規 CSS ファイルの作成に使用するテンプレートを選択します。', tplCheck: 'CSS テンプレートの使用(<u>U</u>)' },
  };

  async function newFileWizard(kind) {
    const k = FILE_KINDS[kind];
    const c = selectionContext();
    if (!c.project) { await dialog({ title: k.title, message: '先にプロジェクトを作成してください。', icon: 'info' }); return; }
    const tpls = TEMPLATES[kind] || [];
    const pages = [{ title: k.banner, message: k.message }, { title: k.tplTitle, message: k.tplMessage }];
    let page = 0, tplIndex = Math.max(0, tpls.findIndex(t => t.default));
    let check = () => true;
    const go = (d, p) => { if (p < 0 || p >= (tpls.length ? 2 : 1)) return; page = p; showPage(d, pages, page); check(); };
    // 拡張子が無ければ付ける (Eclipse と同じ)
    const fileName = n => (k.add && n && !/\.[^.]+$/.test(n)) ? n + k.add : n;
    const r = await dialog({
      title: k.title, width: 560, help: true,
      banner: { title: pages[0].title, message: pages[0].message },
      html: `<div data-page="0">${parentPickerHtml(c.folder)}
          <div class="row" style="margin-top:10px;grid-template-columns:120px 1fr"><label>ファイル名(<u>M</u>):</label><input type="text" id="nf-name" spellcheck="false"></div></div>
        ${tpls.length ? `<div data-page="1" hidden>
          <label class="chk"><input type="checkbox" id="tp-use" checked>${k.tplCheck}</label>
          <div style="margin:6px 0 3px">テンプレート(<u>T</u>):</div>
          <table class="mk-table tp-table" style="border:1px solid #7a7a7a"><thead><tr><th>名前</th><th>説明</th></tr></thead><tbody>
            ${tpls.map((t, i) => `<tr class="row" data-t="${i}"><td>${esc(t.name)}</td><td>${esc(t.desc)}</td></tr>`).join('')}</tbody></table>
          <div style="margin:8px 0 3px">プレビュー(<u>P</u>):</div>
          <pre id="tp-preview" class="tp-preview"></pre></div>` : ''}`,
      buttons: [
        { label: '< 戻る(B)', value: 'back', validate: d => { go(d, page - 1); return false; } },
        { label: '次へ(N) >', value: 'next', validate: d => { go(d, page + 1); return false; } },
        { label: '完了(F)', value: 'ok', default: true, validate: d => !$('[data-b="2"]', d).disabled },
        { label: '取り消し', value: null },
      ],
      collect: d => ({
        parent: $('#np-parent', d).value.trim().replace(/\/+$/, ''), name: fileName($('#nf-name', d).value.trim()),
        useTemplate: tpls.length > 0 && $('#tp-use', d).checked,
      }),
      onOpen: d => {
        check = () => {
          const parent = $('#np-parent', d).value.trim().replace(/\/+$/, ''), raw = $('#nf-name', d).value.trim(), n = fileName(raw);
          let msg = '';
          if (!isFolder(parent)) msg = '親フォルダーが存在しません。';
          else if (!raw) msg = 'ファイル名を入力してください。';
          else if (!NAME_RE.test(n)) msg = 'お手軽Java では、ファイル名に半角の英数字と _ - . だけが使えます。';
          else if (k.ext && !k.ext.test(n)) msg = k.extMsg;
          else if (!k.ext && !TEXT_EXT.test(n)) msg = 'お手軽Java で作れるのは、.txt・.html・.css・.js・.json・.xml などの文字のファイルです。';
          else if (exists(parent + '/' + n)) msg = `'${n}' はすでに存在します。`;
          bannerMessage(d, raw || page > 0 ? msg : '', pages[page].message);
          $('[data-b="0"]', d).disabled = page === 0;
          $('[data-b="1"]', d).disabled = !tpls.length || page === 1 || !!msg;
          $('[data-b="2"]', d).disabled = !!msg;
        };
        wireParentPicker(d, check);
        $('#nf-name', d).addEventListener('input', check);
        if (tpls.length) {
          const pick = i => {
            tplIndex = i;
            $$('.tp-table tr.row', d).forEach(tr => tr.classList.toggle('selected', +tr.dataset.t === i));
            $('#tp-preview', d).textContent = tpls[i].text;
          };
          $$('.tp-table tr.row', d).forEach(tr => tr.addEventListener('mousedown', () => { if ($('#tp-use', d).checked) pick(+tr.dataset.t); }));
          $('#tp-use', d).addEventListener('change', e => { $('.tp-table', d).style.opacity = e.target.checked ? '' : '.5'; $('#tp-preview', d).style.opacity = e.target.checked ? '' : '.5'; });
          pick(tplIndex);
        }
        check();
        setTimeout(() => $('#nf-name', d).focus(), 0);
      },
    });
    if (!r || r.value !== 'ok') return;
    const path = r.parent + '/' + r.name;
    const content = r.useTemplate ? tpls[tplIndex].text.replace(/\$\{encoding\}/g, 'UTF-8') : '';
    try {
      await writeNew(path, content);
      fileChanged(path);
      revealInExplorer(path);
      const ed = openEditor(path);
      // Eclipse と同じく、CSS は作成直後に 1 行目 (@charset) が選択された状態になる
      if (kind === 'css' && r.useTemplate) setTimeout(() => ed.cm.setSelection({ line: 0, ch: 0 }, { line: 0, ch: ed.cm.getLine(0).length }), 0);
      else gotoPos(ed, 0, 0);
      status(`'${r.name}' を作成しました`);
    } catch (e) { showError('ファイルを作成できません', e.message); }
  }

  // =================================================================
  // パソコンのファイルをドロップして取り込む (Eclipse の「ファイル操作」)
  // =================================================================
  async function importDroppedFiles(dir, list) {
    if (Storage.mode !== 'server') { showError('ファイル操作', 'ブラウザ保存モードでは、ファイルを取り込めません。\nstart.bat (Mac は start.command) から起動してください。'); return; }
    if (!list.length) return;
    const r = await dialog({
      title: 'ファイル操作', width: 440,
      html: `<div style="margin-bottom:8px">ファイルをどのようにインポートしますか?</div>
        <label class="chk"><input type="radio" name="fo" checked>ファイルをコピー(<u>C</u>)</label>
        <label class="chk" style="color:var(--text-dim)"><input type="radio" name="fo" disabled>ファイルへのリンク(<u>L</u>)</label>`,
      buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取り消し', value: null }],
    });
    if (r !== 'ok') return;
    const skipped = [];
    let count = 0;
    for (const f of list) {
      const path = dir + '/' + f.name;
      if (!NAME_RE.test(f.name)) { skipped.push(`${f.name} (名前に使えない文字があります。半角の英数字と _ - . だけが使えます)`); continue; }
      const binary = BINARY_EXT.test(f.name);
      if (!binary && !TEXT_EXT.test(f.name)) { skipped.push(`${f.name} (お手軽Java では扱えない種類のファイルです)`); continue; }
      if (dirs.has(path)) { skipped.push(`${f.name} (同じ名前のフォルダーがあります)`); continue; }
      if (files.has(path) || binaries.has(path)) {
        const ok = await dialog({ title: '上書きの確認', icon: 'warning', message: `'${f.name}' はすでに存在します。上書きしますか?`, buttons: [{ label: 'はい', value: true, default: true }, { label: 'いいえ', value: false }] });
        if (!ok) continue;
      }
      try {
        if (binary) {
          await Storage.writeBinary(path, f);
          binaries.add(path);
        } else {
          const text = (await f.text()).replace(/\r\n/g, '\n');
          await Storage.writeFile(path, text);
          files.set(path, text);
        }
        for (let x = parentOf(path); x; x = parentOf(x)) dirs.add(x);
        fileChanged(path);
        count++;
      } catch (e) { skipped.push(`${f.name} (${e.message || 'フォルダーは取り込めません'})`); }
    }
    if (count) revealInExplorer(dir + '/' + list.find(f => files.has(dir + '/' + f.name) || binaries.has(dir + '/' + f.name)).name);
    if (skipped.length) await dialog({ title: 'ファイル操作', icon: 'warning', message: '次のファイルは取り込めませんでした:\n\n' + skipped.join('\n') });
    else if (count) status(`${count} 個のファイルをコピーしました`);
  }

  Object.assign(IDE, { createWebProject, importDroppedFiles, newFileWizard, newFolderWizard, newWebProjectWizard });
})();
