﻿# 配布用の zip (dist\OtegaruJava.zip) を作る
#   使い方: powershell -ExecutionPolicy Bypass -File tools\make-zip.ps1
#   - 利用者向けの説明 docs\README-dist.md から README.txt (プレーンテキスト) を作り、zip に入れる
#   - 隣に公開用リポジトリ (..\Otegaru) があれば、README.md・README.txt・zip をそこへコピーする
#     (コミットとプッシュはしない。公開するかどうかは手で決める)
param(
  [string]$PublishRepo = (Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'Otegaru')
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$dist = Join-Path $Root 'dist'
$zipPath = Join-Path $dist 'OtegaruJava.zip'
$readmeMd = Join-Path $Root 'docs\README-dist.md'
$readmeTxt = Join-Path $dist 'README.txt'
$top = 'OtegaruJava'
New-Item -ItemType Directory -Force $dist | Out-Null
if (Test-Path $zipPath) {
  try { Remove-Item $zipPath } catch {
    throw "dist\OtegaruJava.zip を別のプログラムが使っています。エクスプローラーのプレビューや、zip を開いているウィンドウを閉じてから、もう一度実行してください。"
  }
}

# 1. 利用者向けの説明をプレーンテキストにする
& (Join-Path $PSScriptRoot 'md2txt.ps1') -In $readmeMd -Out $readmeTxt
Write-Host "作成しました: $readmeTxt"

# 2. zip を作る (README.txt は zip の一番上に入れる)
$items = @('start.bat', 'tools', 'www')
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, 'Create')
try {
  $base = (Resolve-Path $Root).Path.TrimEnd('\') + '\'
  [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $readmeTxt, "$top/README.txt", 'Optimal')
  foreach ($it in $items) {
    $p = Join-Path $Root $it
    $files = if (Test-Path $p -PathType Container) { Get-ChildItem -Path $p -Recurse -File } else { Get-Item $p }
    foreach ($f in $files) {
      $name = $top + '/' + $f.FullName.Substring($base.Length).Replace('\', '/')
      [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $name, 'Optimal')
    }
  }
  # 空の work フォルダー (書いたプログラムの保存場所)
  [void]$zip.CreateEntry($top + '/work/')
} finally { $zip.Dispose() }
Write-Host "作成しました: $zipPath ($([math]::Round((Get-Item $zipPath).Length / 1MB, 1)) MB)"

# 3. 公開用リポジトリへコピーする
if ($PublishRepo -and (Test-Path (Join-Path $PublishRepo '.git'))) {
  New-Item -ItemType Directory -Force (Join-Path $PublishRepo 'dist') | Out-Null
  Copy-Item $readmeMd (Join-Path $PublishRepo 'README.md') -Force
  Copy-Item $readmeTxt (Join-Path $PublishRepo 'README.txt') -Force
  Copy-Item $zipPath (Join-Path $PublishRepo 'dist\OtegaruJava.zip') -Force
  Write-Host "公開用リポジトリにコピーしました: $PublishRepo (README.md, README.txt, dist\OtegaruJava.zip)"
} else {
  Write-Host "公開用リポジトリが見つからないので、コピーはしませんでした: $PublishRepo"
}
