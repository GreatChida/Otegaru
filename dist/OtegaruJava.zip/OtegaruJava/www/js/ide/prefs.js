// お手軽Java - 設定・キー・アシスト・バージョン情報
'use strict';

(() => {
  const { S, $, IS_MAC, esc, settings } = IDE;
  const { applyTheme, dialog, keyLabel, markOccurrences, saveSettings } = IDE.fn;

  // ---------- 設定・キー・アシスト・バージョン情報 ----------
  async function preferences() {
    const r = await dialog({
      title: '設定', width: 560,
      html: `<fieldset><legend>一般 → 外観</legend>
          <div class="row"><label>テーマ:</label><select id="pf-theme"><option value="light">ライト (Eclipse 標準)</option><option value="dark">ダーク</option></select><span></span></div></fieldset>
        <fieldset><legend>Java → エディター</legend>
          <div class="row"><label>フォント・サイズ:</label><select id="pf-font">${[12, 13, 14, 15, 16, 18, 20, 22].map(s => `<option ${s === settings.fontSize ? 'selected' : ''}>${s}</option>`).join('')}</select><span></span></div>
          <div class="row"><label>インデント:</label><select id="pf-indent"><option value="spaces">スペース 4 つ (教材と同じ)</option><option value="tabs">タブ (Eclipse の既定)</option></select><span></span></div>
          <label class="chk"><input type="checkbox" id="pf-occ">出現箇所のマーク</label></fieldset>
        <fieldset><legend>Java → エディター → コンテンツ・アシスト</legend>
          <label class="chk"><input type="checkbox" id="pf-auto">自動有効化を使用可能にする</label>
          <div class="row"><label>自動有効化の遅延 (ミリ秒):</label><input type="text" id="pf-delay"><span></span></div>
          <div class="row"><label>Java の自動有効化トリガー:</label><input type="text" id="pf-trig"><span></span></div>
          <div class="hint">教材 第3章の注意のとおり、トリガーは既定の「.」のままがおすすめです。</div></fieldset>
        <fieldset><legend>実行/デバッグ → 起動</legend>
          <div class="row"><label>起動前に保存:</label><select id="pf-save"><option value="prompt">プロンプト</option><option value="always">常に</option></select><span></span></div>
          <div class="row"><label>エラーがあるときの起動:</label><select id="pf-err"><option value="prompt">プロンプト</option><option value="always">常に続行</option></select><span></span></div></fieldset>`,
      buttons: [{ label: '適用して閉じる', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: d => ({
        theme: $('#pf-theme', d).value, fontSize: +$('#pf-font', d).value, indentSpaces: $('#pf-indent', d).value === 'spaces',
        markOccurrences: $('#pf-occ', d).checked, autoActivation: $('#pf-auto', d).checked,
        autoActivationDelay: Math.max(0, +$('#pf-delay', d).value || 200), autoActivationTriggers: $('#pf-trig', d).value || '.',
        saveBeforeLaunch: $('#pf-save', d).value, launchWithErrors: $('#pf-err', d).value,
      }),
      onOpen: d => {
        $('#pf-theme', d).value = settings.theme; $('#pf-indent', d).value = settings.indentSpaces ? 'spaces' : 'tabs';
        $('#pf-occ', d).checked = settings.markOccurrences; $('#pf-auto', d).checked = settings.autoActivation;
        $('#pf-delay', d).value = settings.autoActivationDelay; $('#pf-trig', d).value = settings.autoActivationTriggers;
        $('#pf-save', d).value = settings.saveBeforeLaunch; $('#pf-err', d).value = settings.launchWithErrors;
      },
    });
    if (!r || r.value !== 'ok') return;
    delete r.value; delete r.checked;
    Object.assign(settings, r);
    saveSettings();
    applyTheme();
  }
  function keyAssist() {
    const groups = [
      ['ファイル', [['保存', 'Ctrl+S'], ['すべて保存', 'Ctrl+Shift+S'], ['閉じる', 'Ctrl+F4 (タブの × でも可)'], ['名前変更', 'F2'], ['リフレッシュ', 'F5']]],
      ['編集', [['コンテンツ・アシスト (補完)', 'Ctrl+Space'], ['ワード補完', 'Alt+/'], ['クイック・フィックス', 'Ctrl+1'], ['検索/置換', 'Ctrl+F'], ['次を検索 / 前を検索', 'Ctrl+K / Ctrl+Shift+K'], ['元に戻す / やり直し', 'Ctrl+Z / Ctrl+Y']]],
      ['ソース', [['コメントの切り替え', 'Ctrl+/'], ['ブロック・コメントの追加', 'Ctrl+Shift+/'], ['フォーマット', 'Ctrl+Shift+F'], ['インデントの訂正', 'Ctrl+I'], ['インポートの編成', 'Ctrl+Shift+O'], ['インポートの追加', 'Ctrl+Shift+M']]],
      ['行の操作', [['行の削除', 'Ctrl+D'], ['行を上/下へ移動', 'Alt+↑ / Alt+↓'], ['行の複製', 'Ctrl+Alt+↓'], ['下に行を挿入', 'Shift+Enter'], ['上に行を挿入', 'Ctrl+Shift+Enter']]],
      ['ナビゲート', [['宣言を開く', 'F3 / Ctrl+クリック'], ['行へ移動', 'Ctrl+L'], ['次の注釈 / 前の注釈', 'Ctrl+. / Ctrl+,'], ['対応する括弧', 'Ctrl+Shift+P'], ['名前変更 (ファイル内)', 'Alt+Shift+R']]],
      ['実行・ビルド', [['実行', 'Ctrl+F11'], ['すべてビルド', 'Ctrl+B'], ['検索 (ワークスペース)', 'Ctrl+H'], ['最大化', 'Ctrl+M / タブをダブルクリック'], ['キー・アシスト', 'Ctrl+Shift+L']]],
      ['テンプレート (入力して Ctrl+Space)', [['System.out.println();', 'sysout'], ['main メソッド', 'main'], ['for 文 / 拡張 for 文', 'for / foreach'], ['if / if else / while', 'if / ifelse / while'], ['try catch', 'try'], ['switch', 'switch']]],
    ];
    dialog({
      title: 'キー・アシスト', width: 680,
      html: `<div class="keyassist">${groups.map(([g, rows]) => `<h4>${esc(keyLabel(g))}</h4>` + rows.map(([a, k]) => `<div><span>${esc(a)}</span><kbd>${esc(keyLabel(k))}</kbd></div>`).join('')).join('')}</div>
        <p class="hint">${IS_MAC
    ? '※ ⌘N・⌘W・⌘T・⌘Q・⌘H・⌘M は macOS とブラウザーが使うため使えません。検索は ⌃H、最大化は ⌃M でも使えます。'
    : '※ ブラウザーの都合で Ctrl+N・Ctrl+W・Ctrl+T は使えません (ブラウザーの機能が動きます)。'}</p>`,
      buttons: [{ label: '閉じる', value: true, default: true }],
    });
  }
  function about() {
    dialog({
      title: 'お手軽Java について', width: 560,
      html: `<div style="display:flex;gap:14px"><div style="width:64px;height:64px;border-radius:8px;background:linear-gradient(135deg,#2c2255,#f7941e);flex:none"></div><div>
        <b style="font-size:15px">お手軽Java</b> <span class="hint">v0.3.0</span><br>
        インストール不要の Eclipse 風 Java 独習環境<br><br>
        <table style="font-size:12px;border-collapse:collapse">
        <tr><td style="padding-right:12px">Java ランタイム</td><td>CheerpJ 5.0 (Leaning Technologies) / JavaSE-${JavaRT.version}<br><span class="hint">個人・教育・趣味の利用は無料 (商用は要ライセンス)</span></td></tr>
        <tr><td>コンパイラー</td><td>Eclipse Compiler for Java (ECJ) 3.45 / EPL-2.0</td></tr>
        <tr><td>エディター</td><td>CodeMirror 5.65 / MIT</td></tr>
        <tr><td>Markdown</td><td>marked 12 / MIT</td></tr>
        <tr><td>教材</td><td>Qiita「【Java入門】」シリーズ (chida0818)</td></tr>
        <tr><td>保存先</td><td>${Storage.mode === 'server' ? esc(Storage.rootPath) : 'ブラウザ (localStorage)'}</td></tr>
        </table></div></div>`,
      buttons: [{ label: '閉じる', value: true, default: true }],
    });
  }

  Object.assign(IDE, { about, keyAssist, preferences });
})();
