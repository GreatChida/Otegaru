// お手軽Java - 共通: 状態・設定・パスの扱い・ステータス・アイコン
'use strict';

// 分けたファイルどうしは、この IDE を通して機能と状態をやり取りする。
// 他のファイルの関数は IDE.fn から受け取る (呼んだときに IDE から探すので、読み込む順番に関係なく使える)
const IDE = { fn: new Proxy({}, { get: (_, name) => (...args) => IDE[name](...args) }) };

(() => {
  // =================================================================
  // 状態
  // =================================================================
  // 入れ替わる値 (今のエディター・エクスプローラーの選択など) は S にまとめる
  const S = { active: null, selected: null, javaReady: false, fileVersion: 0, maximized: null };
  const files = new Map();      // パス -> 保存済みの内容
  const binaries = new Set();   // 画像などのファイルのパス (中身は読み込まない)
  const dirs = new Set();       // フォルダのパス
  const editors = [];           // {path, cm, pane, tab, gen}
  const problems = new Map();   // プロジェクト名 -> [{path, kind, line, col, start, end, msg, code}]
  const building = new Map();   // プロジェクト名 -> {running: Promise, again: bool}
  const builtVersion = new Map(); // プロジェクト名 -> 最後にビルドした内容の版
  const projVersion = new Map();
  const expanded = new Set();
  const ui = {};                // 画面の状態 (localStorage に保存)。中身を入れ替えて使う
  const settings = {};          // 設定 (localStorage に保存)。中身を入れ替えて使う
  const run = { running: false, inputQueue: [], waiting: null, title: '', start: null, text: '', className: '', project: '' };

  const SETTINGS_KEY = 'otekaru.settings.v1';
  const UI_KEY = 'otekaru.ui.v1';
  const DEFAULT_SETTINGS = {
    theme: 'light', fontSize: 14, indentSpaces: true, indentUnit: 4,
    autoActivation: true, autoActivationDelay: 200, autoActivationTriggers: '.',
    autoBuild: true, saveBeforeLaunch: 'prompt', launchWithErrors: 'prompt', markOccurrences: true,
  };

  // Mac では、Eclipse (mac 版) と同じく Ctrl の代わりに ⌘ を使う (補完の Control + Space はそのまま)
  const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent || '');
  /** "Ctrl+Shift+F" のようなキーの表記を、Mac では "⇧⌘F" にする */
  function keyLabel(s) {
    if (!IS_MAC || !s) return s;
    return s.replace(/((?:Ctrl|Shift|Alt)\+)+([A-Za-z0-9]+|[^\s()（）,、A-Za-z0-9])/g, (m, x, key) => {
      const mods = m.slice(0, m.length - key.length);
      const ctrl = /Ctrl\+/.test(mods);
      return (ctrl && key === 'Space' ? '⌃' : '') + (/Alt\+/.test(mods) ? '⌥' : '') + (/Shift\+/.test(mods) ? '⇧' : '') + (ctrl && key !== 'Space' ? '⌘' : '') + key;
    }).replace(/Ctrl\+クリック/g, '⌘+クリック');
  }
  /** キーの表記を <kbd> で囲んだ HTML にする */
  function kbdHtml(s) {
    const l = keyLabel(s);
    if (IS_MAC) return `<kbd>${l.replace(/[<>&]/g, '')}</kbd>`;
    return l.split('+').map(p => `<kbd>${p}</kbd>`).join('+');
  }
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // =================================================================
  // パスの扱い  (プロジェクト/src/パッケージ/クラス.java)
  // =================================================================
  const projectOf = p => p.split('/')[0];
  const baseName = p => p.split('/').pop();
  const parentOf = p => p.split('/').slice(0, -1).join('/');
  const isJava = p => /\.java$/.test(p);
  const isHidden = p => p.split('/').some(s => s.startsWith('.'));
  const extOf = p => (baseName(p).match(/\.([^.]+)$/) || [])[1]?.toLowerCase() || '';
  /** ファイルの種類: java / html / css / js / xml / image / text */
  function fileKind(p) {
    const e = extOf(p);
    if (e === 'java') return 'java';
    if (e === 'html' || e === 'htm') return 'html';
    if (e === 'css' || e === 'js') return e;
    if (e === 'xml' || e === 'svg') return 'xml';
    if (/^(png|jpg|jpeg|gif|webp|ico)$/.test(e)) return 'image';
    return 'text';
  }
  /** エクスプローラーやタブに出すアイコンの名前 */
  function fileIcon(p) { return { java: 'jfile', html: 'htmlfile', css: 'cssfile', js: 'jsfile', image: 'imgfile' }[fileKind(p)] || 'file'; }
  /** Java のソース・フォルダー (Java プロジェクトは src、動的 Web プロジェクトは src/main/java) */
  function srcRoot(project) {
    const m = (files.get(project + '/.classpath') || '').match(/<classpathentry\s+kind="src"\s+path="([^"]+)"/);
    return project + '/' + (m ? m[1] : 'src');
  }
  /** 動的 Web プロジェクト (Eclipse の WTP のモジュール) か */
  function isWebProject(project) { return /org\.eclipse\.wst\.common\.modulecore\.ModuleCoreNature/.test(files.get(project + '/.project') || ''); }
  function webComponent(project) { return files.get(project + '/.settings/org.eclipse.wst.common.component') || ''; }
  /** Web コンテンツのフォルダー (src/main/webapp など。ワークスペースからのパス) */
  function webContentRoot(project) {
    const m = webComponent(project).match(/<wb-resource\s+deploy-path="\/"\s+source-path="\/?([^"]*)"/);
    return project + '/' + (m ? m[1].replace(/\/$/, '') : 'src/main/webapp');
  }
  /** コンテキスト・ルート (URL の /html/ の部分) */
  function contextRoot(project) {
    const m = webComponent(project).match(/<property\s+name="context-root"\s+value="([^"]*)"/);
    return m ? m[1] : project;
  }
  function srcRel(p) { const r = srcRoot(projectOf(p)) + '/'; return p.startsWith(r) ? p.slice(r.length) : null; }
  function pkgOfDir(dir) { const r = srcRoot(projectOf(dir)); return dir === r ? '' : dir.slice(r.length + 1).replace(/\//g, '.'); }
  function fqnOf(p) { const rel = srcRel(p); return rel ? rel.replace(/\.java$/, '').replace(/\//g, '.') : null; }
  function projects() {
    const set = new Set();
    for (const d of dirs) if (!d.includes('/') && !d.startsWith('.')) set.add(d);
    for (const f of [...files.keys(), ...binaries]) if (f.includes('/') && !f.startsWith('.')) set.add(projectOf(f));
    const hidden = new Set(ui.hiddenProjects || []);
    return [...set].filter(p => !hidden.has(p)).sort((a, b) => a.localeCompare(b));
  }
  function projectJre(project) {
    const cp = files.get(project + '/.classpath') || '';
    const m = cp.match(/JavaSE-(\d+)/);
    return m ? +m[1] : 17;
  }
  function javaFilesOf(project) {
    const r = srcRoot(project) + '/';
    return [...files.keys()].filter(f => f.startsWith(r) && isJava(f)).sort();
  }
  function packagesOf(project) {
    const r = srcRoot(project);
    const set = new Set();
    for (const d of dirs) if (d.startsWith(r + '/')) set.add(d);
    for (const f of javaFilesOf(project)) set.add(parentOf(f));
    // Eclipse と同じく、.java を持たず子パッケージだけを持つフォルダは表示しない
    const list = [...set].filter(d => d !== r);
    return list.filter(d => {
      const hasJava = javaFilesOf(project).some(f => parentOf(f) === d);
      const hasChild = list.some(x => x.startsWith(d + '/'));
      return hasJava || !hasChild;
    }).sort((a, b) => pkgOfDir(a).localeCompare(pkgOfDir(b)));
  }
  function contentOf(p) {
    const ed = editors.find(e => e.path === p);
    return ed ? ed.cm.getValue() : files.get(p);
  }

  function replaceContents(obj, values) {
    for (const k of Object.keys(obj)) delete obj[k];
    Object.assign(obj, values);
  }
  function loadSettings() {
    try { replaceContents(settings, Object.assign({}, DEFAULT_SETTINGS, JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}'))); } catch (e) { replaceContents(settings, DEFAULT_SETTINGS); }
  }
  function saveSettings() { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (e) { /* 無視 */ } }
  function loadUi() {
    try { replaceContents(ui, JSON.parse(localStorage.getItem(UI_KEY) || '{}')); } catch (e) { replaceContents(ui, {}); }
    (ui.expanded || []).forEach(x => expanded.add(x));
  }
  function saveUi() {
    ui.expanded = [...expanded];
    ui.openEditors = editors.map(e => e.path);
    ui.activeEditor = S.active ? S.active.path : null;
    try { localStorage.setItem(UI_KEY, JSON.stringify(ui)); } catch (e) { /* 無視 */ }
  }
  function applyTheme() {
    document.documentElement.dataset.theme = settings.theme === 'dark' ? 'dark' : 'light';
    document.documentElement.style.setProperty('--code-size', settings.fontSize + 'px');
    for (const e of editors) { e.cm.setOption('indentWithTabs', !settings.indentSpaces); e.cm.refresh(); }
  }

  // =================================================================
  // ステータス
  // =================================================================
  let statusTimer = null;
  function status(msg, keep) {
    const el = $('#st-msg');
    el.textContent = msg || '';
    clearTimeout(statusTimer);
    if (msg && !keep) statusTimer = setTimeout(() => { el.textContent = ''; }, 6000);
  }
  function setJavaStatus(msg, busy) {
    const el = $('#st-java');
    el.textContent = msg;
    el.style.display = msg ? '' : 'none'; // Java を使わないあいだは出さない
    el.classList.toggle('busy', !!busy);
  }
  function progress(on) { $('#st-progress').hidden = !on; }

  const ICON_SVG = {
    project: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/><text x="10.5" y="13" font-size="7" font-family="Arial" font-weight="bold" fill="#3060b0">J</text></svg>',
    srcfolder: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/><path d="M8 7 L12.5 9.2 L12.5 12.8 L8 15 L3.5 12.8 L3.5 9.2 Z" transform="translate(1,-2) scale(.75)" fill="#c8a165" stroke="#8a6a35"/></svg>',
    package: Assist.ICONS.package,
    packageEmpty: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 5 L8 2 L14 5 L14 11.5 L8 14.5 L2 11.5 Z" fill="#f4ecdc" stroke="#a89070"/><path d="M2 5 L8 8 L14 5 M8 8 L8 14.5" fill="none" stroke="#a89070"/></svg>',
    jfile: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#7a8aa0"/><path d="M10 1.5v3h3" fill="none" stroke="#7a8aa0"/><text x="8" y="12.5" font-size="8" font-family="Arial" font-weight="bold" fill="#3060b0" text-anchor="middle">J</text></svg>',
    file: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#888"/><path d="M10 1.5v3h3" fill="none" stroke="#888"/><path d="M5 8h6M5 10h6M5 12h4" stroke="#aaa"/></svg>',
    jre: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2" y="4" width="12" height="9" rx="1" fill="#d9c7a0" stroke="#8a7650"/><rect x="4" y="2" width="8" height="3" fill="#b9a780" stroke="#8a7650"/></svg>',
    save: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 2h10l2 2v10H2z" fill="#4a7fc1" stroke="#2c5a94"/><rect x="4.5" y="2.5" width="6" height="4" fill="#fff"/><rect x="4" y="9" width="8" height="4.5" fill="#dfe8f5"/></svg>',
    saveall: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M4 1h9l2 2v9H4z" fill="#8fb0dc" stroke="#2c5a94"/><path d="M1 4h9l2 2v9H1z" fill="#4a7fc1" stroke="#2c5a94"/><rect x="3" y="4.5" width="5" height="3" fill="#fff"/></svg>',
    run: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="7" fill="#2fa52f" stroke="#1d7a1d"/><path d="M6 4.5 L11.5 8 L6 11.5 Z" fill="#fff"/></svg>',
    terminate: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="3" y="3" width="10" height="10" fill="#d9302c" stroke="#a11c19"/></svg>',
    newwiz: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#888"/><path d="M10 1.5v3h3" fill="none" stroke="#888"/><path d="M11.5 9v6M8.5 12h6" stroke="#d48b1a" stroke-width="1.8"/></svg>',
    build: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 12 L9 5" stroke="#777" stroke-width="2.5"/><rect x="8" y="1.5" width="6" height="6" transform="rotate(45 11 4.5)" fill="#9a9a9a" stroke="#555"/></svg>',
    lesson: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3c2.5-1 4.5-1 6.5.5v10.5c-2-1.5-4-1.5-6.5-.5z" fill="#55a4e8" stroke="#2b6cb0"/><path d="M14.5 3c-2.5-1-4.5-1-6.5.5v10.5c2-1.5 4-1.5 6.5-.5z" fill="#8cc4f2" stroke="#2b6cb0"/></svg>',
    search: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="6.5" cy="6.5" r="4.5" fill="#fff" stroke="#555" stroke-width="1.5"/><path d="M10 10 L14.5 14.5" stroke="#555" stroke-width="2"/></svg>',
    console: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="1.5" y="2.5" width="13" height="11" fill="#fff" stroke="#555"/><rect x="1.5" y="2.5" width="13" height="2.5" fill="#4a7fc1"/><path d="M4 8 L6 9.5 L4 11 M7.5 11h3.5" stroke="#333" fill="none"/></svg>',
    markers: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2" y="2" width="12" height="12" fill="#fff" stroke="#777"/><circle cx="5.5" cy="6" r="1.8" fill="#e51400"/><path d="M8 6h4.5" stroke="#555"/><path d="M5.5 9 L7.3 12 L3.7 12 Z" fill="#f5a623"/><path d="M8 11h4.5" stroke="#555"/></svg>',
    outline: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 3h10M5 6h8M5 9h8M3 12h10" stroke="#555" stroke-width="1.5"/><circle cx="3" cy="6" r="1" fill="#3fae3f"/><circle cx="3" cy="9" r="1" fill="#d94a4a"/></svg>',
    explorer: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/></svg>',
    collapse: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2.5" y="2.5" width="11" height="11" fill="#fff" stroke="#777"/><path d="M5 8h6" stroke="#333" stroke-width="1.5"/></svg>',
    link: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 11 L13 5 M3 5 L13 11" stroke="#d5a33a" stroke-width="1.8"/></svg>',
    clear: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2.5" y="2.5" width="11" height="11" fill="#fff" stroke="#777"/><path d="M5 5 L11 11 M11 5 L5 11" stroke="#999"/></svg>',
    scrolllock: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="3.5" y="7" width="9" height="7" fill="#e8c46a" stroke="#a8822a"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2" fill="none" stroke="#777" stroke-width="1.5"/></svg>',
    error: '<svg viewBox="0 0 16 16" width="14" height="14"><circle cx="8" cy="8" r="7" fill="#e51400"/><path d="M5.2 5.2 L10.8 10.8 M10.8 5.2 L5.2 10.8" stroke="#fff" stroke-width="1.8"/></svg>',
    warning: '<svg viewBox="0 0 16 16" width="14" height="14"><path d="M8 1.5 L15 14.5 L1 14.5 Z" fill="#f5c623" stroke="#b58a00"/><path d="M8 6v4.5" stroke="#000" stroke-width="1.6"/><circle cx="8" cy="12.5" r=".9" fill="#000"/></svg>',
    info: '<svg viewBox="0 0 16 16" width="14" height="14"><circle cx="8" cy="8" r="7" fill="#3f7fd9"/><text x="8" y="12" font-size="10" font-family="Georgia" font-weight="bold" fill="#fff" text-anchor="middle">i</text></svg>',
    decoError: '<svg viewBox="0 0 9 9" width="9" height="9"><rect x="0" y="0" width="9" height="9" fill="#fff"/><circle cx="4.5" cy="4.5" r="4" fill="#e51400"/><path d="M2.7 2.7 L6.3 6.3 M6.3 2.7 L2.7 6.3" stroke="#fff" stroke-width="1.3"/></svg>',
    decoWarning: '<svg viewBox="0 0 9 9" width="9" height="9"><path d="M4.5 0.5 L8.7 8.5 L0.3 8.5 Z" fill="#f5c623" stroke="#b58a00" stroke-width=".7"/></svg>',
    bulb: '<svg viewBox="0 0 16 16" width="14" height="14"><path d="M8 1.5a4.5 4.5 0 0 0-2.6 8.2V12h5.2V9.7A4.5 4.5 0 0 0 8 1.5z" fill="#ffd94a" stroke="#b58a00"/><rect x="5.5" y="12.5" width="5" height="2" fill="#999"/></svg>',
    wizard: '<svg viewBox="0 0 56 48" width="56" height="48"><rect x="6" y="6" width="34" height="28" fill="#eef3fa" stroke="#7d93b2"/><path d="M10 12h26M10 17h20M10 22h24" stroke="#9cb0cc" stroke-width="2"/><circle cx="42" cy="32" r="10" fill="#3fa53f" stroke="#2c6e2c"/><text x="42" y="36.5" font-size="12" font-family="Arial" font-weight="bold" fill="#fff" text-anchor="middle">J</text></svg>',
    // HTML入門 (動的 Web プロジェクト・サーバー) 用
    webproject: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/><circle cx="11" cy="11" r="3.6" fill="#4f8fd8" stroke="#2c5a94" stroke-width=".8"/><path d="M7.4 11h7.2M11 7.4c-1.6 2.2-1.6 5 0 7.2M11 7.4c1.6 2.2 1.6 5 0 7.2" stroke="#fff" stroke-width=".7" fill="none"/></svg>',
    folder: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M1.5 3.5h5l1.5 1.5h6.5v8.5h-13z" fill="#e8c46a" stroke="#a8822a"/></svg>',
    htmlfile: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#7a8aa0"/><path d="M10 1.5v3h3" fill="none" stroke="#7a8aa0"/><path d="M6.6 8 L4.8 10 L6.6 12 M9.4 8 L11.2 10 L9.4 12" fill="none" stroke="#d2691e" stroke-width="1.3"/></svg>',
    cssfile: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#7a8aa0"/><path d="M10 1.5v3h3" fill="none" stroke="#7a8aa0"/><path d="M7 7.5c-1.2 0-1.2 1-1.2 1.6S5.2 10 4.8 10c.4 0 1 .3 1 .9s0 1.6 1.2 1.6M9 7.5c1.2 0 1.2 1 1.2 1.6s.6.9 1 .9c-.4 0-1 .3-1 .9s0 1.6-1.2 1.6" fill="none" stroke="#2965f1" stroke-width="1.1"/></svg>',
    jsfile: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#7a8aa0"/><path d="M10 1.5v3h3" fill="none" stroke="#7a8aa0"/><text x="8" y="12.5" font-size="6.5" font-family="Arial" font-weight="bold" fill="#b8a000" text-anchor="middle">JS</text></svg>',
    imgfile: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="1.5" y="2.5" width="13" height="11" fill="#fff" stroke="#7a8aa0"/><circle cx="5.5" cy="6" r="1.4" fill="#f5a623"/><path d="M2 13 L6.5 8.5 L9 11 L11 9 L14 12.5 V13 Z" fill="#5aa05a"/></svg>',
    server: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2.5" y="1.5" width="11" height="13" rx="1" fill="#d7dde6" stroke="#6a7a90"/><path d="M4.5 4.5h7M4.5 7h7M4.5 9.5h7" stroke="#6a7a90"/><circle cx="11" cy="12.2" r="1" fill="#6a7a90"/></svg>',
    module: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2" y="3" width="12" height="10" fill="#fff" stroke="#7a8aa0"/><rect x="2" y="3" width="12" height="2.5" fill="#4f8fd8"/><circle cx="8" cy="9.4" r="2.4" fill="none" stroke="#2c5a94"/></svg>',
    srvStart: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="6.5" fill="#2fa52f" stroke="#1d7a1d"/><path d="M6.3 4.8 L11 8 L6.3 11.2 Z" fill="#fff"/></svg>',
    srvStop: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="3" y="3" width="10" height="10" fill="#d9302c" stroke="#a11c19"/></svg>',
    srvRestart: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M12.5 8a4.5 4.5 0 1 1-1.4-3.3" fill="none" stroke="#2fa52f" stroke-width="2"/><path d="M12.8 2.2 L12.8 6 L9 6 Z" fill="#2fa52f"/></svg>',
    webwizard: '<svg viewBox="0 0 56 48" width="56" height="48"><rect x="6" y="6" width="34" height="28" fill="#eef3fa" stroke="#7d93b2"/><path d="M10 12h26M10 17h20M10 22h24" stroke="#9cb0cc" stroke-width="2"/><circle cx="42" cy="32" r="10" fill="#4f8fd8" stroke="#2c5a94"/><path d="M32 32h20M42 22c-4 6-4 14 0 20M42 22c4 6 4 14 0 20" stroke="#fff" stroke-width="1.4" fill="none"/></svg>',
  };
  function icon(name) { return ICON_SVG[name] || Assist.ICONS[name] || ''; }

  Object.assign(IDE, { S, $, $$, binaries, extOf, fileIcon, fileKind, DEFAULT_SETTINGS, ICON_SVG, IS_MAC, SETTINGS_KEY, UI_KEY, applyTheme, baseName, building, builtVersion, contentOf, contextRoot, dirs, editors, esc, expanded, files, fqnOf, icon, isHidden, isJava, isWebProject, javaFilesOf, kbdHtml, keyLabel, loadSettings, loadUi, packagesOf, parentOf, pkgOfDir, problems, progress, projVersion, projectJre, projectOf, projects, run, saveSettings, saveUi, setJavaStatus, settings, srcRel, srcRoot, status, ui, webContentRoot });
})();
