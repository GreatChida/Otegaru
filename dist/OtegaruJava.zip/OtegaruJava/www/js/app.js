// お手軽Java - Eclipse (Pleiades) 風 IDE 本体 (起動)
// 機能ごとのファイルは js/ide/ にある。ファイルどうしは IDE (js/ide/core.js) を通してつながる
'use strict';

const App = (() => {
  const { S, $, binaries, editors, files, dirs, problems, settings, ui, run } = IDE;
  const { loadSettings, applyTheme, loadUi, buildMenus, buildToolbar, initLayout, initViews, currentProjectTypes, applyLessonCode, status,
    renderExplorer, openEditor, updateWelcome, restoreTerminated, globalKeys, isDirty, saveUi, needsJava, ensureJava, setJavaStatus,
    command, runFile, initServers, openLessonPage, ensureWorkspace } = IDE.fn;

  async function boot() {
    loadSettings();
    applyTheme();
    const splash = document.createElement('div');
    splash.className = 'boot';
    splash.innerHTML = `<div class="box"><div class="splash"><h1>お手軽Java</h1><div class="ver">Eclipse 風 Java 独習環境 ・ CheerpJ ・ Java 17</div>
      <svg class="cup" viewBox="0 0 64 64"><path d="M14 26h30v14a14 14 0 0 1-14 14h-2a14 14 0 0 1-14-14z" fill="#fff" opacity=".92"/><path d="M44 30h4a6 6 0 0 1 0 12h-4" fill="none" stroke="#fff" stroke-width="3" opacity=".92"/><path d="M24 8c-3 4 3 6 0 10M32 6c-3 4 3 6 0 10" stroke="#fff" stroke-width="2.5" fill="none" opacity=".8"/></svg></div>
      <div class="msg" id="boot-msg">ワークスペースを読み込み中…</div><div class="bar"></div></div>`;
    document.body.appendChild(splash);

    // 最初の起動では、ワークスペースの場所を決めてから読み込む
    const chosen = await ensureWorkspace(() => { splash.style.display = 'none'; });
    splash.style.display = '';
    const w = await Storage.load();
    for (const d of w.dirs) dirs.add(d);
    for (const [p, c] of Object.entries(w.files)) files.set(p, c.replace(/\r\n/g, '\n'));
    for (const b of w.binaries) binaries.add(b);
    loadUi();

    buildMenus();
    buildToolbar();
    initLayout();
    initViews();
    Assist.setContext({ projectTypes: currentProjectTypes, currentPkg: () => S.active ? (JavaSrc.parse(S.active.cm.getValue()).pkg) : '' });
    Lesson.init({ applyCode: applyLessonCode, consoleText: () => run.text, openExternal: url => window.open(url, '_blank', 'noopener'), notify: status, openInBrowser: openLessonPage });
    initServers();
    renderExplorer();
    for (const p of (ui.openEditors || [])) if (files.has(p)) openEditor(p, { noFocus: true });
    if (ui.activeEditor && files.has(ui.activeEditor)) openEditor(ui.activeEditor);
    updateWelcome();
    restoreTerminated();
    splash.remove();
    document.addEventListener('keydown', globalKeys, true);
    window.addEventListener('beforeunload', e => { if (editors.some(isDirty)) { e.preventDefault(); e.returnValue = ''; } saveUi(); });
    if (Storage.mode !== 'server') status('ブラウザ保存モード: start.bat (Mac は start.command) から起動すると ワークスペースのフォルダーにファイルとして保存されます');
    else if (chosen) status('ワークスペース: ' + chosen.path);

    // Java (CheerpJ) の準備は裏で行う。Java を使わない (HTML だけの) ときは読み込まない
    if (needsJava()) ensureJava(); else setJavaStatus('');
  }

  return { boot, command, get settings() { return settings; }, files, editors, problems, runFile, openEditor };
})();

window.addEventListener('DOMContentLoaded', () => App.boot().catch(e => { console.error(e); alert('起動に失敗しました: ' + e.message); }));
