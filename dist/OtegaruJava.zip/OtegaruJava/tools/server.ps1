﻿# お手軽Java ローカルWebサーバ (Windows PowerShell 5.1 標準機能のみ / インストール不要)
# - HTTP Range 要求に対応 (CheerpJ の必須要件)
# - localhost のみで待ち受け (外部からはアクセス不可)
# - /api/* でワークスペース (ドキュメントの workspace フォルダー) へのファイル保存・読込
# - ワークスペースの場所は最初の起動で IDE の画面から選び、workspace.json に覚える
# - /api/web/* で、Tomcat の代わりの Web サーバー (HTML入門用。動的 Web プロジェクトを配信する) を開始・停止
param(
  [int]$Port = 8765,
  [switch]$NoBrowser,
  [string]$DocumentsDir   # ドキュメント・フォルダーの代わりに使うフォルダー (試すとき用)
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$WebRoot = [System.IO.Path]::GetFullPath((Join-Path $Root 'www'))
$Utf8 = New-Object System.Text.UTF8Encoding($false)

# ワークスペース: 選んだ場所を workspace.json に覚える。まだ選んでいない (または消えた) ときは $null で、IDE の画面で選ぶ
$ConfigFile = Join-Path $Root 'workspace.json'
$LegacyWorkDir = Join-Path $Root 'work'   # 以前の版の保存場所 (展開したフォルダーの中)
$Documents = if ($DocumentsDir) { $DocumentsDir } else { [Environment]::GetFolderPath('MyDocuments') }
$WorkDir = $null
if (Test-Path $ConfigFile) {
  try {
    $saved = [string](ConvertFrom-Json ([System.IO.File]::ReadAllText($ConfigFile, $Utf8))).path
    if ($saved -and (Test-Path -LiteralPath $saved -PathType Container)) { $WorkDir = $saved }
  } catch {}
}

$Mime = @{
  '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8'
  '.js'='text/javascript; charset=utf-8'; '.mjs'='text/javascript; charset=utf-8'
  '.css'='text/css; charset=utf-8'; '.json'='application/json; charset=utf-8'
  '.txt'='text/plain; charset=utf-8'; '.java'='text/plain; charset=utf-8'; '.md'='text/plain; charset=utf-8'
  '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.gif'='image/gif'; '.ico'='image/x-icon'
  '.jar'='application/java-archive'; '.class'='application/java-vm'; '.wasm'='application/wasm'
  '.woff2'='font/woff2'
}

# 空いているポートを探して起動
$listener = $null
for ($p = $Port; $p -lt $Port + 20; $p++) {
  $l = New-Object System.Net.HttpListener
  $l.Prefixes.Add("http://localhost:$p/")
  try { $l.Start(); $listener = $l; $Port = $p; break } catch { $l.Close() }
}
if (-not $listener) { Write-Host "ポートを確保できませんでした。" -ForegroundColor Red; exit 1 }

$url = "http://localhost:$Port/"
$Host.UI.RawUI.WindowTitle = "お手軽Java - $url"
Write-Host ""
Write-Host "  お手軽Java が起動しました: $url" -ForegroundColor Green
Write-Host "  このウィンドウを閉じる (または Ctrl+C) と終了します。"
if ($WorkDir) { Write-Host "  ワークスペース (書いたプログラムの保存場所): $WorkDir" }
else { Write-Host "  ワークスペース (書いたプログラムの保存場所) は、ブラウザーの画面で選んでください。" }
Write-Host ""
if (-not $NoBrowser) { Start-Process $url }

function Send-Bytes($res, [byte[]]$bytes, [string]$type, [int]$status = 200) {
  $res.StatusCode = $status
  $res.ContentType = $type
  $res.ContentLength64 = $bytes.Length
  $res.OutputStream.Write($bytes, 0, $bytes.Length)
}
function Send-Text($res, [string]$text, [string]$type = 'text/plain; charset=utf-8', [int]$status = 200) {
  Send-Bytes $res ($Utf8.GetBytes($text)) $type $status
}
function Send-Json($res, [string]$json) { Send-Text $res $json 'application/json; charset=utf-8' }

# ワークスペースで扱うファイル: 文字のファイル (内容を IDE に読み込む) と、画像などのバイナリー・ファイル
$TextExt = '\.(java|txt|md|prefs|html|htm|css|js|json|xml|svg|mf|component|properties)$'
$BinaryExt = '\.(png|jpg|jpeg|gif|webp|ico)$'

function Get-SafeWorkPath([string]$rel, [switch]$File) {
  # ワークスペースの中だけを扱う。各部分は英数字 _ - . のみ (.. は不可)
  if ([string]::IsNullOrWhiteSpace($rel)) { return $null }
  $parts = $rel.Replace('\', '/').Split('/')
  foreach ($p in $parts) {
    if ($p -notmatch '^[A-Za-z0-9_\-\.]{1,80}$' -or $p -eq '.' -or $p -eq '..') { return $null }
  }
  if ($File -and $rel -notmatch $TextExt -and $rel -notmatch $BinaryExt -and $rel -notmatch '(^|/)\.(project|classpath|jsdtscope)$') { return $null }
  $full = [System.IO.Path]::GetFullPath((Join-Path $WorkDir ($parts -join '\')))
  if (-not $full.StartsWith([System.IO.Path]::GetFullPath($WorkDir) + '\', [StringComparison]::OrdinalIgnoreCase)) { return $null }
  return $full
}

function Read-Body($req) {
  $sr = New-Object System.IO.StreamReader($req.InputStream, $Utf8)
  $body = $sr.ReadToEnd(); $sr.Close(); return $body
}

function Get-Tree {
  $base = [System.IO.Path]::GetFullPath($WorkDir).TrimEnd('\') + '\'
  # 「.」で始まるフォルダーは .settings (Eclipse の設定) と .otegaru (お手軽Java の設定) だけを読む
  # (Eclipse のワークスペースを使うときに、.metadata などの大量のファイルを読まないように)
  $dirItems = New-Object System.Collections.ArrayList
  $stack = New-Object System.Collections.Stack
  $stack.Push((Get-Item -LiteralPath $WorkDir))
  while ($stack.Count) {
    $d = $stack.Pop()
    foreach ($c in @(Get-ChildItem -LiteralPath $d.FullName -Directory -Force)) {
      if ($c.Name.StartsWith('.') -and $c.Name -ne '.settings' -and $c.Name -ne '.otegaru') { continue }
      [void]$dirItems.Add($c); $stack.Push($c)
    }
  }
  $dirs = @($dirItems | ForEach-Object { $_.FullName.Substring($base.Length).Replace('\', '/') })
  $files = @(@(Get-Item -LiteralPath $WorkDir) + @($dirItems) | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -File -Force } | ForEach-Object {
    $rel = $_.FullName.Substring($base.Length).Replace('\', '/')
    if ($rel -match $TextExt -or $_.Name -match '^\.(project|classpath|jsdtscope)$') {
      [ordered]@{ path = $rel; content = [System.IO.File]::ReadAllText($_.FullName, $Utf8) }
    } elseif ($rel -match $BinaryExt) {
      [ordered]@{ path = $rel; binary = $true; size = $_.Length }
    }
  })
  $obj = [ordered]@{ dirs = $dirs; files = $files; root = [System.IO.Path]::GetFullPath($WorkDir) }
  return (ConvertTo-Json -InputObject $obj -Depth 5 -Compress)
}

# ---- ワークスペースの選択 ----
# 候補は「ドキュメント\workspace」。すでにあるときは、そのまま使うか「workspace2」などの無い名前にするかを IDE で聞く
function Get-LegacyProjects {
  if (-not (Test-Path $LegacyWorkDir)) { return @() }
  return @(Get-ChildItem -LiteralPath $LegacyWorkDir -Directory | Where-Object { -not $_.Name.StartsWith('.') } | ForEach-Object { $_.Name })
}
function Get-WorkspaceInfo {
  $cand = Join-Path $Documents 'workspace'
  $n = 2; while (Test-Path -LiteralPath (Join-Path $Documents "workspace$n")) { $n++ }
  $info = [ordered]@{
    configured = [bool]$WorkDir; path = $WorkDir; documents = $Documents
    candidate = $cand; candidateExists = (Test-Path -LiteralPath $cand)
    candidateIsOtegaru = (Test-Path -LiteralPath (Join-Path $cand '.otegaru'))
    alternative = (Join-Path $Documents "workspace$n")
    legacy = [ordered]@{ path = $LegacyWorkDir; projects = @(Get-LegacyProjects) }
  }
  return (ConvertTo-Json -InputObject $info -Depth 4 -Compress)
}
function Select-Workspace([string]$json) {
  $req = ConvertFrom-Json $json
  $target = [System.IO.Path]::GetFullPath([string]$req.path)
  # 選べるのは、ドキュメントの中の workspace・workspace2… だけ
  $name = Split-Path -Leaf $target
  if ((Split-Path -Parent $target) -ne [System.IO.Path]::GetFullPath($Documents) -or $name -notmatch '^workspace\d*$') { throw 'このフォルダーはワークスペースにできません' }
  if (-not (Test-Path -LiteralPath $target)) { New-Item -ItemType Directory $target | Out-Null }
  $marker = Join-Path $target '.otegaru'
  if (-not (Test-Path -LiteralPath $marker)) { New-Item -ItemType Directory $marker | Out-Null }
  # 以前の保存場所 (展開したフォルダーの work) のプロジェクトをコピーする (元はそのまま残す)
  $copied = @(); $skipped = @()
  if ($req.copyLegacy) {
    foreach ($p in Get-LegacyProjects) {
      $dest = Join-Path $target $p
      if (Test-Path -LiteralPath $dest) { $skipped += $p; continue }
      Copy-Item -LiteralPath (Join-Path $LegacyWorkDir $p) -Destination $dest -Recurse
      $copied += $p
    }
  }
  [System.IO.File]::WriteAllText($ConfigFile, (ConvertTo-Json -InputObject ([ordered]@{ path = $target }) -Compress), $Utf8)
  $script:WorkDir = $target
  Write-Host "  ワークスペース (書いたプログラムの保存場所): $target"
  return (ConvertTo-Json -InputObject ([ordered]@{ ok = $true; path = $target; copied = @($copied); skipped = @($skipped) }) -Compress)
}

function Handle-Api($req, $res) {
  $path = $req.Url.AbsolutePath
  $q = $req.QueryString['path']
  $m = $req.HttpMethod
  if ($path -eq '/api/ping') { Send-Json $res '{"ok":true}'; return }
  if ($path -eq '/api/workspace') { Send-Json $res (Get-WorkspaceInfo); return }
  if ($path -eq '/api/workspace/select' -and $m -eq 'POST') {
    try { Send-Json $res (Select-Workspace (Read-Body $req)) } catch { Send-Text $res $_.Exception.Message 'text/plain; charset=utf-8' 400 }
    return
  }
  if ($path -eq '/api/shutdown') { Send-Json $res '{"ok":true}'; $script:stop = $true; return }
  if (-not $WorkDir) { Send-Text $res 'ワークスペースが選ばれていません' 'text/plain; charset=utf-8' 409; return }
  if ($path -eq '/api/tree') { Send-Json $res (Get-Tree); return }
  if ($path -eq '/api/file') {
    $fp = Get-SafeWorkPath $q -File
    if (-not $fp) { Send-Text $res '使えない名前です (英数字 _ - . のみ)' 'text/plain; charset=utf-8' 400; return }
    if ($m -eq 'GET') {
      if (-not (Test-Path $fp -PathType Leaf)) { Send-Text $res 'not found' 'text/plain; charset=utf-8' 404; return }
      Send-Text $res ([System.IO.File]::ReadAllText($fp, $Utf8)); return
    }
    if ($m -eq 'PUT' -or $m -eq 'POST') {
      $dir = Split-Path -Parent $fp
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
      if ($fp -match $BinaryExt) {
        # 画像などは、届いたバイト列をそのまま書く
        $out = [System.IO.File]::Create($fp)
        try { $req.InputStream.CopyTo($out) } finally { $out.Close() }
      } else {
        [System.IO.File]::WriteAllText($fp, (Read-Body $req), $Utf8)
      }
      Send-Json $res '{"ok":true}'; return
    }
    if ($m -eq 'DELETE') {
      if (Test-Path $fp -PathType Leaf) { Remove-Item -LiteralPath $fp -Force }
      Send-Json $res '{"ok":true}'; return
    }
  }
  if ($path -eq '/api/dir') {
    $dp = Get-SafeWorkPath $q
    if (-not $dp) { Send-Text $res '使えない名前です (英数字 _ - . のみ)' 'text/plain; charset=utf-8' 400; return }
    if ($m -eq 'POST' -or $m -eq 'PUT') { New-Item -ItemType Directory -Force $dp | Out-Null; Send-Json $res '{"ok":true}'; return }
    if ($m -eq 'DELETE') {
      # 削除はごみ箱へ (元に戻せるように)
      if (Test-Path $dp) {
        Add-Type -AssemblyName Microsoft.VisualBasic
        [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($dp, 'OnlyErrorDialogs', 'SendToRecycleBin')
      }
      Send-Json $res '{"ok":true}'; return
    }
  }
  if ($path -eq '/api/trash') {
    # ファイルをごみ箱へ
    $fp = Get-SafeWorkPath $q -File
    if (-not $fp) { Send-Text $res 'bad path' 'text/plain; charset=utf-8' 400; return }
    if (Test-Path $fp -PathType Leaf) {
      Add-Type -AssemblyName Microsoft.VisualBasic
      [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($fp, 'OnlyErrorDialogs', 'SendToRecycleBin')
    }
    Send-Json $res '{"ok":true}'; return
  }
  if ($path -eq '/api/rename' -and $m -eq 'POST') {
    $from = Get-SafeWorkPath $req.QueryString['from']
    $to = Get-SafeWorkPath $req.QueryString['to']
    if (-not $from -or -not $to -or -not (Test-Path $from) -or (Test-Path $to)) { Send-Text $res '名前を変更できません' 'text/plain; charset=utf-8' 400; return }
    $dir = Split-Path -Parent $to
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
    Move-Item -LiteralPath $from -Destination $to
    Send-Json $res '{"ok":true}'; return
  }
  if ($path -eq '/api/open-folder') {
    $dp = $WorkDir
    if ($q) { $t = Get-SafeWorkPath $q; if ($t -and (Test-Path $t -PathType Container)) { $dp = $t } }
    Start-Process explorer.exe $dp; Send-Json $res '{"ok":true}'; return
  }
  if ($path -eq '/api/raw') {
    # ワークスペースのファイルをそのまま返す (IDE で画像を開くとき)
    $fp = Get-SafeWorkPath $q -File
    if (-not $fp -or -not (Test-Path $fp -PathType Leaf)) { Send-Text $res 'not found' 'text/plain; charset=utf-8' 404; return }
    $type = $Mime[[System.IO.Path]::GetExtension($fp).ToLower()]; if (-not $type) { $type = 'application/octet-stream' }
    Send-Bytes $res ([System.IO.File]::ReadAllBytes($fp)) $type; return
  }
  if ($path -eq '/api/open-file') {
    # 関連付けされたアプリ (画像ならフォトなど) で開く
    $fp = Get-SafeWorkPath $q -File
    if (-not $fp -or -not (Test-Path $fp -PathType Leaf)) { Send-Text $res 'not found' 'text/plain; charset=utf-8' 404; return }
    Invoke-Item -LiteralPath $fp; Send-Json $res '{"ok":true}'; return
  }
  if ($path -eq '/api/web') { Send-Json $res (Get-WebState); return }
  if ($path -eq '/api/web/start' -and $m -eq 'POST') {
    $p = 0
    if (-not [int]::TryParse($req.QueryString['port'], [ref]$p) -or $p -lt 1 -or $p -gt 65535) { Send-Text $res 'ポート番号が正しくありません' 'text/plain; charset=utf-8' 400; return }
    Set-WebModules (Read-Body $req)
    $err = Start-Web $p
    if ($err) { Send-Text $res $err 'text/plain; charset=utf-8' 409; return }
    Send-Json $res (Get-WebState); return
  }
  if ($path -eq '/api/web/stop' -and $m -eq 'POST') { Stop-Web; Send-Json $res (Get-WebState); return }
  if ($path -eq '/api/web/modules' -and $m -eq 'POST') { Set-WebModules (Read-Body $req); Send-Json $res (Get-WebState); return }
  if ($path -eq '/api/shutdown') { Send-Json $res '{"ok":true}'; $script:stop = $true; return }
  Send-Text $res 'not found' 'text/plain; charset=utf-8' 404
}

function Handle-Static($req, $res) {
  $rel = [Uri]::UnescapeDataString($req.Url.AbsolutePath).TrimStart('/')
  if ($rel -eq '') { $rel = 'index.html' }
  $full = [System.IO.Path]::GetFullPath((Join-Path $WebRoot $rel))
  if (-not $full.StartsWith($WebRoot, [StringComparison]::OrdinalIgnoreCase)) { Send-Text $res 'forbidden' 'text/plain' 403; return }
  if (Test-Path $full -PathType Container) { $full = Join-Path $full 'index.html' }
  if (-not (Test-Path $full -PathType Leaf)) { Send-Text $res 'not found' 'text/plain' 404; return }

  $ext = [System.IO.Path]::GetExtension($full).ToLower()
  $type = $Mime[$ext]; if (-not $type) { $type = 'application/octet-stream' }
  $res.AddHeader('Accept-Ranges', 'bytes')
  $res.AddHeader('Cache-Control', 'no-cache')
  $fs = [System.IO.File]::OpenRead($full)
  try {
    $len = $fs.Length
    $range = $req.Headers['Range']
    [int64]$start = 0; [int64]$end = $len - 1; $status = 200
    if ($range -and $range -match '^bytes=(\d*)-(\d*)$') {
      if ($Matches[1] -ne '') {
        $start = [int64]$Matches[1]
        if ($Matches[2] -ne '') { $end = [Math]::Min([int64]$Matches[2], $len - 1) }
      } elseif ($Matches[2] -ne '') {
        $start = [Math]::Max([int64]0, $len - [int64]$Matches[2])
      }
      if ($start -gt $end -or $start -ge $len) {
        $res.StatusCode = 416; $res.AddHeader('Content-Range', "bytes */$len"); return
      }
      $status = 206
      $res.AddHeader('Content-Range', "bytes $start-$end/$len")
    }
    $count = $end - $start + 1
    $res.StatusCode = $status
    $res.ContentType = $type
    $res.ContentLength64 = $count
    if ($req.HttpMethod -eq 'HEAD') { return }
    [void]$fs.Seek($start, [System.IO.SeekOrigin]::Begin)
    $buf = New-Object byte[] 65536
    $remain = $count
    while ($remain -gt 0) {
      $n = $fs.Read($buf, 0, [int][Math]::Min([int64]$buf.Length, $remain))
      if ($n -le 0) { break }
      $res.OutputStream.Write($buf, 0, $n)
      $remain -= $n
    }
  } finally { $fs.Close() }
}

# =====================================================================
# Tomcat の代わりの Web サーバー (HTML入門用)
#  - 動的 Web プロジェクトの Web コンテンツ (src/main/webapp など) を http://localhost:ポート/コンテキスト・ルート/ で返す
#  - Tomcat と同じように、POST でもファイルをそのまま返し、無いときは「HTTPステータス 404 – 見つかりません」を返す
#  - HttpListener は管理者権限が無いと 80 番ポートを使えないので、TCP で直接待ち受ける (この PC の中からだけ)
# =====================================================================
$Web = @{ running = $false; port = 0; modules = @(); listeners = @(); clients = (New-Object System.Collections.ArrayList) }
$Latin1 = [System.Text.Encoding]::GetEncoding(28591)
$WebMime = @{
  '.html'='text/html'; '.htm'='text/html'; '.css'='text/css'; '.js'='text/javascript'; '.json'='application/json'
  '.txt'='text/plain'; '.xml'='application/xml'; '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'
  '.gif'='image/gif'; '.webp'='image/webp'; '.ico'='image/x-icon'; '.pdf'='application/pdf'
}

function Get-WebState {
  $mods = @($Web.modules | ForEach-Object { [ordered]@{ context = $_.context; dir = $_.dir } })
  return (ConvertTo-Json -InputObject ([ordered]@{ running = $Web.running; port = $Web.port; modules = $mods }) -Depth 4 -Compress)
}

# 配信するプロジェクト ([{context, dir}]。dir はワークスペースからのパス) を決める
function Set-WebModules([string]$json) {
  $list = @()
  if ($json) {
    foreach ($m in @((ConvertFrom-Json $json).modules)) {
      if ($m.context -notmatch '^[A-Za-z0-9_\-\.]{1,80}$') { continue }
      $full = Get-SafeWorkPath ([string]$m.dir)
      if ($full) { $list += @{ context = [string]$m.context; dir = [string]$m.dir; full = $full } }
    }
  }
  $Web.modules = $list
}

# 待ち受けを始める。始められないときは理由を返す
function Start-Web([int]$p) {
  Stop-Web
  $ls = @()
  foreach ($addr in @([System.Net.IPAddress]::Loopback, [System.Net.IPAddress]::IPv6Loopback)) {
    $t = New-Object System.Net.Sockets.TcpListener($addr, $p)
    try { $t.Start(); $ls += @{ tcp = $t; task = $null } }
    catch {
      if ($addr -eq [System.Net.IPAddress]::Loopback) {
        foreach ($x in $ls) { $x.tcp.Stop() }
        return "ポート $p は、ほかのプログラムが使用中です。"
      }
      # IPv6 が使えない PC では、IPv4 だけで待ち受ける
    }
  }
  $Web.listeners = $ls; $Web.port = $p; $Web.running = $true
  Write-Host "  Web サーバー (Tomcat の代わり) を開始しました: http://localhost$(if ($p -ne 80) { ":$p" })/"
  return $null
}

function Stop-Web {
  foreach ($x in $Web.listeners) { try { $x.tcp.Stop() } catch {} }
  foreach ($c in $Web.clients) { try { $c.client.Close() } catch {} }
  $Web.clients.Clear()
  if ($Web.running) { Write-Host "  Web サーバー (Tomcat の代わり) を停止しました。" }
  $Web.listeners = @(); $Web.running = $false
}

function Get-TomcatErrorPage([int]$status, [string]$title, [string]$message, [string]$desc) {
  $e = [System.Net.WebUtility]::HtmlEncode($message)
  return "<!doctype html><html lang=`"ja`"><head><title>HTTPステータス $status – $title</title><style type=`"text/css`">body {font-family:Tahoma,Arial,sans-serif;} h1, h2, h3, b {color:white;background-color:#525D76;} h1 {font-size:22px;} h2 {font-size:16px;} h3 {font-size:14px;} p {font-size:12px;} a {color:black;} .line {height:1px;background-color:#525D76;border:none;}</style></head><body><h1>HTTPステータス $status – $title</h1><hr class=`"line`" /><p><b>タイプ</b> ステータスレポート</p><p><b>メッセージ</b> $e</p><p><b>説明</b> $desc</p><hr class=`"line`" /><h3>Apache Tomcat/11.0</h3></body></html>"
}

function Send-WebResponse($ns, [int]$status, [string]$reason, [string]$type, [byte[]]$body, [string]$extra, [bool]$headOnly) {
  $h = "HTTP/1.1 $status $reason`r`n"
  if ($type) { $h += "Content-Type: $type`r`n" }
  $h += "Content-Length: $($body.Length)`r`nDate: $([DateTime]::UtcNow.ToString('r'))`r`n$extra" + "Connection: close`r`n`r`n"
  $hb = $Latin1.GetBytes($h)
  $ns.Write($hb, 0, $hb.Length)
  if (-not $headOnly -and $body.Length) { $ns.Write($body, 0, $body.Length) }
}

function Send-WebNotFound($ns, [string]$path, [bool]$headOnly) {
  $html = Get-TomcatErrorPage 404 '見つかりません' "要求されたリソース [$path] は利用できません" 'オリジンサーバーは、ターゲットリソースの現在の表現を見つけられなかったか、またはそれが存在することを開示するつもりはありません。'
  Send-WebResponse $ns 404 'Not Found' 'text/html;charset=utf-8' ($Utf8.GetBytes($html)) "Content-Language: ja`r`n" $headOnly
}

# フォルダーの中から、大文字・小文字まで同じ名前の項目を探す (Tomcat と同じく、名前の大文字・小文字を区別する)
function Find-Exact([string]$dir, [string]$name) {
  if ($name -match '[\*\?]') { return $null }
  foreach ($e in [System.IO.Directory]::GetFileSystemEntries($dir, $name)) {
    if ([System.IO.Path]::GetFileName($e) -ceq $name) { return $e }
  }
  return $null
}

function Handle-WebClient($tc) {
  $ns = $tc.GetStream()
  $ns.ReadTimeout = 3000
  # 要求の行とヘッダーを読む
  $ms = New-Object System.IO.MemoryStream
  $buf = New-Object byte[] 8192
  $text = ''; $end = -1
  while ($end -lt 0) {
    $n = $ns.Read($buf, 0, $buf.Length)
    if ($n -le 0) { return }
    $ms.Write($buf, 0, $n)
    $text = $Latin1.GetString($ms.ToArray())
    $end = $text.IndexOf("`r`n`r`n")
    if ($end -lt 0 -and $ms.Length -gt 65536) { return }
  }
  $lines = $text.Substring(0, $end).Split("`n")
  if ($lines[0] -notmatch '^(\S+)\s+(\S+)') { return }
  $method = $Matches[1]; $target = $Matches[2]
  # 本文 (フォームの POST など) は読み捨てる
  $len = 0
  foreach ($l in $lines) { if ($l -match '^Content-Length:\s*(\d+)') { $len = [int]$Matches[1] } }
  $remain = $len - ($ms.Length - ($end + 4))
  while ($remain -gt 0) { $n = $ns.Read($buf, 0, [Math]::Min($buf.Length, $remain)); if ($n -le 0) { break }; $remain -= $n }

  $headOnly = $method -eq 'HEAD'
  $raw = $target.Split('?')[0]
  try { $path = [Uri]::UnescapeDataString($raw) } catch { $path = $raw }
  $segs = $path.TrimStart('/').Split('/')
  $mod = $null
  foreach ($m in $Web.modules) { if ($m.context -ceq $segs[0]) { $mod = $m } }
  if (-not $mod -or $segs[0] -eq '') { Send-WebNotFound $ns $path $headOnly; return }
  # /html → /html/ (Tomcat と同じく、末尾に / を付けた URL に移る)
  if ($segs.Count -eq 1) { Send-WebResponse $ns 302 'Found' $null (New-Object byte[] 0) "Location: $raw/`r`n" $headOnly; return }
  $rest = @($segs[1..($segs.Count - 1)])
  if ($rest[0] -imatch '^(WEB-INF|META-INF)$') { Send-WebNotFound $ns $path $headOnly; return }
  $cur = $mod.full
  if (-not (Test-Path -LiteralPath $cur -PathType Container)) { Send-WebNotFound $ns $path $headOnly; return }
  for ($i = 0; $i -lt $rest.Count; $i++) {
    $s = $rest[$i]
    if ($s -eq '' -and $i -eq $rest.Count - 1) { break }
    if ($s -eq '' -or $s -eq '.' -or $s -eq '..' -or $s.Contains('\')) { Send-WebNotFound $ns $path $headOnly; return }
    $cur = Find-Exact $cur $s
    if (-not $cur) { Send-WebNotFound $ns $path $headOnly; return }
  }
  if (Test-Path -LiteralPath $cur -PathType Container) {
    if (-not $path.EndsWith('/')) { Send-WebResponse $ns 302 'Found' $null (New-Object byte[] 0) "Location: $raw/`r`n" $headOnly; return }
    # ようこそファイル (index.html) が無いときは 404 (Tomcat はフォルダーの一覧を出さない)
    $welcome = $null
    foreach ($w in @('index.html', 'index.htm')) { if (-not $welcome) { $welcome = Find-Exact $cur $w } }
    if (-not $welcome -or -not (Test-Path -LiteralPath $welcome -PathType Leaf)) { Send-WebNotFound $ns $path $headOnly; return }
    $cur = $welcome
  }
  if ($method -ne 'GET' -and $method -ne 'HEAD' -and $method -ne 'POST') {
    $html = Get-TomcatErrorPage 405 '許可されていないメソッド' "メソッド [$method] はこのリソースでは許可されていません" '要求行で受信されたメソッドは、オリジンサーバーによって認識されていますが、ターゲットリソースによってサポートされていません。'
    Send-WebResponse $ns 405 'Method Not Allowed' 'text/html;charset=utf-8' ($Utf8.GetBytes($html)) "Allow: GET, HEAD, POST, OPTIONS`r`n" $headOnly; return
  }
  $type = $WebMime[[System.IO.Path]::GetExtension($cur).ToLower()]
  $lm = (Get-Item -LiteralPath $cur).LastWriteTimeUtc.ToString('r')
  # 保存した内容がすぐに見えるよう、ブラウザーには毎回確かめさせる
  Send-WebResponse $ns 200 'OK' $type ([System.IO.File]::ReadAllBytes($cur)) "Last-Modified: $lm`r`nCache-Control: no-cache`r`n" $headOnly
}

# 届いた要求を処理する。何も送ってこない接続 (ブラウザーが先に開けておく接続) は、しばらくしたら閉じる
function Serve-WebClients {
  for ($i = $Web.clients.Count - 1; $i -ge 0; $i--) {
    $c = $Web.clients[$i]
    $drop = $false
    try {
      if ($c.client.Available -gt 0) { Handle-WebClient $c.client; $drop = $true }
      elseif (([DateTime]::UtcNow - $c.since).TotalSeconds -gt 20) { $drop = $true }
    } catch { $drop = $true }
    if ($drop) { try { $c.client.Close() } catch {}; $Web.clients.RemoveAt($i) }
  }
}

function Handle-Context($ctx) {
  $req = $ctx.Request; $res = $ctx.Response
  try {
    if ($req.Url.AbsolutePath.StartsWith('/api/')) { Handle-Api $req $res } else { Handle-Static $req $res }
  } catch {
    try { Send-Text $res ("error: " + $_.Exception.Message) 'text/plain; charset=utf-8' 500 } catch {}
  } finally {
    try { $res.OutputStream.Close() } catch {}
  }
}

$script:stop = $false
try {
  # IDE への要求と、Web サーバーへの接続を、どちらも待つ
  $ctxTask = $listener.GetContextAsync()
  while ($listener.IsListening -and -not $script:stop) {
    $tasks = New-Object System.Collections.Generic.List[System.Threading.Tasks.Task]
    $tasks.Add($ctxTask)
    foreach ($w in $Web.listeners) {
      if (-not $w.task) { $w.task = $w.tcp.AcceptTcpClientAsync() }
      $tasks.Add($w.task)
    }
    [void][System.Threading.Tasks.Task]::WaitAny($tasks.ToArray(), $(if ($Web.clients.Count) { 20 } else { 500 }))
    if ($ctxTask.IsCompleted) {
      $ctx = $null
      try { $ctx = $ctxTask.GetAwaiter().GetResult() } catch {}
      if ($listener.IsListening) { $ctxTask = $listener.GetContextAsync() }
      if ($ctx) { Handle-Context $ctx }
    }
    foreach ($w in $Web.listeners) {
      if ($w.task -and $w.task.IsCompleted) {
        if ($w.task.Status -eq 'RanToCompletion') { [void]$Web.clients.Add(@{ client = $w.task.Result; since = [DateTime]::UtcNow }) }
        $w.task = $null
      }
    }
    Serve-WebClients
  }
} finally {
  Stop-Web
  $listener.Stop(); $listener.Close()
  Write-Host "お手軽Java を終了しました。"
}
