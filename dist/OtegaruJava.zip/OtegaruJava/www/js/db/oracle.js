// お手軽DB (DB入門) - Oracle の SQL を H2 で動かすための層
//  - ワークシートの SQL の区切り (文の実行 = カーソル位置の 1 文、スクリプトの実行 = すべての文)
//  - H2 に無い Oracle の文の置き換え (CREATE USER・GRANT・DESC)
//  - H2 が通してしまう書き方 (表の別名の AS など) を、Oracle と同じくエラーにする
//  - H2 のエラーを、Oracle のエラー (ORA-) に置き換える。正確に決められないものは「推定」にする
//  - 実行結果のメッセージ (「Table DEPARTMENTは作成されました。」など) を SQL Developer と同じにする
'use strict';

const OraSql = (() => {
  // ------------------------------------------------------------
  // 字句 (文字列・コメント・識別子) の読み取り
  // ------------------------------------------------------------
  /** SQL を字句に分ける。{t: 'word'|'str'|'qid'|'num'|'sym'|'comment'|'space', v, s (開始位置), e (終了位置)} */
  function tokens(sql) {
    const out = [];
    let i = 0;
    const n = sql.length;
    while (i < n) {
      const c = sql[i], s = i;
      if (/\s/.test(c)) { while (i < n && /\s/.test(sql[i])) i++; out.push({ t: 'space', v: sql.slice(s, i), s, e: i }); continue; }
      if (c === '-' && sql[i + 1] === '-') { while (i < n && sql[i] !== '\n') i++; out.push({ t: 'comment', v: sql.slice(s, i), s, e: i }); continue; }
      if (c === '/' && sql[i + 1] === '*') { const k = sql.indexOf('*/', i + 2); i = k < 0 ? n : k + 2; out.push({ t: 'comment', v: sql.slice(s, i), s, e: i }); continue; }
      if (c === "'") {
        i++;
        while (i < n) { if (sql[i] === "'") { if (sql[i + 1] === "'") { i += 2; continue; } i++; break; } i++; }
        out.push({ t: 'str', v: sql.slice(s, i), s, e: i, open: sql[i - 1] !== "'" || i - s < 2 });
        continue;
      }
      if (c === '"') { const k = sql.indexOf('"', i + 1); i = k < 0 ? n : k + 1; out.push({ t: 'qid', v: sql.slice(s, i), s, e: i }); continue; }
      if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(sql[i + 1] || ''))) { while (i < n && /[0-9.]/.test(sql[i])) i++; out.push({ t: 'num', v: sql.slice(s, i), s, e: i }); continue; }
      if (/[A-Za-z_$#\u0080-￿]/.test(c) && !/[‘’“”（）；，　]/.test(c)) {
        while (i < n && /[A-Za-z0-9_$#\u0080-￿]/.test(sql[i]) && !/[‘’“”（）；，　]/.test(sql[i])) i++;
        out.push({ t: 'word', v: sql.slice(s, i), s, e: i, u: sql.slice(s, i).toUpperCase() });
        continue;
      }
      i++;
      out.push({ t: 'sym', v: c, s, e: i });
    }
    return out;
  }
  const code = toks => toks.filter(t => t.t !== 'space' && t.t !== 'comment');

  // ------------------------------------------------------------
  // ワークシートの区切り
  // ------------------------------------------------------------
  /**
   * ワークシートの文を区切る。「;」で終わるか、空行が来たら 1 つの文 (SQL Developer と同じ)。
   * 行だけの「/」も区切り。コメントだけの部分は文にしない。
   * @returns [{sql, from, to, line}] from/to は文字の位置、line は 1 から数えた開始行
   */
  function split(text) {
    const list = [];
    const toks = tokens(text);
    let start = -1, last = -1;
    const push = end => {
      if (start >= 0) {
        const sql = text.slice(start, end).trim();
        if (sql) list.push({ sql, from: start, to: end, line: text.slice(0, start).split('\n').length });
      }
      start = -1;
    };
    for (const t of toks) {
      if (t.t === 'space') {
        // 空行 (改行が 2 つ以上) で区切る
        if (start >= 0 && (t.v.match(/\n/g) || []).length >= 2) push(last);
        continue;
      }
      if (t.t === 'comment' && start < 0) continue;
      if (t.t === 'sym' && t.v === ';') { if (start >= 0) push(t.e); continue; }
      if (t.t === 'sym' && t.v === '/' && start >= 0 && /(^|\n)[ \t]*$/.test(text.slice(0, t.s)) && /^[ \t]*(\n|$)/.test(text.slice(t.e))) { push(t.s); continue; }
      if (start < 0) start = t.s;
      last = t.e;
    }
    push(last);
    return list;
  }
  /** カーソルの位置の文 (文の実行)。文と文の間の空行にカーソルがあるときは、直前の文 */
  function statementAt(text, pos) {
    const list = split(text);
    const hit = list.find(s => pos >= s.from && pos <= s.to);
    if (hit) return hit;
    // 文の後ろ (「;」の後ろなど) にカーソルがあるときは、空行をはさまない直前の文、なければ直後の文
    const prev = list.filter(s => s.to <= pos).pop(), next = list.find(s => s.from >= pos);
    const blank = s => /\n[ \t]*\n/.test(s);
    if (prev && !blank(text.slice(prev.to, pos))) return prev;
    if (next && !blank(text.slice(pos, next.from))) return next;
    return null;
  }
  /** 文の最後の「;」を取る */
  const strip = sql => sql.replace(/[;\s]+$/, '');

  // ------------------------------------------------------------
  // 文の種類と、成功したときのメッセージ
  // ------------------------------------------------------------
  const OBJ = { TABLE: 'Table', SEQUENCE: 'Sequence', VIEW: 'View', USER: 'User', INDEX: 'Index', SYNONYM: 'Synonym' };
  /** 文の種類 {kind, obj, name} (kind は SELECT・INSERT・CREATE など) */
  function classify(sql) {
    const w = code(tokens(sql));
    const u = i => (w[i] && w[i].u) || '';
    const kind = u(0);
    let obj = '', name = '';
    if (kind === 'CREATE' || kind === 'DROP' || kind === 'ALTER' || kind === 'TRUNCATE') {
      let k = 1;
      if (u(k) === 'OR' && u(k + 1) === 'REPLACE') k += 2;
      if (u(k) === 'UNIQUE') k++;
      obj = u(k);
      name = w[k + 1] ? (w[k + 1].t === 'qid' ? w[k + 1].v.slice(1, -1) : w[k + 1].u) : '';
      if (w[k + 2] && w[k + 2].v === '.' && w[k + 3]) name = w[k + 3].t === 'qid' ? w[k + 3].v.slice(1, -1) : w[k + 3].u;
    }
    if (kind === 'INSERT' && u(1) === 'INTO') name = w[2] ? w[2].u : '';
    if (kind === 'UPDATE') name = w[1] ? w[1].u : '';
    if (kind === 'DELETE') name = u(1) === 'FROM' ? (w[2] ? w[2].u : '') : (w[1] ? w[1].u : '');
    if (kind === 'WITH') return { kind: 'SELECT', obj, name };
    return { kind, obj, name };
  }
  /** 成功したときのスクリプト出力 (SQL Developer の文言) */
  function successMessage(c, r) {
    const n = r && typeof r.count === 'number' ? r.count : 0;
    const o = OBJ[c.obj] || (c.obj ? c.obj[0] + c.obj.slice(1).toLowerCase() : '');
    switch (c.kind) {
      case 'INSERT': return n + '行挿入しました。';
      case 'UPDATE': return n + '行更新しました。';
      case 'DELETE': return n + '行削除しました。';
      case 'MERGE': return n + '行がマージされました。';
      case 'COMMIT': return 'コミットが完了しました。';
      case 'ROLLBACK': return 'ロールバックが完了しました。';
      case 'GRANT': return 'Grantが正常に実行されました。';
      case 'REVOKE': return 'Revokeが正常に実行されました。';
      case 'CREATE': return `${o} ${c.name}は作成されました。`;
      case 'DROP': return `${o} ${c.name}が削除されました。`;
      case 'ALTER': return `${o} ${c.name}が変更されました。`;
      case 'TRUNCATE': return `${o} ${c.name}が切り捨てられました。`;
      case 'COMMENT': return 'Commentが作成されました。';
      default: return '';
    }
  }

  // ------------------------------------------------------------
  // Oracle だけの文の置き換え
  // ------------------------------------------------------------
  /**
   * H2 に送る文に置き換える。
   * @returns {send: [H2 の SQL], tx: 'commit'|'rollback', desc: 表の名前, error: {ora, text}}
   */
  function translate(sql, ctx) {
    const s = strip(sql);
    let m;
    if ((m = s.match(/^CREATE\s+USER\s+("?)(\w+)\1\s+IDENTIFIED\s+BY\s+("?)([^"\s]+)\3\s*$/i))) {
      const u = m[2].toUpperCase();
      if (!ctx.admin) return { error: { ora: 'ORA-01031', text: '権限が不足しています' } };
      return { send: [`CREATE USER "${u}" PASSWORD '${m[4].replace(/'/g, "''")}'`, `CREATE SCHEMA "${u}" AUTHORIZATION "${u}"`] };
    }
    if ((m = s.match(/^GRANT\s+(ALL\s+PRIVILEGES|DBA|CONNECT\s*,\s*RESOURCE(\s*,\s*\w+)*|CREATE\s+SESSION.*?)\s+TO\s+("?)(\w+)\3\s*$/i))) {
      if (!ctx.admin) return { error: { ora: 'ORA-01031', text: '権限が不足しています' } };
      return { send: [`ALTER USER "${m[4].toUpperCase()}" ADMIN TRUE`] };
    }
    if ((m = s.match(/^DESC(?:RIBE)?\s+("?)([\w$#]+)\1\s*$/i))) return { desc: m[2].toUpperCase() };
    if (/^COMMIT(\s+WORK)?$/i.test(s)) return { tx: 'commit' };
    if (/^ROLLBACK(\s+WORK)?$/i.test(s)) return { tx: 'rollback' };
    return { send: [s] };
  }

  // ------------------------------------------------------------
  // H2 では通るが Oracle ではエラーになる書き方を、先に見つける
  // ------------------------------------------------------------
  const KEYWORDS = new Set(['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER', 'TRUNCATE', 'COMMIT', 'ROLLBACK', 'GRANT', 'REVOKE', 'MERGE',
    'WITH', 'DESC', 'DESCRIBE', 'COMMENT', 'SAVEPOINT', 'RENAME', 'EXPLAIN', 'LOCK', 'SET', 'CALL', 'EXEC', 'EXECUTE', 'BEGIN', 'DECLARE', 'PURGE', 'FLASHBACK', 'SHOW', 'PROMPT', 'CLEAR']);
  /**
   * @param ctx.columnsOf(テーブル名) そのテーブルの列名 (分からなければ null)
   * @returns {ora, text} または null
   */
  function precheck(sql, ctx) {
    const all = tokens(sql);
    const w = code(all);
    if (!w.length) return null;
    // 先頭のつづりの間違い (SQL Developer のスクリプトのエラー)
    if (w[0].t === 'word' && !KEYWORDS.has(w[0].u)) {
      const head = strip(sql).replace(/\s+/g, ' ');
      return { ora: 'SP2-0734', text: `"${head.length > 10 ? head.slice(0, 10) + '...' : head}"で開始するコマンドが不明です - 行の残りは無視されました。`, script: true };
    }
    if (w[0].u !== 'SELECT' && w[0].u !== 'WITH') return null;
    // FROM・JOIN の後ろの表の別名に AS を付けた (Oracle では ORA-00933)
    const tables = [];
    for (let i = 0; i < w.length; i++) {
      if ((w[i].u === 'FROM' || w[i].u === 'JOIN') && w[i + 1] && w[i + 1].t === 'word') {
        tables.push(w[i + 1].u);
        if (w[i + 2] && w[i + 2].u === 'AS') return { ora: 'ORA-00933', text: 'SQLコマンドが正しく終了されていません。' };
      }
      if (w[i].v === ',' && tables.length && w[i + 1] && w[i + 1].t === 'word' && w[i + 2] && w[i + 2].u === 'AS' && inFromClause(w, i)) return { ora: 'ORA-00933', text: 'SQLコマンドが正しく終了されていません。' };
    }
    // 列の別名を WHERE・GROUP BY・HAVING に書いた (Oracle では ORA-00904。H2 は通してしまう)
    const aliases = new Set();
    let depth = 0, inSelect = true;
    for (let i = 1; i < w.length; i++) {
      if (w[i].v === '(') depth++;
      if (w[i].v === ')') depth--;
      if (depth === 0 && w[i].u === 'FROM') { inSelect = false; break; }
      if (inSelect && depth === 0 && w[i].u === 'AS' && w[i + 1] && (w[i + 1].t === 'word')) aliases.add(w[i + 1].u);
    }
    if (aliases.size && ctx && ctx.columnsOf) {
      const cols = new Set();
      for (const t of tables) { const c = ctx.columnsOf(t); if (!c) return null; c.forEach(x => cols.add(x)); }
      let clause = '';
      depth = 0;
      for (let i = 0; i < w.length; i++) {
        if (w[i].v === '(') depth++;
        if (w[i].v === ')') depth--;
        if (depth > 0) { /* 副問合せの中は見ない */ }
        if (depth === 0 && (w[i].u === 'WHERE' || w[i].u === 'HAVING' || (w[i].u === 'GROUP' && w[i + 1] && w[i + 1].u === 'BY'))) { clause = w[i].u; continue; }
        if (depth === 0 && (w[i].u === 'ORDER' || w[i].u === 'UNION')) clause = '';
        if (clause && w[i].t === 'word' && aliases.has(w[i].u) && !cols.has(w[i].u) && !(w[i - 1] && w[i - 1].v === '.') && !(w[i + 1] && w[i + 1].v === '(')) {
          return { ora: 'ORA-00904', text: `"${w[i].u}": 無効な識別子です。` };
        }
      }
    }
    return null;
  }
  function inFromClause(w, i) {
    for (let k = i; k >= 0; k--) { if (w[k].u === 'FROM') return true; if (['WHERE', 'SELECT', 'GROUP', 'ORDER', 'HAVING', 'ON'].includes(w[k].u)) return false; }
    return false;
  }

  // ------------------------------------------------------------
  // H2 のエラーを Oracle のエラーに置き換える
  // ------------------------------------------------------------
  /** H2 のメッセージの最初の行 (日本語) と、英語の行 */
  function h2Lines(msg) {
    const lines = String(msg || '').split('\n');
    return { first: lines[0] || '', all: String(msg || '') };
  }
  const qn = s => s.split('.').map(x => `"${x.replace(/"/g, '')}"`).join('.');

  /**
   * @param e {code, state, msg} H2 のエラー
   * @param sql 実行した文
   * @param ctx {user: 接続のユーザー (スキーマ)}
   * @returns {ora, text, guessed}
   */
  function mapError(e, sql, ctx) {
    const { first, all } = h2Lines(e.msg);
    const user = (ctx && ctx.user) || 'DBAPP';
    const c = classify(sql);
    const R = (ora, text, guessed) => ({ ora, text, guessed: !!guessed });
    let m;
    switch (e.code) {
      case 23505: { // 一意制約
        m = all.match(/"(?:([\w$#]+)\.)?([\w$#]+) INDEX/) || all.match(/"(?:([\w$#]+)\.)?([\w$#]+?)(?:_INDEX_\w+)? ON /);
        return R('ORA-00001', `一意制約(${m ? (m[1] || user) + '.' + m[2] : user})に反しています`);
      }
      case 23502: { // NOT NULL
        m = first.match(/"([\w$#]+)"/);
        const col = m ? m[1] : '';
        const tbl = c.name || '';
        return c.kind === 'UPDATE' ? R('ORA-01407', `("${user}"."${tbl}"."${col}")をNULLには更新できません。`)
          : R('ORA-01400', `("${user}"."${tbl}"."${col}")にはNULLは挿入できません。`);
      }
      case 23513: m = all.match(/"([\w$#]+):/); return R('ORA-02290', `チェック制約(${user}.${m ? m[1] : ''})に違反しました`);
      case 23506: m = all.match(/"([\w$#]+):/); return R('ORA-02291', `整合性制約(${user}.${m ? m[1] : ''})に違反しました - 親キーがありません`);
      case 23503: m = all.match(/"([\w$#]+):/); return R('ORA-02292', `整合性制約(${user}.${m ? m[1] : ''})に違反しました - 子レコードがあります`);
      case 22001: { // 値が長すぎる
        m = first.match(/"([\w$#]+) (CHARACTER VARYING|VARCHAR2?|CHARACTER|CHAR)\((\d+)\)"/);
        if (m) {
          const actual = (all.match(/\((\d+)\)"\s*(;|$)/m) || [])[1] || '?';
          return R('ORA-12899', `列"${user}"."${c.name}"."${m[1]}"の値が大きすぎます(実際: ${actual}、最大: ${m[3]})`);
        }
        return R('ORA-01438', 'この列に許容される指定精度より大きな値です');
      }
      case 22003: return R('ORA-01438', 'この列に許容される指定精度より大きな値です');
      case 42102: case 42103: case 42104: return R('ORA-00942', '表またはビューが存在しません。');
      case 42122: m = first.match(/"([^"]+)"/); return R('ORA-00904', `${m ? qn(m[1]) : '""'}: 無効な識別子です。`);
      case 90022: m = first.match(/"([^"]+)"/); return R('ORA-00904', `${m ? qn(m[1]) : '""'}: 無効な識別子です。`);
      case 42101: case 90035: case 42111: case 90045: return R('ORA-00955', 'すでに使用されているオブジェクト名です。');
      case 90036: return R('ORA-02289', '順序が存在しません。');
      case 90107: return R('ORA-02449', '表の一意キーまたは主キーが外部キーに参照されています。');
      case 90059: return R('ORA-00918', '列の定義が未確定です。');
      case 22018: return R('ORA-01722', '数値が無効です。');
      case 50100: return /CHARACTER VARYING|VARCHAR/.test(first) ? R('ORA-01722', '数値が無効です。') : R('ORA-03001', '未実装の機能です', true);
      case 21002: return valueCount(sql);
      case 22007: return R('ORA-01858', '数値を指定する箇所に数値以外の文字が指定されています');
      case 90016: return /\bGROUP\s+BY\b/i.test(sql) ? R('ORA-00979', 'GROUP BYの式ではありません。') : R('ORA-00937', '単一グループのグループ関数ではありません。');
      case 90054: return R('ORA-00934', 'ここではグループ関数は使用できません。');
      case 50004: return R('ORA-00902', 'データ型が無効です。');
      case 28000: return R('ORA-01017', 'ユーザー名/パスワードが無効です。ログオンは拒否されました。');
      case 90033: m = first.match(/"([^"]+)"/); return R('ORA-01920', `ユーザー名'${m ? m[1] : ''}'は他のユーザー名またはロール名と競合しています`);
      case 90032: return R('ORA-01918', `ユーザー'${(first.match(/"([^"]+)"/) || [])[1] || ''}'は存在しません`);
      case 90096: case 90093: return R('ORA-01031', '権限が不足しています');
      case 42000: case 42001: return syntax(first, sql);
      default: return R('', '', true);
    }
  }
  function valueCount(sql) {
    const w = code(tokens(sql));
    // INSERT INTO 表 (列, …) VALUES (値, …) の数を比べる
    const groups = [];
    let depth = 0, n = 0;
    for (const t of w) {
      if (t.v === '(') { depth++; if (depth === 1) n = 1; continue; }
      if (t.v === ')') { depth--; if (depth === 0) groups.push(n); continue; }
      if (depth === 1 && t.v === ',') n++;
    }
    if (groups.length >= 2) return groups[1] < groups[0] ? { ora: 'ORA-00947', text: '値の個数が不足しています。', guessed: false } : { ora: 'ORA-00913', text: '値の個数が多すぎます。', guessed: false };
    return { ora: 'ORA-00947', text: '値の個数が不足しています。', guessed: true };
  }
  /** 構文のエラー: H2 が [*] で示した位置の前後から、Oracle のエラーを推定する */
  function syntax(first, sql) {
    const R = (ora, text) => ({ ora, text, guessed: true });
    const m = first.match(/"([\s\S]*)\[\*\]([\s\S]*?)"(?:;|$)/);
    const before = m ? m[1].replace(/\\n|\n/g, ' ') : '', after = m ? m[2].replace(/\\n|\n/g, ' ') : '';
    const a = after.trim(), b = before.trim();
    const kind = classify(sql).kind;
    if (/^['"]?[‘’“”]/.test(a) || /[‘’“”（），；　]/.test(a.slice(0, 2))) return R('ORA-00911', '文字が無効です。');
    if (/^'/.test(a) && (a.match(/'/g) || []).length % 2 === 1) return R('ORA-01756', '引用符付き文字列が正しく終了していません');
    if (/=$/.test(b) && /^=/.test(a)) return R('ORA-00936', '式がありません。');
    if (/[=<>!]$/.test(b) && /^[=<>]/.test(a)) return R('ORA-00920', '関係演算子が無効です。');
    if (/\(\s*$/.test(b) && /^\)/.test(a)) return R('ORA-00938', '関数の引数が不足しています。');
    if (/\w\s*$/.test(b) && /^\)/.test(a) && /\w+\s*\([^()]*$/.test(b) && kind !== 'CREATE') return R('ORA-00909', '引数の個数が無効です。');
    if (/,\s*$/.test(b) && /^\)/.test(a) && kind === 'CREATE') return R('ORA-00904', ': 無効な識別子です。');
    if (/(,|\bWHERE|\bON|\bAND|\bOR|\bSELECT|\bBY|\bSET)\s*$/i.test(b) && (!a || /^(FROM|WHERE|ORDER|GROUP|\)|;|,)/i.test(a))) return R('ORA-00936', '式がありません。');
    if (kind === 'CREATE' && /\(/.test(b)) {
      if (/^NOT\b|^NUL|^PRIMARY|^CONSTRAINT|^REFERENCES|^CHECK|^DEFAULT/i.test(a)) return R('ORA-00905', 'キーワードがありません。');
      return R('ORA-00907', '右カッコがありません。');
    }
    if (kind === 'INSERT' && /\bVALUES\s*\(/i.test(b)) return R('ORA-00917', 'カンマがありません。');
    if (/\bJOIN\s+[\w$#]+(\s+[\w$#]+)?\s*$/i.test(b) && !/^ON\b/i.test(a)) return R('ORA-00905', 'キーワードがありません。');
    if (!b && /^\w+/.test(a)) return R('ORA-00900', 'SQL文が無効です。');
    return R('ORA-00933', 'SQLコマンドが正しく終了されていません。');
  }

  // ------------------------------------------------------------
  // H2 のエラー番号から、H2 のドキュメントのエラー・コードの説明へのリンク
  // ------------------------------------------------------------
  // org.h2.api.ErrorCode の定数名 (よく出るもの)。無いものはエラー・コードの一覧を開く
  const H2_CODES = {
    21002: 'COLUMN_COUNT_DOES_NOT_MATCH', 22001: 'VALUE_TOO_LONG_2', 22003: 'NUMERIC_VALUE_OUT_OF_RANGE_1', 22007: 'INVALID_DATETIME_CONSTANT_2',
    22018: 'DATA_CONVERSION_ERROR_1', 23502: 'NULL_NOT_ALLOWED', 23503: 'REFERENTIAL_INTEGRITY_VIOLATED_CHILD_EXISTS_1',
    23505: 'DUPLICATE_KEY_1', 23506: 'REFERENTIAL_INTEGRITY_VIOLATED_PARENT_MISSING_1', 23513: 'CHECK_CONSTRAINT_VIOLATED_1', 28000: 'WRONG_USER_OR_PASSWORD',
    42000: 'SYNTAX_ERROR_1', 42001: 'SYNTAX_ERROR_2', 42101: 'TABLE_OR_VIEW_ALREADY_EXISTS_1', 42102: 'TABLE_OR_VIEW_NOT_FOUND_1',
    42103: 'TABLE_OR_VIEW_NOT_FOUND_WITH_CANDIDATES_2', 42104: 'TABLE_OR_VIEW_NOT_FOUND_DATABASE_EMPTY_1', 42111: 'INDEX_ALREADY_EXISTS_1',
    42122: 'COLUMN_NOT_FOUND_1', 50004: 'UNKNOWN_DATA_TYPE_1', 50100: 'FEATURE_NOT_SUPPORTED_1', 90016: 'MUST_GROUP_BY_COLUMN_1',
    90022: 'FUNCTION_NOT_FOUND_1', 90032: 'USER_NOT_FOUND_1', 90033: 'USER_ALREADY_EXISTS_1', 90035: 'SEQUENCE_ALREADY_EXISTS_1',
    90036: 'SEQUENCE_NOT_FOUND_1', 90054: 'INVALID_USE_OF_AGGREGATE_FUNCTION_1', 90059: 'AMBIGUOUS_COLUMN_NAME_1', 90107: 'CANNOT_DROP_2',
  };
  function h2DocUrl(code) {
    const name = H2_CODES[code];
    return 'https://h2database.com/javadoc/org/h2/api/ErrorCode.html' + (name ? '#' + name : '');
  }

  return { tokens, split, statementAt, strip, classify, successMessage, translate, precheck, mapError, h2DocUrl };
})();
