// お手軽Java - コマンドと全体のショートカット・レッスンからの反映
'use strict';

(() => {
  const { S, $, $$, IS_MAC, baseName, dirs, editors, expanded, files, isJava, parentOf, problems, projVersion, run, settings, ui } = IDE;
  const { about, activate, addImportAtCursor, addRemoveDialog, applyTheme, closeEditor, closeMenus, consoleClear, createProject, createWebProject,
    deleteSelected, dialog, fileChanged, fileKind, genCtor, genGetSet, genToString, gotoAnnotation, gotoLineDialog, icon, importProject, isDirty,
    isWebProject, keyAssist, markOccurrences, newFileWizard, newFolderWizard, newPackageWizard, newProjectWizard, newTypeWizard, newWebProjectWizard,
    openDeclaration, openEditor, openOverview, organizeImports, preferences, projects, quickFix, refresh, refreshEditors, renameSelected, renameSymbol,
    renderExplorer, renderMarkers, renderTabs, requestBuild, restartServer, revealInExplorer, runFile, runOnServer, saveAll, saveEditor, saveSettings,
    saveUi, searchWorkspace, selectionContext, setConsoleTitle, showBottom, showError, showMenu, showRight, srcRoot, startServer, status, stopServer,
    terminate, toggleComment, toggleMaximize, updateWelcome, webContentRoot, wordComplete, writeNew } = IDE.fn;

  // ---------- レッスンから「エディターに反映」 ----------
  /** 教材のコードを入れる。kind は 'java' (src の下) または 'web' (HTML入門。Web コンテンツのフォルダーの下)。
   *  code が無く partial ({code, note}) があるときは、今のファイルに部分のコードを差し込む */
  async function applyLessonCode(rel, code, kind, partial) {
    if (IDE.dialogStack.length) { status('ダイアログを閉じてから「エディターに反映」してください'); return; }
    const web = kind === 'web';
    let project = web ? await lessonWebProject() : (projects().includes('java') ? 'java' : null);
    if (web && !project) return;
    if (!project) {
      const ps = projects();
      const r = await dialog({
        title: 'エディターに反映', icon: 'info',
        message: ps.length ? `教材では 'java' という名前のプロジェクトを使います。\n'java' プロジェクト (JavaSE-17) を作成しますか?\n(「いいえ」を選ぶと '${ps[0]}' に入れます)` : `教材と同じ 'java' プロジェクト (JavaSE-17) を作成して、コードを入れますか?\n(教材 第2章の「Java プロジェクトを作る」と同じ内容です)`,
        buttons: ps.length ? [{ label: 'はい', value: 'create', default: true }, { label: 'いいえ', value: 'use' }, { label: '取り消し', value: null }] : [{ label: '作成する', value: 'create', default: true }, { label: '取り消し', value: null }],
      });
      if (!r) return;
      if (r === 'create') { await createProject('java', 17, false); project = 'java'; }
      else project = ps[0];
    }
    const path = (web ? webContentRoot(project) : srcRoot(project)) + '/' + rel;
    const existing = editors.find(e => e.path === path);
    const cur = existing ? existing.cm.getValue() : files.get(path);
    // 部分のコードで、教材の中に元になる全体が無いとき (第7章の list.html のように、前の章からコピーしたファイル) は、
    // 今のファイルに差し込む
    if (code == null && partial) {
      if (cur == null) {
        await dialog({ title: 'エディターに反映', icon: 'info', message: `'${rel}' はまだありません。\n教材の手順でファイルを用意してから、もう一度「エディターに反映」してください。` });
        return;
      }
      code = Lesson.mergePartial(cur, partial.code, partial.note);
      if (code == null) {
        await dialog({ title: 'エディターに反映', icon: 'info', message: `教材のこの部分を、今の '${baseName(rel)}' のどこに入れればよいか分かりませんでした。\n教材を見ながら、エディターで書き足してください。` });
        openEditor(path);
        return;
      }
    }
    if (cur != null && cur.trim() === code.trim()) { openEditor(path); status('すでに教材と同じ内容です'); return; }
    if (cur != null && cur.trim() && !partial) {
      const ok = await dialog({ title: 'エディターに反映', icon: 'warning', message: `'${rel}' はすでにあります。教材のこの時点のコードで置き換えますか?\n(元に戻すには、エディターで Ctrl+Z を押します)`, buttons: [{ label: '置き換える', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!ok) return;
    }
    const dir = parentOf(path);
    if (!dirs.has(dir)) { await Storage.mkdir(dir); let x = dir; while (x) { dirs.add(x); x = parentOf(x); } }
    if (existing) {
      existing.cm.setValue(code);
      await saveEditor(existing);
      activate(existing);
    } else {
      await writeNew(path, code);
      fileChanged(path);
      openEditor(path);
    }
    revealInExplorer(path);
    status(web ? `教材のコードを '${rel}' に反映して保存しました` + (fileKind(path) === 'html' ? '。Ctrl+F11 (サーバーで実行) で Chrome に表示できます' : '')
      : `教材のコードを '${rel}' に反映して保存しました。Ctrl+F11 で実行できます`);
  }
  /** HTML入門で使う動的 Web プロジェクト (教材と同じ 'html'。無ければ作るか確かめる) */
  async function lessonWebProject() {
    if (projects().includes('html') && isWebProject('html')) return 'html';
    const webs = projects().filter(isWebProject);
    const taken = projects().includes('html');
    const r = await dialog({
      title: 'エディターに反映', icon: 'info',
      message: taken
        ? `教材では 'html' という名前の動的 Web プロジェクトを使いますが、'html' は動的 Web プロジェクトではありません。` + (webs.length ? `\n'${webs[0]}' に入れますか?` : '')
        : webs.length ? `教材では 'html' という名前の動的 Web プロジェクトを使います。\n'html' プロジェクトを作成しますか?\n(「いいえ」を選ぶと '${webs[0]}' に入れます)`
          : `教材と同じ 'html' 動的 Web プロジェクトを作成して、コードを入れますか?\n(教材 第2章の「動的 Web プロジェクトを作る」と同じ内容です)`,
      buttons: taken
        ? (webs.length ? [{ label: 'はい', value: 'use', default: true }, { label: '取り消し', value: null }] : [{ label: 'OK', value: null, default: true }])
        : webs.length ? [{ label: 'はい', value: 'create', default: true }, { label: 'いいえ', value: 'use' }, { label: '取り消し', value: null }]
          : [{ label: '作成する', value: 'create', default: true }, { label: '取り消し', value: null }],
    });
    if (!r) return null;
    if (r === 'create') { await createWebProject('html', 'html', false); return 'html'; }
    return webs[0];
  }
  /** レッスンから「ブラウザで開く」: 保存してから、そのページをサーバーで実行する */
  async function openLessonPage(rel, chapterPages) {
    const project = projects().includes('html') && isWebProject('html') ? 'html' : projects().find(isWebProject);
    if (project && /\.css$/.test(rel)) return openCssPage(project, rel, chapterPages || []);
    const path = project && webContentRoot(project) + '/' + rel;
    if (!path || !files.has(path)) {
      await dialog({ title: 'ブラウザで開く', icon: 'info', message: `'${rel}' はまだありません。\n先に「エディターに反映」するか、教材の手順でファイルを作成してください。` });
      return;
    }
    return runOnServer(path);
  }
  /** CSS の「ブラウザで開く」: その CSS を読み込んでいる、同じ章のページを開く */
  async function openCssPage(project, rel, chapterPages) {
    const root = webContentRoot(project) + '/';
    const chapter = rel.split('/')[0];
    const css = baseName(rel);
    // 教材に出てくるページを先に、次にワークスペースの同じ章のページを探す
    const pages = [...new Set([...chapterPages, ...[...files.keys()].filter(f => f.startsWith(root + chapter + '/') && fileKind(f) === 'html').map(f => f.slice(root.length)).sort()])];
    const page = pages.find(p => files.has(root + p) && (files.get(root + p) || '').includes(css));
    if (!page) {
      await dialog({ title: 'ブラウザで開く', icon: 'info', message: `'${rel}' を読み込んでいるページが、'${chapter}' の中にありません。\n教材の手順で、ページに <link> の行を書き足してから開いてください。` });
      return;
    }
    return runOnServer(root + page);
  }

  // =================================================================
  // コマンド
  // =================================================================
  // ファイルではないエディター (サーバーの概要) では使えない、文字を編集するコマンド
  const TEXT_COMMANDS = new Set(['revert', 'undo', 'redo', 'cut', 'copy', 'paste', 'selectAll', 'find', 'findNext', 'findPrev', 'contentAssist', 'wordComplete',
    'quickFix', 'toggleComment', 'blockComment', 'blockUncomment', 'shiftRight', 'shiftLeft', 'correctIndent', 'format', 'organizeImports', 'addImport',
    'genGetSet', 'genToString', 'genCtor', 'renameSymbol', 'openDecl', 'gotoLine', 'nextAnnotation', 'prevAnnotation', 'matchBracket', 'markOccurrencesNow']);

  function command(cmd) {
    if (S.active && S.active.custom && TEXT_COMMANDS.has(cmd)) return;
    const cm = S.active && S.active.cm;
    switch (cmd) {
      case 'newProject': return newProjectWizard();
      case 'newWebProject': return newWebProjectWizard();
      case 'newFolder': return newFolderWizard();
      case 'newFile': return newFileWizard('file');
      case 'newHtmlFile': return newFileWizard('html');
      case 'newCssFile': return newFileWizard('css');
      case 'newPackage': return newPackageWizard();
      case 'newClass': return newTypeWizard('class');
      case 'newInterface': return newTypeWizard('interface');
      case 'save': return S.active && saveEditor(S.active);
      case 'saveAll': return saveAll();
      case 'revert': if (S.active) { S.active.cm.setValue(files.get(S.active.path) || ''); S.active.gen = S.active.cm.changeGeneration(true); renderTabs(); } return;
      case 'closeEditor': return closeEditor(S.active);
      case 'closeAll': return (async () => { for (const e of editors.slice()) await closeEditor(e); })();
      case 'rename': return renameSelected();
      case 'delete': return deleteSelected();
      case 'copyResource': return IDE.copySelected();
      case 'pasteResource': return IDE.pasteSelected();
      case 'refresh': return refresh();
      case 'openFolder': return Storage.openFolder('').catch(e => showError('開けません', e.message));
      case 'openSelectedFolder': { const c = selectionContext(); const p = S.selected ? S.selected.slice(2) : ''; return Storage.openFolder(files.has(p) ? parentOf(p) : p).catch(e => showError('開けません', e.message)); }
      case 'importProject': return importProject();
      case 'exit': return (async () => {
        if (editors.some(isDirty)) { const r = await dialog({ title: '終了の確認', message: '保存されていない変更があります。保存して終了しますか?', buttons: [{ label: '保存して終了', value: 'save', default: true }, { label: '保存せずに終了', value: 'discard' }, { label: '取り消し', value: null }] }); if (!r) return; if (r === 'save') await saveAll(); else editors.forEach(e => e.gen = e.cm.changeGeneration(true)); }
        else { const r = await dialog({ title: '終了の確認', message: 'お手軽Java を終了しますか?\n(起動したときに開いたウィンドウのサーバーも終了します)', buttons: [{ label: '終了', value: true, default: true }, { label: '取り消し', value: false }] }); if (!r) return; }
        saveUi();
        await Storage.shutdown();
        document.body.innerHTML = '<div style="padding:40px;font:14px sans-serif">お手軽Java を終了しました。このタブを閉じてください。</div>';
      })();
      case 'undo': return cm && cm.undo();
      case 'redo': return cm && cm.redo();
      case 'cut': if (cm) { navigator.clipboard.writeText(cm.getSelection()).then(() => cm.replaceSelection('')); } return;
      case 'copy': if (cm) navigator.clipboard.writeText(cm.getSelection()); return;
      case 'paste': if (cm) navigator.clipboard.readText().then(t => cm.replaceSelection(t)).catch(() => status('貼り付けは Ctrl+V を使ってください')); return;
      case 'selectAll': return cm && cm.execCommand('selectAll');
      case 'find': return cm && cm.execCommand(cm.getSelection() || true ? 'replace' : 'find');
      case 'findNext': return cm && cm.execCommand('findPersistentNext');
      case 'findPrev': return cm && cm.execCommand('findPersistentPrev');
      case 'contentAssist': return cm && cm.showHint({ completeSingle: true });
      case 'wordComplete': return wordComplete();
      case 'quickFix': return quickFix(S.active);
      case 'toggleComment': return cm && toggleComment(cm);
      case 'blockComment': return cm && cm.blockComment(cm.getCursor('from'), cm.getCursor('to'));
      case 'blockUncomment': return cm && cm.uncomment(cm.getCursor('from'), cm.getCursor('to'));
      case 'shiftRight': return cm && cm.indentSelection('add');
      case 'shiftLeft': return cm && cm.indentSelection('subtract');
      case 'correctIndent': if (cm) { const f = cm.getCursor('from').line, t = cm.getCursor('to').line; cm.operation(() => { for (let l = f; l <= t; l++) cm.indentLine(l, 'smart'); }); } return;
      case 'format': if (cm && !isJava(S.active.path)) { status('お手軽Java のフォーマットは、Java のソースだけで使えます'); return; }
      if (cm) {
        const src = cm.getValue();
        const out = Assist.format(src, settings.indentUnit, !settings.indentSpaces);
        if (out !== src) { const cur = cm.getCursor(); const sc = cm.getScrollInfo(); cm.operation(() => { cm.setValue(out); cm.setCursor(cur); cm.scrollTo(sc.left, sc.top); }); }
      } return;
      case 'organizeImports': return organizeImports();
      case 'addImport': return addImportAtCursor();
      case 'genGetSet': return genGetSet();
      case 'genToString': return genToString();
      case 'genCtor': return genCtor();
      case 'renameSymbol': return renameSymbol();
      case 'openDecl': return S.active && openDeclaration(S.active);
      case 'openSelected': if (S.selected && S.selected.startsWith('F:')) openEditor(S.selected.slice(2)); return;
      case 'gotoLine': return gotoLineDialog();
      case 'nextAnnotation': return gotoAnnotation(1);
      case 'prevAnnotation': return gotoAnnotation(-1);
      case 'matchBracket': return cm && cm.execCommand('goToBracket');
      case 'markOccurrencesNow': return S.active && markOccurrences(S.active);
      case 'searchWorkspace': return searchWorkspace();
      case 'buildAll': return Promise.all(projects().map(p => { projVersion.set(p, ++S.fileVersion); return requestBuild(p); }));
      case 'clean': return (async () => { const r = await dialog({ title: 'クリーン', message: 'すべてのプロジェクトをクリーンして、ビルドし直しますか?', buttons: [{ label: 'クリーン', value: true, default: true }, { label: '取り消し', value: false }] }); if (r) { problems.clear(); renderMarkers(); command('buildAll'); } })();
      case 'toggleAutoBuild': settings.autoBuild = !settings.autoBuild; saveSettings(); if (settings.autoBuild) command('buildAll'); return;
      case 'run': {
        // エディターで開いているクラス、または選択中のクラスを実行 (Eclipse と同じ)。HTML ファイルはサーバーで実行
        const runnable = p => isJava(p) || fileKind(p) === 'html';
        let path = S.active && !S.active.custom && runnable(S.active.path) ? S.active.path : null;
        if (S.selected && S.selected.startsWith('F:') && (!S.active || document.activeElement === $('#explorer'))) path = S.selected.slice(2);
        if (!path) { const c = selectionContext(); path = c.file; }
        return path && fileKind(path) === 'html' ? runOnServer(path) : runFile(path);
      }
      case 'runSelected': {
        const p = S.selected && S.selected.startsWith('F:') ? S.selected.slice(2) : (S.active && !S.active.custom ? S.active.path : null);
        return p && fileKind(p) === 'html' ? runOnServer(p) : runFile(p);
      }
      case 'runOnServer': { const p = S.selected && S.selected.startsWith('F:') ? S.selected.slice(2) : (S.active && !S.active.custom ? S.active.path : null); return runOnServer(p); }
      case 'showServers': return showBottom('servers');
      case 'serverOpen': return openOverview();
      case 'serverStart': return startServer();
      case 'serverStop': return stopServer();
      case 'serverRestart': return restartServer();
      case 'serverAddRemove': return addRemoveDialog();
      case 'terminate': return terminate();
      case 'clearConsole': if (!run.running) { consoleClear(); setConsoleTitle(''); } else { $$('#console-out > span').forEach(s => s.remove()); } return;
      case 'scrollLock': $('#btn-scrolllock').classList.toggle('on'); return;
      case 'collapseAll': expanded.clear(); saveUi(); renderExplorer(); return;
      case 'linkEditor': ui.linkEditor = !ui.linkEditor; $('[data-cmd="linkEditor"]').classList.toggle('on', ui.linkEditor); saveUi(); if (S.active && ui.linkEditor) revealInExplorer(S.active.path); return;
      case 'showExplorer': $('#left').style.display = ''; return;
      case 'showOutline': return showRight('outline');
      case 'showLesson': return showRight('lesson');
      case 'showMarkers': return showBottom('markers');
      case 'showConsole': return showBottom('ide-console');
      case 'showSearch': return showBottom('search');
      case 'maximize': return toggleMaximize(document.activeElement && document.activeElement.closest('.view') || $('#editor-area'));
      case 'resetPerspective': ui.layout = {}; saveUi(); $('#left').style.width = ''; $('#right').style.width = ''; $('#view-bottom').style.height = ''; if (S.maximized) toggleMaximize(null); showRight('lesson'); showBottom('ide-console'); refreshEditors(); return;
      case 'toggleTheme': settings.theme = settings.theme === 'dark' ? 'light' : 'dark'; saveSettings(); applyTheme(); return;
      case 'preferences': return preferences();
      case 'keyAssist': return keyAssist();
      case 'about': return about();
      case 'welcome': if (S.active) { for (const e of editors) e.pane.classList.remove('active'); } $('#welcome').hidden = false; updateWelcomeForce(); return;
      case 'lessonIndex': showRight('lesson'); Lesson.setCourse('java'); Lesson.go(0); return;
      case 'lessonStart': showRight('lesson'); Lesson.setCourse('java'); Lesson.go(2); return;
      case 'lessonIndexHtml': showRight('lesson'); Lesson.setCourse('html'); Lesson.go(0); return;
      case 'lessonStartHtml': showRight('lesson'); Lesson.setCourse('html'); Lesson.go(2); return;
      default: console.warn('unknown command', cmd);
    }
  }
  function updateWelcomeForce() { const n = editors.length; const save = editors.splice(0); updateWelcome(); editors.push(...save); $('#welcome').hidden = false; $('#welcome').addEventListener('click', () => { if (editors.length && S.active) { $('#welcome').hidden = true; activate(S.active); } }, { once: true }); }

  // ---------- 全体のショートカット (エディター外でも有効) ----------
  function globalKeys(e) {
    if (!$('#overlay').hidden) return;
    // Mac では ⌘ を Ctrl と同じに扱う
    const ctrl = e.ctrlKey || (IS_MAC && e.metaKey);
    const k = (ctrl ? 'Ctrl+' : '') + (e.shiftKey ? 'Shift+' : '') + (e.altKey ? 'Alt+' : '') + (e.key.length === 1 ? e.key.toUpperCase() : e.key);
    const inEditor = e.target.closest && e.target.closest('.CodeMirror');
    const map = {
      'Ctrl+S': 'save', 'Ctrl+Shift+S': 'saveAll', 'Ctrl+F11': 'run', 'Ctrl+B': 'buildAll', 'Ctrl+Shift+L': 'keyAssist',
      'Ctrl+H': 'searchWorkspace', 'F5': inEditor ? null : 'refresh', 'Ctrl+M': 'maximize', 'Ctrl+F4': 'closeEditor', 'Ctrl+Shift+F4': 'closeAll',
      'Alt+Shift+X': 'runSelected',
    };
    if (e.key === 'F5') { e.preventDefault(); if (!inEditor) command('refresh'); return; }
    if (e.key === 'F11' && !ctrl) { e.preventDefault(); command('run'); return; }
    const cmd = map[k];
    if (cmd) { e.preventDefault(); e.stopPropagation(); command(cmd); return; }
    if (e.key === 'Escape') { closeMenus(); if (S.maximized && !inEditor) toggleMaximize(null); }
    if (e.altKey && !e.ctrlKey && !e.shiftKey && /^[a-z]$/i.test(e.key)) {
      const m = IDE.MENUS.find(x => x.key.toLowerCase() === e.key.toLowerCase());
      if (m) { e.preventDefault(); const top = $$('.menu-top')[IDE.MENUS.indexOf(m)]; showMenu(m.items, top); }
    }
  }

  Object.assign(IDE, { applyLessonCode, command, lessonWebProject, openLessonPage, globalKeys, updateWelcomeForce });
})();
