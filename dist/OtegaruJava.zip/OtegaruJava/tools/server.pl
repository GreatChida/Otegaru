#!/usr/bin/perl
# お手軽Java ローカル Web サーバー (macOS 用。macOS に最初から入っている Perl だけで動く)
#   - HTTP Range 要求に対応 (CheerpJ の必須要件)
#   - 127.0.0.1 (この Mac の中) だけで待ち受ける (ほかのパソコンからは接続できない)
#   - /api/* でワークスペース (書類の workspace フォルダー) へのファイル保存・読み込み (Windows 版 tools/server.ps1 と同じ API)
#   - ワークスペースの場所は最初の起動で IDE の画面から選び、workspace.json に覚える
#   - /api/web/* で、Tomcat の代わりの Web サーバー (HTML入門用。動的 Web プロジェクトを配信する) を開始・停止
# 使い方: start.command をダブルクリック (または: perl tools/server.pl [--port 8765] [--no-browser])
use strict;
use warnings;
use utf8;
use IO::Socket::INET;
use IO::Select;
use Socket qw(IPPROTO_TCP TCP_NODELAY);
use File::Basename qw(dirname basename);
use File::Path qw(make_path);
use File::Copy qw(move copy);
use File::Find;
use File::Spec;
use Cwd qw(abs_path);
use Encode qw(decode encode);
use JSON::PP;
use POSIX qw(strftime);

binmode(STDOUT, ':encoding(UTF-8)');
binmode(STDERR, ':encoding(UTF-8)');
$| = 1;

my $port = 8765;
my $no_browser = 0;
my $documents_arg = '';
while (@ARGV) {
  my $a = shift @ARGV;
  if ($a eq '--port' || $a eq '-Port') { $port = shift @ARGV; }
  elsif ($a eq '--no-browser' || $a eq '-NoBrowser') { $no_browser = 1; }
  elsif ($a eq '--documents' || $a eq '-DocumentsDir') { $documents_arg = shift @ARGV; }   # 書類フォルダーの代わり (試すとき用)
}

my $root = abs_path(dirname(abs_path($0)) . '/..');
my $web = "$root/www";
my $JSON = JSON::PP->new->utf8->canonical;
# ワークスペース: 選んだ場所を workspace.json に覚える。まだ選んでいない (または消えた) ときは undef で、IDE の画面で選ぶ
my $config_file = "$root/workspace.json";
my $legacy_work = "$root/work";   # 以前の版の保存場所 (展開したフォルダーの中)
my $documents = $documents_arg || "$ENV{HOME}/Documents";
sub load_work {
  my $c = eval { $JSON->decode(read_file($config_file) // '') } or return undef;
  my $p = defined $c->{path} ? encode('UTF-8', $c->{path}) : '';
  return ($p ne '' && -d $p) ? $p : undef;
}
my $work = load_work();
# パスを JSON で返すとき (ファイル名はバイト列なので、文字に直す)
sub path_text { my ($p) = @_; return defined $p ? decode('UTF-8', $p) : undef; }

my %MIME = (
  html => 'text/html; charset=utf-8', htm => 'text/html; charset=utf-8',
  js => 'text/javascript; charset=utf-8', mjs => 'text/javascript; charset=utf-8',
  css => 'text/css; charset=utf-8', json => 'application/json; charset=utf-8',
  txt => 'text/plain; charset=utf-8', java => 'text/plain; charset=utf-8', md => 'text/plain; charset=utf-8',
  svg => 'image/svg+xml', png => 'image/png', jpg => 'image/jpeg', gif => 'image/gif', ico => 'image/x-icon',
  jar => 'application/java-archive', class => 'application/java-vm', wasm => 'application/wasm', woff2 => 'font/woff2',
);

# ワークスペースで扱うファイル: 文字のファイル (内容を IDE に読み込む) と、画像などのバイナリー・ファイル
my $TEXT_EXT = qr/\.(java|txt|md|prefs|html|htm|css|js|json|xml|svg|mf|component|properties)$/i;
my $BINARY_EXT = qr/\.(png|jpg|jpeg|gif|webp|ico)$/i;
my %WEB_MIME = (
  html => 'text/html', htm => 'text/html', css => 'text/css', js => 'text/javascript', json => 'application/json',
  txt => 'text/plain', xml => 'application/xml', svg => 'image/svg+xml', png => 'image/png', jpg => 'image/jpeg', jpeg => 'image/jpeg',
  gif => 'image/gif', webp => 'image/webp', ico => 'image/x-icon', pdf => 'application/pdf',
);

# 空いているポートを探して待ち受ける
my $server;
for my $p ($port .. $port + 19) {
  $server = IO::Socket::INET->new(LocalAddr => '127.0.0.1', LocalPort => $p, Listen => 64, Proto => 'tcp', ReuseAddr => 0);
  if ($server) { $port = $p; last; }
}
die "ポートを確保できませんでした。\n" unless $server;

my $url = "http://localhost:$port/";
print "\n  お手軽Java が起動しました: $url\n";
print "  このウィンドウを閉じる (または Control + C) と終了します。\n";
print $work ? "  ワークスペース (書いたプログラムの保存場所): " . path_text($work) . "\n\n" : "  ワークスペース (書いたプログラムの保存場所) は、ブラウザーの画面で選んでください。\n\n";
if (!$no_browser) {
  if ($^O eq 'darwin') { system('open', $url); }
  elsif (system('xdg-open', $url) != 0) { print "  ブラウザで $url を開いてください。\n"; }
}

# ---------------------------------------------------------------
# Tomcat の代わりの Web サーバー (HTML入門用) の状態
#   待ち受け (ソケット) は親プロセスが持つ。要求は子プロセスで処理するので、
#   子 (/api/web/start など) からはパイプで親に頼み、親は状態をファイルに書いて子に知らせる
# ---------------------------------------------------------------
my $parent = $$;
my $state_file = File::Spec->catfile(File::Spec->tmpdir, "otegaru-web-$parent.json");
my %web = (running => JSON::PP::false, port => 0, modules => [], ack => '', error => '');
my $web_sock;
pipe(my $ctl_r, my $ctl_w) or die "パイプを作れません: $!\n";
$ctl_w->autoflush(1);
write_web_state();

sub write_web_state {
  open(my $fh, '>:raw', "$state_file.tmp") or return;
  print $fh $JSON->encode(\%web);
  close $fh;
  rename "$state_file.tmp", $state_file;
}
sub read_web_state {
  my $s = eval { $JSON->decode(read_file($state_file) // '') };
  return $s || { running => JSON::PP::false, port => 0, modules => [] };
}

# 親プロセスで、子から届いた頼み (1 行の JSON) を実行する
sub web_control {
  my ($line, $sel) = @_;
  my $m = eval { $JSON->decode($line) } or return;
  $web{error} = '';
  if ($m->{cmd} eq 'start' || $m->{cmd} eq 'stop') {
    if ($web_sock) { $sel->remove($web_sock); close $web_sock; undef $web_sock; }
    print "  Web サーバー (Tomcat の代わり) を停止しました。\n" if $web{running} && $m->{cmd} eq 'stop';
    $web{running} = JSON::PP::false;
  }
  if ($m->{cmd} eq 'start') {
    my $p = int($m->{port} || 0);
    $web_sock = IO::Socket::INET->new(LocalAddr => '127.0.0.1', LocalPort => $p, Listen => 64, Proto => 'tcp', ReuseAddr => 1);
    if ($web_sock) {
      $sel->add($web_sock);
      $web{running} = JSON::PP::true;
      $web{port} = $p;
      print "  Web サーバー (Tomcat の代わり) を開始しました: http://localhost" . ($p == 80 ? '' : ":$p") . "/\n";
    } else {
      $web{error} = "ポート $p は、ほかのプログラムが使用中です。";
    }
  }
  $web{modules} = $m->{modules} if $m->{modules};
  $web{ack} = $m->{id} // '';
  write_web_state();
}

# 1 つの接続ごとに子プロセスで処理する (ブラウザが先に開けておく接続で止まらないように)
my $stop = 0;
$SIG{CHLD} = 'IGNORE';
$SIG{TERM} = sub { $stop = 1; };
$SIG{INT} = sub { $stop = 1; };
my $sel = IO::Select->new($server, $ctl_r);
my $ctl_buf = '';
while (!$stop) {
  for my $fh ($sel->can_read(1)) {
    if ($fh == $ctl_r) {
      sysread($ctl_r, my $chunk, 65536) or next;
      $ctl_buf .= $chunk;
      while ($ctl_buf =~ s/^([^\n]*)\n//) { web_control($1, $sel); }
      next;
    }
    my $c = $fh->accept;
    next unless $c;
    my $is_web = ($web_sock && $fh == $web_sock) ? 1 : 0;
    my $pid = fork();
    if (!defined $pid) { eval { handle($c, $is_web); }; close $c; next; }
    if ($pid == 0) {
      $server->close;
      close $web_sock if $web_sock;
      close $ctl_r;
      eval { handle($c, $is_web); };
      close $c;
      POSIX::_exit(0);
    }
    close $c;
  }
}
close $web_sock if $web_sock;
unlink $state_file;
print "お手軽Java を終了しました。\n";
exit 0;

# ---------------------------------------------------------------
sub handle {
  my ($c, $is_web) = @_;
  our $IS_WEB = $is_web;
  binmode($c);
  setsockopt($c, IPPROTO_TCP, TCP_NODELAY, 1);
  $c->autoflush(1);
  # 1 つの接続で続けて届く要求を順に処理する (keep-alive)。5 秒間なにも来なければ切る
  # (CheerpJ は ecj.jar などを小さな範囲で何度も読むので、接続を使い回すと速い)
  my $sel = IO::Select->new($c);
  my $first = 1;
  while (1) {
    last unless $sel->can_read($first ? 30 : 5);
    $first = 0;
    last unless handle_one($c);
  }
}

# 要求を 1 つ処理する。接続を続けてよければ 1 を返す
sub handle_one {
  my ($c) = @_;
  local $/ = "\n";
  my $line = <$c>;
  return 0 unless defined $line;
  my ($method, $target) = $line =~ m{^(\w+)\s+(\S+)};
  return 0 unless $method;
  my %h;
  while (defined(my $l = <$c>)) {
    $l =~ s/\r?\n\z//;
    last if $l eq '';
    my ($k, $v) = split /:\s*/, $l, 2;
    $h{lc $k} = $v if defined $v;
  }
  my $body = '';
  my $len = $h{'content-length'} || 0;
  while (length($body) < $len) {
    my $n = read($c, my $buf, $len - length($body));
    last unless $n;
    $body .= $buf;
  }
  our $KEEP = (($h{connection} // '') !~ /close/i) ? 1 : 0;
  my ($path, $query) = split /\?/, $target, 2;
  my $raw_path = $path;
  my %q;
  for my $kv (split /&/, ($query // '')) {
    my ($k, $v) = split /=/, $kv, 2;
    $q{url_decode($k)} = url_decode($v // '');
  }
  $path = url_decode($path);
  # ワークスペースは別の要求 (別のプロセス) で決まることがあるので、毎回読み直す
  $work = load_work();
  my $ok = eval {
    our $IS_WEB;
    if ($IS_WEB) { handle_web($c, $method, $raw_path); }
    elsif ($path =~ m{^/api/}) { handle_api($c, $method, $path, \%q, $body); }
    else { handle_static($c, $method, $path, \%h); }
    1;
  };
  if (!$ok) {
    my $err = $@ || 'error';
    send_text($c, 500, 'error: ' . $err);
  }
  return $KEEP;
}

sub url_decode {
  my ($s) = @_;
  $s =~ tr/+/ /;
  $s =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
  return decode('UTF-8', $s);
}

sub send_raw {
  my ($c, $status, $type, $bytes, $extra) = @_;
  my %text = (200 => 'OK', 206 => 'Partial Content', 302 => 'Found', 400 => 'Bad Request', 403 => 'Forbidden', 404 => 'Not Found',
    405 => 'Method Not Allowed', 409 => 'Conflict', 416 => 'Range Not Satisfiable', 500 => 'Internal Server Error');
  my $head = "HTTP/1.1 $status " . ($text{$status} || 'OK') . "\r\n";
  $head .= "Content-Type: $type\r\n" if $type;
  $head .= "Content-Length: " . length($bytes) . "\r\n";
  $head .= $extra if $extra;
  our $KEEP;
  $head .= ($KEEP ? "Connection: keep-alive\r\nKeep-Alive: timeout=5\r\n" : "Connection: close\r\n") . "\r\n";
  # ヘッダーと本文を 1 回で送る (2 回に分けると TCP の待ちが入って遅くなる)
  print $c $head . $bytes;
}
sub send_text { my ($c, $status, $text) = @_; send_raw($c, $status, 'text/plain; charset=utf-8', encode('UTF-8', $text)); }
sub send_json { my ($c, $obj) = @_; send_raw($c, 200, 'application/json; charset=utf-8', $JSON->encode($obj)); }

# ワークスペースの中だけを扱う。各部分は英数字 _ - . のみ (.. は不可)
sub safe_work_path {
  my ($rel, $is_file) = @_;
  return undef if !defined $rel || $rel eq '';
  my @parts = split m{/}, $rel;
  for my $p (@parts) {
    return undef if $p !~ /^[A-Za-z0-9_\-.]{1,80}$/ || $p eq '.' || $p eq '..';
  }
  if ($is_file) {
    return undef unless $rel =~ $TEXT_EXT || $rel =~ $BINARY_EXT || $rel =~ m{(^|/)\.(project|classpath|jsdtscope)$};
  }
  return "$work/" . join('/', @parts);
}

sub read_file { my ($f) = @_; open(my $fh, '<:raw', $f) or return undef; local $/; my $d = <$fh>; close $fh; return defined $d ? $d : ''; }
sub write_file { my ($f, $bytes) = @_; make_path(dirname($f)); open(my $fh, '>:raw', $f) or die "書き込めません: $f\n"; print $fh $bytes; close $fh; }

# ゴミ箱へ移す (元に戻せるように)
sub to_trash {
  my ($p) = @_;
  return 1 unless -e $p;
  my $trash = "$ENV{HOME}/.Trash";
  if ($^O eq 'darwin') {
    # Finder に頼む (「戻す」が使える)。だめならゴミ箱のフォルダーへ移す
    my $esc = $p; $esc =~ s/(["\\])/\\$1/g;
    return 1 if system('osascript', '-e', qq{tell application "Finder" to delete POSIX file "$esc"}) == 0 && !-e $p;
  }
  if (-d $trash) {
    my $dest = "$trash/" . basename($p);
    $dest .= ' ' . strftime('%H.%M.%S', localtime) if -e $dest;
    return 1 if move($p, $dest);
  }
  die "ゴミ箱に移せませんでした: $p\n";
}

sub handle_api {
  my ($c, $method, $path, $q, $body) = @_;
  my $qp = $q->{path};
  if ($path eq '/api/ping') { return send_json($c, { ok => JSON::PP::true }); }
  if ($path eq '/api/workspace') { return send_json($c, workspace_info()); }
  if ($path eq '/api/workspace/select' && $method eq 'POST') {
    my $r = eval { select_workspace($body) };
    return $r ? send_json($c, $r) : send_text($c, 400, $@ || 'error');
  }
  if ($path ne '/api/shutdown' && !$work) { return send_text($c, 409, 'ワークスペースが選ばれていません'); }
  if ($path eq '/api/tree') {
    my (@dirs, @files);
    find({ no_chdir => 1, wanted => sub {
      my $f = $File::Find::name;
      return if $f eq $work;
      my $rel = substr($f, length($work) + 1);
      my $b = basename($f);
      if (-d $f) {
        # 「.」で始まるフォルダーは .settings (Eclipse の設定) と .otegaru (お手軽Java の設定) だけを読む
        # (Eclipse のワークスペースを使うときに、.metadata などの大量のファイルを読まないように)
        if ($b =~ /^\./ && $b ne '.settings' && $b ne '.otegaru') { $File::Find::prune = 1; return; }
        push @dirs, $rel; return;
      }
      if ($b =~ $TEXT_EXT || $b =~ /^\.(project|classpath|jsdtscope)$/) {
        push @files, { path => $rel, content => decode('UTF-8', read_file($f) // '') };
      } elsif ($b =~ $BINARY_EXT) {
        push @files, { path => $rel, binary => JSON::PP::true, size => -s $f };
      }
    } }, $work);
    return send_json($c, { dirs => [sort @dirs], files => [sort { $a->{path} cmp $b->{path} } @files], root => path_text($work) });
  }
  if ($path eq '/api/file') {
    my $fp = safe_work_path($qp, 1);
    return send_text($c, 400, '使えない名前です (英数字 _ - . のみ)') unless $fp;
    if ($method eq 'GET') {
      return send_text($c, 404, 'not found') unless -f $fp;
      return send_raw($c, 200, 'text/plain; charset=utf-8', read_file($fp));
    }
    if ($method eq 'PUT' || $method eq 'POST') { write_file($fp, $body); return send_json($c, { ok => JSON::PP::true }); }
    if ($method eq 'DELETE') { unlink $fp if -f $fp; return send_json($c, { ok => JSON::PP::true }); }
  }
  if ($path eq '/api/dir') {
    my $dp = safe_work_path($qp, 0);
    return send_text($c, 400, '使えない名前です (英数字 _ - . のみ)') unless $dp;
    if ($method eq 'POST' || $method eq 'PUT') { make_path($dp); return send_json($c, { ok => JSON::PP::true }); }
    if ($method eq 'DELETE') { to_trash($dp); return send_json($c, { ok => JSON::PP::true }); }
  }
  if ($path eq '/api/trash') {
    my $fp = safe_work_path($qp, 1);
    return send_text($c, 400, 'bad path') unless $fp;
    to_trash($fp) if -f $fp;
    return send_json($c, { ok => JSON::PP::true });
  }
  if ($path eq '/api/rename' && $method eq 'POST') {
    my $from = safe_work_path($q->{from}, 0);
    my $to = safe_work_path($q->{to}, 0);
    return send_text($c, 400, '名前を変更できません') if !$from || !$to || !-e $from || -e $to;
    make_path(dirname($to));
    move($from, $to) or return send_text($c, 400, '名前を変更できません');
    return send_json($c, { ok => JSON::PP::true });
  }
  if ($path eq '/api/open-folder') {
    my $dp = $work;
    if ($qp) { my $t = safe_work_path($qp, 0); $dp = $t if $t && -d $t; }
    if ($^O eq 'darwin') { system('open', $dp); } else { system('xdg-open', $dp); }
    return send_json($c, { ok => JSON::PP::true });
  }
  if ($path eq '/api/raw') {
    # ワークスペースのファイルをそのまま返す (IDE で画像を開くとき)
    my $fp = safe_work_path($qp, 1);
    return send_text($c, 404, 'not found') unless $fp && -f $fp;
    my ($ext) = $fp =~ /\.([^.\/]+)$/;
    return send_raw($c, 200, $MIME{lc($ext // '')} || 'application/octet-stream', read_file($fp));
  }
  if ($path eq '/api/open-file') {
    # 関連付けされたアプリ (画像ならプレビューなど) で開く
    my $fp = safe_work_path($qp, 1);
    return send_text($c, 404, 'not found') unless $fp && -f $fp;
    if ($^O eq 'darwin') { system('open', $fp); } else { system('xdg-open', $fp); }
    return send_json($c, { ok => JSON::PP::true });
  }
  if ($path eq '/api/web') { return send_json($c, web_state_public(read_web_state())); }
  if ($path =~ m{^/api/web/(start|stop|modules)$} && $method eq 'POST') {
    my $cmd = $1;
    my %m = (cmd => $cmd, id => "$$-" . time() . '-' . int(rand(1e9)));
    if ($cmd eq 'start') {
      my $p = $q->{port} // '';
      return send_text($c, 400, 'ポート番号が正しくありません') unless $p =~ /^\d+$/ && $p >= 1 && $p <= 65535;
      $m{port} = int($p);
    }
    if ($cmd ne 'stop') {
      my $req = eval { $JSON->decode($body) } || {};
      $m{modules} = [ grep { ($_->{context} // '') =~ /^[A-Za-z0-9_\-.]{1,80}$/ && safe_work_path($_->{dir}, 0) }
        map { { context => $_->{context}, dir => $_->{dir} } } @{ $req->{modules} || [] } ];
    }
    print $ctl_w $JSON->encode(\%m) . "\n";
    # 親が実行して状態を書くのを待つ
    my $s;
    for (1 .. 150) {
      $s = read_web_state();
      last if ($s->{ack} // '') eq $m{id};
      select(undef, undef, undef, 0.02);
    }
    return send_text($c, 409, $s->{error}) if $s->{error};
    return send_json($c, web_state_public($s));
  }
  if ($path eq '/api/shutdown') {
    send_json($c, { ok => JSON::PP::true });
    kill 'TERM', $parent;
    return;
  }
  send_text($c, 404, 'not found');
}

# ---- ワークスペースの選択 ----
# 候補は「書類/workspace」。すでにあるときは、そのまま使うか「workspace2」などの無い名前にするかを IDE で聞く
sub legacy_projects {
  opendir(my $dh, $legacy_work) or return ();
  my @p = sort grep { !/^\./ && -d "$legacy_work/$_" } readdir($dh);
  closedir $dh;
  return @p;
}
sub workspace_info {
  my $cand = "$documents/workspace";
  my $n = 2; $n++ while -e "$documents/workspace$n";
  return {
    configured => $work ? JSON::PP::true : JSON::PP::false, path => path_text($work), documents => path_text($documents),
    candidate => path_text($cand), candidateExists => (-e $cand ? JSON::PP::true : JSON::PP::false),
    candidateIsOtegaru => (-d "$cand/.otegaru" ? JSON::PP::true : JSON::PP::false),
    alternative => path_text("$documents/workspace$n"),
    legacy => { path => path_text($legacy_work), projects => [ map { path_text($_) } legacy_projects() ] },
  };
}
# フォルダーを中身ごとコピーする
sub copy_tree {
  my ($from, $to) = @_;
  find({ no_chdir => 1, wanted => sub {
    my $f = $File::Find::name;
    my $dest = $to . substr($f, length($from));
    if (-d $f) { make_path($dest); } else { copy($f, $dest) or die "コピーできません: $f\n"; }
  } }, $from);
}
sub select_workspace {
  my ($body) = @_;
  my $req = $JSON->decode($body);
  my $target = encode('UTF-8', $req->{path} // '');
  $target =~ s{/+$}{};
  # 選べるのは、書類の中の workspace・workspace2… だけ
  die "このフォルダーはワークスペースにできません\n" unless dirname($target) eq $documents && basename($target) =~ /^workspace\d*$/;
  make_path("$target/.otegaru");
  # 以前の保存場所 (展開したフォルダーの work) のプロジェクトをコピーする (元はそのまま残す)
  my (@copied, @skipped);
  if ($req->{copyLegacy}) {
    for my $p (legacy_projects()) {
      if (-e "$target/$p") { push @skipped, path_text($p); next; }
      copy_tree("$legacy_work/$p", "$target/$p");
      push @copied, path_text($p);
    }
  }
  write_file($config_file, $JSON->encode({ path => path_text($target) }));
  $work = $target;
  print "  ワークスペース (書いたプログラムの保存場所): " . path_text($target) . "\n";
  return { ok => JSON::PP::true, path => path_text($target), copied => \@copied, skipped => \@skipped };
}

sub web_state_public {
  my ($s) = @_;
  return { running => $s->{running} ? JSON::PP::true : JSON::PP::false, port => $s->{port} + 0,
    modules => [ map { { context => $_->{context}, dir => $_->{dir} } } @{ $s->{modules} || [] } ] };
}

# ---------------------------------------------------------------
# Tomcat の代わりの Web サーバー (HTML入門用)
#  - 動的 Web プロジェクトの Web コンテンツ (src/main/webapp など) を http://localhost:ポート/コンテキスト・ルート/ で返す
#  - Tomcat と同じように、POST でもファイルをそのまま返し、無いときは「HTTPステータス 404 – 見つかりません」を返す
# ---------------------------------------------------------------
sub tomcat_error_page {
  my ($status, $title, $message, $desc) = @_;
  my $e = $message; $e =~ s/&/&amp;/g; $e =~ s/</&lt;/g; $e =~ s/>/&gt;/g; $e =~ s/"/&quot;/g;
  return encode('UTF-8', qq{<!doctype html><html lang="ja"><head><title>HTTPステータス $status – $title</title><style type="text/css">body {font-family:Tahoma,Arial,sans-serif;} h1, h2, h3, b {color:white;background-color:#525D76;} h1 {font-size:22px;} h2 {font-size:16px;} h3 {font-size:14px;} p {font-size:12px;} a {color:black;} .line {height:1px;background-color:#525D76;border:none;}</style></head><body><h1>HTTPステータス $status – $title</h1><hr class="line" /><p><b>タイプ</b> ステータスレポート</p><p><b>メッセージ</b> $e</p><p><b>説明</b> $desc</p><hr class="line" /><h3>Apache Tomcat/11.0</h3></body></html>});
}
sub web_not_found {
  my ($c, $path) = @_;
  send_raw($c, 404, 'text/html;charset=utf-8', tomcat_error_page(404, '見つかりません', "要求されたリソース [$path] は利用できません",
    'オリジンサーバーは、ターゲットリソースの現在の表現を見つけられなかったか、またはそれが存在することを開示するつもりはありません。'), "Content-Language: ja\r\n");
}
# フォルダーの中から、大文字・小文字まで同じ名前の項目を探す (Tomcat と同じく、名前の大文字・小文字を区別する)
sub find_exact {
  my ($dir, $name) = @_;
  opendir(my $dh, $dir) or return undef;
  my @hit = grep { decode('UTF-8', $_) eq $name } readdir($dh);
  closedir $dh;
  return @hit ? "$dir/$hit[0]" : undef;
}
sub handle_web {
  my ($c, $method, $raw) = @_;
  (my $p = $raw) =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
  my $path = eval { decode('UTF-8', $p, Encode::FB_CROAK) } // $p;
  my @segs = split m{/}, substr($path, 1), -1;
  @segs = ('') unless @segs;
  my ($mod) = grep { $_->{context} eq $segs[0] } @{ read_web_state()->{modules} || [] };
  return web_not_found($c, $path) if !$mod || $segs[0] eq '';
  # /html → /html/ (Tomcat と同じく、末尾に / を付けた URL に移る)
  return send_raw($c, 302, '', '', "Location: $raw/\r\n") if @segs == 1;
  my @rest = @segs[1 .. $#segs];
  return web_not_found($c, $path) if $rest[0] =~ /^(WEB-INF|META-INF)$/i;
  my $cur = "$work/$mod->{dir}";
  return web_not_found($c, $path) unless -d $cur;
  for my $i (0 .. $#rest) {
    my $s = $rest[$i];
    last if $s eq '' && $i == $#rest;
    return web_not_found($c, $path) if $s eq '' || $s eq '.' || $s eq '..';
    $cur = find_exact($cur, $s);
    return web_not_found($c, $path) unless $cur;
  }
  if (-d $cur) {
    return send_raw($c, 302, '', '', "Location: $raw/\r\n") unless $path =~ m{/$};
    # ようこそファイル (index.html) が無いときは 404 (Tomcat はフォルダーの一覧を出さない)
    my $welcome = find_exact($cur, 'index.html') // find_exact($cur, 'index.htm');
    return web_not_found($c, $path) unless $welcome && -f $welcome;
    $cur = $welcome;
  }
  if ($method ne 'GET' && $method ne 'HEAD' && $method ne 'POST') {
    return send_raw($c, 405, 'text/html;charset=utf-8', tomcat_error_page(405, '許可されていないメソッド', "メソッド [$method] はこのリソースでは許可されていません",
      '要求行で受信されたメソッドは、オリジンサーバーによって認識されていますが、ターゲットリソースによってサポートされていません。'), "Allow: GET, HEAD, POST, OPTIONS\r\n");
  }
  my ($ext) = $cur =~ /\.([^.\/]+)$/;
  my $type = $WEB_MIME{lc($ext // '')} || '';
  my $data = read_file($cur) // '';
  my $lm = strftime('%a, %d %b %Y %H:%M:%S GMT', gmtime((stat($cur))[9]));
  # 保存した内容がすぐに見えるよう、ブラウザーには毎回確かめさせる
  my $extra = "Last-Modified: $lm\r\nCache-Control: no-cache\r\n";
  if ($method eq 'HEAD') {
    our $KEEP;
    print $c "HTTP/1.1 200 OK\r\n" . ($type ? "Content-Type: $type\r\n" : '') . "Content-Length: " . length($data) . "\r\n$extra"
      . ($KEEP ? "Connection: keep-alive\r\n" : "Connection: close\r\n") . "\r\n";
    return;
  }
  send_raw($c, 200, $type, $data, $extra);
}

sub handle_static {
  my ($c, $method, $path, $h) = @_;
  my $rel = $path;
  $rel =~ s{^/+}{};
  $rel = 'index.html' if $rel eq '';
  return send_text($c, 403, 'forbidden') if grep { $_ eq '..' } split m{/}, $rel;
  my $full = "$web/$rel";
  # 同じ接続の中で何度も読まれるファイル (ecj.jar など) は、メモリーに置いて使い回す
  our %CACHE;
  my $data_all = $CACHE{$full};
  if (!defined $data_all) {
    $full .= '/index.html' if -d $full;
    return send_text($c, 404, 'not found') unless -f $full;
    $data_all = read_file($full);
    return send_text($c, 404, 'not found') unless defined $data_all;
    $CACHE{"$web/$rel"} = $data_all;
  }
  my ($ext) = $full =~ /\.([^.\/]+)$/;
  my $type = $MIME{lc($ext // '')} || 'application/octet-stream';
  my $size = length($data_all);
  my ($start, $end, $status) = (0, $size - 1, 200);
  my $extra = "Accept-Ranges: bytes\r\nCache-Control: no-cache\r\n";
  if (($h->{range} // '') =~ /^bytes=(\d*)-(\d*)$/) {
    if ($1 ne '') { $start = $1; $end = $2 if $2 ne '' && $2 < $end; }
    elsif ($2 ne '') { $start = $size - $2; $start = 0 if $start < 0; }
    if ($start > $end || $start >= $size) {
      return send_raw($c, 416, 'text/plain', '', "Content-Range: bytes */$size\r\n");
    }
    $status = 206;
    $extra .= "Content-Range: bytes $start-$end/$size\r\n";
  }
  my $count = $end - $start + 1;
  my $data = ($method ne 'HEAD' && $count > 0) ? substr($data_all, $start, $count) : '';
  if ($method eq 'HEAD') {
    our $KEEP;
    print $c "HTTP/1.1 $status OK\r\nContent-Type: $type\r\nContent-Length: $count\r\n${extra}" . ($KEEP ? "Connection: keep-alive\r\n" : "Connection: close\r\n") . "\r\n";
    return;
  }
  send_raw($c, $status, $type, $data, $extra);
}
