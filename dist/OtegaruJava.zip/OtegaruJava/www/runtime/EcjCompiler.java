package otekaru;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.eclipse.jdt.core.compiler.CategorizedProblem;
import org.eclipse.jdt.internal.compiler.ClassFile;
import org.eclipse.jdt.internal.compiler.CompilationResult;
import org.eclipse.jdt.internal.compiler.Compiler;
import org.eclipse.jdt.internal.compiler.DefaultErrorHandlingPolicies;
import org.eclipse.jdt.internal.compiler.ICompilerRequestor;
import org.eclipse.jdt.internal.compiler.batch.CompilationUnit;
import org.eclipse.jdt.internal.compiler.batch.FileSystem;
import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
import org.eclipse.jdt.internal.compiler.problem.DefaultProblem;
import org.eclipse.jdt.internal.compiler.problem.DefaultProblemFactory;

/**
 * Eclipse のコンパイラー (ECJ) を内部 API で呼ぶ。
 * Java 標準ライブラリ (jrt) の準備には時間がかかるので、最初の 1 回だけ行い、以後は使い回す。
 * コンパイル結果のクラス・ファイルはメモリーに置き、Runner がそこから実行する。
 */
final class EcjCompiler {

    /** Java 標準ライブラリだけを持つ環境 (ソースは毎回コンパイル単位として渡す) */
    static final class Env extends FileSystem {
        Env(Classpath[] paths) {
            super(paths, null, false);
        }

        @Override
        public void cleanup() {
            // 標準ライブラリのキャッシュを残すため、何もしない
        }

    }

    private static Env env;

    static void prepare() {
        if (env == null) {
            Runner.patchEcjForCheerpJ();
            FileSystem.Classpath jrt = FileSystem.getJrtClasspath(System.getProperty("java.home"), "UTF-8", null, null);
            env = new Env(new FileSystem.Classpath[] { jrt });
        }
    }

    /**
     * @param sources パス (src からの相対) -> ソース
     * @param classes 結果のクラス (バイナリ名 -> バイト列) を入れる
     * @return エラーがなければ 0
     */
    /** コンパイルの結果を受け取る先 (Compiler は使い回すので、受け取り先だけ毎回差し替える) */
    private static ICompilerRequestor current;
    private static final Map<String, Compiler> compilers = new HashMap<>();
    private static DefaultProblemFactory problemFactory;

    private static CompilerOptions options(String release) {
        Map<String, String> o = new HashMap<>();
        o.put(CompilerOptions.OPTION_Compliance, release);
        o.put(CompilerOptions.OPTION_Source, release);
        o.put(CompilerOptions.OPTION_TargetPlatform, release);
        o.put(CompilerOptions.OPTION_Encoding, "UTF-8");
        o.put(CompilerOptions.OPTION_LocalVariableAttribute, CompilerOptions.GENERATE);
        o.put(CompilerOptions.OPTION_LineNumberAttribute, CompilerOptions.GENERATE);
        o.put(CompilerOptions.OPTION_SourceFileAttribute, CompilerOptions.GENERATE);
        o.put(CompilerOptions.OPTION_PreserveUnusedLocal, CompilerOptions.PRESERVE);
        // Eclipse の既定に合わせた警告
        o.put(CompilerOptions.OPTION_ReportUnusedImport, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportUnusedLocal, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportUnusedPrivateMember, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportMissingSerialVersion, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportRawTypeReference, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportUncheckedTypeOperation, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportDeadCode, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportNullReference, CompilerOptions.WARNING);
        o.put(CompilerOptions.OPTION_ReportUnclosedCloseable, CompilerOptions.WARNING);
        CompilerOptions co = new CompilerOptions(o);
        co.performMethodsFullRecovery = true;
        co.performStatementsRecovery = true;
        return co;
    }

    /** release ごとの Compiler (作るのに時間がかかるので使い回す) */
    static Compiler compilerFor(String release) {
        prepare();
        Compiler c = compilers.get(release);
        if (c == null) {
            if (problemFactory == null) {
                problemFactory = new DefaultProblemFactory(Locale.JAPAN);
            }
            c = new Compiler(env, DefaultErrorHandlingPolicies.proceedWithAllProblems(), options(release),
                    result -> current.acceptResult(result), problemFactory);
            compilers.put(release, c);
        }
        return c;
    }

    /**
     * @param sources パス (src からの相対) -> ソース
     * @param classes 結果のクラス (バイナリ名 -> バイト列) を入れる
     * @return エラーがなければ 0
     */
    static int compile(Map<String, String> sources, String release, Map<String, byte[]> classes) {
        return compile(sources, release, classes, false);
    }

    static int compile(Map<String, String> sources, String release, Map<String, byte[]> classes, boolean quiet) {
        long ta = System.currentTimeMillis();
        Compiler compiler = compilerFor(release);
        long tb = System.currentTimeMillis();
        List<ICompilationUnit> units = new ArrayList<>();
        Map<String, String> nameToRel = new HashMap<>();
        for (Map.Entry<String, String> e : sources.entrySet()) {
            String rel = e.getKey();
            String path = "/src/" + rel;
            nameToRel.put(path, rel);
            units.add(new CompilationUnit(e.getValue().toCharArray(), path, "UTF-8"));
        }
        final boolean[] hasError = { false };
        current = (CompilationResult result) -> {
            String rel = nameToRel.getOrDefault(new String(result.getFileName()), new String(result.getFileName()));
            CategorizedProblem[] problems = result.getAllProblems();
            if (problems != null) {
                for (CategorizedProblem p : problems) {
                    if (p.isError()) {
                        hasError[0] = true;
                    }
                    if (!p.isError() && !p.isWarning()) {
                        continue;
                    }
                    if (quiet) {
                        continue;
                    }
                    int col = p instanceof DefaultProblem ? ((DefaultProblem) p).getSourceColumnNumber() : 0;
                    Runner.diag(p.isError() ? "ERROR" : "WARNING", rel, p.getSourceLineNumber(), col,
                            p.getSourceStart(), p.getSourceEnd(), String.valueOf(p.getID()), p.getMessage());
                }
            }
            for (ClassFile cf : result.getClassFiles()) {
                classes.put(new String(cf.fileName()).replace('/', '.'), cf.getBytes());
            }
        };
        try {
            compiler.compile(units.toArray(new ICompilationUnit[0]));
        } finally {
            current = null;
        }
        if (System.getProperty("otekaru.debug") != null) {
            System.err.println("ecj prepare " + (tb - ta) + "ms, compile " + (System.currentTimeMillis() - tb) + "ms");
        }
        return hasError[0] ? 1 : 0;
    }
}
