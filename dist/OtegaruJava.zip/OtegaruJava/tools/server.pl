#!/usr/bin/perl
# お手軽Java ローカル Web サーバー (macOS 用。macOS に最初から入っている Perl だけで動く)
#   - HTTP Range 要求に対応 (CheerpJ の必須要件)
#   - 127.0.0.1 (この Mac の中) だけで待ち受ける (ほかのパソコンからは接続できない)
#   - /api/* で work フォルダーへのファイル保存・読み込み (Windows 版 tools/server.ps1 と同じ API)
# 使い方: start.command をダブルクリック (または: perl tools/server.pl [--port 8765] [--no-browser])
use strict;
use warnings;
use utf8;
use IO::Socket::INET;
use IO::Select;
use Socket qw(IPPROTO_TCP TCP_NODELAY);
use File::Basename qw(dirname basename);
use File::Path qw(make_path);
use File::Copy qw(move);
use File::Find;
use Cwd qw(abs_path);
use Encode qw(decode encode);
use JSON::PP;
use POSIX qw(strftime);

binmode(STDOUT, ':encoding(UTF-8)');
binmode(STDERR, ':encoding(UTF-8)');
$| = 1;

my $port = 8765;
my $no_browser = 0;
while (@ARGV) {
  my $a = shift @ARGV;
  if ($a eq '--port' || $a eq '-Port') { $port = shift @ARGV; }
  elsif ($a eq '--no-browser' || $a eq '-NoBrowser') { $no_browser = 1; }
}

my $root = abs_path(dirname(abs_path($0)) . '/..');
my $web = "$root/www";
my $work = "$root/work";
make_path($work) unless -d $work;
my $JSON = JSON::PP->new->utf8->canonical;

my %MIME = (
  html => 'text/html; charset=utf-8', htm => 'text/html; charset=utf-8',
  js => 'text/javascript; charset=utf-8', mjs => 'text/javascript; charset=utf-8',
  css => 'text/css; charset=utf-8', json => 'application/json; charset=utf-8',
  txt => 'text/plain; charset=utf-8', java => 'text/plain; charset=utf-8', md => 'text/plain; charset=utf-8',
  svg => 'image/svg+xml', png => 'image/png', jpg => 'image/jpeg', gif => 'image/gif', ico => 'image/x-icon',
  jar => 'application/java-archive', class => 'application/java-vm', wasm => 'application/wasm', woff2 => 'font/woff2',
);

# 空いているポートを探して待ち受ける
my $server;
for my $p ($port .. $port + 19) {
  $server = IO::Socket::INET->new(LocalAddr => '127.0.0.1', LocalPort => $p, Listen => 64, Proto => 'tcp', ReuseAddr => 0);
  if ($server) { $port = $p; last; }
}
die "ポートを確保できませんでした。\n" unless $server;

my $url = "http://localhost:$port/";
print "\n  お手軽Java が起動しました: $url\n";
print "  このウィンドウを閉じる (または Control + C) と終了します。\n";
print "  ワークスペース (書いたプログラムの保存場所): $work\n\n";
if (!$no_browser) {
  if ($^O eq 'darwin') { system('open', $url); }
  elsif (system('xdg-open', $url) != 0) { print "  ブラウザで $url を開いてください。\n"; }
}

# 1 つの接続ごとに子プロセスで処理する (ブラウザが先に開けておく接続で止まらないように)
my $parent = $$;
my $stop = 0;
$SIG{CHLD} = 'IGNORE';
$SIG{TERM} = sub { $stop = 1; };
$SIG{INT} = sub { $stop = 1; };
while (!$stop) {
  my $c = $server->accept;
  next unless $c;
  my $pid = fork();
  if (!defined $pid) { eval { handle($c); }; close $c; next; }
  if ($pid == 0) {
    $server->close;
    eval { handle($c); };
    close $c;
    POSIX::_exit(0);
  }
  close $c;
}
print "お手軽Java を終了しました。\n";
exit 0;

# ---------------------------------------------------------------
sub handle {
  my ($c) = @_;
  binmode($c);
  setsockopt($c, IPPROTO_TCP, TCP_NODELAY, 1);
  $c->autoflush(1);
  # 1 つの接続で続けて届く要求を順に処理する (keep-alive)。5 秒間なにも来なければ切る
  # (CheerpJ は ecj.jar などを小さな範囲で何度も読むので、接続を使い回すと速い)
  my $sel = IO::Select->new($c);
  my $first = 1;
  while (1) {
    last unless $sel->can_read($first ? 30 : 5);
    $first = 0;
    last unless handle_one($c);
  }
}

# 要求を 1 つ処理する。接続を続けてよければ 1 を返す
sub handle_one {
  my ($c) = @_;
  local $/ = "\n";
  my $line = <$c>;
  return 0 unless defined $line;
  my ($method, $target) = $line =~ m{^(\w+)\s+(\S+)};
  return 0 unless $method;
  my %h;
  while (defined(my $l = <$c>)) {
    $l =~ s/\r?\n\z//;
    last if $l eq '';
    my ($k, $v) = split /:\s*/, $l, 2;
    $h{lc $k} = $v if defined $v;
  }
  my $body = '';
  my $len = $h{'content-length'} || 0;
  while (length($body) < $len) {
    my $n = read($c, my $buf, $len - length($body));
    last unless $n;
    $body .= $buf;
  }
  our $KEEP = (($h{connection} // '') !~ /close/i) ? 1 : 0;
  my ($path, $query) = split /\?/, $target, 2;
  my %q;
  for my $kv (split /&/, ($query // '')) {
    my ($k, $v) = split /=/, $kv, 2;
    $q{url_decode($k)} = url_decode($v // '');
  }
  $path = url_decode($path);
  my $ok = eval {
    if ($path =~ m{^/api/}) { handle_api($c, $method, $path, \%q, $body); }
    else { handle_static($c, $method, $path, \%h); }
    1;
  };
  if (!$ok) {
    my $err = $@ || 'error';
    send_text($c, 500, 'error: ' . $err);
  }
  return $KEEP;
}

sub url_decode {
  my ($s) = @_;
  $s =~ tr/+/ /;
  $s =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
  return decode('UTF-8', $s);
}

sub send_raw {
  my ($c, $status, $type, $bytes, $extra) = @_;
  my %text = (200 => 'OK', 206 => 'Partial Content', 400 => 'Bad Request', 403 => 'Forbidden', 404 => 'Not Found', 416 => 'Range Not Satisfiable', 500 => 'Internal Server Error');
  my $head = "HTTP/1.1 $status " . ($text{$status} || 'OK') . "\r\n";
  $head .= "Content-Type: $type\r\n" if $type;
  $head .= "Content-Length: " . length($bytes) . "\r\n";
  $head .= $extra if $extra;
  our $KEEP;
  $head .= ($KEEP ? "Connection: keep-alive\r\nKeep-Alive: timeout=5\r\n" : "Connection: close\r\n") . "\r\n";
  # ヘッダーと本文を 1 回で送る (2 回に分けると TCP の待ちが入って遅くなる)
  print $c $head . $bytes;
}
sub send_text { my ($c, $status, $text) = @_; send_raw($c, $status, 'text/plain; charset=utf-8', encode('UTF-8', $text)); }
sub send_json { my ($c, $obj) = @_; send_raw($c, 200, 'application/json; charset=utf-8', $JSON->encode($obj)); }

# work フォルダーの中だけを扱う。各部分は英数字 _ - . のみ (.. は不可)
sub safe_work_path {
  my ($rel, $is_file) = @_;
  return undef if !defined $rel || $rel eq '';
  my @parts = split m{/}, $rel;
  for my $p (@parts) {
    return undef if $p !~ /^[A-Za-z0-9_\-.]{1,80}$/ || $p eq '.' || $p eq '..';
  }
  if ($is_file) {
    return undef unless $rel =~ /\.(java|txt|md|prefs)$/ || $rel =~ m{(^|/)\.(project|classpath)$};
  }
  return "$work/" . join('/', @parts);
}

sub read_file { my ($f) = @_; open(my $fh, '<:raw', $f) or return undef; local $/; my $d = <$fh>; close $fh; return defined $d ? $d : ''; }
sub write_file { my ($f, $bytes) = @_; make_path(dirname($f)); open(my $fh, '>:raw', $f) or die "書き込めません: $f\n"; print $fh $bytes; close $fh; }

# ゴミ箱へ移す (元に戻せるように)
sub to_trash {
  my ($p) = @_;
  return 1 unless -e $p;
  my $trash = "$ENV{HOME}/.Trash";
  if ($^O eq 'darwin') {
    # Finder に頼む (「戻す」が使える)。だめならゴミ箱のフォルダーへ移す
    my $esc = $p; $esc =~ s/(["\\])/\\$1/g;
    return 1 if system('osascript', '-e', qq{tell application "Finder" to delete POSIX file "$esc"}) == 0 && !-e $p;
  }
  if (-d $trash) {
    my $dest = "$trash/" . basename($p);
    $dest .= ' ' . strftime('%H.%M.%S', localtime) if -e $dest;
    return 1 if move($p, $dest);
  }
  die "ゴミ箱に移せませんでした: $p\n";
}

sub handle_api {
  my ($c, $method, $path, $q, $body) = @_;
  my $qp = $q->{path};
  if ($path eq '/api/ping') { return send_json($c, { ok => JSON::PP::true }); }
  if ($path eq '/api/tree') {
    my (@dirs, @files);
    find({ no_chdir => 1, wanted => sub {
      my $f = $File::Find::name;
      return if $f eq $work;
      my $rel = substr($f, length($work) + 1);
      if (-d $f) { push @dirs, $rel; return; }
      my $b = basename($f);
      return unless $b =~ /\.(java|txt|md|prefs)$/ || $b eq '.project' || $b eq '.classpath';
      push @files, { path => $rel, content => decode('UTF-8', read_file($f) // '') };
    } }, $work);
    return send_json($c, { dirs => [sort @dirs], files => [sort { $a->{path} cmp $b->{path} } @files], root => $work });
  }
  if ($path eq '/api/file') {
    my $fp = safe_work_path($qp, 1);
    return send_text($c, 400, '使えない名前です (英数字 _ - . のみ)') unless $fp;
    if ($method eq 'GET') {
      return send_text($c, 404, 'not found') unless -f $fp;
      return send_raw($c, 200, 'text/plain; charset=utf-8', read_file($fp));
    }
    if ($method eq 'PUT' || $method eq 'POST') { write_file($fp, $body); return send_json($c, { ok => JSON::PP::true }); }
    if ($method eq 'DELETE') { unlink $fp if -f $fp; return send_json($c, { ok => JSON::PP::true }); }
  }
  if ($path eq '/api/dir') {
    my $dp = safe_work_path($qp, 0);
    return send_text($c, 400, '使えない名前です (英数字 _ - . のみ)') unless $dp;
    if ($method eq 'POST' || $method eq 'PUT') { make_path($dp); return send_json($c, { ok => JSON::PP::true }); }
    if ($method eq 'DELETE') { to_trash($dp); return send_json($c, { ok => JSON::PP::true }); }
  }
  if ($path eq '/api/trash') {
    my $fp = safe_work_path($qp, 1);
    return send_text($c, 400, 'bad path') unless $fp;
    to_trash($fp) if -f $fp;
    return send_json($c, { ok => JSON::PP::true });
  }
  if ($path eq '/api/rename' && $method eq 'POST') {
    my $from = safe_work_path($q->{from}, 0);
    my $to = safe_work_path($q->{to}, 0);
    return send_text($c, 400, '名前を変更できません') if !$from || !$to || !-e $from || -e $to;
    make_path(dirname($to));
    move($from, $to) or return send_text($c, 400, '名前を変更できません');
    return send_json($c, { ok => JSON::PP::true });
  }
  if ($path eq '/api/open-folder') {
    my $dp = $work;
    if ($qp) { my $t = safe_work_path($qp, 0); $dp = $t if $t && -d $t; }
    if ($^O eq 'darwin') { system('open', $dp); } else { system('xdg-open', $dp); }
    return send_json($c, { ok => JSON::PP::true });
  }
  if ($path eq '/api/shutdown') {
    send_json($c, { ok => JSON::PP::true });
    kill 'TERM', $parent;
    return;
  }
  send_text($c, 404, 'not found');
}

sub handle_static {
  my ($c, $method, $path, $h) = @_;
  my $rel = $path;
  $rel =~ s{^/+}{};
  $rel = 'index.html' if $rel eq '';
  return send_text($c, 403, 'forbidden') if grep { $_ eq '..' } split m{/}, $rel;
  my $full = "$web/$rel";
  # 同じ接続の中で何度も読まれるファイル (ecj.jar など) は、メモリーに置いて使い回す
  our %CACHE;
  my $data_all = $CACHE{$full};
  if (!defined $data_all) {
    $full .= '/index.html' if -d $full;
    return send_text($c, 404, 'not found') unless -f $full;
    $data_all = read_file($full);
    return send_text($c, 404, 'not found') unless defined $data_all;
    $CACHE{"$web/$rel"} = $data_all;
  }
  my ($ext) = $full =~ /\.([^.\/]+)$/;
  my $type = $MIME{lc($ext // '')} || 'application/octet-stream';
  my $size = length($data_all);
  my ($start, $end, $status) = (0, $size - 1, 200);
  my $extra = "Accept-Ranges: bytes\r\nCache-Control: no-cache\r\n";
  if (($h->{range} // '') =~ /^bytes=(\d*)-(\d*)$/) {
    if ($1 ne '') { $start = $1; $end = $2 if $2 ne '' && $2 < $end; }
    elsif ($2 ne '') { $start = $size - $2; $start = 0 if $start < 0; }
    if ($start > $end || $start >= $size) {
      return send_raw($c, 416, 'text/plain', '', "Content-Range: bytes */$size\r\n");
    }
    $status = 206;
    $extra .= "Content-Range: bytes $start-$end/$size\r\n";
  }
  my $count = $end - $start + 1;
  my $data = ($method ne 'HEAD' && $count > 0) ? substr($data_all, $start, $count) : '';
  if ($method eq 'HEAD') {
    our $KEEP;
    print $c "HTTP/1.1 $status OK\r\nContent-Type: $type\r\nContent-Length: $count\r\n${extra}" . ($KEEP ? "Connection: keep-alive\r\n" : "Connection: close\r\n") . "\r\n";
    return;
  }
  send_raw($c, $status, $type, $data, $extra);
}
