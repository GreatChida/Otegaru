// お手軽Java - パッケージ・エクスプローラー (表示・削除・名前変更・リフレッシュ・インポート)
'use strict';

(() => {
  const { S, $, $$, ICON_SVG, baseName, binaries, dirs, editors, esc, expanded, files, isHidden, isJava, parentOf, problems, projectOf, ui } = IDE;
  const { closeEditor, command, contentOf, dialog, fileChanged, fileIcon, fileKind, icon, importDroppedFiles, isDirty, isWebProject, javaFilesOf,
    newMenuItems, openEditor, packagesOf, pickFromList, pkgOfDir, projectJre, projects, promptText, renderMarkers, renderTabs, requestBuild, saveAll,
    saveUi, showContextMenu, showError, srcRel, srcRoot, status, updateWelcome, validIdent, writeNew } = IDE.fn;

  // =================================================================
  // パッケージ・エクスプローラー
  // =================================================================
  // ノードの id: P: プロジェクト / S: ソース・フォルダー / K: パッケージ / F: ファイル / J: JRE / D: フォルダー
  function nodeIdFor(path) {
    if (!path.includes('/')) return 'P:' + path;
    const proj = projectOf(path);
    if (path === srcRoot(proj)) return 'S:' + path;
    if (files.has(path) || binaries.has(path)) return 'F:' + path;
    if (path.startsWith(srcRoot(proj) + '/')) return 'K:' + path;
    return 'D:' + path;
  }
  /** フォルダーの直下のフォルダー (隠しフォルダーを除く) */
  function childFolders(dir) {
    const set = new Set();
    for (const d of dirs) if (parentOf(d) === dir) set.add(d);
    for (const f of [...files.keys(), ...binaries]) {
      if (!f.startsWith(dir + '/')) continue;
      const rest = f.slice(dir.length + 1).split('/');
      if (rest.length > 1) set.add(dir + '/' + rest[0]);
    }
    return [...set].filter(d => !isHidden(d)).sort((a, b) => a.localeCompare(b));
  }
  /** フォルダーの直下のファイル (隠しファイルを除く) */
  function childFiles(dir) {
    return [...files.keys(), ...binaries].filter(f => parentOf(f) === dir && !isHidden(f)).sort((a, b) => a.localeCompare(b));
  }
  function problemCount(prefix) {
    let e = 0, w = 0;
    for (const list of problems.values()) for (const p of list) {
      if (p.path === prefix || p.path.startsWith(prefix + '/') || (prefix.startsWith('K:'))) { /* no */ }
    }
    return { e, w };
  }
  function severityUnder(test) {
    let sev = 0;
    for (const list of problems.values()) for (const p of list) if (test(p.path)) { if (p.kind === 'ERROR') return 2; if (p.kind === 'WARNING') sev = 1; }
    return sev;
  }
  function deco(sev) { return sev === 2 ? `<span class="deco">${ICON_SVG.decoError}</span>` : sev === 1 ? `<span class="deco">${ICON_SVG.decoWarning}</span>` : ''; }

  function renderExplorer() {
    const el = $('#explorer');
    const rows = [];
    const add = (id, depth, iconHtml, label, opts = {}) => {
      const tw = opts.leaf ? '' : (expanded.has(id) ? '⌄' : '›');
      rows.push(`<div class="tree-row${S.selected === id ? ' selected' : ''}" data-id="${esc(id)}" style="padding-left:${depth * 14 + 2}px"><span class="tree-twisty">${tw}</span><span class="tree-icon">${iconHtml}${opts.deco || ''}</span><span class="tree-label">${opts.dirty ? '<span class="dirty">&gt;</span>' : ''}${label}</span></div>`);
    };
    const ps = projects();
    if (!ps.length) {
      el.innerHTML = `<div class="tree-empty">ワークスペースにプロジェクトがありません。<br>
        <a data-cmd="newProject">Java プロジェクトの作成</a><br>
        <a data-cmd="newWebProject">動的 Web プロジェクトを作成します</a><br>
        <a data-cmd="lessonStart">教材 (第2章) を見ながら始める</a><br>
        <a data-cmd="lessonStartHtml">HTML入門 (第2章) を見ながら始める</a></div>`;
      $$('[data-cmd]', el).forEach(a => a.onclick = () => command(a.dataset.cmd));
      return;
    }
    for (const p of ps) {
      const pid = 'P:' + p;
      add(pid, 0, icon(isWebProject(p) ? 'webproject' : 'project'), esc(p), { deco: deco(severityUnder(x => projectOf(x) === p)) });
      if (!expanded.has(pid)) continue;
      const sroot = srcRoot(p);
      const sid = 'S:' + sroot;
      add(sid, 1, icon('srcfolder'), esc(sroot.slice(p.length + 1)), { deco: deco(severityUnder(x => x.startsWith(sroot + '/'))) });
      if (expanded.has(sid)) {
        const pkgs = packagesOf(p);
        const defFiles = javaFilesOf(p).filter(f => parentOf(f) === srcRoot(p));
        if (defFiles.length) {
          const did = 'K:' + srcRoot(p);
          add(did, 2, icon('package'), '(デフォルト・パッケージ)', { deco: deco(severityUnder(x => parentOf(x) === srcRoot(p))) });
          if (expanded.has(did)) for (const f of defFiles) addFile(f, 3);
        }
        for (const d of pkgs) {
          const kid = 'K:' + d;
          const fs = javaFilesOf(p).filter(f => parentOf(f) === d);
          add(kid, 2, fs.length ? icon('package') : icon('packageEmpty'), esc(pkgOfDir(d)), { leaf: !fs.length, deco: deco(severityUnder(x => parentOf(x) === d)) });
          if (expanded.has(kid)) for (const f of fs) addFile(f, 3);
        }
      }
      add('J:' + p, 1, icon('jre'), 'JRE システム・ライブラリー <span class="dim">[JavaSE-' + projectJre(p) + ']</span>', { leaf: true });
      // ソース・フォルダー以外のフォルダーとファイル (動的 Web プロジェクトの src/main/webapp など)
      addFolderContents(p, 1, sroot);
    }
    function addFolderContents(dir, depth, sroot) {
      // ソース・フォルダー (とその中) は、上の「src」「src/main/java」の行に出すので、ここでは出さない
      for (const d of childFolders(dir).filter(d => d !== sroot && !d.startsWith(sroot + '/'))) {
        const id = 'D:' + d;
        const leaf = !childFolders(d).some(x => x !== sroot) && !childFiles(d).length;
        add(id, depth, icon('folder'), esc(baseName(d)), { leaf });
        if (expanded.has(id)) addFolderContents(d, depth + 1, sroot);
      }
      for (const f of childFiles(dir)) addFile(f, depth);
    }
    function addFile(f, depth) {
      const ed = editors.find(e => e.path === f);
      const sev = severityUnder(x => x === f);
      add('F:' + f, depth, icon(fileIcon(f)), esc(baseName(f)), { leaf: true, deco: deco(sev), dirty: ed && isDirty(ed) });
    }
    el.innerHTML = rows.join('');
  }

  function initExplorerEvents() {
    const el = $('#explorer');
    el.addEventListener('mousedown', e => {
      const row = e.target.closest('.tree-row');
      if (!row) return;
      const id = row.dataset.id;
      S.selected = id;
      if (e.target.closest('.tree-twisty') && e.button === 0) toggleNode(id);
      else if (e.button === 0 && e.detail === 2) {
        // ダブルクリック: ファイルは開き、フォルダーなどは開閉する
        // (ここで描き直すと 2 回目のクリックが別の要素に当たり dblclick にならないので、mousedown の回数で見る)
        e.preventDefault();
        if (id.startsWith('F:')) openEditor(id.slice(2)); else toggleNode(id);
      } else {
        // 選択を変えるだけなら描き直さない
        $$('.tree-row.selected', el).forEach(r => r.classList.remove('selected'));
        row.classList.add('selected');
      }
      el.focus();
    });
    el.addEventListener('contextmenu', e => {
      e.preventDefault();
      const row = e.target.closest('.tree-row');
      if (row) { S.selected = row.dataset.id; renderExplorer(); }
      showContextMenu(explorerMenu(row ? row.dataset.id : null), e.clientX, e.clientY);
    });
    // パソコンのファイル (画像など) を、フォルダーの上にドロップしてコピーする
    const hasFiles = e => [...(e.dataTransfer && e.dataTransfer.types || [])].includes('Files');
    el.addEventListener('dragover', e => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      const row = e.target.closest('.tree-row');
      const target = dropTarget(row && row.dataset.id);
      e.dataTransfer.dropEffect = target ? 'copy' : 'none';
      $$('.tree-row.drop', el).forEach(r => r.classList.remove('drop'));
      if (row && target) row.classList.add('drop');
    });
    el.addEventListener('dragleave', e => { if (!el.contains(e.relatedTarget)) $$('.tree-row.drop', el).forEach(r => r.classList.remove('drop')); });
    el.addEventListener('drop', e => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      $$('.tree-row.drop', el).forEach(r => r.classList.remove('drop'));
      const row = e.target.closest('.tree-row');
      const target = dropTarget(row && row.dataset.id);
      if (!target) { status('ファイルは、フォルダーの上にドロップしてください'); return; }
      importDroppedFiles(target, [...e.dataTransfer.files]);
    });
    el.addEventListener('keydown', e => {
      const rows = $$('.tree-row', el);
      const idx = rows.findIndex(r => r.dataset.id === S.selected);
      if (e.key === 'ArrowDown' && idx < rows.length - 1) { S.selected = rows[idx + 1].dataset.id; renderExplorer(); e.preventDefault(); }
      else if (e.key === 'ArrowUp' && idx > 0) { S.selected = rows[idx - 1].dataset.id; renderExplorer(); e.preventDefault(); }
      else if (e.key === 'ArrowRight' && S.selected && !expanded.has(S.selected)) { toggleNode(S.selected); e.preventDefault(); }
      else if (e.key === 'ArrowLeft' && S.selected && expanded.has(S.selected)) { toggleNode(S.selected); e.preventDefault(); }
      else if (e.key === 'Enter' && S.selected) { if (S.selected.startsWith('F:')) openEditor(S.selected.slice(2)); else toggleNode(S.selected); }
      else if (e.key === 'Delete' && S.selected) { command('delete'); }
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && /^c$/i.test(e.key) && S.selected) { e.preventDefault(); copySelected(); }
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && /^v$/i.test(e.key) && S.selected) { e.preventDefault(); pasteSelected(); }
      else if (e.key === 'F2' && S.selected) { e.preventDefault(); command('rename'); }
    });
  }
  /** ドロップ先のフォルダー (ファイルの上ならそのフォルダー) */
  function dropTarget(id) {
    if (!id || id.startsWith('J:')) return null;
    const path = id.slice(2);
    return id.startsWith('F:') ? parentOf(path) : path;
  }
  function toggleNode(id) {
    if (expanded.has(id)) expanded.delete(id); else expanded.add(id);
    saveUi();
    renderExplorer();
  }
  function revealInExplorer(path) {
    const p = projectOf(path);
    expanded.add('P:' + p);
    const sroot = srcRoot(p);
    const isFile = files.has(path) || binaries.has(path);
    if (path === sroot || path.startsWith(sroot + '/')) {
      expanded.add('S:' + sroot);
      if (isFile) expanded.add('K:' + parentOf(path)); else expanded.add('K:' + path);
    } else {
      for (let d = isFile ? parentOf(path) : path; d && d !== p; d = parentOf(d)) expanded.add('D:' + d);
    }
    S.selected = nodeIdFor(path);
    renderExplorer();
    const row = $(`#explorer .tree-row[data-id="${CSS.escape(S.selected)}"]`);
    if (row) row.scrollIntoView({ block: 'nearest' });
  }
  /** 選択中のノードから、プロジェクト・パッケージ・ファイルを求める */
  function selectionContext() {
    let id = S.selected;
    if (!id && S.active) id = 'F:' + S.active.path;
    // folder は、新しいフォルダーやファイルを作る場所 (選んでいるフォルダー、ファイルならそのフォルダー)
    const c = { project: null, pkgDir: null, file: null, folder: null };
    if (!id) { c.project = projects()[0] || null; c.folder = c.project; return c; }
    const path = id.slice(2);
    c.project = projectOf(path);
    c.folder = id.startsWith('F:') ? parentOf(path) : id.startsWith('J:') ? c.project : path;
    if (id.startsWith('K:')) c.pkgDir = path;
    if (id.startsWith('F:')) { c.file = path; if (srcRel(path)) c.pkgDir = parentOf(path); }
    return c;
  }
  function explorerMenu(id) {
    const newSub = newMenuItems();
    if (!id) return [{ label: '新規', sub: newSub }];
    const path = id.slice(2);
    const items = [{ label: '新規', sub: newSub }];
    if (id.startsWith('F:')) {
      items.unshift({ label: '開く', cmd: 'openSelected', key: 'F3' });
      let runSub = [{ label: '(該当なし)', enabled: () => false }];
      if (isJava(path) && JavaSrc.hasMain(contentOf(path) || '')) runSub = [{ label: '1 Java アプリケーション', cmd: 'runSelected', key: 'Alt+Shift+X, J', icon: 'run' }];
      else if (fileKind(path) === 'html' && isWebProject(projectOf(path))) runSub = [{ label: '1 サーバーで実行', cmd: 'runOnServer', key: 'Alt+Shift+X, R', icon: 'run' }];
      items.push('-', { label: '実行', sub: runSub, icon: 'run' });
    }
    if (id.startsWith('J:')) return [{ label: '(JRE システム・ライブラリー)', enabled: () => false }];
    items.push('-');
    items.push({ label: 'コピー', cmd: 'copyResource', key: 'Ctrl+C', enabled: () => canCopy(id) });
    items.push({ label: '貼り付け', cmd: 'pasteResource', key: 'Ctrl+V', enabled: () => clipboard.length > 0 && !!dropTarget(id) });
    if (!id.startsWith('S:')) {
      items.push({ label: '削除', cmd: 'delete', key: 'Delete' });
      items.push({ label: '名前変更...', cmd: 'rename', key: 'F2' });
    }
    items.push('-', { label: 'リフレッシュ', cmd: 'refresh', key: 'F5' });
    if (Storage.mode === 'server') items.push({ label: '表示方法 → システム・エクスプローラー', cmd: 'openSelectedFolder' });
    return items;
  }

  // ---------- コピー・貼り付け (Eclipse と同じく、確認の画面を出さずにすぐコピーする) ----------
  let clipboard = [];   // コピーしたファイル・フォルダーのパス
  const canCopy = id => !!id && (id.startsWith('F:') || id.startsWith('D:'));
  function copySelected() {
    if (!canCopy(S.selected)) { status('コピーできるのは、ファイルとフォルダーです'); return; }
    clipboard = [S.selected.slice(2)];
    status(`'${baseName(clipboard[0])}' をコピーしました。貼り付け先のフォルダーを右クリックして「貼り付け」を選んでください`);
  }
  async function pasteSelected() {
    const dest = dropTarget(S.selected);
    if (!clipboard.length || !dest) return;
    let last = null;
    for (const src of clipboard) {
      const isDir = dirs.has(src) && !files.has(src) && !binaries.has(src);
      if (!isDir && !files.has(src) && !binaries.has(src)) { showError('貼り付けできません', `'${baseName(src)}' は、もうありません。`); continue; }
      if (isDir && (dest === src || dest.startsWith(src + '/'))) { showError('貼り付けできません', 'フォルダーを、そのフォルダー自身の中には貼り付けできません。'); continue; }
      let name = baseName(src);
      // 同じ名前があるときは、新しい名前を聞く (Eclipse の「名前の衝突」)
      if (exists(dest + '/' + name)) {
        name = await askNewName(name, dest);
        if (!name) continue;
      }
      try { last = await copyResource(src, dest + '/' + name); } catch (e) { showError('貼り付けできません', e.message); }
    }
    if (last) { revealInExplorer(last); status(`'${baseName(last)}' を貼り付けました`); }
  }
  const exists = p => files.has(p) || binaries.has(p) || dirs.has(p);
  async function askNewName(name, dest) {
    const m = name.match(/^(.*?)(\.[^.]*)?$/);
    let n = 1, suggestion;
    do { suggestion = `${m[1]}_copy${n > 1 ? n : ''}${m[2] || ''}`; n++; } while (exists(dest + '/' + suggestion));
    const r = await dialog({
      title: '名前の衝突', width: 440,
      html: `<div style="margin-bottom:8px">'${esc(name)}' の新しい名前を入力してください:</div>
        <input type="text" id="nc-name" value="${esc(suggestion)}" spellcheck="false" style="width:100%;box-sizing:border-box"><div id="nc-msg" class="hint" style="min-height:18px;margin-top:4px"></div>`,
      buttons: [{ label: 'OK', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({ name: $('#nc-name', d).value.trim() }),
      onOpen: d => {
        const check = () => {
          const v = $('#nc-name', d).value.trim();
          const msg = !v ? '名前を入力してください。' : !/^[A-Za-z0-9_\-.]+$/.test(v) ? 'お手軽Java では、名前に半角の英数字と _ - . だけが使えます。' : exists(dest + '/' + v) ? '同じ名前のリソースがすでに存在します。' : '';
          $('#nc-msg', d).textContent = msg;
          $('[data-b="0"]', d).disabled = !!msg;
        };
        $('#nc-name', d).addEventListener('input', check);
        check();
      },
    });
    return r && r.value === 'ok' ? r.name : null;
  }
  /** ファイル・フォルダーを、中身ごとコピーする。コピー先のパスを返す */
  async function copyResource(src, to) {
    if (files.has(src)) {
      let text = files.get(src);
      // Java のソースを別のパッケージに貼り付けたときは、Eclipse と同じく package 宣言を直す
      if (isJava(to) && srcRel(to) && srcRel(src)) {
        const pkg = pkgOfDir(parentOf(to));
        text = /^\s*package\s+[\w.]+\s*;/m.test(text)
          ? text.replace(/^(\s*package\s+)[\w.]+(\s*;)/m, pkg ? '$1' + pkg + '$2' : '').replace(/^\n+/, '')
          : (pkg ? `package ${pkg};\n\n` + text : text);
      }
      await writeNew(to, text);
      fileChanged(to);
    } else if (binaries.has(src)) {
      const blob = await (await fetch(Storage.rawUrl(src), { cache: 'no-store' })).blob();
      await Storage.writeBinary(to, blob);
      binaries.add(to);
      for (let x = parentOf(to); x; x = parentOf(x)) dirs.add(x);
      fileChanged(to);
    } else {
      await Storage.mkdir(to);
      for (let x = to; x; x = parentOf(x)) dirs.add(x);
      const children = [...dirs].filter(d => parentOf(d) === src).concat([...files.keys(), ...binaries].filter(f => parentOf(f) === src));
      for (const c of children) await copyResource(c, to + '/' + baseName(c));
    }
    return to;
  }

  // ---------- 削除・名前変更 ----------
  async function deleteSelected() {
    const id = S.selected;
    if (!id || id.startsWith('S:') || id.startsWith('J:')) return;
    const path = id.slice(2);
    if (id.startsWith('P:')) {
      const r = await dialog({
        title: 'リソースの削除', icon: 'warning',
        message: `プロジェクト '${path}' をワークスペースから削除してもよろしいですか?`,
        check: 'ディスク上からプロジェクト・コンテンツを削除 (元に戻せません)',
        buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取り消し', value: null }],
      });
      if (!r || r.value !== 'ok') return;
      for (const e of editors.filter(e => projectOf(e.path) === path)) { e.gen = e.cm.changeGeneration(true); await closeEditor(e); }
      if (r.checked) {
        try { await Storage.deleteDir(path); } catch (e) { showError('削除できません', e.message); return; }
        for (const f of [...files.keys()]) if (projectOf(f) === path) files.delete(f);
        for (const d of [...dirs]) if (d === path || d.startsWith(path + '/')) dirs.delete(d);
        if (Storage.mode === 'server') status(`'${path}' をごみ箱に移動しました`);
      } else {
        ui.hiddenProjects = [...new Set([...(ui.hiddenProjects || []), path])];
        saveUi();
        status(`'${path}' をワークスペースから外しました (ファイルは残っています。ファイル → インポート で戻せます)`);
      }
      problems.delete(path);
    } else if (id.startsWith('D:')) {
      const r = await dialog({ title: 'リソースの削除', icon: 'warning', message: `'${baseName(path)}' を削除してもよろしいですか?\n(フォルダーの中のファイルもすべて削除されます)` + (Storage.mode === 'server' ? '\n(ごみ箱に移動します)' : ''), buttons: [{ label: 'OK', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!r) return;
      try {
        for (const e of editors.filter(e => e.path.startsWith(path + '/'))) { e.gen = e.cm.changeGeneration(true); await closeEditor(e); }
        await Storage.deleteDir(path);
      } catch (e) { showError('削除できません', e.message); return; }
      for (const f of [...files.keys()]) if (f.startsWith(path + '/')) files.delete(f);
      for (const f of [...binaries]) if (f.startsWith(path + '/')) binaries.delete(f);
      for (const d of [...dirs]) if (d === path || d.startsWith(path + '/')) dirs.delete(d);
      fileChanged(path);
    } else {
      const isFile = id.startsWith('F:');
      const name = isFile ? baseName(path) : pkgOfDir(path);
      const r = await dialog({ title: 'リソースの削除', icon: 'warning', message: `'${name}' を削除してもよろしいですか?` + (Storage.mode === 'server' ? '\n(ファイルはごみ箱に移動します)' : ''), buttons: [{ label: 'OK', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!r) return;
      try {
        if (isFile) {
          const ed = editors.find(e => e.path === path);
          if (ed) { ed.gen = ed.cm.changeGeneration(true); await closeEditor(ed); }
          await Storage.deleteFile(path);
          files.delete(path);
          binaries.delete(path);
        } else {
          for (const e of editors.filter(e => e.path.startsWith(path + '/') && parentOf(e.path) === path)) { e.gen = e.cm.changeGeneration(true); await closeEditor(e); }
          // パッケージの削除は、そのフォルダーの .java だけ (子パッケージは残す)
          const own = [...files.keys()].filter(f => parentOf(f) === path);
          for (const f of own) { await Storage.deleteFile(f); files.delete(f); }
          const hasChild = [...dirs].some(d => d.startsWith(path + '/')) || [...files.keys()].some(f => f.startsWith(path + '/'));
          if (!hasChild) { await Storage.deleteDir(path); dirs.delete(path); }
        }
      } catch (e) { showError('削除できません', e.message); return; }
      fileChanged(path);
    }
    S.selected = null;
    renderExplorer(); renderMarkers(); updateWelcome();
  }

  async function renameSelected() {
    const id = S.selected || (S.active ? 'F:' + S.active.path : null);
    if (!id || id.startsWith('S:') || id.startsWith('J:')) return;
    const path = id.slice(2);
    if (id.startsWith('P:')) { await dialog({ title: '名前変更', message: 'お手軽Java では、プロジェクトの名前は変更できません。', icon: 'info' }); return; }
    if (id.startsWith('F:') && isJava(path)) {
      const old = baseName(path).replace(/\.java$/, '');
      const nn = await promptText('コンパイル単位の名前変更', '新しい名前(M):', old, v => !validIdent(v) ? `'${v}' は有効な Java 識別子ではありません。` : (files.has(parentOf(path) + '/' + v + '.java') && v !== old ? '型はすでに存在します。' : ''));
      if (!nn || nn === old) return;
      await saveAll();
      const to = parentOf(path) + '/' + nn + '.java';
      const re = new RegExp('(?<![\\w$])' + old + '(?![\\w$])', 'g');
      try {
        await Storage.rename(path, to);
        const content = (files.get(path) || '').replace(re, nn);
        files.delete(path);
        await Storage.writeFile(to, content); files.set(to, content);
        // 同じプロジェクトで、この型を使っているファイルの参照も直す
        const project = projectOf(path);
        const pkg = pkgOfDir(parentOf(path));
        for (const f of javaFilesOf(project)) {
          if (f === to) continue;
          const src = files.get(f);
          const samePkg = parentOf(f) === parentOf(path);
          const imports = new RegExp('import\\s+' + (pkg ? pkg.replace(/\./g, '\\.') + '\\.' : '') + old + '\\s*;').test(src);
          if ((samePkg || imports) && re.test(src)) { re.lastIndex = 0; const n = src.replace(re, nn); await Storage.writeFile(f, n); files.set(f, n); const e2 = editors.find(e => e.path === f); if (e2) { e2.cm.setValue(n); e2.gen = e2.cm.changeGeneration(true); } }
          re.lastIndex = 0;
        }
        const ed = editors.find(e => e.path === path);
        if (ed) { ed.path = to; ed.cm.setValue(content); ed.gen = ed.cm.changeGeneration(true); }
        fileChanged(to);
        S.selected = 'F:' + to;
        renderExplorer(); renderTabs();
      } catch (e) { showError('名前を変更できません', e.message); }
      return;
    }
    if (id.startsWith('F:') || id.startsWith('D:')) {
      await renameResource(path);
      return;
    }
    if (id.startsWith('K:')) {
      const oldPkg = pkgOfDir(path);
      const project = projectOf(path);
      const nn = await promptText('パッケージの名前変更', '新しい名前(M):', oldPkg, v => !v.split('.').every(validIdent) ? `'${v}' は有効な Java 識別子ではありません。` : '');
      if (!nn || nn === oldPkg) return;
      await saveAll();
      const toDir = srcRoot(project) + '/' + nn.replace(/\./g, '/');
      try {
        const own = [...files.keys()].filter(f => parentOf(f) === path);
        await Storage.mkdir(toDir);
        for (const f of own) {
          const to = toDir + '/' + baseName(f);
          const c = files.get(f).replace(new RegExp('^(\\s*package\\s+)' + oldPkg.replace(/\./g, '\\.') + '(\\s*;)', 'm'), '$1' + nn + '$2');
          await Storage.writeFile(to, c); files.set(to, c);
          await Storage.deleteFile(f); files.delete(f);
          const ed = editors.find(e => e.path === f);
          if (ed) { ed.path = to; ed.cm.setValue(c); ed.gen = ed.cm.changeGeneration(true); }
        }
        // import の書き換え
        for (const f of javaFilesOf(project)) {
          const s = files.get(f);
          const n = s.replace(new RegExp('(import\\s+)' + oldPkg.replace(/\./g, '\\.') + '\\.', 'g'), '$1' + nn + '.');
          if (n !== s) { await Storage.writeFile(f, n); files.set(f, n); const ed = editors.find(e => e.path === f); if (ed) { ed.cm.setValue(n); ed.gen = ed.cm.changeGeneration(true); } }
        }
        const hasChild = [...dirs].some(d => d.startsWith(path + '/'));
        if (!hasChild) { try { await Storage.deleteDir(path); } catch (e) { /* 無視 */ } dirs.delete(path); }
        let x = toDir; while (x) { dirs.add(x); x = parentOf(x); }
        fileChanged(toDir + '/x.java');
        S.selected = 'K:' + toDir; expanded.add(S.selected);
        renderExplorer(); renderTabs();
      } catch (e) { showError('名前を変更できません', e.message); }
    }
  }

  /** Java 以外のファイルやフォルダーの名前を変える (Eclipse の「リソースの名前変更」) */
  async function renameResource(path) {
    const old = baseName(path);
    const parent = parentOf(path);
    const exists = n => files.has(parent + '/' + n) || binaries.has(parent + '/' + n) || dirs.has(parent + '/' + n);
    const nn = await promptText('リソースの名前変更', '新しい名前(M):', old, v => !/^[A-Za-z0-9_\-.]+$/.test(v) ? 'お手軽Java では、名前に半角の英数字と _ - . だけが使えます。' : (v !== old && exists(v) ? '同じ名前のリソースがすでに存在します。' : ''));
    if (!nn || nn === old) return;
    await saveAll();
    const to = parent + '/' + nn;
    const mv = p => p === path ? to : (p.startsWith(path + '/') ? to + p.slice(path.length) : p);
    try { await Storage.rename(path, to); } catch (e) { showError('名前を変更できません', e.message); return; }
    for (const [k, v] of [...files]) if (mv(k) !== k) { files.delete(k); files.set(mv(k), v); }
    for (const k of [...binaries]) if (mv(k) !== k) { binaries.delete(k); binaries.add(mv(k)); }
    for (const d of [...dirs]) if (mv(d) !== d) { dirs.delete(d); dirs.add(mv(d)); }
    for (const e of editors) if (!e.custom) e.path = mv(e.path);
    fileChanged(to);
    S.selected = nodeIdFor(to);
    renderExplorer(); renderTabs(); saveUi();
  }

  async function importProject() {
    const hidden = ui.hiddenProjects || [];
    if (!hidden.length) { await dialog({ title: 'インポート', message: 'ワークスペースから外したプロジェクトはありません。\n(ワークスペースのフォルダーに置いたプロジェクトは、F5 リフレッシュで表示されます)', icon: 'info' }); return; }
    const sel = await pickFromList('インポート', 'ワークスペースに戻すプロジェクトを選択してください:', hidden);
    if (!sel) return;
    ui.hiddenProjects = hidden.filter(p => p !== sel);
    saveUi();
    renderExplorer(); requestBuild(sel);
  }

  async function refresh() {
    const w = await Storage.load();
    for (const [p, c] of Object.entries(w.files)) {
      const t = c.replace(/\r\n/g, '\n');
      if (files.get(p) !== t) {
        files.set(p, t);
        const ed = editors.find(e => e.path === p);
        if (ed && !isDirty(ed)) { const cur = ed.cm.getCursor(); ed.cm.setValue(t); ed.gen = ed.cm.changeGeneration(true); ed.cm.setCursor(cur); }
        fileChanged(p);
      }
    }
    for (const p of [...files.keys()]) if (!(p in w.files) && !editors.some(e => e.path === p && isDirty(e))) files.delete(p);
    dirs.clear(); for (const d of w.dirs) dirs.add(d);
    binaries.clear(); for (const b of w.binaries) binaries.add(b);
    renderExplorer();
    for (const p of projects()) requestBuild(p);
    status('リフレッシュしました');
  }

  Object.assign(IDE, { childFiles, childFolders, copySelected, pasteSelected, deco, deleteSelected, renameResource, explorerMenu, importProject, initExplorerEvents, nodeIdFor, problemCount, refresh, renameSelected, renderExplorer, revealInExplorer, selectionContext, severityUnder, toggleNode });
})();
