// Java ソースの簡易解析 (アウトライン・補完・コード生成で使う)
// 本物の構文解析ではなく、入門レベルのコードを想定した軽量な解析。
'use strict';

const JavaSrc = (() => {
  const MODIFIERS = ['public', 'protected', 'private', 'static', 'final', 'abstract', 'synchronized', 'native', 'transient', 'volatile', 'default', 'strictfp', 'sealed', 'non-sealed'];

  /** 文字列・文字・コメントを空白に置き換える (位置と改行は保つ) */
  function blank(src) {
    let out = '';
    let i = 0;
    const n = src.length;
    while (i < n) {
      const c = src[i], d = src[i + 1];
      if (c === '/' && d === '/') {
        while (i < n && src[i] !== '\n') { out += ' '; i++; }
      } else if (c === '/' && d === '*') {
        out += '  '; i += 2;
        while (i < n && !(src[i] === '*' && src[i + 1] === '/')) { out += src[i] === '\n' ? '\n' : ' '; i++; }
        if (i < n) { out += '  '; i += 2; }
      } else if (c === '"' && src.startsWith('"""', i)) {
        out += '   '; i += 3;
        while (i < n && !src.startsWith('"""', i)) { out += src[i] === '\n' ? '\n' : ' '; i++; }
        if (i < n) { out += '   '; i += 3; }
      } else if (c === '"' || c === "'") {
        const q = c; out += q; i++;
        while (i < n && src[i] !== q && src[i] !== '\n') {
          if (src[i] === '\\') { out += ' '; i++; }
          if (i < n) { out += ' '; i++; }
        }
        if (i < n && src[i] === q) { out += q; i++; }
      } else {
        out += c; i++;
      }
    }
    return out;
  }

  function lineOf(src, pos) {
    let line = 0;
    for (let i = 0; i < pos && i < src.length; i++) if (src.charCodeAt(i) === 10) line++;
    return line;
  }

  function splitTop(s, sep) {
    const parts = []; let depth = 0, cur = '';
    for (const ch of s) {
      if (ch === '<' || ch === '(' || ch === '[') depth++;
      else if (ch === '>' || ch === ')' || ch === ']') depth--;
      if (ch === sep && depth === 0) { parts.push(cur); cur = ''; } else cur += ch;
    }
    if (cur.trim()) parts.push(cur);
    return parts;
  }

  function parseParams(s) {
    s = s.trim();
    if (!s) return [];
    return splitTop(s, ',').map(p => {
      p = p.replace(/@\w+(\([^)]*\))?/g, '').replace(/\bfinal\s+/g, '').trim();
      const m = p.match(/^(.+?)\s+(\w+)$/);
      return m ? { type: m[1].replace(/\s+/g, ' ').trim(), name: m[2] } : { type: p, name: '' };
    });
  }

  function stripMods(h) {
    const mods = [];
    let s = h.replace(/@\w+(\.\w+)*(\s*\([^)]*\))?/g, ' ').trim();
    for (;;) {
      const m = s.match(/^([\w-]+)\s+/);
      if (m && MODIFIERS.includes(m[1])) { mods.push(m[1]); s = s.slice(m[0].length); } else break;
    }
    return { mods, rest: s };
  }

  /**
   * ファイルを解析する
   * @returns {pkg, imports:[{name,static,line}], types:[{kind,name,line,ext,impl,members:[...]}]}
   */
  function parse(src) {
    const b = blank(src);
    const res = { pkg: '', pkgLine: -1, imports: [], types: [] };
    const pm = b.match(/^\s*package\s+([\w.]+)\s*;/m);
    if (pm) { res.pkg = pm[1]; res.pkgLine = lineOf(b, pm.index + pm[0].indexOf('package')); }
    const ire = /^\s*import\s+(static\s+)?([\w.]+(?:\.\*)?)\s*;/gm;
    let m;
    while ((m = ire.exec(b))) res.imports.push({ name: m[2], static: !!m[1], line: lineOf(b, m.index + m[0].indexOf('import')), from: m.index, to: m.index + m[0].length });

    // 型宣言と、その直下のメンバーを集める
    const stack = []; // {type, depth}
    let depth = 0, segStart = 0;
    const typeRe = /(?:^|[\s;{}])((?:(?:public|protected|private|static|final|abstract|sealed|non-sealed|strictfp)\s+)*)(class|interface|enum|record)\s+(\w+)([^{]*)$/;
    for (let i = 0; i < b.length; i++) {
      const ch = b[i];
      if (ch === '{') {
        const head = b.slice(segStart, i);
        const cur = stack.length ? stack[stack.length - 1] : null;
        const tm = head.match(typeRe);
        if (tm && (!cur || depth === cur.depth + 1 || depth === cur.depth)) {
          const rest = tm[4] || '';
          const ext = (rest.match(/\bextends\s+([\w.<>,\s]+?)(?=\bimplements\b|$)/) || [])[1];
          const impl = (rest.match(/\bimplements\s+([\w.<>,\s]+)/) || [])[1];
          const off = segStart + head.lastIndexOf(tm[3]);
          const t = { kind: tm[2], name: tm[3], mods: (tm[1] || '').trim().split(/\s+/).filter(Boolean), line: lineOf(b, off), from: off, ext: ext ? ext.trim() : '', impl: impl ? splitTop(impl, ',').map(x => x.trim()) : [], members: [], open: i, close: -1, parent: cur ? cur.type : null };
          if (tm[2] === 'record') {
            const rp = rest.match(/^\s*\(([^)]*)\)/);
            if (rp) for (const p of parseParams(rp[1])) t.members.push({ kind: 'field', name: p.name, type: p.type, mods: ['private', 'final'], line: t.line });
          }
          if (cur) cur.type.members.push({ kind: 'type', name: t.name, type: t, mods: t.mods, line: t.line });
          else res.types.push(t);
          stack.push({ type: t, depth: depth + 1 });
        } else if (cur && depth === cur.depth) {
          const h = head.trim();
          const mem = parseMemberHead(h, cur.type, segStart + head.indexOf(h), b);
          if (mem) cur.type.members.push(mem);
        }
        depth++;
        segStart = i + 1;
      } else if (ch === '}') {
        depth--;
        const cur = stack.length ? stack[stack.length - 1] : null;
        if (cur && depth === cur.depth - 1) { cur.type.close = i; stack.pop(); }
        segStart = i + 1;
      } else if (ch === ';') {
        const cur = stack.length ? stack[stack.length - 1] : null;
        if (cur && depth === cur.depth) {
          const head = b.slice(segStart, i);
          const h = head.trim();
          if (cur.type.kind === 'enum' && !cur.type._constantsDone) {
            cur.type._constantsDone = true;
            for (const c of splitTop(h.replace(/\([^)]*\)/g, ''), ',')) {
              const nm = c.trim();
              if (/^\w+$/.test(nm)) cur.type.members.push({ kind: 'enumConst', name: nm, type: cur.type.name, mods: ['public', 'static', 'final'], line: lineOf(b, segStart + head.indexOf(nm)) });
            }
          } else {
            const mems = parseFieldOrAbstract(h, cur.type, segStart + head.indexOf(h), b);
            for (const mm of mems) cur.type.members.push(mm);
          }
        }
        segStart = i + 1;
      } else if (ch === '(' ) {
        // 括弧の中の ; { } は区切りとみなさない (for 文など) — メンバー階層だけ見ているので対応不要
      }
    }
    return res;
  }

  function parseMemberHead(h, type, off, b) {
    if (!h) return { kind: 'init', name: '{...}', mods: [], line: lineOf(b, off) };
    if (/^static$/.test(h)) return { kind: 'init', name: 'static {...}', mods: ['static'], line: lineOf(b, off) };
    const { mods, rest } = stripMods(h);
    // メソッドまたはコンストラクター
    let m = rest.match(/^(?:<[^>]*>\s*)?([\w.<>\[\],?\s]+?)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w.,\s]+)?$/);
    if (m) return { kind: 'method', name: m[2], ret: m[1].replace(/\s+/g, ' ').trim(), params: parseParams(m[3]), mods, line: lineOf(b, off + h.indexOf(m[2] + '(') >= 0 ? off + h.lastIndexOf(m[2]) : off) };
    m = rest.match(/^(?:<[^>]*>\s*)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w.,\s]+)?$/);
    if (m && m[1] === type.name) return { kind: 'ctor', name: m[1], params: parseParams(m[2]), mods, line: lineOf(b, off + h.lastIndexOf(m[1])) };
    if (m && type.kind === 'record' && m[1] === type.name) return { kind: 'ctor', name: m[1], params: [], mods, line: lineOf(b, off) };
    // 配列初期化子つきのフィールド (int[] a = {1,2};) は ; 側で処理される
    return null;
  }

  function parseFieldOrAbstract(h, type, off, b) {
    if (!h) return [];
    const { mods, rest } = stripMods(h);
    // 抽象メソッド / インターフェースのメソッド
    let m = rest.match(/^(?:<[^>]*>\s*)?([\w.<>\[\],?\s]+?)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w.,\s]+)?$/);
    if (m) return [{ kind: 'method', name: m[2], ret: m[1].replace(/\s+/g, ' ').trim(), params: parseParams(m[3]), mods: type.kind === 'interface' && !mods.includes('private') && !mods.includes('static') ? mods.concat(['abstract']) : mods, line: lineOf(b, off + h.lastIndexOf(m[2])) }];
    // フィールド (複数宣言にも対応)
    const eq = rest.search(/=/);
    const declPart = eq >= 0 ? rest.slice(0, eq) : rest;
    m = declPart.match(/^([\w.<>\[\],?\s]+?)\s+(\w+)\s*(\[\])?\s*$/);
    if (!m) return [];
    const type0 = m[1].replace(/\s+/g, ' ').trim();
    if (['return', 'throw', 'new', 'package', 'import'].includes(type0)) return [];
    const out = [{ kind: 'field', name: m[2], type: type0 + (m[3] || ''), mods, line: lineOf(b, off + h.indexOf(m[2])) }];
    if (eq < 0) {
      // int a, b;
      const extra = rest.slice(rest.indexOf(m[2]) + m[2].length).split(',').slice(1);
      for (const e of extra) { const nm = e.trim().match(/^(\w+)/); if (nm) out.push({ kind: 'field', name: nm[1], type: type0, mods, line: out[0].line }); }
    }
    if (type.kind === 'interface') for (const f of out) for (const x of ['public', 'static', 'final']) if (!f.mods.includes(x)) f.mods.push(x);
    return out;
  }

  /** 文字位置 pos を含む最も内側の型を返す */
  function typeAt(parsed, pos) {
    let best = null;
    const walk = (types) => {
      for (const t of types) {
        if (t.open <= pos && (t.close < 0 || pos <= t.close)) {
          best = t;
          walk(t.members.filter(m => m.kind === 'type').map(m => m.type));
        }
      }
    };
    walk(parsed.types);
    return best;
  }

  /** ローカル変数・パラメーター・フィールドの型を、カーソルより前の宣言から推定する */
  function varType(src, pos, name, parsed) {
    const b = blank(src).slice(0, pos);
    const esc = name.replace(/[$]/g, '\\$');
    const re = new RegExp('(?:^|[\\s(,;{])((?:final\\s+)?([A-Za-z_][\\w.]*(?:\\s*<[^;(){}=]*?>)?(?:\\s*\\[\\s*\\])*))\\s+' + esc + '\\s*(?=[=;,):\\[]|$)', 'g');
    let m, last = null;
    while ((m = re.exec(b))) {
      const t = m[2].replace(/\s+/g, '');
      if (['return', 'new', 'throw', 'else', 'case', 'instanceof', 'package', 'import', 'class', 'extends', 'implements'].includes(t)) continue;
      last = t;
    }
    if (last === 'var') {
      // var x = new Foo(...)
      const vm = new RegExp('\\bvar\\s+' + esc + '\\s*=\\s*new\\s+([\\w.]+)').exec(b);
      if (vm) return vm[1];
      return null;
    }
    if (last) return last;
    if (parsed) {
      const t = typeAt(parsed, pos);
      if (t) {
        for (let cur = t; cur; cur = cur.parent) {
          const f = cur.members.find(x => x.kind === 'field' && x.name === name);
          if (f) return f.type;
        }
      }
    }
    return null;
  }

  function simpleName(type) {
    if (!type) return '';
    return type.replace(/<.*>/, '').replace(/\[\]/g, '').split('.').pop().trim();
  }
  function typeArgs(type) {
    const m = (type || '').match(/<(.*)>/);
    return m ? splitTop(m[1], ',').map(s => s.trim()) : [];
  }

  /** メソッドの署名を Eclipse 風に: name(String, int) : void */
  function signature(m) {
    if (m.kind === 'method') return m.name + '(' + m.params.map(p => p.type).join(', ') + ') : ' + m.ret;
    if (m.kind === 'ctor') return m.name + '(' + m.params.map(p => p.type).join(', ') + ')';
    if (m.kind === 'field' || m.kind === 'enumConst') return m.name + ' : ' + m.type;
    return m.name;
  }

  function hasMain(src) {
    return /\bpublic\s+static\s+void\s+main\s*\(\s*(final\s+)?String\s*(\[\s*\]\s*\w+|\.\.\.\s*\w+|\w+\s*\[\s*\])\s*\)/.test(blank(src))
      || /\bstatic\s+public\s+void\s+main\s*\(/.test(blank(src));
  }

  return { blank, parse, lineOf, typeAt, varType, simpleName, typeArgs, signature, hasMain, parseParams, splitTop };
})();
