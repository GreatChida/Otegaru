// ワークスペースの保存層
//  - start.bat から起動したとき: ローカルサーバの /api を使い、ワークスペース (ドキュメントの workspace) に本物のファイルとして保存
//  - それ以外 (静的ホスティングなど): ブラウザの localStorage に保存
'use strict';

const Storage = (() => {
  const LS_KEY = 'otekaru.workspace.v1';
  let mode = 'local';
  let rootPath = '';

  async function api(method, url, body) {
    const headers = body != null && !(body instanceof Blob) ? { 'Content-Type': 'text/plain; charset=utf-8' } : {};
    const res = await fetch(url, { method, body, headers });
    if (!res.ok) throw new Error(await res.text() || res.statusText);
    return res;
  }

  function lsLoad() {
    try {
      const v = JSON.parse(localStorage.getItem(LS_KEY));
      if (v && v.files) return v;
    } catch (e) { /* 壊れていたら空から */ }
    return { dirs: [], files: {} };
  }
  function lsSave(ws) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(ws)); } catch (e) { console.warn(e); }
  }

  return {
    get mode() { return mode; },
    get rootPath() { return rootPath; },

    /** ワークスペースの状態 (選んだか、候補の場所など)。ローカル・サーバーが無いときは null */
    async workspaceInfo() {
      try {
        const res = await fetch('/api/workspace', { cache: 'no-store' });
        return res.ok ? await res.json() : null;
      } catch (e) { return null; }
    },
    /** ワークスペースを決める。copyLegacy なら、展開したフォルダーの work のプロジェクトをコピーする */
    async selectWorkspace(path, copyLegacy) {
      return (await api('POST', '/api/workspace/select', JSON.stringify({ path, copyLegacy: !!copyLegacy }))).json();
    },

    /** { dirs: [path], files: {path: content}, binaries: [path] } を返す (binaries は画像などの中身を読まないファイル) */
    async load() {
      try {
        const res = await fetch('/api/tree', { cache: 'no-store' });
        if (res.ok) {
          const t = await res.json();
          mode = 'server';
          rootPath = t.root || '';
          const files = {}, binaries = [];
          for (const f of (t.files || [])) { if (f.binary) binaries.push(f.path); else files[f.path] = f.content; }
          return { dirs: t.dirs || [], files, binaries };
        }
      } catch (e) { /* サーバなし */ }
      mode = 'local';
      return Object.assign({ binaries: [] }, lsLoad());
    },

    /** 画像などをそのまま書く (ワークスペースがフォルダーのときだけ) */
    async writeBinary(path, blob) {
      if (mode !== 'server') throw new Error('ブラウザ保存モードでは、画像などのファイルは使えません (start.bat または start.command から起動してください)');
      return api('PUT', '/api/file?path=' + encodeURIComponent(path), blob);
    },
    /** ワークスペースのファイルを開く URL */
    rawUrl(path) { return '/api/raw?path=' + encodeURIComponent(path); },
    /** パソコンで関連付けされたアプリ (画像ならフォト・プレビューなど) で開く */
    async openFile(path) {
      if (mode !== 'server') throw new Error('ブラウザ保存モードでは、ファイルをアプリで開けません');
      return api('POST', '/api/open-file?path=' + encodeURIComponent(path), '');
    },

    // ---- Tomcat の代わりの Web サーバー (HTML入門用) ----
    async webState() {
      if (mode !== 'server') return null;
      return (await api('GET', '/api/web')).json();
    },
    /** 開始する。modules は [{context, dir}] (dir はワークスペースからの Web コンテンツのパス) */
    async webStart(port, modules) {
      return (await api('POST', '/api/web/start?port=' + encodeURIComponent(port), JSON.stringify({ modules }))).json();
    },
    async webStop() { return (await api('POST', '/api/web/stop', '')).json(); },
    async webModules(modules) { return (await api('POST', '/api/web/modules', JSON.stringify({ modules }))).json(); },

    async writeFile(path, content) {
      if (mode === 'server') return api('PUT', '/api/file?path=' + encodeURIComponent(path), content);
      const ws = lsLoad(); ws.files[path] = content; lsSave(ws);
    },
    async deleteFile(path) {
      if (mode === 'server') return api('POST', '/api/trash?path=' + encodeURIComponent(path));
      const ws = lsLoad(); delete ws.files[path]; lsSave(ws);
    },
    async mkdir(path) {
      if (mode === 'server') return api('POST', '/api/dir?path=' + encodeURIComponent(path));
      const ws = lsLoad(); if (!ws.dirs.includes(path)) ws.dirs.push(path); lsSave(ws);
    },
    async deleteDir(path) {
      if (mode === 'server') return api('DELETE', '/api/dir?path=' + encodeURIComponent(path));
      const ws = lsLoad();
      ws.dirs = ws.dirs.filter(d => d !== path && !d.startsWith(path + '/'));
      for (const f of Object.keys(ws.files)) if (f.startsWith(path + '/')) delete ws.files[f];
      lsSave(ws);
    },
    async rename(from, to) {
      if (mode === 'server') return api('POST', '/api/rename?from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to));
      const ws = lsLoad();
      const mv = p => p === from ? to : (p.startsWith(from + '/') ? to + p.slice(from.length) : p);
      ws.dirs = ws.dirs.map(mv);
      const nf = {};
      for (const [k, v] of Object.entries(ws.files)) nf[mv(k)] = v;
      ws.files = nf;
      lsSave(ws);
    },
    async openFolder(path) {
      if (mode === 'server') return api('POST', '/api/open-folder?path=' + encodeURIComponent(path || ''));
      throw new Error('ブラウザ保存モードではフォルダを開けません');
    },
    async shutdown() {
      if (mode === 'server') { try { await api('POST', '/api/shutdown'); } catch (e) { /* 終了済み */ } }
    },
  };
})();
