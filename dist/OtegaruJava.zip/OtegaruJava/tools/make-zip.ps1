﻿# 配布用の zip (dist\OtegaruJava.zip) を作る
#   使い方: powershell -ExecutionPolicy Bypass -File tools\make-zip.ps1
#   - 利用者向けの説明 docs\README-dist.md から README.txt (プレーンテキスト) を作り、zip に入れる
#   - 隣に公開用リポジトリ (..\Otegaru) があれば、README.md・README.txt・zip をそこへコピーする
#     (コミットとプッシュはしない。公開するかどうかは手で決める)
param(
  [string]$PublishRepo = (Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'Otegaru')
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$dist = Join-Path $Root 'dist'
$zipPath = Join-Path $dist 'OtegaruJava.zip'
$readmeMd = Join-Path $Root 'docs\README-dist.md'
$readmeTxt = Join-Path $dist 'README.txt'
$top = 'OtegaruJava'
New-Item -ItemType Directory -Force $dist | Out-Null
if (Test-Path $zipPath) {
  try { Remove-Item $zipPath } catch {
    throw "dist\OtegaruJava.zip を別のプログラムが使っています。エクスプローラーのプレビューや、zip を開いているウィンドウを閉じてから、もう一度実行してください。"
  }
}

# 1. 利用者向けの説明をプレーンテキストにする
& (Join-Path $PSScriptRoot 'md2txt.ps1') -In $readmeMd -Out $readmeTxt
Write-Host "作成しました: $readmeTxt"

# 2. zip を作る (README.txt は zip の一番上に入れる)
$items = @('start.bat', 'start.command', 'tools', 'www')
# Mac で動かすファイル: 改行を LF にし、実行できる印 (Unix の実行権限) を付ける
$lfOnly = '\.(command|pl|sh)$'
$executable = @("$top/start.command", "$top/tools/server.pl")
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, 'Create')
try {
  $base = (Resolve-Path $Root).Path.TrimEnd('\') + '\'
  [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $readmeTxt, "$top/README.txt", 'Optimal')
  foreach ($it in $items) {
    $p = Join-Path $Root $it
    $files = if (Test-Path $p -PathType Container) { Get-ChildItem -Path $p -Recurse -File } else { Get-Item $p }
    foreach ($f in $files) {
      $name = $top + '/' + $f.FullName.Substring($base.Length).Replace('\', '/')
      if ($name -match $lfOnly) {
        # Git の設定で CRLF になっていても、Mac で動くように LF にして入れる
        $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8).Replace("`r`n", "`n")
        $entry = $zip.CreateEntry($name, 'Optimal')
        $w = New-Object System.IO.StreamWriter($entry.Open(), (New-Object System.Text.UTF8Encoding($false)))
        try { $w.Write($text) } finally { $w.Dispose() }
      } else {
        [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $name, 'Optimal')
      }
    }
  }
  # 空の work フォルダー (書いたプログラムの保存場所)
  [void]$zip.CreateEntry($top + '/work/')
} finally { $zip.Dispose() }

# Windows PowerShell 5.1 の zip 機能では Unix の権限を付けられないので、
# zip の中央ディレクトリを直接書き換える (作成した OS を Unix にし、権限を設定する)
function Set-ZipUnixModes([string]$path, [string[]]$execNames) {
  $b = [System.IO.File]::ReadAllBytes($path)
  $eocd = -1
  for ($i = $b.Length - 22; $i -ge [Math]::Max(0, $b.Length - 65557); $i--) {
    if ($b[$i] -eq 0x50 -and $b[$i + 1] -eq 0x4b -and $b[$i + 2] -eq 0x05 -and $b[$i + 3] -eq 0x06) { $eocd = $i; break }
  }
  if ($eocd -lt 0) { throw 'zip の終端が見つかりません' }
  $count = [BitConverter]::ToUInt16($b, $eocd + 10)
  $pos = [BitConverter]::ToUInt32($b, $eocd + 16)
  for ($n = 0; $n -lt $count; $n++) {
    if ([BitConverter]::ToUInt32($b, $pos) -ne 0x02014b50) { throw '中央ディレクトリが壊れています' }
    $nameLen = [BitConverter]::ToUInt16($b, $pos + 28)
    $extraLen = [BitConverter]::ToUInt16($b, $pos + 30)
    $commentLen = [BitConverter]::ToUInt16($b, $pos + 32)
    $name = [System.Text.Encoding]::UTF8.GetString($b, $pos + 46, $nameLen)
    if ($name.EndsWith('/')) { $mode = 0x41ED; $dosAttr = 0x10 }          # drwxr-xr-x
    elseif ($execNames -contains $name) { $mode = 0x81ED; $dosAttr = 0 }  # -rwxr-xr-x
    else { $mode = 0x81A4; $dosAttr = 0 }                                  # -rw-r--r--
    $b[$pos + 5] = 3   # 作成した OS = Unix
    $attr = [BitConverter]::GetBytes([uint32]([int64]$mode * 65536 + $dosAttr))
    [Array]::Copy($attr, 0, $b, $pos + 38, 4)
    $pos += 46 + $nameLen + $extraLen + $commentLen
  }
  [System.IO.File]::WriteAllBytes($path, $b)
}
Set-ZipUnixModes $zipPath $executable
Write-Host "作成しました: $zipPath ($([math]::Round((Get-Item $zipPath).Length / 1MB, 1)) MB)"

# 3. 公開用リポジトリへコピーする
if ($PublishRepo -and (Test-Path (Join-Path $PublishRepo '.git'))) {
  New-Item -ItemType Directory -Force (Join-Path $PublishRepo 'dist') | Out-Null
  Copy-Item $readmeMd (Join-Path $PublishRepo 'README.md') -Force
  Copy-Item $readmeTxt (Join-Path $PublishRepo 'README.txt') -Force
  Copy-Item $zipPath (Join-Path $PublishRepo 'dist\OtegaruJava.zip') -Force
  Write-Host "公開用リポジトリにコピーしました: $PublishRepo (README.md, README.txt, dist\OtegaruJava.zip)"
} else {
  Write-Host "公開用リポジトリが見つからないので、コピーはしませんでした: $PublishRepo"
}
