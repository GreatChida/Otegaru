﻿お手軽Java (テスト版)
=====================

インストール不要の、Eclipse (Pleiades) 風 Java 独習環境です。
zip を展開して start.bat (Mac は start.command) をダブルクリックするだけで、ブラウザに IDE が開きます。
JDK も Eclipse も、管理者権限も要りません。

教材には Qiita の「【Java入門】目次 ( https://qiita.com/chida0818/items/1f0f457d575d4a675c16 )」「【HTML入門】目次 ( https://qiita.com/chida0818/items/4efc23bf7222b2377b2d )」「【DB入門】目次 ( https://qiita.com/chida0818/items/d1fbd989a20e8eed1cbc )」シリーズを使います。
右側の「レッスン」に教材の本文が表示され、教材のコードをエディターに反映したり、実行結果を教材と比べたりできます。

※ テスト版です。 動作の確認中のため、内容は予告なく変わることがあります。

【ダウンロード】

dist/OtegaruJava.zip ( https://github.com/GreatChida/Otegaru/raw/main/dist/OtegaruJava.zip ) をダウンロードしてください (約 6.3MB)。Windows と Mac で同じ zip を使います。
これまでの版は Releases ( https://github.com/GreatChida/Otegaru/releases ) にあります。
zip の中にも、この説明と同じ内容の README.txt が入っています。

【動作環境】

・Windows 11、または macOS
・Google Chrome (最新版)。ほかのブラウザは対象外です
・インターネット接続 (Java の実行環境 CheerpJ と、Qiita の教材を読み込むため)

起動には、Windows は最初から入っている PowerShell を、Mac は最初から入っている Perl を使います。別にインストールするものはありません。
Chrome が既定のブラウザでない場合は、起動したあと、黒いウィンドウ (Mac はターミナル) に表示されるアドレスを Chrome で開いてください。

【使い方 (Windows)】

1. ダウンロードした zip を右クリックして プロパティ を開き、下の「セキュリティ」の 許可する にチェックを入れて OK を押します。
   (インターネットから取得したファイルのため、これをしないと起動時に警告が出ることがあります)
2. zip を好きな場所に展開します (例: デスクトップ)。深いフォルダーの中は避けてください。
3. 展開した OtegaruJava フォルダーの start.bat をダブルクリックします。黒いウィンドウが開き、ブラウザにお手軽Java が表示されます。
4. 初回は Java の準備に 30 秒〜1 分ほどかかります (画面右下に進み具合が出ます)。「JavaSE-17」と表示されたら使えます。
5. 右の「レッスン」で第2章を開き、教材のとおりに進めてください。
6. 終わるときは、メニューの ファイル → 終了 を選ぶか、黒いウィンドウを閉じます。

【使い方 (Mac)】

1. ダウンロードした zip をダブルクリックします。OtegaruJava フォルダーができます。好きな場所 (例: 書類) に移してください。
2. OtegaruJava フォルダーの start.command をダブルクリックします。
3. 最初の 1 回だけ、「"start.command" は開いていません」などと表示されて起動できません。このときは 完了 をクリックして閉じます (ゴミ箱に入れる は押さないでください)。
4. Apple メニュー → システム設定… → プライバシーとセキュリティ を開き、「セキュリティ」の欄の「"start.command" がブロックされました」の右にある このまま開く をクリックします。確認の画面でも このまま開く をクリックし、パスワードを入力します。
5. ターミナルのウィンドウが開き、ブラウザにお手軽Java が表示されます。初回は Java の準備に 30 秒〜1 分ほどかかります。「JavaSE-17」と表示されたら使えます。
6. 終わるときは、メニューの ファイル → 終了 を選ぶか、ターミナルのウィンドウを閉じます。

2 回目からは、start.command をダブルクリックするだけで起動します。
ショートカットは Mac の Eclipse と同じく、Ctrl の代わりに ⌘ を使います (保存は ⌘S、実行は ⌘F11)。補完だけは Control + Space です。
macOS の初期設定では Control + Space が入力ソースの切り替えに使われているので、システム設定の キーボード → キーボードショートカット… → 入力ソース で「前の入力ソースを選択」のチェックを外してください。

書いたプログラムは、ワークスペース (ドキュメント (Mac は書類) の workspace フォルダー) に、Eclipse と同じ形 (workspace/java/src/ch03/Basic.java など) で保存されます。
.project と .classpath も作るので、後で本物の Eclipse にインポートすることもできます。

・最初の起動のとき、workspace フォルダーがすでにあれば、そのまま使うか、workspace2 などの新しいフォルダーにするかを選べます。
・選んだ場所は、展開したフォルダーの workspace.json に記録されます。新しい版の zip を展開し直したときは、最初の起動でもう一度聞かれます (前のワークスペースをそのまま使えます)。
・場所を選び直すときは、お手軽Java を終了してから workspace.json を削除し、もう一度起動します。
・以前の版 (展開したフォルダーの中の work フォルダーに保存していた版) のプロジェクトは、最初の起動のときにワークスペースへコピーできます。

【レッスンの表示】

レッスンに表示する本文は、レッスン・ビューの上の切り替えで選べます。

・Qiita の最新 (既定): Qiita から最新の記事を読み込み、Qiita と同じ見た目で表示します。章の一覧も目次記事から作るので、新しく追加された章も表示されます。読み込んだ本文は 30 分間ブラウザに保存し、その間は読み込み直しません (Qiita の取得回数の上限は 1 時間に 60 回です)。読み込めないときは、前回読み込んだ本文か内蔵の本文を表示します。
・内蔵の教材: zip に入っている本文を表示します。

上部の「戻る」で、レッスン内で移動する前の位置に戻れます。「<<」「>>」で前後の章へ移動します。

【Eclipse と同じように使えるもの】

・ファイル → 新規 → Java プロジェクト / パッケージ / クラス / インターフェース
    → ○ (Eclipse と同じダイアログ)
・保存 (Ctrl+S) すると自動でコンパイル
    → ○ (Eclipse と同じコンパイラー ECJ を使用)
・行の左の赤い ×、波線、マーカー・ビュー、パッケージ・エクスプローラーの ×
    → ○ (エラー文は Pleiades と同じ日本語)
・実行 (Ctrl+F11)、実行 → Java アプリケーション
    → ○ (コンソールに <終了> 表示、エラー時の「続行」も同じ)
・補完 (Ctrl+Space)、sysout main for foreach if try などのテンプレート
    → ○
・フォーマット (Ctrl+Shift+F)、コメントの切り替え (Ctrl+/)、インポートの編成 (Ctrl+Shift+O)
    → ○
・ソース → getter および setter の生成 / toString() の生成 / コンストラクターの生成
    → ○
・クイック・フィックス (Ctrl+1)、宣言を開く (F3)、行へ移動 (Ctrl+L)
    → ○ (よく使うもの)
・コンソールからの入力 (Scanner)
    → ○
・キー・アシスト (Ctrl+Shift+L)
    → ○

ダイアログを開いている間も、レッスンはスクロールして読めます。ダイアログはタイトルバーをドラッグして動かせます。
Mac では表の Ctrl を ⌘ に読み替えてください (補完の Control + Space は除く)。
ブラウザーの都合で Ctrl+N・Ctrl+W・Ctrl+T (Mac は ⌘N・⌘W・⌘T・⌘Q・⌘H・⌘M) は使えません。

【Eclipse と違うところ】

・例外のスタックトレースの行番号が Unknown Source になります。クリックすると、例外が起きたメソッドを開きます。
・NullPointerException の詳しい説明 (Cannot invoke ... because "e4" is null) は表示されません。
・終わらないプログラム (無限ループ) をコンソールの赤い ■ で止めると、画面を読み込み直します (保存済みのファイルはそのままです)。
・デバッガー (ブレークポイント) はありません。

【困ったときは】

・start.bat を開くと「Windows によって PC が保護されました」などの警告が出る
    → 使い方の 1. のとおり、zip の「ブロックの解除」をしてから展開し直してください。
・画面右下が「Java を起動できません」になる
    → インターネットに接続されているか確認して、ブラウザのページを読み込み直してください。
・ブラウザが開かない、または Chrome 以外のブラウザで開く
    → 黒いウィンドウ (Mac はターミナル) に表示されている http://localhost:8765/ (番号は変わることがあります) を Chrome で開いてください。
・Mac で「"start.command" は開いていません」と出る
    → 使い方 (Mac) の 3.〜4. のとおり、システム設定の「プライバシーとセキュリティ」で このまま開く をクリックしてください。
・Mac で補完 (Control + Space) が効かない
    → 使い方 (Mac) の最後のとおり、キーボードショートカットの「前の入力ソースを選択」のチェックを外してください。
・レッスンに「Qiita の取得回数の上限」と出る
    → しばらく待つか、レッスンの切り替えで「内蔵の教材」を選んでください。

【仕組み】

・CheerpJ 5.0 (WebAssembly 製の Java 仮想マシン) がブラウザの中で OpenJDK 17 を動かします。
・その上で ECJ (Eclipse Compiler for Java) を常駐させてコンパイルします。最初の 1 回は約 10 秒、2 回目以降は 0.1〜0.2 秒です。
・CheerpJ は HTTP Range 要求に対応した Web サーバーが必要なため、Windows は最初から入っている PowerShell で、Mac は最初から入っている Perl で、小さな Web サーバーを動かしています。サーバーはこのパソコンの中 (localhost) だけで待ち受けるので、ほかのパソコンからは接続できません。

【ライセンス】

・お手軽Java 自体: ライセンスは未定です。
・CheerpJ ( https://cheerpj.com/ ) (Leaning Technologies): 個人・教育・趣味の利用は無料です。業務で使う場合はライセンスが必要です。 実行時にインターネットから読み込みます (zip には入っていません)。
・ECJ (Eclipse Compiler for Java) ( https://github.com/eclipse-jdt/eclipse.jdt.core ) 3.45.0: Eclipse Public License 2.0。ソース・コードは Maven Central ( https://repo1.maven.org/maven2/org/eclipse/jdt/ecj/3.45.0/ ) から入手できます。
・CodeMirror ( https://codemirror.net/5/ ) 5.65.16: MIT License
・marked ( https://marked.js.org/ ) 12.0.2: MIT License
・教材本文: Qiita「【Java入門】 ( https://qiita.com/chida0818/items/1f0f457d575d4a675c16 )」「【HTML入門】 ( https://qiita.com/chida0818/items/4efc23bf7222b2377b2d )」「【DB入門】 ( https://qiita.com/chida0818/items/d1fbd989a20e8eed1cbc )」シリーズ (chida0818) の記事です。
