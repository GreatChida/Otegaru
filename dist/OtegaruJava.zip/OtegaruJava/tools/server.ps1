﻿# お手軽Java ローカルWebサーバ (Windows PowerShell 5.1 標準機能のみ / インストール不要)
# - HTTP Range 要求に対応 (CheerpJ の必須要件)
# - localhost のみで待ち受け (外部からはアクセス不可)
# - /api/* で work フォルダへのファイル保存・読込
param(
  [int]$Port = 8765,
  [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$WebRoot = [System.IO.Path]::GetFullPath((Join-Path $Root 'www'))
$WorkDir = Join-Path $Root 'work'
if (-not (Test-Path $WorkDir)) { New-Item -ItemType Directory $WorkDir | Out-Null }
$Utf8 = New-Object System.Text.UTF8Encoding($false)

$Mime = @{
  '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8'
  '.js'='text/javascript; charset=utf-8'; '.mjs'='text/javascript; charset=utf-8'
  '.css'='text/css; charset=utf-8'; '.json'='application/json; charset=utf-8'
  '.txt'='text/plain; charset=utf-8'; '.java'='text/plain; charset=utf-8'; '.md'='text/plain; charset=utf-8'
  '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.gif'='image/gif'; '.ico'='image/x-icon'
  '.jar'='application/java-archive'; '.class'='application/java-vm'; '.wasm'='application/wasm'
  '.woff2'='font/woff2'
}

# 空いているポートを探して起動
$listener = $null
for ($p = $Port; $p -lt $Port + 20; $p++) {
  $l = New-Object System.Net.HttpListener
  $l.Prefixes.Add("http://localhost:$p/")
  try { $l.Start(); $listener = $l; $Port = $p; break } catch { $l.Close() }
}
if (-not $listener) { Write-Host "ポートを確保できませんでした。" -ForegroundColor Red; exit 1 }

$url = "http://localhost:$Port/"
$Host.UI.RawUI.WindowTitle = "お手軽Java - $url"
Write-Host ""
Write-Host "  お手軽Java が起動しました: $url" -ForegroundColor Green
Write-Host "  このウィンドウを閉じる (または Ctrl+C) と終了します。"
Write-Host "  ワークスペース (書いたプログラムの保存場所): $WorkDir"
Write-Host ""
if (-not $NoBrowser) { Start-Process $url }

function Send-Bytes($res, [byte[]]$bytes, [string]$type, [int]$status = 200) {
  $res.StatusCode = $status
  $res.ContentType = $type
  $res.ContentLength64 = $bytes.Length
  $res.OutputStream.Write($bytes, 0, $bytes.Length)
}
function Send-Text($res, [string]$text, [string]$type = 'text/plain; charset=utf-8', [int]$status = 200) {
  Send-Bytes $res ($Utf8.GetBytes($text)) $type $status
}
function Send-Json($res, [string]$json) { Send-Text $res $json 'application/json; charset=utf-8' }

function Get-SafeWorkPath([string]$rel, [switch]$File) {
  # work フォルダの中だけを扱う。各部分は英数字 _ - . のみ (.. は不可)
  if ([string]::IsNullOrWhiteSpace($rel)) { return $null }
  $parts = $rel.Replace('\', '/').Split('/')
  foreach ($p in $parts) {
    if ($p -notmatch '^[A-Za-z0-9_\-\.]{1,80}$' -or $p -eq '.' -or $p -eq '..') { return $null }
  }
  if ($File -and $rel -notmatch '\.(java|txt|md|prefs)$' -and $rel -notmatch '(^|/)\.(project|classpath)$') { return $null }
  $full = [System.IO.Path]::GetFullPath((Join-Path $WorkDir ($parts -join '\')))
  if (-not $full.StartsWith([System.IO.Path]::GetFullPath($WorkDir) + '\', [StringComparison]::OrdinalIgnoreCase)) { return $null }
  return $full
}

function Read-Body($req) {
  $sr = New-Object System.IO.StreamReader($req.InputStream, $Utf8)
  $body = $sr.ReadToEnd(); $sr.Close(); return $body
}

function Get-Tree {
  $base = [System.IO.Path]::GetFullPath($WorkDir).TrimEnd('\') + '\'
  $dirs = @(Get-ChildItem -Path $WorkDir -Directory -Recurse | ForEach-Object { $_.FullName.Substring($base.Length).Replace('\', '/') })
  $files = @(Get-ChildItem -Path $WorkDir -File -Recurse -Include *.java, *.txt, *.md, *.prefs, .project, .classpath | ForEach-Object {
    [ordered]@{ path = $_.FullName.Substring($base.Length).Replace('\', '/'); content = [System.IO.File]::ReadAllText($_.FullName, $Utf8) }
  })
  $obj = [ordered]@{ dirs = $dirs; files = $files; root = [System.IO.Path]::GetFullPath($WorkDir) }
  return (ConvertTo-Json -InputObject $obj -Depth 5 -Compress)
}

function Handle-Api($req, $res) {
  $path = $req.Url.AbsolutePath
  $q = $req.QueryString['path']
  $m = $req.HttpMethod
  if ($path -eq '/api/ping') { Send-Json $res '{"ok":true}'; return }
  if ($path -eq '/api/tree') { Send-Json $res (Get-Tree); return }
  if ($path -eq '/api/file') {
    $fp = Get-SafeWorkPath $q -File
    if (-not $fp) { Send-Text $res '使えない名前です (英数字 _ - . のみ)' 'text/plain; charset=utf-8' 400; return }
    if ($m -eq 'GET') {
      if (-not (Test-Path $fp -PathType Leaf)) { Send-Text $res 'not found' 'text/plain; charset=utf-8' 404; return }
      Send-Text $res ([System.IO.File]::ReadAllText($fp, $Utf8)); return
    }
    if ($m -eq 'PUT' -or $m -eq 'POST') {
      $body = Read-Body $req
      $dir = Split-Path -Parent $fp
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
      [System.IO.File]::WriteAllText($fp, $body, $Utf8)
      Send-Json $res '{"ok":true}'; return
    }
    if ($m -eq 'DELETE') {
      if (Test-Path $fp -PathType Leaf) { Remove-Item -LiteralPath $fp -Force }
      Send-Json $res '{"ok":true}'; return
    }
  }
  if ($path -eq '/api/dir') {
    $dp = Get-SafeWorkPath $q
    if (-not $dp) { Send-Text $res '使えない名前です (英数字 _ - . のみ)' 'text/plain; charset=utf-8' 400; return }
    if ($m -eq 'POST' -or $m -eq 'PUT') { New-Item -ItemType Directory -Force $dp | Out-Null; Send-Json $res '{"ok":true}'; return }
    if ($m -eq 'DELETE') {
      # 削除はごみ箱へ (元に戻せるように)
      if (Test-Path $dp) {
        Add-Type -AssemblyName Microsoft.VisualBasic
        [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($dp, 'OnlyErrorDialogs', 'SendToRecycleBin')
      }
      Send-Json $res '{"ok":true}'; return
    }
  }
  if ($path -eq '/api/trash') {
    # ファイルをごみ箱へ
    $fp = Get-SafeWorkPath $q -File
    if (-not $fp) { Send-Text $res 'bad path' 'text/plain; charset=utf-8' 400; return }
    if (Test-Path $fp -PathType Leaf) {
      Add-Type -AssemblyName Microsoft.VisualBasic
      [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($fp, 'OnlyErrorDialogs', 'SendToRecycleBin')
    }
    Send-Json $res '{"ok":true}'; return
  }
  if ($path -eq '/api/rename' -and $m -eq 'POST') {
    $from = Get-SafeWorkPath $req.QueryString['from']
    $to = Get-SafeWorkPath $req.QueryString['to']
    if (-not $from -or -not $to -or -not (Test-Path $from) -or (Test-Path $to)) { Send-Text $res '名前を変更できません' 'text/plain; charset=utf-8' 400; return }
    $dir = Split-Path -Parent $to
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
    Move-Item -LiteralPath $from -Destination $to
    Send-Json $res '{"ok":true}'; return
  }
  if ($path -eq '/api/open-folder') {
    $dp = $WorkDir
    if ($q) { $t = Get-SafeWorkPath $q; if ($t -and (Test-Path $t -PathType Container)) { $dp = $t } }
    Start-Process explorer.exe $dp; Send-Json $res '{"ok":true}'; return
  }
  if ($path -eq '/api/shutdown') { Send-Json $res '{"ok":true}'; $script:stop = $true; return }
  Send-Text $res 'not found' 'text/plain; charset=utf-8' 404
}

function Handle-Static($req, $res) {
  $rel = [Uri]::UnescapeDataString($req.Url.AbsolutePath).TrimStart('/')
  if ($rel -eq '') { $rel = 'index.html' }
  $full = [System.IO.Path]::GetFullPath((Join-Path $WebRoot $rel))
  if (-not $full.StartsWith($WebRoot, [StringComparison]::OrdinalIgnoreCase)) { Send-Text $res 'forbidden' 'text/plain' 403; return }
  if (Test-Path $full -PathType Container) { $full = Join-Path $full 'index.html' }
  if (-not (Test-Path $full -PathType Leaf)) { Send-Text $res 'not found' 'text/plain' 404; return }

  $ext = [System.IO.Path]::GetExtension($full).ToLower()
  $type = $Mime[$ext]; if (-not $type) { $type = 'application/octet-stream' }
  $res.AddHeader('Accept-Ranges', 'bytes')
  $res.AddHeader('Cache-Control', 'no-cache')
  $fs = [System.IO.File]::OpenRead($full)
  try {
    $len = $fs.Length
    $range = $req.Headers['Range']
    [int64]$start = 0; [int64]$end = $len - 1; $status = 200
    if ($range -and $range -match '^bytes=(\d*)-(\d*)$') {
      if ($Matches[1] -ne '') {
        $start = [int64]$Matches[1]
        if ($Matches[2] -ne '') { $end = [Math]::Min([int64]$Matches[2], $len - 1) }
      } elseif ($Matches[2] -ne '') {
        $start = [Math]::Max([int64]0, $len - [int64]$Matches[2])
      }
      if ($start -gt $end -or $start -ge $len) {
        $res.StatusCode = 416; $res.AddHeader('Content-Range', "bytes */$len"); return
      }
      $status = 206
      $res.AddHeader('Content-Range', "bytes $start-$end/$len")
    }
    $count = $end - $start + 1
    $res.StatusCode = $status
    $res.ContentType = $type
    $res.ContentLength64 = $count
    if ($req.HttpMethod -eq 'HEAD') { return }
    [void]$fs.Seek($start, [System.IO.SeekOrigin]::Begin)
    $buf = New-Object byte[] 65536
    $remain = $count
    while ($remain -gt 0) {
      $n = $fs.Read($buf, 0, [int][Math]::Min([int64]$buf.Length, $remain))
      if ($n -le 0) { break }
      $res.OutputStream.Write($buf, 0, $n)
      $remain -= $n
    }
  } finally { $fs.Close() }
}

$script:stop = $false
try {
  while ($listener.IsListening -and -not $script:stop) {
    $ctx = $listener.GetContext()
    $req = $ctx.Request; $res = $ctx.Response
    try {
      if ($req.Url.AbsolutePath.StartsWith('/api/')) { Handle-Api $req $res } else { Handle-Static $req $res }
    } catch {
      try { Send-Text $res ("error: " + $_.Exception.Message) 'text/plain; charset=utf-8' 500 } catch {}
    } finally {
      try { $res.OutputStream.Close() } catch {}
    }
  }
} finally {
  $listener.Stop(); $listener.Close()
  Write-Host "お手軽Java を終了しました。"
}
