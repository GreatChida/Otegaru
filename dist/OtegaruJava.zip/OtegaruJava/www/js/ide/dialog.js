// お手軽Java - ダイアログ (モーダル・移動・入力・一覧から選ぶ)
'use strict';

(() => {
  const { S, $, $$, ICON_SVG, esc } = IDE;
  const { icon } = IDE.fn;

  // =================================================================
  // ダイアログ
  // =================================================================
  // ダイアログはモーダル (後ろの IDE は触れない)。ただしレッスン・ビューだけは読めるように、
  // 幕 (#overlay) より手前に出す (body.modal-open)。ダイアログは幕とは別の要素として重ねる。
  const dialogStack = [];

  /** ダイアログを、レッスン・ビューに重ならない位置 (エディター側の中央) に置く */
  function placeDialog(d) {
    const r = d.getBoundingClientRect();
    const right = $('#right');
    const rr = right && right.offsetParent ? right.getBoundingClientRect() : null;
    const areaRight = rr && rr.width ? rr.left : window.innerWidth;
    let left = (areaRight - r.width) / 2;
    if (left < 8) left = (window.innerWidth - r.width) / 2; // 入りきらないときは画面の中央
    let top = (window.innerHeight - r.height) / 2 - 20;
    const n = dialogStack.length - 1; // 重ねて開いたダイアログは少しずらす
    left += n * 24; top += n * 24;
    moveDialog(d, left, top);
  }
  /** 画面の外に出ないように動かす (タイトルバーが必ず見えるようにする) */
  function moveDialog(d, left, top) {
    const r = d.getBoundingClientRect();
    left = Math.min(Math.max(8 - r.width + 120, left), window.innerWidth - 120);
    top = Math.min(Math.max(0, top), window.innerHeight - 40);
    d.style.left = Math.round(left) + 'px';
    d.style.top = Math.round(top) + 'px';
  }
  /** タイトルバーをドラッグして動かせるようにする */
  function makeDraggable(d) {
    const bar = $('.dlg-titlebar', d);
    bar.addEventListener('mousedown', e => {
      if (e.button !== 0 || e.target.closest('button')) return;
      e.preventDefault();
      const r = d.getBoundingClientRect();
      const dx = e.clientX - r.left, dy = e.clientY - r.top;
      document.body.classList.add('dragging-dialog');
      const move = ev => moveDialog(d, ev.clientX - dx, ev.clientY - dy);
      const up = () => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        document.body.classList.remove('dragging-dialog');
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
    });
  }
  window.addEventListener('resize', () => {
    for (const d of dialogStack) { const r = d.getBoundingClientRect(); moveDialog(d, r.left, r.top); }
  });

  function dialog(opts) {
    return new Promise(resolve => {
      const ov = $('#overlay');
      ov.hidden = false;
      document.body.classList.add('modal-open');
      const d = document.createElement('div');
      d.className = 'dialog';
      d.style.minWidth = (opts.width || 440) + 'px';
      d.style.zIndex = String(700 + dialogStack.length * 10);
      const iconHtml = opts.icon === 'error' ? ICON_SVG.error : opts.icon === 'warning' ? ICON_SVG.warning : opts.icon === 'info' ? ICON_SVG.info : '';
      const buttons = opts.buttons || [{ label: 'OK', value: true, default: true }];
      d.innerHTML = `<div class="dlg-titlebar"><span class="t">${esc(opts.title || '')}</span><button class="x" data-x>×</button></div>
        ${opts.banner ? `<div class="dlg-banner"><div><div class="bt">${esc(opts.banner.title)}</div><div class="bm" id="dlg-msg">${opts.banner.html || esc(opts.banner.message || '')}</div></div><div class="bimg">${ICON_SVG[opts.banner.icon || 'wizard']}</div></div>` : ''}
        <div class="dlg-body">${opts.message ? `<div style="display:flex;gap:10px;align-items:flex-start">${iconHtml ? `<div style="transform:scale(1.8);margin:6px 8px">${iconHtml}</div>` : ''}<div style="white-space:pre-wrap">${esc(opts.message)}</div></div>` : ''}
        ${opts.list ? `<div class="dlg-list" style="height:auto;max-height:180px;margin-top:10px">${opts.list.map((x, i) => `<label class="li"><input type="checkbox" data-li="${i}" ${x.checked ? 'checked' : ''}>${esc(x.label)}</label>`).join('')}</div>` : ''}
        ${opts.html || ''}
        ${opts.check ? `<label class="chk" style="margin-top:12px"><input type="checkbox" id="dlg-check">${esc(opts.check)}</label>` : ''}
        </div>
        <div class="dlg-buttons">${opts.help ? '<button class="help" title="ヘルプ">?</button>' : ''}${buttons.map((b, i) => `<button class="dlg-btn${b.default ? ' default' : ''}" data-b="${i}">${esc(b.label)}</button>`).join('')}</div>`;
      // 親のダイアログ (クラス作成の「参照...」など) は、子を閉じるまで触れなくする
      const parent = dialogStack[dialogStack.length - 1];
      if (parent) parent.classList.add('blocked');
      document.body.appendChild(d);
      dialogStack.push(d);
      placeDialog(d);
      makeDraggable(d);
      const close = (val) => {
        d.remove();
        dialogStack.splice(dialogStack.indexOf(d), 1);
        if (parent) parent.classList.remove('blocked');
        if (!dialogStack.length) { ov.hidden = true; document.body.classList.remove('modal-open'); }
        document.removeEventListener('keydown', onKey, true);
        resolve(val);
        if (!dialogStack.length && S.active) setTimeout(() => S.active.cm.focus(), 0);
      };
      const result = (b) => {
        if (opts.check || opts.collect) {
          const out = { value: b.value, checked: !!($('#dlg-check', d) || {}).checked };
          if (opts.collect) Object.assign(out, opts.collect(d));
          return out;
        }
        return b.value;
      };
      const onKey = e => {
        // いちばん手前のダイアログだけが反応する。レッスン・ビューでのキー操作は邪魔しない
        if (dialogStack[dialogStack.length - 1] !== d) return;
        if (e.target.closest && e.target.closest('#view-right')) return;
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(opts.check || opts.collect ? null : (buttons.find(b => b.value === null || b.value === false) || {}).value ?? null); }
        else if (e.key === 'Enter' && !e.target.matches('textarea')) {
          const def = buttons.find(b => b.default);
          if (def) {
            const btn = $(`[data-b="${buttons.indexOf(def)}"]`, d);
            if (btn && !btn.disabled) { e.preventDefault(); e.stopPropagation(); if (def.validate && !def.validate(d)) return; close(result(def)); }
          }
        }
      };
      document.addEventListener('keydown', onKey, true);
      $$('[data-b]', d).forEach(btn => btn.addEventListener('click', () => {
        const b = buttons[+btn.dataset.b];
        if (b.validate && !b.validate(d)) return;
        close(result(b));
      }));
      $('[data-x]', d).onclick = () => close(opts.check || opts.collect ? null : null);
      if (opts.onOpen) opts.onOpen(d, { close: v => close(v) });
      // 読み取り専用の欄 (ソース・フォルダーなど) は飛ばして、入力できる最初の欄にフォーカスする
      const first = $('input[type=text]:not([readonly]):not([disabled])', d);
      if (first) { first.focus(); first.select(); } else { const def = $('.dlg-btn.default', d); if (def) def.focus(); }
    });
  }
  function showError(title, msg) { return dialog({ title, message: msg, icon: 'error' }); }

  async function pickFromList(title, message, items) {
    let picked = null;
    const r = await dialog({
      title, width: 420, message,
      html: `<input type="text" id="pl-filter" placeholder="絞り込み" style="width:100%;margin:8px 0 4px;padding:3px"><div class="dlg-list" id="pl-list">${items.map((x, i) => `<div class="li" data-i="${i}" tabindex="0">${Assist.ICONS.package} ${esc(x)}</div>`).join('')}</div>`,
      buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: () => ({ picked }),
      onOpen: (d, api) => {
        const list = $('#pl-list', d);
        const select = el => { $$('.li', list).forEach(x => x.style.background = ''); el.style.background = 'var(--sel)'; picked = items[+el.dataset.i]; };
        $$('.li', list).forEach(el => { el.onclick = () => select(el); el.ondblclick = () => { select(el); api.close({ value: 'ok', picked }); }; });
        const first = $('.li', list); if (first) select(first);
        $('#pl-filter', d).addEventListener('input', e => { const q = e.target.value.toLowerCase(); $$('.li', list).forEach(el => el.style.display = items[+el.dataset.i].toLowerCase().includes(q) ? '' : 'none'); });
      },
    });
    return r && r.value === 'ok' ? r.picked : null;
  }

  function promptText(title, label, value, validate) {
    return dialog({
      title, width: 440,
      html: `<div class="row" style="grid-template-columns:120px 1fr"><label>${esc(label)}</label><input type="text" id="pt-v" value="${esc(value || '')}" spellcheck="false"></div><div id="pt-msg" class="hint" style="min-height:18px"></div>`,
      buttons: [{ label: 'OK', value: 'ok', default: true, validate: d => !$('[data-b="0"]', d).disabled }, { label: '取り消し', value: null }],
      collect: d => ({ text: $('#pt-v', d).value.trim() }),
      onOpen: d => {
        const upd = () => { const v = $('#pt-v', d).value.trim(); const m = validate ? validate(v) : ''; $('#pt-msg', d).textContent = m || ''; $('[data-b="0"]', d).disabled = !v || !!m; };
        $('#pt-v', d).addEventListener('input', upd); upd();
      },
    }).then(r => r && r.value === 'ok' ? r.text : null);
  }

  Object.assign(IDE, { dialog, dialogStack, makeDraggable, moveDialog, pickFromList, placeDialog, promptText, showError });
})();
