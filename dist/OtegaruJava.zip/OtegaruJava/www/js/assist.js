// Eclipse 風の編集支援: コンテンツ・アシスト (補完)、テンプレート、フォーマット、インポートの編成、コード生成
'use strict';

const Assist = (() => {
  // ---------------------------------------------------------------
  // Java 標準ライブラリ (入門で使う範囲) のメンバー情報
  //  "s " で始まるものは static。メソッドは name(引数):戻り値、フィールドは name:型
  // ---------------------------------------------------------------
  const LIB = {
    'Object': { pkg: 'java.lang', m: ['equals(Object obj):boolean', 'hashCode():int', 'toString():String', 'getClass():Class<?>'] },
    'String': { pkg: 'java.lang', ext: 'Object', m: ['length():int', 'charAt(int index):char', 'equals(Object anObject):boolean', 'equalsIgnoreCase(String anotherString):boolean', 'isEmpty():boolean', 'isBlank():boolean', 'substring(int beginIndex):String', 'substring(int beginIndex, int endIndex):String', 'indexOf(String str):int', 'lastIndexOf(String str):int', 'contains(CharSequence s):boolean', 'startsWith(String prefix):boolean', 'endsWith(String suffix):boolean', 'toUpperCase():String', 'toLowerCase():String', 'trim():String', 'strip():String', 'replace(CharSequence target, CharSequence replacement):String', 'split(String regex):String[]', 'compareTo(String anotherString):int', 'repeat(int count):String', 'toCharArray():char[]', 'matches(String regex):boolean', 'concat(String str):String', 'chars():IntStream', 's format(String format, Object... args):String', 's valueOf(Object obj):String', 's valueOf(int i):String', 's join(CharSequence delimiter, CharSequence... elements):String'] },
    'System': { pkg: 'java.lang', m: ['s out:PrintStream', 's err:PrintStream', 's in:InputStream', 's currentTimeMillis():long', 's nanoTime():long', 's exit(int status):void', 's lineSeparator():String', 's getProperty(String key):String', 's arraycopy(Object src, int srcPos, Object dest, int destPos, int length):void'] },
    'PrintStream': { pkg: 'java.io', ext: 'Object', m: ['println():void', 'println(String x):void', 'println(int x):void', 'println(Object x):void', 'print(String s):void', 'print(int i):void', 'print(Object obj):void', 'printf(String format, Object... args):PrintStream', 'flush():void'] },
    'Math': { pkg: 'java.lang', m: ['s PI:double', 's E:double', 's abs(int a):int', 's max(int a, int b):int', 's min(int a, int b):int', 's pow(double a, double b):double', 's sqrt(double a):double', 's random():double', 's round(double a):long', 's floor(double a):double', 's ceil(double a):double'] },
    'Integer': { pkg: 'java.lang', ext: 'Number', m: ['s MAX_VALUE:int', 's MIN_VALUE:int', 's parseInt(String s):int', 's valueOf(int i):Integer', 's valueOf(String s):Integer', 's toString(int i):String', 's compare(int x, int y):int', 'intValue():int', 'doubleValue():double', 'equals(Object obj):boolean', 'compareTo(Integer anotherInteger):int', 'toString():String'] },
    'Long': { pkg: 'java.lang', m: ['s MAX_VALUE:long', 's MIN_VALUE:long', 's parseLong(String s):long', 's valueOf(long l):Long', 'longValue():long', 'intValue():int'] },
    'Double': { pkg: 'java.lang', m: ['s parseDouble(String s):double', 's valueOf(double d):Double', 'doubleValue():double', 'intValue():int', 'isNaN():boolean'] },
    'Boolean': { pkg: 'java.lang', m: ['s TRUE:Boolean', 's FALSE:Boolean', 's parseBoolean(String s):boolean', 's valueOf(boolean b):Boolean', 'booleanValue():boolean'] },
    'Character': { pkg: 'java.lang', m: ['s isDigit(char ch):boolean', 's isLetter(char ch):boolean', 's isUpperCase(char ch):boolean', 's toUpperCase(char ch):char', 's toLowerCase(char ch):char', 'charValue():char'] },
    'StringBuilder': { pkg: 'java.lang', ext: 'Object', m: ['append(String str):StringBuilder', 'append(int i):StringBuilder', 'append(Object obj):StringBuilder', 'insert(int offset, String str):StringBuilder', 'reverse():StringBuilder', 'deleteCharAt(int index):StringBuilder', 'setLength(int newLength):void', 'length():int', 'charAt(int index):char', 'toString():String'] },
    'Throwable': { pkg: 'java.lang', ext: 'Object', m: ['getMessage():String', 'printStackTrace():void', 'getCause():Throwable', 'getStackTrace():StackTraceElement[]', 'getLocalizedMessage():String'] },
    'Exception': { pkg: 'java.lang', ext: 'Throwable', m: [] },
    'RuntimeException': { pkg: 'java.lang', ext: 'Exception', m: [] },
    'IllegalArgumentException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'IllegalStateException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'NullPointerException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'ArithmeticException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'NumberFormatException': { pkg: 'java.lang', ext: 'IllegalArgumentException', m: [] },
    'ArrayIndexOutOfBoundsException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'IndexOutOfBoundsException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'ClassCastException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'UnsupportedOperationException': { pkg: 'java.lang', ext: 'RuntimeException', m: [] },
    'Error': { pkg: 'java.lang', ext: 'Throwable', m: [] },
    'Thread': { pkg: 'java.lang', m: ['s sleep(long millis):void', 's currentThread():Thread', 'getName():String', 'start():void', 'join():void'] },
    'Override': { pkg: 'java.lang', annotation: true, m: [] },
    'Deprecated': { pkg: 'java.lang', annotation: true, m: [] },
    'SuppressWarnings': { pkg: 'java.lang', annotation: true, m: [] },
    'FunctionalInterface': { pkg: 'java.lang', annotation: true, m: [] },
    'Comparable': { pkg: 'java.lang', iface: true, m: ['compareTo(T o):int'] },
    'Iterable': { pkg: 'java.lang', iface: true, m: ['iterator():Iterator<T>', 'forEach(Consumer<? super T> action):void'] },
    'Runnable': { pkg: 'java.lang', iface: true, m: ['run():void'] },
    'CharSequence': { pkg: 'java.lang', iface: true, m: ['length():int', 'charAt(int index):char'] },
    'Number': { pkg: 'java.lang', m: ['intValue():int', 'doubleValue():double', 'longValue():long'] },
    'Enum': { pkg: 'java.lang', m: ['name():String', 'ordinal():int'] },
    'Record': { pkg: 'java.lang', m: [] },
    'Class': { pkg: 'java.lang', m: ['getName():String', 'getSimpleName():String'] },
    'Collection': { pkg: 'java.util', iface: true, m: ['add(E e):boolean', 'remove(Object o):boolean', 'size():int', 'isEmpty():boolean', 'contains(Object o):boolean', 'clear():void', 'addAll(Collection<? extends E> c):boolean', 'iterator():Iterator<E>', 'stream():Stream<E>', 'forEach(Consumer<? super E> action):void', 'toArray():Object[]'] },
    'List': { pkg: 'java.util', iface: true, ext: 'Collection', m: ['add(E e):boolean', 'add(int index, E element):void', 'get(int index):E', 'set(int index, E element):E', 'remove(int index):E', 'remove(Object o):boolean', 'size():int', 'isEmpty():boolean', 'contains(Object o):boolean', 'indexOf(Object o):int', 'clear():void', 'addAll(Collection<? extends E> c):boolean', 'sort(Comparator<? super E> c):void', 'subList(int fromIndex, int toIndex):List<E>', 'iterator():Iterator<E>', 'stream():Stream<E>', 'forEach(Consumer<? super E> action):void', 'toArray():Object[]', 's of(E... elements):List<E>'] },
    'ArrayList': { pkg: 'java.util', ext: 'List', m: [] },
    'LinkedList': { pkg: 'java.util', ext: 'List', m: ['addFirst(E e):void', 'addLast(E e):void', 'getFirst():E', 'getLast():E', 'removeFirst():E', 'removeLast():E'] },
    'Set': { pkg: 'java.util', iface: true, ext: 'Collection', m: ['add(E e):boolean', 'remove(Object o):boolean', 'contains(Object o):boolean', 'size():int', 'isEmpty():boolean', 'clear():void', 'iterator():Iterator<E>', 's of(E... elements):Set<E>'] },
    'HashSet': { pkg: 'java.util', ext: 'Set', m: [] },
    'TreeSet': { pkg: 'java.util', ext: 'Set', m: [] },
    'LinkedHashSet': { pkg: 'java.util', ext: 'Set', m: [] },
    'Map': { pkg: 'java.util', iface: true, m: ['put(K key, V value):V', 'get(Object key):V', 'getOrDefault(Object key, V defaultValue):V', 'containsKey(Object key):boolean', 'containsValue(Object value):boolean', 'remove(Object key):V', 'size():int', 'isEmpty():boolean', 'keySet():Set<K>', 'values():Collection<V>', 'entrySet():Set<Map.Entry<K, V>>', 'putIfAbsent(K key, V value):V', 'clear():void', 'forEach(BiConsumer<? super K, ? super V> action):void', 's of(K k1, V v1):Map<K, V>'] },
    'HashMap': { pkg: 'java.util', ext: 'Map', m: [] },
    'TreeMap': { pkg: 'java.util', ext: 'Map', m: [] },
    'LinkedHashMap': { pkg: 'java.util', ext: 'Map', m: [] },
    'Entry': { pkg: 'java.util.Map', iface: true, m: ['getKey():K', 'getValue():V', 'setValue(V value):V'] },
    'Iterator': { pkg: 'java.util', iface: true, m: ['hasNext():boolean', 'next():E', 'remove():void'] },
    'Arrays': { pkg: 'java.util', m: ['s toString(Object[] a):String', 's sort(Object[] a):void', 's asList(T... a):List<T>', 's fill(Object[] a, Object val):void', 's copyOf(T[] original, int newLength):T[]', 's stream(T[] array):Stream<T>', 's equals(Object[] a, Object[] a2):boolean'] },
    'Collections': { pkg: 'java.util', m: ['s sort(List<T> list):void', 's reverse(List<?> list):void', 's shuffle(List<?> list):void', 's max(Collection<? extends T> coll):T', 's min(Collection<? extends T> coll):T', 's unmodifiableList(List<? extends T> list):List<T>', 's emptyList():List<T>'] },
    'Objects': { pkg: 'java.util', m: ['s equals(Object a, Object b):boolean', 's hash(Object... values):int', 's hashCode(Object o):int', 's requireNonNull(T obj):T', 's isNull(Object obj):boolean', 's nonNull(Object obj):boolean', 's toString(Object o):String'] },
    'Optional': { pkg: 'java.util', m: ['isPresent():boolean', 'isEmpty():boolean', 'get():T', 'orElse(T other):T', 'orElseThrow():T', 'ifPresent(Consumer<? super T> action):void', 's of(T value):Optional<T>', 's ofNullable(T value):Optional<T>', 's empty():Optional<T>'] },
    'Scanner': { pkg: 'java.util', m: ['nextLine():String', 'next():String', 'nextInt():int', 'nextDouble():double', 'nextBoolean():boolean', 'hasNext():boolean', 'hasNextLine():boolean', 'hasNextInt():boolean', 'close():void'] },
    'Random': { pkg: 'java.util', m: ['nextInt():int', 'nextInt(int bound):int', 'nextDouble():double', 'nextBoolean():boolean'] },
    'Date': { pkg: 'java.util', m: ['getTime():long', 'toString():String', 'before(Date when):boolean', 'after(Date when):boolean'] },
    'Comparator': { pkg: 'java.util', iface: true, m: ['compare(T o1, T o2):int', 'reversed():Comparator<T>', 's comparing(Function<? super T, ? extends U> keyExtractor):Comparator<T>'] },
    'Serializable': { pkg: 'java.io', iface: true, m: [] },
    'IOException': { pkg: 'java.io', ext: 'Exception', m: [] },
    'FileNotFoundException': { pkg: 'java.io', ext: 'IOException', m: [] },
    'UncheckedIOException': { pkg: 'java.io', ext: 'RuntimeException', m: [] },
    'BufferedReader': { pkg: 'java.io', m: ['readLine():String', 'close():void'] },
    'InputStreamReader': { pkg: 'java.io', m: [] },
    'InputStream': { pkg: 'java.io', m: ['read():int', 'close():void'] },
    'File': { pkg: 'java.io', m: ['exists():boolean', 'getName():String', 'getPath():String'] },
    'LocalDate': { pkg: 'java.time', m: ['s now():LocalDate', 's of(int year, int month, int dayOfMonth):LocalDate', 's parse(CharSequence text):LocalDate', 'getYear():int', 'getMonthValue():int', 'getDayOfMonth():int', 'plusDays(long daysToAdd):LocalDate', 'minusDays(long daysToSubtract):LocalDate', 'isBefore(ChronoLocalDate other):boolean', 'isAfter(ChronoLocalDate other):boolean', 'format(DateTimeFormatter formatter):String', 'toString():String'] },
    'LocalDateTime': { pkg: 'java.time', m: ['s now():LocalDateTime', 's of(int year, int month, int dayOfMonth, int hour, int minute):LocalDateTime', 'getHour():int', 'getMinute():int', 'toLocalDate():LocalDate', 'format(DateTimeFormatter formatter):String'] },
    'LocalTime': { pkg: 'java.time', m: ['s now():LocalTime', 's of(int hour, int minute):LocalTime', 'getHour():int', 'getMinute():int'] },
    'DateTimeFormatter': { pkg: 'java.time.format', m: ['s ofPattern(String pattern):DateTimeFormatter', 'format(TemporalAccessor temporal):String'] },
    'BigDecimal': { pkg: 'java.math', m: ['s valueOf(long val):BigDecimal', 'add(BigDecimal augend):BigDecimal', 'subtract(BigDecimal subtrahend):BigDecimal', 'multiply(BigDecimal multiplicand):BigDecimal', 'compareTo(BigDecimal val):int'] },
    'Stream': { pkg: 'java.util.stream', iface: true, m: ['filter(Predicate<? super T> predicate):Stream<T>', 'map(Function<? super T, ? extends R> mapper):Stream<R>', 'forEach(Consumer<? super T> action):void', 'toList():List<T>', 'count():long', 'sorted():Stream<T>'] },
    'Collectors': { pkg: 'java.util.stream', m: ['s toList():Collector<T, ?, List<T>>', 's joining(CharSequence delimiter):Collector<CharSequence, ?, String>'] },
  };
  const ARRAY_MEMBERS = ['length:int', 'clone():Object'];
  const KEYWORDS = ['abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char', 'class', 'continue', 'default', 'do', 'double', 'else', 'enum', 'extends', 'final', 'finally', 'float', 'for', 'if', 'implements', 'import', 'instanceof', 'int', 'interface', 'long', 'new', 'null', 'package', 'private', 'protected', 'public', 'record', 'return', 'short', 'static', 'super', 'switch', 'synchronized', 'this', 'throw', 'throws', 'true', 'false', 'try', 'var', 'void', 'volatile', 'while'];
  const PRIMITIVES = ['int', 'long', 'double', 'float', 'boolean', 'char', 'byte', 'short', 'void'];

  function parseLibMember(s) {
    const st = s.startsWith('s ');
    if (st) s = s.slice(2);
    let m = s.match(/^(\w+)\((.*)\):(.+)$/);
    if (m) return { kind: 'method', name: m[1], params: JavaSrc.parseParams(m[2]), ret: m[3], static: st };
    m = s.match(/^(\w+):(.+)$/);
    return { kind: 'field', name: m[1], type: m[2], static: st };
  }
  const libCache = {};
  function libMembers(name) {
    if (libCache[name]) return libCache[name];
    const out = [];
    const seen = new Set();
    for (let t = name, guard = 0; t && LIB[t] && guard < 8; t = LIB[t].ext, guard++) {
      for (const s of LIB[t].m) {
        const mm = parseLibMember(s);
        const key = mm.name + '(' + (mm.params || []).map(p => p.type).join(',') + ')' + mm.kind;
        if (!seen.has(key)) { seen.add(key); mm.owner = t; out.push(mm); }
      }
      if (!LIB[t].ext && t !== 'Object' && !LIB[t].iface) {
        for (const s of LIB.Object.m) { const mm = parseLibMember(s); const key = mm.name + '()' + mm.kind; if (!seen.has(key)) { seen.add(key); mm.owner = 'Object'; out.push(mm); } }
      }
    }
    return (libCache[name] = out);
  }

  // ---------------------------------------------------------------
  // アイコン (補完・アウトライン・エクスプローラーで共通)
  // ---------------------------------------------------------------
  const ICONS = {
    class: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="6.5" fill="#3f9a3f" stroke="#2c6e2c"/><text x="8" y="11.6" font-size="10" font-family="Arial" font-weight="bold" fill="#fff" text-anchor="middle">C</text></svg>',
    interface: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="6.5" fill="#7f5fbf" stroke="#5a3f94"/><text x="8" y="11.6" font-size="10" font-family="Arial" font-weight="bold" fill="#fff" text-anchor="middle">I</text></svg>',
    enum: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="6.5" fill="#b07d3a" stroke="#83592a"/><text x="8" y="11.6" font-size="10" font-family="Arial" font-weight="bold" fill="#fff" text-anchor="middle">E</text></svg>',
    record: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="6.5" fill="#3f8a9a" stroke="#2c6370"/><text x="8" y="11.6" font-size="10" font-family="Arial" font-weight="bold" fill="#fff" text-anchor="middle">R</text></svg>',
    annotation: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="6.5" fill="#6a7f9a" stroke="#4b5c70"/><text x="8" y="11.6" font-size="10" font-family="Arial" font-weight="bold" fill="#fff" text-anchor="middle">@</text></svg>',
    methodPublic: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="4.5" fill="#3fae3f" stroke="#2c7a2c"/></svg>',
    methodPrivate: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="3.5" y="3.5" width="9" height="9" fill="#d94a4a" stroke="#a33"/></svg>',
    methodProtected: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M8 3 L13 13 L3 13 Z" fill="#e8b33a" stroke="#b5881f"/></svg>',
    methodDefault: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M8 3 L13 8 L8 13 L3 8 Z" fill="#3f7fd9" stroke="#2c5aa0"/></svg>',
    fieldPublic: '<svg viewBox="0 0 16 16" width="16" height="16"><circle cx="8" cy="8" r="3" fill="#3fae3f"/></svg>',
    fieldPrivate: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="5" y="5" width="6" height="6" fill="#d94a4a"/></svg>',
    fieldProtected: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M8 4.5 L11.5 11.5 L4.5 11.5 Z" fill="#e8b33a"/></svg>',
    fieldDefault: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M8 4.5 L11.5 8 L8 11.5 L4.5 8 Z" fill="#3f7fd9"/></svg>',
    local: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="4" y="5" width="8" height="6" rx="1" fill="#e6c34a" stroke="#a88a24"/></svg>',
    template: '<svg viewBox="0 0 16 16" width="16" height="16"><rect x="2.5" y="2.5" width="11" height="11" fill="#fff" stroke="#888"/><path d="M5 6h6M5 8.5h6M5 11h4" stroke="#4a7fc1"/></svg>',
    keyword: '<svg viewBox="0 0 16 16" width="16" height="16"><text x="8" y="12" font-size="10" font-family="Arial" font-weight="bold" fill="#7f0055" text-anchor="middle">k</text></svg>',
    package: '<svg viewBox="0 0 16 16" width="16" height="16"><path d="M2 5 L8 2 L14 5 L14 11.5 L8 14.5 L2 11.5 Z" fill="#c8a165" stroke="#8a6a35"/><path d="M2 5 L8 8 L14 5 M8 8 L8 14.5" fill="none" stroke="#8a6a35"/></svg>',
  };
  function memberIcon(m) {
    const mods = m.mods || [];
    const vis = mods.includes('private') ? 'Private' : mods.includes('protected') ? 'Protected' : (mods.includes('public') || m.lib) ? 'Public' : 'Default';
    if (m.kind === 'method' || m.kind === 'ctor') return ICONS['method' + vis];
    if (m.kind === 'field' || m.kind === 'enumConst') return ICONS['field' + vis];
    if (m.kind === 'type') return ICONS[m.type.kind] || ICONS.class;
    return ICONS.local;
  }
  function typeIcon(kind) { return ICONS[kind] || ICONS.class; }

  // ---------------------------------------------------------------
  // テンプレート (Eclipse の既定のテンプレート名)
  // ---------------------------------------------------------------
  const TEMPLATES = [
    { name: 'sysout', desc: '標準出力に出力', body: 'System.out.println(${cursor});' },
    { name: 'syserr', desc: '標準エラーに出力', body: 'System.err.println(${cursor});' },
    { name: 'systrace', desc: 'メソッド名を標準出力に出力', body: 'System.out.println("${enclosing_type}.${enclosing_method}()");' },
    { name: 'main', desc: 'main メソッド', body: 'public static void main(String[] args) {\n\t${cursor}\n}' },
    { name: 'for', desc: '配列を反復処理', body: 'for (int ${index} = 0; ${index} < ${array}.length; ${index}++) {\n\t${cursor}\n}' },
    { name: 'for', desc: '一時変数を使用して配列を反復処理', body: 'for (int ${index} = 0; ${index} < ${array}.length; ${index}++) {\n\t${array_type} ${array_element} = ${array}[${index}];\n\t${cursor}\n}' },
    { name: 'foreach', desc: '配列または Iterable を反復処理', body: 'for (${iterable_type} ${iterable_element} : ${iterable}) {\n\t${cursor}\n}' },
    { name: 'if', desc: 'if ステートメント', body: 'if (${condition}) {\n\t${cursor}\n}' },
    { name: 'ifelse', desc: 'if else ステートメント', body: 'if (${condition}) {\n\t${cursor}\n} else {\n\t\n}' },
    { name: 'elseif', desc: 'else if ブロック', body: 'else if (${condition}) {\n\t${cursor}\n}' },
    { name: 'else', desc: 'else ブロック', body: 'else {\n\t${cursor}\n}' },
    { name: 'while', desc: '条件を使用した while ループ', body: 'while (${condition}) {\n\t${cursor}\n}' },
    { name: 'do', desc: 'do while ステートメント', body: 'do {\n\t${cursor}\n} while (${condition});' },
    { name: 'switch', desc: 'switch case ステートメント', body: 'switch (${key}) {\ncase ${value}:\n\t${cursor}\n\tbreak;\n\ndefault:\n\tbreak;\n}' },
    { name: 'try', desc: 'try catch ブロック', body: 'try {\n\t${cursor}\n} catch (${Exception} e) {\n\t// TODO 自動生成された catch ブロック\n\te.printStackTrace();\n}' },
    { name: 'catch', desc: 'catch ブロック', body: 'catch (${Exception} e) {\n\t${cursor}// TODO: handle exception\n}' },
    { name: 'finally', desc: 'finally ブロック', body: 'finally {\n\t${cursor}\n}' },
    { name: 'new', desc: '新規オブジェクトの作成', body: '${type} ${name} = new ${type}(${arguments});' },
    { name: 'private_method', desc: 'private メソッド', body: 'private ${return_type} ${name}(${}) {\n\t${cursor}\n}' },
    { name: 'public_method', desc: 'public メソッド', body: 'public ${return_type} ${name}(${}) {\n\t${cursor}\n}' },
    { name: 'protected_method', desc: 'protected メソッド', body: 'protected ${return_type} ${name}(${}) {\n\t${cursor}\n}' },
    { name: 'private_static_method', desc: 'private static メソッド', body: 'private static ${return_type} ${name}(${}) {\n\t${cursor}\n}' },
    { name: 'static_final', desc: '新規 static final フィールド', body: '${visibility} static final ${type} ${NAME} = ${value};' },
    { name: 'toarray', desc: 'コレクションを配列に変換', body: '(${type}[]) ${collection}.toArray(new ${type}[${collection}.size()])' },
    { name: 'instanceof', desc: 'instanceof によって動的に型を判別', body: 'if (${name} instanceof ${type} ${new_name}) {\n\t${cursor}\n}' },
    { name: 'lazy', desc: '遅延作成', body: 'if (${name} == null) {\n\t${name} = new ${type}(${arguments});\n\t${cursor}\n}\n\nreturn ${name};' },
    { name: 'Test', desc: 'テスト・メソッド', body: '@Test\npublic void ${name}() throws Exception {\n\t${cursor}\n}' },
  ];

  // ---------------------------------------------------------------
  // 補完
  // ---------------------------------------------------------------
  let ctx = null; // app から設定: { projectTypes(): [{name, pkg, kind, parsedType}], currentPkg }

  function setContext(c) { ctx = c; }

  function allClassNames() {
    const map = new Map(); // simpleName -> [{pkg, kind, src}]
    for (const [n, v] of Object.entries(LIB)) {
      if (n === 'Entry') continue;
      if (!map.has(n)) map.set(n, []);
      map.get(n).push({ pkg: v.pkg, kind: v.annotation ? 'annotation' : v.iface ? 'interface' : 'class', lib: true });
    }
    if (ctx) for (const t of ctx.projectTypes()) {
      if (!map.has(t.name)) map.set(t.name, []);
      map.get(t.name).push({ pkg: t.pkg, kind: t.kind, type: t.type });
    }
    return map;
  }

  /** 型名 (単純名) から、メンバーの一覧を返す */
  function membersOfType(typeName, opts) {
    opts = opts || {};
    if (!typeName) return [];
    if (/\[\]$/.test(typeName)) return ARRAY_MEMBERS.map(parseLibMember).map(m => Object.assign(m, { lib: true, owner: typeName }));
    const sn = JavaSrc.simpleName(typeName);
    const args = JavaSrc.typeArgs(typeName);
    if (ctx) {
      const pts = ctx.projectTypes().filter(t => t.name === sn);
      const pt = pts.find(t => t.pkg === ctx.currentPkg()) || pts[0];
      if (pt) {
        const out = [];
        const seen = new Set();
        for (let t = pt.type, guard = 0; t && guard < 6; guard++) {
          for (const m of t.members) {
            if (m.kind === 'init' || m.kind === 'ctor' || m.kind === 'type') continue;
            if (opts.samePkgOnly === false && m.mods.includes('private')) continue;
            const key = m.name + (m.params ? '(' + m.params.map(p => p.type).join(',') + ')' : '');
            if (seen.has(key)) continue;
            seen.add(key);
            out.push(Object.assign({}, m, { owner: t.name, static: m.mods.includes('static') }));
          }
          const ext = t.ext ? JavaSrc.simpleName(t.ext) : (t.kind === 'enum' ? 'Enum' : t.kind === 'record' ? 'Record' : 'Object');
          const next = ctx.projectTypes().find(x => x.name === ext);
          if (next) { t = next.type; continue; }
          for (const m of libMembers(ext)) {
            const key = m.name + (m.params ? '(' + m.params.map(p => p.type).join(',') + ')' : '');
            if (!seen.has(key)) { seen.add(key); out.push(Object.assign({}, m, { lib: true })); }
          }
          break;
        }
        return out;
      }
    }
    return libMembers(sn).map(m => substituteGenerics(Object.assign({}, m, { lib: true }), sn, args));
  }

  function substituteGenerics(m, typeName, args) {
    if (!args.length) return m;
    const names = { List: ['E'], ArrayList: ['E'], LinkedList: ['E'], Collection: ['E'], Set: ['E'], HashSet: ['E'], TreeSet: ['E'], LinkedHashSet: ['E'], Iterator: ['E'], Map: ['K', 'V'], HashMap: ['K', 'V'], TreeMap: ['K', 'V'], LinkedHashMap: ['K', 'V'], Entry: ['K', 'V'], Optional: ['T'], Stream: ['T'], Comparable: ['T'], Iterable: ['T'], Comparator: ['T'] }[typeName];
    if (!names) return m;
    const rep = s => s && s.replace(/\b([A-Z])\b/g, (x, v) => { const i = names.indexOf(v); return i >= 0 && args[i] ? args[i] : x; });
    if (m.ret) m.ret = rep(m.ret);
    if (m.type) m.type = rep(m.type);
    if (m.params) m.params = m.params.map(p => ({ type: rep(p.type), name: p.name }));
    return m;
  }

  /** 式 (a.b().c) の型を推定する */
  function resolveExprType(src, pos, expr, parsed) {
    const parts = [];
    let depth = 0, cur = '';
    for (const ch of expr) {
      if (ch === '(' || ch === '[') depth++;
      if (ch === ')' || ch === ']') depth--;
      if (ch === '.' && depth === 0) { parts.push(cur); cur = ''; } else cur += ch;
    }
    parts.push(cur);
    let type = null, isStatic = false;
    const first = parts[0].trim();
    const cls = allClassNames();
    const curType = JavaSrc.typeAt(parsed, pos);
    if (first === 'this') type = curType ? curType.name : null;
    else if (first === 'super') type = curType && curType.ext ? curType.ext : 'Object';
    else if (/^".*"$/.test(first)) type = 'String';
    else if (/^\w+\s*\(.*\)$/.test(first)) {
      const nm = first.match(/^(\w+)/)[1];
      const m = curType ? membersOfType(curType.name).find(x => x.name === nm && x.kind === 'method') : null;
      type = m ? m.ret : null;
    } else if (/^new\s+([\w.]+)/.test(first)) type = first.match(/^new\s+([\w.<>]+)/)[1];
    else if (/^\w+(\[.*\])*$/.test(first)) {
      const nm = first.replace(/\[.*$/, '');
      const vt = JavaSrc.varType(src, pos, nm, parsed);
      if (vt) { type = vt; if (/\[/.test(first)) type = type.replace(/\[\]$/, ''); }
      else if (cls.has(nm)) { type = nm; isStatic = true; }
    }
    for (let i = 1; i < parts.length && type; i++) {
      const p = parts[i].trim();
      const isCall = /\(.*\)$/.test(p);
      const nm = p.replace(/\(.*$/, '').replace(/\[.*$/, '');
      const ms = membersOfType(type);
      const m = ms.find(x => x.name === nm && (isCall ? x.kind === 'method' : x.kind !== 'method'));
      if (!m) {
        // ネストした型 (Map.Entry など)
        if (cls.has(nm) || nm === 'Entry') { type = nm; isStatic = true; continue; }
        return { type: null };
      }
      type = isCall ? m.ret : m.type;
      if (/\[/.test(p) && type) type = type.replace(/\[\]$/, '');
      isStatic = false;
    }
    return { type, isStatic };
  }

  /** CodeMirror の補完候補を作る */
  function hint(cm, options) {
    const cur = cm.getCursor();
    const line = cm.getLine(cur.line);
    const src = cm.getValue();
    const pos = cm.indexFromPos(cur);
    const parsed = JavaSrc.parse(src);
    let start = cur.ch;
    while (start > 0 && /[\w$]/.test(line[start - 1])) start--;
    const prefix = line.slice(start, cur.ch);
    const before = line.slice(0, start);
    const list = [];
    const lower = prefix.toLowerCase();
    const match = (name) => !prefix || name.toLowerCase().startsWith(lower) || camelMatch(name, prefix);

    // 文字列・コメントの中では補完しない
    const tok = cm.getTokenAt(cur);
    if (tok && /comment|string/.test(tok.type || '')) return null;

    // import 文
    const im = before.match(/^\s*import\s+(static\s+)?([\w.]*)$/);
    if (im) {
      const base = im[2];
      for (const [n, arr] of allClassNames()) for (const c of arr) {
        const fq = c.pkg + '.' + n;
        if ((base + prefix) && fq.toLowerCase().startsWith((base + prefix).toLowerCase())) {
          list.push(item(fq.slice(base.length), n + ' - ' + c.pkg, typeIcon(c.kind), 'class'));
        }
      }
      return finish(cm, list, CodeMirror.Pos(cur.line, start), cur);
    }

    // メンバー補完 (xxx.)
    const dm = before.match(/((?:[\w$]+|\)|\]|")(?:\s*\.\s*[\w$]+(?:\([^()]*\))?(?:\[[^\]]*\])?)*)\s*\.\s*$/);
    if (dm || /\.\s*$/.test(before)) {
      const exprText = extractExpr(before.replace(/\s*\.\s*$/, ''));
      if (exprText) {
        const r = resolveExprType(src, pos, exprText, parsed);
        if (r.type) {
          const ms = membersOfType(r.type);
          const curT = JavaSrc.typeAt(parsed, pos);
          for (const m of ms) {
            if (!match(m.name)) continue;
            if (r.isStatic && !m.static && m.kind !== 'type') continue;
            if (m.mods && m.mods.includes('private') && !(curT && curT.name === m.owner)) continue;
            list.push(memberItem(m));
          }
          if (r.isStatic && match('class')) list.push(item('class', 'class : Class<' + JavaSrc.simpleName(r.type) + '>', ICONS.keyword, 'kw'));
          sortItems(list, prefix);
          return finish(cm, list, CodeMirror.Pos(cur.line, start), cur);
        }
        // 型が分からないときは、何も出さない (Eclipse も候補なし)
        return finish(cm, [], CodeMirror.Pos(cur.line, start), cur);
      }
    }

    if (!prefix && !(options && options.allowEmpty)) {
      // 空のときもテンプレートとローカルを出す (Ctrl+Space)
    }

    const curT = JavaSrc.typeAt(parsed, pos);
    // ローカル変数・パラメーター
    const locals = collectLocals(src, pos);
    const seenNames = new Set();
    for (const l of locals) {
      if (match(l.name) && !seenNames.has(l.name)) { seenNames.add(l.name); list.push(item(l.name, l.name + ' : ' + l.type, ICONS.local, 'local', 0)); }
    }
    // このクラスのメンバー
    if (curT) {
      for (const m of membersOfType(curT.name)) {
        if (!match(m.name) || seenNames.has(m.name + (m.kind === 'method' ? '()' : ''))) continue;
        seenNames.add(m.name + (m.kind === 'method' ? '()' : ''));
        list.push(memberItem(m, 1));
      }
    }
    // テンプレート
    if (prefix) {
      for (const t of TEMPLATES) {
        if (t.name.toLowerCase().startsWith(lower)) {
          list.push({ text: t.name, displayText: t.name, detail: t.name + ' - ' + t.desc, icon: ICONS.template, kind: 'template', rank: 3, template: t, render: renderItem, hint: applyTemplate, doc: t.body.replace(/\$\{(\w*)\}/g, (x, v) => v === 'cursor' ? '' : v || '') });
        }
      }
    }
    // 型 (クラス名)
    if (prefix && /^[A-Za-z]/.test(prefix)) {
      for (const [n, arr] of allClassNames()) {
        if (!match(n)) continue;
        for (const c of arr) {
          list.push({ text: n, displayText: n, detail: n + ' - ' + c.pkg, icon: typeIcon(c.kind), kind: 'class', rank: /^[A-Z]/.test(prefix) ? 1 : 4, pkg: c.pkg, render: renderItem, hint: applyClass });
        }
      }
    }
    // キーワード
    if (prefix) {
      for (const k of KEYWORDS) if (k.startsWith(prefix) && k !== prefix) list.push(item(k, k, ICONS.keyword, 'kw', 5));
    }
    sortItems(list, prefix);
    return finish(cm, list, CodeMirror.Pos(cur.line, start), cur);
  }

  function camelMatch(name, prefix) {
    // "AL" → ArrayList のようなキャメルケースの一致
    if (!/^[A-Z]{2,}/.test(prefix)) return false;
    const caps = name.replace(/[^A-Z]/g, '');
    return caps.startsWith(prefix.replace(/[^A-Z]/g, ''));
  }

  function extractExpr(s) {
    // 末尾から式を取り出す: foo.bar(1, 2).baz
    let i = s.length - 1, depth = 0;
    for (; i >= 0; i--) {
      const ch = s[i];
      if (ch === ')' || ch === ']') depth++;
      else if (ch === '(' || ch === '[') { if (depth === 0) break; depth--; }
      else if (depth === 0 && !/[\w$.\s"]/.test(ch)) break;
      else if (depth === 0 && /\s/.test(ch)) {
        // 空白の前が . なら続ける
        let j = i; while (j >= 0 && /\s/.test(s[j])) j--;
        const k = i + 1; while (k < s.length && /\s/.test(s[k])) {}
        if (j >= 0 && s[j] === '.') { i = j + 1; continue; }
        if (s[i + 1] === '.') continue;
        break;
      }
    }
    let e = s.slice(i + 1).trim();
    const nm = s.slice(0, i + 1).match(/\bnew\s*$/);
    if (nm) e = 'new ' + e;
    return e.replace(/\s*\.\s*/g, '.');
  }

  function collectLocals(src, pos) {
    const b = JavaSrc.blank(src).slice(0, pos);
    // 現在のメソッドの開始位置 (簡易: 直前の "){" かメソッド宣言)
    const out = [];
    const re = /(?:^|[\s(,;{])(?:final\s+)?([A-Za-z_][\w.]*(?:\s*<[^;(){}=]*?>)?(?:\s*\[\s*\])*)\s+([a-z_$][\w$]*)\s*(?=[=;,):])/g;
    let m;
    while ((m = re.exec(b))) {
      const t = m[1].replace(/\s+/g, '');
      if (['return', 'new', 'throw', 'else', 'case', 'package', 'import', 'class', 'extends', 'implements', 'instanceof'].includes(t)) continue;
      if (PRIMITIVES.includes(m[2]) || KEYWORDS.includes(m[2])) continue;
      // スコープの判定は省略 (直近の宣言を優先)
      out.unshift({ name: m[2], type: t, at: m.index });
    }
    return out;
  }

  function item(text, detail, icon, kind, rank) {
    return { text, displayText: text, detail, icon, kind, rank: rank == null ? 2 : rank, render: renderItem };
  }
  function memberItem(m, rank) {
    // その型自身のメンバーを先に、Object から受け継いだものを後ろに並べる
    if (rank == null) rank = m.owner === 'Object' ? 3 : 1;
    if (m.kind === 'method') {
      const sig = m.name + '(' + m.params.map(p => p.type + (p.name ? ' ' + p.name : '')).join(', ') + ') : ' + m.ret + ' - ' + (m.owner || '');
      return { text: m.name + '(' + ')', displayText: m.name, detail: sig, icon: memberIcon(Object.assign({ mods: m.static ? ['public', 'static'] : ['public'] }, m)), kind: 'method', rank: rank == null ? 2 : rank, member: m, render: renderItem, hint: applyMethod };
    }
    return { text: m.name, displayText: m.name, detail: m.name + ' : ' + m.type + ' - ' + (m.owner || ''), icon: memberIcon(Object.assign({ mods: ['public'] }, m)), kind: 'field', rank: rank == null ? 2 : rank, render: renderItem };
  }
  function renderItem(el, self, data) {
    el.innerHTML = '';
    const ic = document.createElement('span');
    ic.innerHTML = data.icon || '';
    ic.style.display = 'inline-flex';
    el.appendChild(ic);
    const t = document.createElement('span');
    t.className = 'h-text';
    t.textContent = data.detail || data.displayText;
    el.appendChild(t);
  }
  function sortItems(list, prefix) {
    list.sort((a, b) => {
      const ea = a.displayText === prefix ? 0 : 1, eb = b.displayText === prefix ? 0 : 1;
      if (ea !== eb) return ea - eb;
      if (a.rank !== b.rank) return a.rank - b.rank;
      return a.displayText.localeCompare(b.displayText);
    });
    // 重複を除く
    const seen = new Set();
    for (let i = list.length - 1; i >= 0; i--) {
      const k = list[i].detail + list[i].kind;
      if (seen.has(k)) list.splice(i, 1); else seen.add(k);
    }
  }
  function finish(cm, list, from, to) {
    const r = { list, from, to };
    CodeMirror.on(r, 'close', () => { const d = document.querySelector('.hint-doc'); if (d) d.remove(); });
    CodeMirror.on(r, 'select', (data, el) => {
      let d = document.querySelector('.hint-doc');
      if (!data.doc) { if (d) d.remove(); return; }
      if (!d) { d = document.createElement('div'); d.className = 'hint-doc'; document.body.appendChild(d); }
      d.textContent = data.doc;
      const box = el.parentNode.getBoundingClientRect();
      d.style.left = (box.right + 4) + 'px';
      d.style.top = box.top + 'px';
    });
    return r;
  }

  function applyMethod(cm, data, completion) {
    const m = completion.member;
    const text = m.name + '(' + ')';
    cm.replaceRange(text, data.from, data.to, 'complete');
    const end = cm.getCursor();
    if (m.params && m.params.length) {
      // 引数の名前を仮に入れて選択 (Eclipse の「引数名を挿入」に近い動き)
      const names = m.params.map(p => p.name || 'arg');
      const pos = CodeMirror.Pos(end.line, end.ch - 1);
      cm.replaceRange(names.join(', '), pos, pos, 'complete');
      const starts = [];
      let ch = pos.ch;
      for (const n of names) { starts.push({ from: CodeMirror.Pos(pos.line, ch), to: CodeMirror.Pos(pos.line, ch + n.length), name: n + '#' + starts.length }); ch += n.length + 2; }
      startLinked(cm, starts, CodeMirror.Pos(pos.line, ch - 2 + 1));
    }
  }

  function applyClass(cm, data, completion) {
    cm.replaceRange(completion.text, data.from, data.to, 'complete');
    addImport(cm, completion.text, completion.pkg);
  }

  /** 必要なら import 文を足す */
  function addImport(cm, name, pkg) {
    if (!pkg || pkg === 'java.lang') return;
    const src = cm.getValue();
    const parsed = JavaSrc.parse(src);
    if (pkg === parsed.pkg) return;
    const fq = pkg + '.' + name;
    if (parsed.imports.some(i => i.name === fq || i.name === pkg + '.*')) return;
    if (parsed.imports.some(i => !i.static && i.name.endsWith('.' + name))) return; // 同名を別にインポート済み
    const lines = src.split('\n');
    let insertLine, text;
    if (parsed.imports.length) {
      // 並び順を保って挿入
      const imps = parsed.imports.filter(i => !i.static);
      let after = imps[imps.length - 1];
      for (const i of imps) if (i.name.localeCompare(fq) < 0) after = i;
      const firstBigger = imps.find(i => i.name.localeCompare(fq) > 0);
      if (firstBigger && (!after || after.name.localeCompare(fq) > 0)) { insertLine = firstBigger.line; text = 'import ' + fq + ';\n'; }
      else { insertLine = after.line + 1; text = 'import ' + fq + ';\n'; }
    } else if (parsed.pkgLine >= 0) {
      insertLine = parsed.pkgLine + 1;
      // package 行のあとに「空行・import・空行」の形で入れる
      text = (lines[insertLine] !== undefined && lines[insertLine].trim() === '') ? '\nimport ' + fq + ';\n' : '\nimport ' + fq + ';\n\n';
    } else {
      insertLine = 0; text = 'import ' + fq + ';\n\n';
    }
    cm.replaceRange(text, CodeMirror.Pos(insertLine, 0), null, 'complete');
  }

  // ---------------------------------------------------------------
  // テンプレートの展開と「リンク・モード」(Tab で次の入力欄へ)
  // ---------------------------------------------------------------
  function applyTemplate(cm, data, completion) {
    const t = completion.template;
    const src = cm.getValue();
    const pos = cm.indexFromPos(data.from);
    const indentUnit = cm.getOption('indentUnit');
    const lineText = cm.getLine(data.from.line);
    const baseIndent = lineText.match(/^\s*/)[0];
    const parsed = JavaSrc.parse(src);
    const curT = JavaSrc.typeAt(parsed, pos);
    const guess = guessTemplateVars(src, pos, curT, parsed);
    let body = t.body.replace(/\t/g, ' '.repeat(indentUnit)).replace(/\n/g, '\n' + baseIndent);
    // ${name} を値に置き換え、位置を記録する
    const holes = [];
    let out = '', cursorAt = -1, i = 0;
    const re = /\$\{(\w*)\}/g; let m;
    while ((m = re.exec(body))) {
      out += body.slice(i, m.index);
      const name = m[1];
      if (name === 'cursor') cursorAt = out.length;
      else if (name === 'enclosing_type') out += curT ? curT.name : 'Type';
      else if (name === 'enclosing_method') out += guess.method || 'method';
      else {
        const val = guess[name] || (name === '' ? '' : name);
        holes.push({ name: name || ('_' + holes.length), start: out.length, len: val.length });
        out += val;
      }
      i = m.index + m[0].length;
    }
    out += body.slice(i);
    cm.replaceRange(out, data.from, data.to, 'complete');
    const base = cm.indexFromPos(data.from);
    const marks = holes.map(h => ({ name: h.name, from: cm.posFromIndex(base + h.start), to: cm.posFromIndex(base + h.start + h.len) }));
    const exitPos = cursorAt >= 0 ? cm.posFromIndex(base + cursorAt) : cm.posFromIndex(base + out.length);
    if (marks.length) startLinked(cm, marks, exitPos);
    else cm.setCursor(exitPos);
    // 型が必要なら import
    if (t.name === 'new' || t.name === 'try') { /* 何もしない */ }
  }

  function guessTemplateVars(src, pos, curT, parsed) {
    const g = { index: 'i', condition: 'condition', key: 'key', value: 'value', Exception: 'Exception', type: 'type', name: 'name', arguments: '', return_type: 'void', visibility: 'private', NAME: 'NAME', iterable: 'iterable', iterable_type: 'type', iterable_element: 'element', array: 'array', array_type: 'type', array_element: 'element', collection: 'collection' };
    const locals = collectLocals(src, pos);
    const arr = locals.find(l => /\[\]$/.test(l.type));
    if (arr) { g.array = arr.name; g.array_type = arr.type.replace(/\[\]$/, ''); g.array_element = singular(arr.name); }
    const it = locals.find(l => /\[\]$/.test(l.type) || /^(List|ArrayList|Set|HashSet|Collection|LinkedList|Iterable)\b/.test(l.type));
    if (it) {
      g.iterable = it.name;
      g.iterable_type = /\[\]$/.test(it.type) ? it.type.replace(/\[\]$/, '') : (JavaSrc.typeArgs(it.type)[0] || 'Object');
      g.iterable_element = singular(it.name);
    }
    if (curT) {
      const meth = curT.members.filter(m => m.kind === 'method' || m.kind === 'ctor');
      const b = JavaSrc.blank(src);
      let best = null;
      for (const m of meth) { const lp = lineStartIndex(src, m.line); if (lp <= pos) best = m; }
      if (best) g.method = best.name;
    }
    return g;
  }
  function lineStartIndex(src, line) { let p = 0; for (let i = 0; i < line; i++) { p = src.indexOf('\n', p) + 1; if (p === 0) return src.length; } return p; }
  function singular(n) {
    if (/ies$/.test(n)) return n.replace(/ies$/, 'y');
    if (/s$/.test(n) && n.length > 2) return n.replace(/s$/, '');
    return n === 'list' ? 'item' : n + 'Item';
  }

  let linked = null;
  function startLinked(cm, holes, exitPos) {
    stopLinked(cm);
    const groups = new Map();
    const marks = holes.map(h => {
      const mk = cm.markText(h.from, h.to, { className: 'linked-ph', inclusiveLeft: true, inclusiveRight: true, clearWhenEmpty: false });
      if (!groups.has(h.name)) groups.set(h.name, []);
      groups.get(h.name).push(mk);
      return { name: h.name, mark: mk };
    });
    const order = [...groups.keys()];
    const exitMark = cm.setBookmark(exitPos, { insertLeft: true });
    linked = { cm, groups, order, idx: 0, exitMark, syncing: false };
    selectGroup(0);
    const onChange = (cm2, change) => {
      if (!linked || linked.syncing || change.origin === 'setValue') return;
      // 現在のグループの最初の値を、同じ名前の他の欄にも反映
      const name = linked.order[linked.idx];
      const ms = linked.groups.get(name) || [];
      const first = ms[0] && ms[0].find();
      if (!first) return;
      const val = cm.getRange(first.from, first.to);
      linked.syncing = true;
      cm.operation(() => {
        for (const mk of ms.slice(1)) { const r = mk.find(); if (r && cm.getRange(r.from, r.to) !== val) cm.replaceRange(val, r.from, r.to, '+linked'); }
      });
      linked.syncing = false;
      // カーソルがすべての欄の外に出たら終了
    };
    const onCursor = () => {
      if (!linked || linked.syncing) return;
      const c = cm.getCursor();
      const inside = [...linked.groups.values()].flat().some(mk => { const r = mk.find(); return r && CodeMirror.cmpPos(c, r.from) >= 0 && CodeMirror.cmpPos(c, r.to) <= 0; });
      if (!inside) stopLinked(cm);
    };
    linked.onChange = onChange; linked.onCursor = onCursor;
    cm.on('change', onChange);
    cm.on('cursorActivity', onCursor);
  }
  function selectGroup(i) {
    const l = linked;
    l.idx = i;
    for (const [n, ms] of l.groups) for (const mk of ms) {
      const r = mk.find();
      if (!r) continue;
    }
    const ms = l.groups.get(l.order[i]);
    const r = ms && ms[0].find();
    if (r) { l.syncing = true; l.cm.setSelection(r.from, r.to); l.syncing = false; }
  }
  function stopLinked(cm) {
    if (!linked) return;
    for (const ms of linked.groups.values()) for (const mk of ms) mk.clear();
    linked.cm.off('change', linked.onChange);
    linked.cm.off('cursorActivity', linked.onCursor);
    if (linked.exitMark) linked.exitMark.clear();
    linked = null;
  }
  /** Tab / Shift+Tab / Enter をリンク・モードで処理。処理したら true */
  function linkedKey(cm, key) {
    if (!linked || linked.cm !== cm) return false;
    if (key === 'Esc') { stopLinked(cm); return true; }
    if (key === 'Tab' || key === 'Shift-Tab') {
      const n = linked.order.length;
      let i = linked.idx + (key === 'Tab' ? 1 : -1);
      if (i >= n) { const p = linked.exitMark.find(); stopLinked(cm); if (p) cm.setCursor(p); return true; }
      if (i < 0) i = n - 1;
      selectGroup(i);
      return true;
    }
    if (key === 'Enter') { const p = linked.exitMark.find(); stopLinked(cm); if (p) cm.setCursor(p); return true; }
    return false;
  }

  // ---------------------------------------------------------------
  // フォーマット (Ctrl+Shift+F)
  //   インデントを {} に合わせて付け直し、よくある空白を整える。
  //   (教材と同じ「スペース 4 つ」でインデントする)
  // ---------------------------------------------------------------
  function format(src, indentUnit, useTabs) {
    const unit = useTabs ? '\t' : ' '.repeat(indentUnit || 4);
    const lines = src.replace(/\r\n?/g, '\n').split('\n');
    const out = [];
    let depth = 0;
    let inBlockComment = false;
    let parenDepth = 0;
    let pendingCaseIndent = false;
    let blankRun = 0;
    let switchStack = [];
    for (let raw of lines) {
      let line = raw.replace(/\s+$/, '');
      const trimmed = line.trim();
      if (inBlockComment) {
        out.push(trimmed.startsWith('*') ? unit.repeat(depth) + ' ' + trimmed : (trimmed ? unit.repeat(depth) + trimmed : ''));
        if (trimmed.includes('*/')) inBlockComment = false;
        blankRun = 0;
        continue;
      }
      if (!trimmed) { blankRun++; if (blankRun <= 1) out.push(''); continue; }
      blankRun = 0;
      const spaced = spaceLine(trimmed);
      const code = codeOnly(spaced);
      // 行頭の } で先に下げる
      let lead = 0;
      for (const ch of code) { if (ch === '}' || ch === ')') lead++; else break; }
      let lineDepth = Math.max(0, depth - countLeadingClosers(code));
      const isCase = /^(case\b.*:|default\s*:)/.test(code) || /^(case\b.*->|default\s*->)/.test(code);
      const inSwitch = switchStack.length && switchStack[switchStack.length - 1] === depth - 0;
      let extra = 0;
      if (switchStack.length && !isCase && switchStack[switchStack.length - 1] === lineDepth && !/^}/.test(code)) extra = 1;
      // 続きの行 (前の行が ; { } で終わっていない) は 2 段下げる
      const prev = out.length ? codeOnly(out[out.length - 1].trim()) : '';
      const cont = prev && !/[;{}:,]$/.test(prev) && !/^(@\w+|\/\/|\*|\/\*)/.test(prev) && !/^[{}]/.test(code) && !/^\/\//.test(code) && parenDepth > 0;
      out.push(unit.repeat(lineDepth + extra + (cont ? 2 : 0)) + spaced);
      // 深さの更新
      for (const ch of code) {
        if (ch === '{') depth++;
        else if (ch === '}') { depth--; if (switchStack.length && switchStack[switchStack.length - 1] > depth) switchStack.pop(); }
        else if (ch === '(') parenDepth++;
        else if (ch === ')') parenDepth = Math.max(0, parenDepth - 1);
      }
      if (/^switch\b.*\{$/.test(code) || /\bswitch\s*\(.*\)\s*\{$/.test(code)) switchStack.push(depth);
      if (/\/\*/.test(spaced) && !/\*\//.test(spaced.slice(spaced.indexOf('/*')))) inBlockComment = true;
      depth = Math.max(0, depth);
    }
    while (out.length && out[out.length - 1] === '') out.pop();
    return out.join('\n') + '\n';
  }
  function countLeadingClosers(code) { let n = 0; for (const ch of code) { if (ch === '}') n++; else if (ch === ' ' ) continue; else break; } return n; }
  /** 文字列・コメントを除いたコード部分 */
  function codeOnly(line) {
    return JavaSrc.blank(line).replace(/\s+$/, '');
  }
  /** 1 行の中の空白を整える (文字列とコメントは触らない) */
  function spaceLine(line) {
    if (/^(\/\/|\*|\/\*)/.test(line)) return line;
    // 文字列とコメントを退避
    const saved = [];
    let s = line.replace(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\/\/.*$|\/\*.*?\*\//g, (m) => { saved.push(m); return '\u0000' + (saved.length - 1) + '\u0000'; });
    s = s.replace(/\b(if|for|while|switch|catch|synchronized|try)\(/g, '$1 (');
    s = s.replace(/\)\{/g, ') {');
    s = s.replace(/\b(else|try|finally|do)\{/g, '$1 {');
    s = s.replace(/\}(else|catch|finally|while)\b/g, '} $1');
    s = s.replace(/([\w>\]])\{$/g, '$1 {');
    s = s.replace(/,(?=\S)/g, ', ');
    s = s.replace(/\s+,/g, ',');
    s = s.replace(/;(?=[^\s)])/g, '; ');
    s = s.replace(/\(\s+/g, '(').replace(/\s+\)/g, ')');
    // 二項演算子の前後に空白 (=, ==, !=, <=, >=, &&, ||, +=, -=, *=, /=, %=)
    s = s.replace(/\s*(==|!=|<=|>=|&&|\|\||\+=|-=|\*=|\/=|%=)\s*/g, ' $1 ');
    s = s.replace(/([^=!<>+\-*/%&|^\s])\s*=(?!=)\s*/g, '$1 = ');
    s = s.replace(/([^\s=!<>])=\s+/g, '$1 = ');
    // + - * / % (単項でない場合)
    s = s.replace(/([\w)\]"\u0000])\s*([+\-*/%])(?![+\-=])\s*(?=[\w("'\u0000])/g, (m, a, op) => a + ' ' + op + ' ');
    // < > (ジェネリクスでない比較)
    s = s.replace(/([a-z_\d)\]])\s*(<|>)(?![<>=])\s*(?=[\w(\-])/g, (m, a, op, off, all) => {
      // List<String> のような型引数は除外 (直前の語が大文字始まり)
      const before = all.slice(0, off + 1).match(/(\w+)$/);
      if (before && /^[A-Z]/.test(before[1])) return m;
      return a + ' ' + op + ' ';
    });
    s = s.replace(/ {2,}/g, ' ');
    s = s.replace(/\u0000(\d+)\u0000/g, (m, i) => saved[+i]);
    return s;
  }

  // ---------------------------------------------------------------
  // インポートの編成 (Ctrl+Shift+O)
  // ---------------------------------------------------------------
  function organizeImports(src, askChoice) {
    const parsed = JavaSrc.parse(src);
    const b = JavaSrc.blank(src);
    // import 文以外の部分で使われている大文字始まりの名前
    let body = b;
    for (const im of parsed.imports.slice().reverse()) body = body.slice(0, im.from) + ' '.repeat(im.to - im.from) + body.slice(im.to);
    body = body.replace(/^\s*package\s+[\w.]+\s*;/m, '');
    const used = new Set();
    const re = /(?<![\w.])([A-Z][\w]*)\b/g;
    let m;
    while ((m = re.exec(body))) used.add(m[1]);
    // @Override などのアノテーション
    const declared = new Set();
    const walk = (types) => { for (const t of types) { declared.add(t.name); walk(t.members.filter(x => x.kind === 'type').map(x => x.type)); } };
    walk(parsed.types);
    // 型パラメーター <T>
    (body.match(/<\s*([A-Z])\s*(?:extends[^>]*)?>/g) || []).forEach(x => declared.add(x.replace(/[<>\s]|extends.*/g, '')));
    const classes = allClassNames();
    const keep = [];
    const statics = parsed.imports.filter(i => i.static);
    for (const im of parsed.imports.filter(i => !i.static)) {
      const sn = im.name.split('.').pop();
      if (sn === '*' || used.has(sn)) keep.push(im.name);
    }
    const need = [];
    const ambiguous = [];
    for (const name of used) {
      if (declared.has(name)) continue;
      if (keep.some(k => k.endsWith('.' + name))) continue;
      const cands = (classes.get(name) || []).filter(c => c.pkg !== 'java.lang' && c.pkg !== parsed.pkg);
      if ((classes.get(name) || []).some(c => c.pkg === 'java.lang' || c.pkg === parsed.pkg)) continue;
      if (!cands.length) continue;
      const pkgs = [...new Set(cands.map(c => c.pkg))];
      if (pkgs.length === 1) need.push(pkgs[0] + '.' + name);
      else ambiguous.push({ name, pkgs });
    }
    return { parsed, keep, need, ambiguous, statics };
  }
  function applyImports(src, info, chosen) {
    const all = [...new Set([...info.keep, ...info.need, ...(chosen || [])])];
    const groups = { java: [], javax: [], org: [], com: [], other: [] };
    for (const n of all) {
      const top = n.split('.')[0];
      (groups[top] || groups.other).push(n);
    }
    const blocks = [];
    for (const k of ['java', 'javax', 'org', 'com', 'other']) if (groups[k].length) blocks.push(groups[k].sort().map(n => 'import ' + n + ';').join('\n'));
    const stat = info.statics.map(i => 'import static ' + i.name + ';');
    let importText = [stat.join('\n'), blocks.join('\n\n')].filter(Boolean).join('\n\n');
    // 既存の import をすべて取り除いて入れ直す
    const lines = src.split('\n');
    const impLines = new Set(info.parsed.imports.map(i => i.line));
    const kept = lines.filter((l, i) => !impLines.has(i));
    // package 行の後ろに入れる
    let pkgIdx = kept.findIndex(l => /^\s*package\s/.test(l));
    // import を消した跡の連続空行を詰める
    const cleaned = [];
    for (let i = 0; i < kept.length; i++) {
      if (i > pkgIdx && kept[i].trim() === '' && cleaned.length && cleaned[cleaned.length - 1].trim() === '' && i < (pkgIdx + 4 + impLines.size)) continue;
      cleaned.push(kept[i]);
    }
    pkgIdx = cleaned.findIndex(l => /^\s*package\s/.test(l));
    let rest = cleaned.slice(pkgIdx + 1);
    while (rest.length && rest[0].trim() === '') rest.shift();
    const head = cleaned.slice(0, pkgIdx + 1);
    const parts = [];
    if (head.length) parts.push(head.join('\n'));
    if (importText) parts.push(importText);
    parts.push(rest.join('\n'));
    return parts.join('\n\n');
  }

  // ---------------------------------------------------------------
  // コード生成 (ソース メニュー)
  // ---------------------------------------------------------------
  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function genGetter(f, ind) {
    const prefix = f.type === 'boolean' ? 'is' : 'get';
    return `${ind}public ${f.type} ${prefix}${cap(f.name)}() {\n${ind}${ind}return ${f.name};\n${ind}}`;
  }
  function genSetter(f, ind, isStatic) {
    const target = isStatic ? f.owner + '.' + f.name : 'this.' + f.name;
    return `${ind}public ${isStatic ? 'static ' : ''}void set${cap(f.name)}(${f.type} ${f.name}) {\n${ind}${ind}${target} = ${f.name};\n${ind}}`;
  }
  function genToString(t, fields, ind) {
    if (!fields.length) return `${ind}@Override\n${ind}public String toString() {\n${ind}${ind}return "${t.name} []";\n${ind}}`;
    const parts = fields.map((f, i) => `${i === 0 ? '"' + t.name + ' [' : '", '}${f.name}=" + ${f.name}`);
    return `${ind}@Override\n${ind}public String toString() {\n${ind}${ind}return ${parts.join(' + ')} + "]";\n${ind}}`;
  }
  function genCtor(t, fields, ind, omitSuper) {
    const params = fields.map(f => f.type + ' ' + f.name).join(', ');
    const body = (omitSuper ? [] : [`${ind}${ind}super();`]).concat(fields.map(f => `${ind}${ind}this.${f.name} = ${f.name};`));
    return `${ind}public ${t.name}(${params}) {\n${body.join('\n')}\n${ind}}`;
  }

  return {
    LIB, ICONS, TEMPLATES, setContext, hint, membersOfType, memberIcon, typeIcon, addImport,
    linkedKey, stopLinked, format, organizeImports, applyImports,
    genGetter, genSetter, genToString, genCtor, allClassNames, cap,
    isLinked: () => !!linked,
  };
})();
