// お手軽Java - サーバー (Tomcat の代わり): サーバー・ビュー・概要エディター・追加および除去・サーバーで実行
//   HTML入門の教材と同じく、Eclipse のサーバー・ビューで Tomcat11_Java25 を開始・停止し、
//   ポートは概要エディターの「HTTP/1.1」の行で変える (Tomcat と同じく最初は 8080)。
//   実際に HTML を配信するのは、ローカル・サーバー (tools/server.ps1・server.pl) の /api/web
'use strict';

(() => {
  const { $, $$, baseName, editors, esc, files, projectOf, run, settings } = IDE;
  const { consoleAppend, consoleClear, contextRoot, dialog, fileKind, fmtTime, icon, isDirty, isWebProject, openCustomEditor, projects, saveAll,
    saveResourcesDialog, saveSettings, setConsoleTitle, showContextMenu, showError, status, webContentRoot } = IDE.fn;

  const NAME = 'Tomcat11_Java25';
  const RUNTIME = 'Tomcat11 (Java25)';
  // サーバーの設定 (ポートと、追加したプロジェクト)。Eclipse の Servers プロジェクトの代わりに、ワークスペースの隠しフォルダーに置く
  const CONFIG = '.otegaru/servers.json';
  const DEFAULT_CONFIG = { httpPort: 8080, adminPort: 8005, modules: [] };
  const srv = { running: false, port: 0, busy: '', selected: null, expanded: true };

  function config() {
    try { return Object.assign({}, DEFAULT_CONFIG, JSON.parse(files.get(CONFIG) || '{}')); } catch (e) { return Object.assign({}, DEFAULT_CONFIG); }
  }
  async function saveConfig(c) {
    const text = JSON.stringify(c, null, 2) + '\n';
    await Storage.writeFile(CONFIG, text);
    files.set(CONFIG, text);
  }
  /** サーバーに追加してあるプロジェクト (今もある動的 Web プロジェクトだけ) */
  function modules(c) { return (c || config()).modules.filter(p => projects().includes(p) && isWebProject(p)); }
  function moduleSpecs(c) { return modules(c).map(p => ({ context: contextRoot(p), dir: webContentRoot(p) })); }
  const baseUrl = port => `http://localhost${port === 80 ? '' : ':' + port}`;

  function stateLabel() {
    if (srv.busy === 'start') return '[始動中]';
    if (srv.busy === 'stop') return '[停止中]';
    if (!srv.running) return '[停止]';
    return srv.port !== config().httpPort ? '[起動済み, 再始動]' : '[起動済み, 同期済み]';
  }

  // =================================================================
  // サーバー・ビュー
  // =================================================================
  async function initServers() {
    $('#server-tools').innerHTML = [['srvStart', '開始', 'serverStart'], ['srvRestart', '再始動', 'serverRestart'], ['srvStop', '停止', 'serverStop']]
      .map(([ic, t, cmd]) => `<button class="tb-mini" data-cmd="${cmd}" title="${t}">${icon(ic)}</button>`).join('');
    $$('#server-tools [data-cmd]').forEach(b => b.addEventListener('click', () => IDE.command(b.dataset.cmd)));
    const el = $('#servers');
    el.addEventListener('mousedown', e => {
      const row = e.target.closest('.srv-row');
      srv.selected = row ? row.dataset.id : null;
      if (row && e.target.closest('.tree-twisty') && row.dataset.id === 'server') srv.expanded = !srv.expanded;
      renderServers();
    });
    el.addEventListener('dblclick', e => { if (e.target.closest('.srv-row[data-id="server"]')) openOverview(); });
    el.addEventListener('contextmenu', e => {
      e.preventDefault();
      const row = e.target.closest('.srv-row');
      srv.selected = row ? row.dataset.id : null;
      renderServers();
      if (!row) return;
      const mod = row.dataset.id.startsWith('M:') ? row.dataset.id.slice(2) : null;
      showContextMenu([
        { label: '開く', cmd: 'serverOpen', key: 'F3' },
        '-',
        { label: '開始', cmd: 'serverStart', icon: 'srvStart', enabled: () => !srv.running && !srv.busy },
        { label: '再始動', cmd: 'serverRestart', icon: 'srvRestart', enabled: () => srv.running && !srv.busy },
        { label: '停止', cmd: 'serverStop', icon: 'srvStop', enabled: () => srv.running && !srv.busy },
        '-',
        { label: '追加および除去...', cmd: 'serverAddRemove' },
        ...(mod ? [{ label: '除去', action: () => removeModule(mod) }] : []),
      ], e.clientX, e.clientY);
    });
    el.addEventListener('keydown', e => { if (e.key === 'F3' || e.key === 'Enter') { e.preventDefault(); openOverview(); } });
    // ローカル・サーバー側で動いているか (画面を読み込み直したときなど)
    try {
      const st = await Storage.webState();
      if (st && st.running) { srv.running = true; srv.port = st.port; await Storage.webModules(moduleSpecs()); }
    } catch (e) { /* 古いサーバーなど */ }
    renderServers();
  }

  function renderServers() {
    const el = $('#servers');
    if (!el) return;
    if (Storage.mode !== 'server') {
      el.innerHTML = '<div class="ol-empty">サーバーは、start.bat (Mac は start.command) から起動したときだけ使えます。</div>';
      return;
    }
    const mods = modules();
    const row = (id, depth, html, leaf) => `<div class="tree-row srv-row${srv.selected === id ? ' selected' : ''}" data-id="${esc(id)}" style="padding-left:${depth * 16 + 2}px"><span class="tree-twisty">${leaf ? '' : (srv.expanded ? '⌄' : '›')}</span>${html}</div>`;
    let h = row('server', 0, `<span class="tree-icon">${icon('server')}</span><span class="tree-label">${NAME}  <span class="dim">${stateLabel()}</span></span>`, !mods.length);
    if (srv.expanded) for (const m of mods) h += row('M:' + m, 1, `<span class="tree-icon">${icon('module')}</span><span class="tree-label">${esc(m)}${srv.running ? '  <span class="dim">[同期済み]</span>' : ''}</span>`, true);
    el.innerHTML = h;
    const tb = cmd => $(`#server-tools [data-cmd="${cmd}"]`);
    if (tb('serverStart')) {
      tb('serverStart').disabled = srv.running || !!srv.busy;
      tb('serverStop').disabled = !srv.running || !!srv.busy;
      tb('serverRestart').disabled = !srv.running || !!srv.busy;
    }
  }

  // =================================================================
  // 開始・停止
  // =================================================================
  /** Tomcat と同じ形のログ (java.util.logging の既定の書式) */
  function logStamp(d) {
    const h = d.getHours() % 12 || 12;
    return `${d.getMonth() + 1}月 ${String(d.getDate()).padStart(2, '0')}, ${d.getFullYear()} ${h}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')} ${d.getHours() < 12 ? '午前' : '午後'}`;
  }
  function serverLog(lines) {
    // Java のプログラムを実行中なら、そのコンソールは消さない
    if (run.running) return;
    const now = new Date();
    for (const [cls, msg] of lines) consoleAppend(`${logStamp(now)} ${cls}\n情報: ${msg}\n`, 'err');
  }

  async function startServer() {
    if (Storage.mode !== 'server') { showError('サーバーを開始できません', 'サーバーは、start.bat (Mac は start.command) から起動したときだけ使えます。'); return false; }
    if (srv.running || srv.busy) return srv.running;
    const c = config();
    srv.busy = 'start'; renderServers();
    const t0 = performance.now();
    try {
      const st = await Storage.webStart(c.httpPort, moduleSpecs(c));
      srv.running = !!st.running; srv.port = st.port;
      if (!run.running) {
        consoleClear();
        setConsoleTitle(`${NAME} [Apache Tomcat] (${fmtTime(new Date())})`);
      }
      serverLog([
        ['org.apache.coyote.AbstractProtocol start', `プロトコルハンドラー ["http-nio-${c.httpPort}"] を開始しています`],
        ['org.apache.catalina.startup.Catalina start', `[${Math.max(1, Math.round(performance.now() - t0))}] ミリ秒でサーバーが起動しました`],
      ]);
      status(`${NAME} を開始しました: ${baseUrl(c.httpPort)}/`);
    } catch (e) {
      srv.running = false;
      const inUse = /使用中/.test(e.message);
      await dialog({
        title: inUse ? 'ポートが使用中です' : 'サーバーを開始できません', icon: 'error',
        message: inUse
          ? `localhost の ${NAME} が必要とするポートは、すでに使用中です。サーバーがすでに別のプロセスとして実行されているか、システムのプロセスがそのポートを使用している可能性があります。このサーバーを開始するには、そのプロセスを停止するか、ポート番号を変更する必要があります。\n\nHTTP/1.1 のポート: ${c.httpPort}`
          : e.message,
      });
    } finally {
      srv.busy = ''; renderServers();
    }
    return srv.running;
  }

  async function stopServer() {
    if (!srv.running || srv.busy) return;
    srv.busy = 'stop'; renderServers();
    try {
      await Storage.webStop();
      serverLog([
        ['org.apache.coyote.AbstractProtocol pause', `プロトコルハンドラー ["http-nio-${srv.port}"] を一時停止しています`],
        ['org.apache.catalina.core.StandardService stopInternal', 'サービス [Catalina] を停止しています'],
      ]);
      if (!run.running) setConsoleTitle(`<終了> ${NAME} [Apache Tomcat] (${fmtTime(new Date())})`);
      srv.running = false;
      status(`${NAME} を停止しました`);
    } catch (e) { showError('サーバーを停止できません', e.message); } finally { srv.busy = ''; renderServers(); }
  }

  async function restartServer() {
    await stopServer();
    await startServer();
  }

  /** 追加したプロジェクトが変わったら、動いているサーバーにすぐ伝える (Eclipse の「即時に公開」) */
  async function publish() {
    if (srv.running) { try { await Storage.webModules(moduleSpecs()); } catch (e) { showError('公開できません', e.message); } }
    renderServers();
  }
  async function removeModule(p) {
    const c = config();
    c.modules = c.modules.filter(x => x !== p);
    await saveConfig(c);
    await publish();
  }

  // =================================================================
  // 概要エディター (サーバーをダブルクリック): ポートの変更
  // =================================================================
  function openOverview() {
    openCustomEditor('server:' + NAME, NAME, 'server', (pane, markDirty) => {
      const c = config();
      pane.innerHTML = `<div class="srv-editor">
        <div class="srv-head">${icon('server')}<span>概要</span></div>
        <div class="srv-cols">
          <section><h3>一般情報</h3><p class="hint">サーバー名、およびその他の共通設定を指定します。</p>
            <div class="row"><label>サーバー名(<u>N</u>):</label><input type="text" value="${NAME}" readonly></div>
            <div class="row"><label>ホスト名(<u>H</u>):</label><input type="text" value="localhost" readonly></div>
            <div class="row"><label>ランタイム環境:</label><input type="text" value="${RUNTIME}" readonly></div>
            <div class="row"><label>構成パス(<u>C</u>):</label><input type="text" value="/Servers/${NAME}-config" readonly></div>
          </section>
          <section><h3>ポート</h3><p class="hint">このサーバーで使用されるポートを変更します。</p>
            <table class="mk-table srv-ports"><thead><tr><th>ポート名</th><th>ポート番号</th></tr></thead><tbody>
              <tr><td>Tomcat 管理ポート</td><td><input type="text" data-port="adminPort" value="${c.adminPort}" spellcheck="false"></td></tr>
              <tr><td>HTTP/1.1</td><td><input type="text" data-port="httpPort" value="${c.httpPort}" spellcheck="false"></td></tr>
            </tbody></table>
            <div class="srv-msg" id="srv-msg"></div>
          </section>
        </div></div>`;
      const inputs = $$('[data-port]', pane);
      const valid = v => /^\d+$/.test(v) && +v >= 1 && +v <= 65535;
      const check = () => {
        const bad = inputs.find(i => !valid(i.value.trim()));
        $('#srv-msg', pane).textContent = bad ? 'ポート番号には、1 から 65535 までの数を入力してください。' : '';
      };
      for (const inp of inputs) {
        inp.addEventListener('input', () => { markDirty(); check(); });
        inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); inp.blur(); } });
      }
      return {
        async save() {
          const bad = inputs.find(i => !valid(i.value.trim()));
          if (bad) throw new Error('ポート番号には、1 から 65535 までの数を入力してください。');
          const c2 = config();
          for (const i of inputs) c2[i.dataset.port] = +i.value.trim();
          await saveConfig(c2);
          renderServers();
          status(srv.running && srv.port !== c2.httpPort ? `ポートを ${c2.httpPort} にしました。反映するには、サーバーを再始動してください` : `${NAME} の設定を保存しました`);
        },
        focus() { const i = inputs[inputs.length - 1]; if (i) i.focus(); },
      };
    });
  }

  // =================================================================
  // 追加および除去
  // =================================================================
  async function addRemoveDialog() {
    if (Storage.mode !== 'server') { showError('追加および除去', 'サーバーは、start.bat (Mac は start.command) から起動したときだけ使えます。'); return; }
    let configured = modules();
    const all = projects().filter(isWebProject);
    if (!all.length) { await dialog({ title: '追加および除去', icon: 'info', message: 'サーバーに追加できるプロジェクトがありません。\n先に動的 Web プロジェクトを作成してください。' }); return; }
    let selAv = null, selCf = null;
    const r = await dialog({
      title: '追加および除去', width: 620, help: true,
      banner: { title: '追加および除去', message: 'サーバーで構成されているリソースを変更します', icon: 'webwizard' },
      html: `<div style="margin-bottom:6px">リソースを左に移動するとサーバーから除去し、右に移動するとサーバーで構成します。</div>
        <div class="ar-grid">
          <div><div>使用可能(<u>A</u>):</div><div class="dlg-list" id="ar-av"></div></div>
          <div class="dlg-side" style="justify-content:center">
            <button class="dlg-btn" id="ar-add">追加(<u>D</u>) &gt;</button><button class="dlg-btn" id="ar-rm">&lt; 除去(<u>R</u>)</button>
            <button class="dlg-btn" id="ar-addall">すべて追加(<u>L</u>) &gt;&gt;</button><button class="dlg-btn" id="ar-rmall">&lt;&lt; すべて除去(<u>E</u>)</button></div>
          <div><div>構成済み(<u>C</u>):</div><div class="dlg-list" id="ar-cf"></div></div>
        </div>
        <label class="chk" style="margin-top:8px"><input type="checkbox" checked disabled>変更をサーバーで即時に公開する(<u>P</u>)</label>`,
      buttons: [{ label: '< 戻る(B)', value: 'back' }, { label: '次へ(N) >', value: 'next' }, { label: '完了(F)', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: () => ({ configured }),
      onOpen: d => {
        $('[data-b="0"]', d).disabled = true; $('[data-b="1"]', d).disabled = true;
        const draw = () => {
          const av = all.filter(p => !configured.includes(p));
          const li = (p, sel) => `<div class="li${sel === p ? ' sel' : ''}" data-p="${esc(p)}" style="${sel === p ? 'background:var(--sel)' : ''}">${icon('webproject')} ${esc(p)}</div>`;
          $('#ar-av', d).innerHTML = av.map(p => li(p, selAv)).join('');
          $('#ar-cf', d).innerHTML = configured.map(p => li(p, selCf)).join('');
          $('#ar-add', d).disabled = !av.includes(selAv); $('#ar-addall', d).disabled = !av.length;
          $('#ar-rm', d).disabled = !configured.includes(selCf); $('#ar-rmall', d).disabled = !configured.length;
          $$('#ar-av .li', d).forEach(x => { x.onclick = () => { selAv = x.dataset.p; draw(); }; x.ondblclick = () => { configured.push(x.dataset.p); selAv = null; draw(); }; });
          $$('#ar-cf .li', d).forEach(x => { x.onclick = () => { selCf = x.dataset.p; draw(); }; x.ondblclick = () => { configured = configured.filter(p => p !== x.dataset.p); selCf = null; draw(); }; });
        };
        $('#ar-add', d).onclick = () => { if (selAv) configured.push(selAv); selAv = null; draw(); };
        $('#ar-rm', d).onclick = () => { configured = configured.filter(p => p !== selCf); selCf = null; draw(); };
        $('#ar-addall', d).onclick = () => { configured = all.slice(); selAv = null; draw(); };
        $('#ar-rmall', d).onclick = () => { configured = []; selCf = null; draw(); };
        selAv = all.find(p => !configured.includes(p)) || null;
        draw();
      },
    });
    if (!r || r.value !== 'ok') return;
    const c = config();
    c.modules = r.configured;
    await saveConfig(c);
    srv.expanded = true;
    await publish();
  }

  // =================================================================
  // サーバーで実行 (HTML ファイルを Chrome の別のタブで開く)
  // =================================================================
  async function runOnServer(path) {
    const p = path ? projectOf(path) : null;
    if (!path || fileKind(path) !== 'html' || !isWebProject(p)) {
      await dialog({ title: 'サーバーで実行', icon: 'info', message: 'サーバーで実行できるのは、動的 Web プロジェクトの HTML ファイルです。' });
      return;
    }
    const root = webContentRoot(p) + '/';
    const rel = path.startsWith(root) ? path.slice(root.length) : null;
    if (!rel || /^(WEB-INF|META-INF)\//i.test(rel)) {
      await dialog({ title: 'サーバーで実行', icon: 'info', message: `'${baseName(path)}' は、ブラウザーから開ける場所 (${root.slice(p.length + 1, -1)} の中。WEB-INF と META-INF を除く) にありません。` });
      return;
    }
    // 保存していないエディターがあれば、Java の実行と同じく保存を確かめる
    const dirty = editors.filter(isDirty);
    if (dirty.length) {
      if (settings.saveBeforeLaunch !== 'always') {
        const r = await saveResourcesDialog(dirty);
        if (!r) return;
        if (r.always) { settings.saveBeforeLaunch = 'always'; saveSettings(); }
      }
      await saveAll();
    }
    const c = config();
    if (!modules(c).includes(p)) {
      const ok = await dialog({ title: 'サーバーで実行', icon: 'info', message: `'${p}' は、サーバー ${NAME} に追加されていません。\n追加して開きますか? (サーバー・ビューの「追加および除去」と同じです)`, buttons: [{ label: '追加して開く', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!ok) return;
      c.modules = [...c.modules.filter(x => x !== p), p];
      await saveConfig(c);
      await publish();
    }
    if (!srv.running) {
      const ok = await dialog({ title: 'サーバーで実行', icon: 'info', message: `サーバー ${NAME} は停止しています。\n開始して開きますか?`, buttons: [{ label: '開始して開く', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!ok || !(await startServer())) return;
    }
    const url = `${baseUrl(srv.port)}/${encodeURIComponent(contextRoot(p))}/${rel.split('/').map(encodeURIComponent).join('/')}`;
    const w = window.open(url, '_blank');
    if (w) { w.opener = null; status(`${url} を開きました`); }
    else await dialog({ title: 'サーバーで実行', icon: 'info', message: 'ブラウザーが新しいタブを開くのを止めました。次の URL を開いてください。', html: `<p><a href="${esc(url)}" target="_blank" rel="noopener">${esc(url)}</a></p>` });
  }

  /** 教材などから、URL だけを知りたいとき (サーバーが動いていれば) */
  function pageUrl(path) {
    const p = projectOf(path);
    const root = webContentRoot(p) + '/';
    if (!srv.running || !path.startsWith(root)) return null;
    return `${baseUrl(srv.port)}/${contextRoot(p)}/${path.slice(root.length)}`;
  }

  Object.assign(IDE, { addRemoveDialog, initServers, openOverview, pageUrl, renderServers, restartServer, runOnServer, startServer, stopServer });
})();
