// お手軽Java - メニューとツールバー
'use strict';

(() => {
  const { S, $, $$, editors, esc, run, settings } = IDE;
  const { command, icon, isDirty, keyLabel } = IDE.fn;

  // =================================================================
  // メニュー
  // =================================================================
  /** 「新規」の項目 (メニュー・ツールバー・エクスプローラーの右クリックで共通) */
  function newMenuItems() {
    return [
      { label: 'Java プロジェクト', cmd: 'newProject', icon: 'project' },
      { label: '動的 Web プロジェクト', cmd: 'newWebProject', icon: 'webproject' },
      '-',
      { label: 'パッケージ', cmd: 'newPackage', icon: 'package' },
      { label: 'クラス', cmd: 'newClass', icon: 'class' },
      { label: 'インターフェース', cmd: 'newInterface', icon: 'interface' },
      '-',
      { label: 'フォルダー', cmd: 'newFolder', icon: 'folder' },
      { label: 'ファイル', cmd: 'newFile', icon: 'file' },
      { label: 'HTML ファイル', cmd: 'newHtmlFile', icon: 'htmlfile' },
      { label: 'CSS ファイル', cmd: 'newCssFile', icon: 'cssfile' },
    ];
  }

  const MENUS = [
    { label: 'ファイル', key: 'F', items: [
      { label: '新規', sub: newMenuItems() },
      '-',
      { label: '閉じる', cmd: 'closeEditor', key: 'Ctrl+F4', enabled: () => !!S.active },
      { label: 'すべて閉じる', cmd: 'closeAll', key: 'Ctrl+Shift+F4', enabled: () => editors.length > 0 },
      '-',
      { label: '保存', cmd: 'save', key: 'Ctrl+S', icon: 'save', enabled: () => S.active && isDirty(S.active) },
      { label: 'すべて保存', cmd: 'saveAll', key: 'Ctrl+Shift+S', icon: 'saveall', enabled: () => editors.some(isDirty) },
      { label: '前回保存した状態に戻す', cmd: 'revert', enabled: () => S.active && isDirty(S.active) },
      '-',
      { label: '名前変更...', cmd: 'rename', key: 'F2' },
      { label: 'リフレッシュ', cmd: 'refresh', key: 'F5' },
      '-',
      { label: 'インポート (ワークスペースから外したプロジェクト)...', cmd: 'importProject' },
      { label: 'ワークスペースのフォルダーを開く', cmd: 'openFolder', enabled: () => Storage.mode === 'server' },
      '-',
      { label: '終了', cmd: 'exit' },
    ] },
    { label: '編集', key: 'E', items: [
      { label: '元に戻す', cmd: 'undo', key: 'Ctrl+Z', enabled: () => !!S.active },
      { label: 'やり直し', cmd: 'redo', key: 'Ctrl+Y', enabled: () => !!S.active },
      '-',
      { label: '切り取り', cmd: 'cut', key: 'Ctrl+X', enabled: () => !!S.active },
      { label: 'コピー', cmd: 'copy', key: 'Ctrl+C', enabled: () => !!S.active },
      { label: '貼り付け', cmd: 'paste', key: 'Ctrl+V', enabled: () => !!S.active },
      '-',
      { label: 'すべて選択', cmd: 'selectAll', key: 'Ctrl+A', enabled: () => !!S.active },
      '-',
      { label: '検索/置換...', cmd: 'find', key: 'Ctrl+F', enabled: () => !!S.active },
      { label: '次を検索', cmd: 'findNext', key: 'Ctrl+K', enabled: () => !!S.active },
      { label: '前を検索', cmd: 'findPrev', key: 'Ctrl+Shift+K', enabled: () => !!S.active },
      '-',
      { label: 'コンテンツ・アシスト', cmd: 'contentAssist', key: 'Ctrl+Space', enabled: () => !!S.active },
      { label: 'ワード補完', cmd: 'wordComplete', key: 'Alt+/', enabled: () => !!S.active },
      { label: 'クイック・フィックス', cmd: 'quickFix', key: 'Ctrl+1', enabled: () => !!S.active },
    ] },
    { label: 'ソース', key: 'S', items: [
      { label: 'コメントの切り替え', cmd: 'toggleComment', key: 'Ctrl+/', enabled: () => !!S.active },
      { label: 'ブロック・コメントの追加', cmd: 'blockComment', key: 'Ctrl+Shift+/', enabled: () => !!S.active },
      { label: 'ブロック・コメントの除去', cmd: 'blockUncomment', key: 'Ctrl+Shift+\\', enabled: () => !!S.active },
      '-',
      { label: 'シフト右', cmd: 'shiftRight', enabled: () => !!S.active },
      { label: 'シフト左', cmd: 'shiftLeft', enabled: () => !!S.active },
      { label: 'インデントの訂正', cmd: 'correctIndent', key: 'Ctrl+I', enabled: () => !!S.active },
      { label: 'フォーマット', cmd: 'format', key: 'Ctrl+Shift+F', enabled: () => !!S.active },
      '-',
      { label: 'インポートの追加', cmd: 'addImport', key: 'Ctrl+Shift+M', enabled: () => !!S.active },
      { label: 'インポートの編成', cmd: 'organizeImports', key: 'Ctrl+Shift+O', enabled: () => !!S.active },
      '-',
      { label: 'getter および setter の生成...', cmd: 'genGetSet', enabled: () => !!S.active },
      { label: 'toString() の生成...', cmd: 'genToString', enabled: () => !!S.active },
      { label: 'フィールドを使用してコンストラクターを生成...', cmd: 'genCtor', enabled: () => !!S.active },
    ] },
    { label: 'リファクタリング', key: 'T', items: [
      { label: '名前変更...', cmd: 'renameSymbol', key: 'Alt+Shift+R', enabled: () => !!S.active },
    ] },
    { label: 'ナビゲート', key: 'N', items: [
      { label: '宣言を開く', cmd: 'openDecl', key: 'F3', enabled: () => !!S.active },
      { label: '行へ移動...', cmd: 'gotoLine', key: 'Ctrl+L', enabled: () => !!S.active },
      '-',
      { label: '次の注釈', cmd: 'nextAnnotation', key: 'Ctrl+.', enabled: () => !!S.active },
      { label: '前の注釈', cmd: 'prevAnnotation', key: 'Ctrl+,', enabled: () => !!S.active },
      { label: '対応する大括弧へ移動', cmd: 'matchBracket', key: 'Ctrl+Shift+P', enabled: () => !!S.active },
    ] },
    { label: '検索', key: 'A', items: [
      { label: '検索...', cmd: 'searchWorkspace', key: 'Ctrl+H' },
      { label: 'ファイル内の出現箇所', cmd: 'markOccurrencesNow', key: 'Ctrl+Shift+U', enabled: () => !!S.active },
    ] },
    { label: 'プロジェクト', key: 'P', items: [
      { label: 'すべてビルド', cmd: 'buildAll', key: 'Ctrl+B' },
      { label: 'クリーン...', cmd: 'clean' },
      { label: '自動的にビルド', cmd: 'toggleAutoBuild', checked: () => settings.autoBuild },
    ] },
    { label: '実行', key: 'R', items: [
      { label: '実行', cmd: 'run', key: 'Ctrl+F11', icon: 'run' },
      { label: '実行 → Java アプリケーション', cmd: 'runSelected', key: 'Alt+Shift+X, J', icon: 'run' },
      '-',
      { label: '終了', cmd: 'terminate', icon: 'terminate', enabled: () => run.running },
    ] },
    { label: 'ウィンドウ', key: 'W', items: [
      { label: 'ビューの表示', sub: [
        { label: 'パッケージ・エクスプローラー', cmd: 'showExplorer' },
        { label: 'アウトライン', cmd: 'showOutline' },
        { label: 'マーカー', cmd: 'showMarkers' },
        { label: 'コンソール', cmd: 'showConsole' },
        { label: 'サーバー', cmd: 'showServers' },
        { label: '検索', cmd: 'showSearch' },
        { label: 'レッスン', cmd: 'showLesson' },
      ] },
      { label: 'アクティブなビューまたはエディターの最大化', cmd: 'maximize', key: 'Ctrl+M' },
      { label: 'パースペクティブのリセット...', cmd: 'resetPerspective' },
      '-',
      { label: 'テーマの切り替え (ライト/ダーク)', cmd: 'toggleTheme' },
      { label: '設定', cmd: 'preferences' },
    ] },
    { label: 'ヘルプ', key: 'H', items: [
      { label: 'ようこそ', cmd: 'welcome' },
      { label: 'Java入門 (Qiita) の目次を開く', cmd: 'lessonIndex' },
      { label: 'HTML入門 (Qiita) の目次を開く', cmd: 'lessonIndexHtml' },
      '-',
      { label: 'キー・アシスト...', cmd: 'keyAssist', key: 'Ctrl+Shift+L' },
      '-',
      { label: 'お手軽Java について', cmd: 'about' },
    ] },
  ];

  let openMenu = null;
  function buildMenus() {
    const bar = $('#menubar');
    bar.innerHTML = '';
    MENUS.forEach((m, i) => {
      const el = document.createElement('div');
      el.className = 'menu-top';
      el.innerHTML = `${esc(m.label)}(<u>${m.key}</u>)`;
      el.addEventListener('mousedown', e => { e.preventDefault(); if (openMenu && openMenu.top === el) closeMenus(); else showMenu(m.items, el); });
      el.addEventListener('mouseenter', () => { if (openMenu && openMenu.top !== el) showMenu(m.items, el); });
      bar.appendChild(el);
    });
    document.addEventListener('mousedown', e => { if (openMenu && !e.target.closest('.menu-popup') && !e.target.closest('.menu-top')) closeMenus(); });
  }
  function closeMenus() {
    $$('.menu-popup.dyn').forEach(x => x.remove());
    $$('.menu-top.open').forEach(x => x.classList.remove('open'));
    openMenu = null;
  }
  function showMenu(items, top, x, y) {
    closeMenus();
    let rect = top ? top.getBoundingClientRect() : { left: x, bottom: y };
    if (top) top.classList.add('open');
    const pop = renderMenu(items, rect.left, rect.bottom, 0);
    openMenu = { top, pop };
  }
  function renderMenu(items, x, y, level) {
    const pop = document.createElement('div');
    pop.className = 'menu-popup dyn';
    pop.dataset.level = level;
    for (const it of items) {
      if (it === '-') { const s = document.createElement('div'); s.className = 'menu-sep'; pop.appendChild(s); continue; }
      const el = document.createElement('div');
      const enabled = it.enabled ? it.enabled() : true;
      const checked = it.checked ? it.checked() : false;
      el.className = 'menu-item' + (it.sub ? ' sub' : '') + (enabled ? '' : ' disabled') + (checked ? ' checked' : '');
      el.innerHTML = `<span class="mi-icon">${it.icon ? icon(it.icon) : ''}</span><span class="mi-label">${esc(it.label)}</span><span class="mi-key">${esc(keyLabel(it.key || ''))}</span>`;
      if (it.sub) {
        el.addEventListener('mouseenter', () => {
          $$('.menu-popup.dyn').filter(p => +p.dataset.level > level).forEach(p => p.remove());
          $$('.menu-item.open', pop).forEach(x => x.classList.remove('open'));
          el.classList.add('open');
          const r = el.getBoundingClientRect();
          renderMenu(it.sub, r.right - 2, r.top - 3, level + 1);
        });
      } else {
        el.addEventListener('mouseenter', () => { $$('.menu-popup.dyn').filter(p => +p.dataset.level > level).forEach(p => p.remove()); $$('.menu-item.open', pop).forEach(x => x.classList.remove('open')); });
        el.addEventListener('mouseup', e => { if (!enabled) return; closeMenus(); hideCtx(); if (it.action) it.action(); else command(it.cmd); });
      }
      pop.appendChild(el);
    }
    document.body.appendChild(pop);
    const r = pop.getBoundingClientRect();
    pop.style.left = Math.min(x, window.innerWidth - r.width - 4) + 'px';
    pop.style.top = Math.min(y, window.innerHeight - r.height - 4) + 'px';
    return pop;
  }
  function hideCtx() { closeMenus(); }
  function showContextMenu(items, x, y) { closeMenus(); renderMenu(items, x, y, 0); openMenu = { top: null }; }

  // =================================================================
  // ツールバー
  // =================================================================
  function buildToolbar() {
    const tb = $('#toolbar');
    const btn = (ic, title, cmd, opts = {}) => `<button class="tb-btn" data-cmd="${cmd}" title="${esc(title)}" ${opts.id ? `id="${opts.id}"` : ''}>${icon(ic)}${opts.drop ? '<span class="drop">▼</span>' : ''}</button>`;
    tb.innerHTML = [
      btn('newwiz', '新規 (プロジェクト・パッケージ・クラス・HTML ファイルなど)', 'newMenu', { drop: true }),
      btn('save', '保存 (Ctrl+S)', 'save', { id: 'tb-save' }),
      btn('saveall', 'すべて保存 (Ctrl+Shift+S)', 'saveAll', { id: 'tb-saveall' }),
      '<span class="tb-sep"></span>',
      btn('project', '新規 Java プロジェクト', 'newProject'),
      btn('package', '新規 Java パッケージ', 'newPackage'),
      btn('class', '新規 Java クラス', 'newClass'),
      btn('interface', '新規 Java インターフェース', 'newInterface'),
      '<span class="tb-sep"></span>',
      btn('build', 'すべてビルド (Ctrl+B)', 'buildAll'),
      btn('run', '実行 (Ctrl+F11)', 'run', { id: 'tb-run' }),
      btn('terminate', '終了', 'terminate', { id: 'tb-terminate' }),
      '<span class="tb-sep"></span>',
      btn('search', '検索 (Ctrl+H)', 'searchWorkspace'),
      btn('lesson', 'レッスンを表示', 'showLesson'),
      `<span class="tb-label" id="tb-mode"></span>`,
    ].join('');
    tb.addEventListener('click', e => {
      const b = e.target.closest('[data-cmd]');
      if (!b || b.disabled) return;
      if (b.dataset.cmd === 'newMenu') { const r = b.getBoundingClientRect(); showContextMenu(MENUS[0].items[0].sub, r.left, r.bottom); return; }
      command(b.dataset.cmd);
    });
    $('#tb-mode').textContent = Storage.mode === 'server' ? 'ワークスペース: ' + (Storage.rootPath || '').split(/[\\/]/).pop() : 'ワークスペース: ブラウザ保存';
    updateToolbar();
  }
  function updateToolbar() {
    const s = $('#tb-save'); if (s) s.disabled = !(S.active && isDirty(S.active));
    const sa = $('#tb-saveall'); if (sa) sa.disabled = !editors.some(isDirty);
    const t = $('#tb-terminate'); if (t) t.disabled = !run.running;
    const bt = $('#btn-terminate'); if (bt) bt.disabled = !run.running;
  }

  Object.assign(IDE, { MENUS, newMenuItems, buildMenus, buildToolbar, closeMenus, hideCtx, renderMenu, showContextMenu, showMenu, updateToolbar });
})();
