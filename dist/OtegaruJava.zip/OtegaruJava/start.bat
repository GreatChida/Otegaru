@echo off
rem Otegaru Java launcher (no install needed)
chcp 65001 > nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\server.ps1" %*
if errorlevel 1 pause
