﻿# Qiita「【Java入門】」シリーズの最新の本文を取得して、www\lessons\lessons.js を作り直す
#   使い方: powershell -ExecutionPolicy Bypass -File tools\update-lessons.ps1
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$out = Join-Path $Root 'www\lessons\lessons.js'
# 目次と各章の記事 ID (目次の順番)
$ids = @(
  '1f0f457d575d4a675c16',
  '6b86112b31faf9091e22', 'd9fe44e3fb2aab706c2c', 'f1d480420fbed38749c8',
  'c9a1813d5ce79c710434', '3a00a5d8154c5c3a5550', '18c6addcb4204d9cbf4e',
  'da06429557905f21b1ab', 'af8e8c4db8e5f61f0b7c', '9145186438ecf5c973f4',
  '3bb1d0850b04b262d078', '25fa2bda4b19ee9e596f', '37acc161b028d6a285a6',
  '4c0d6954d199b7d51941', '7d073b54a53ac623deff', '743cfd1b90cb36315ae5'
)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$list = New-Object System.Collections.ArrayList
foreach ($id in $ids) {
  Write-Host "取得中: $id"
  $res = Invoke-WebRequest -UseBasicParsing -Uri "https://qiita.com/api/v2/items/$id"
  $json = [System.Text.Encoding]::UTF8.GetString($res.RawContentStream.ToArray()) | ConvertFrom-Json
  [void]$list.Add([ordered]@{
    id = $id
    title = $json.title.Replace('【Java入門】', '').Trim()
    url = $json.url
    updated = $json.updated_at
    body = $json.body
  })
  Start-Sleep -Milliseconds 300
}
$body = ConvertTo-Json -InputObject $list -Depth 4 -Compress
$text = "// Qiita「【Java入門】」シリーズ (chida0818) の本文。tools/update-lessons.ps1 で最新に更新できます`nwindow.LESSONS = $body;`n"
[System.IO.File]::WriteAllText($out, $text, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "作成しました: $out"
