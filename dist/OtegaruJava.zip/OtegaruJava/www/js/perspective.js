// 画面 (パースペクティブ) の切り替え: 「HTML入門/Java入門 (Eclipse 風)」と「DB入門 (SQL Developer 風)」
//  - 右上のボタンで切り替える。メニュー・ツールバー・ショートカットは画面ごとに変わる
//  - 右のレッスン・ビューは両方の画面で使う (切り替えるときに DOM ごと移す)
//  - 画面ごとに、最後に開いていた教材 (Java入門・HTML入門 / DB入門) を覚えておく
'use strict';

const Perspective = (() => {
  const { $, esc, ui } = IDE;
  const F = IDE.fn;
  const KEY = 'otekaru.perspective';
  const LIST = {
    eclipse: { label: 'HTML入門/Java入門', title: 'HTML入門・Java入門 (Eclipse 風) の画面', icon: 'project' },
    db: { label: 'DB入門', title: 'DB入門 (SQL Developer 風) の画面', icon: 'dbconn' },
  };
  let current = null;

  function switcherHtml() {
    return `<span class="persp" role="tablist" title="画面の切り替え">${Object.entries(LIST).map(([k, v]) =>
      `<button class="persp-btn${k === current ? ' on' : ''}" data-persp="${k}" title="${esc(v.title)}">${F.icon(v.icon)}<span>${esc(v.label)}</span></button>`).join('')}</span>`;
  }

  function set(p, first) {
    if (!LIST[p]) p = 'eclipse';
    if (p === current && !first) return;
    // 今の画面で開いていた教材を覚える
    if (current && typeof Lesson !== 'undefined') { ui.lessonCourse = Object.assign({}, ui.lessonCourse, { [current]: Lesson.course }); }
    current = p;
    try { localStorage.setItem(KEY, p); } catch (e) { /* 無視 */ }
    document.body.dataset.perspective = p;
    F.closeMenus();
    const db = p === 'db';
    $('#workbench').style.display = db ? 'none' : '';
    $('#db-workbench').style.display = db ? '' : 'none';
    // 右のレッスン (とサッシ) を、表示する画面へ移す
    const host = db ? $('#db-workbench') : $('#workbench');
    host.appendChild($('#sash-right'));
    host.appendChild($('#right'));
    if (db) DbUI.activate();
    else {
      F.buildMenus(IDE.MENUS);
      F.buildToolbar();
      F.refreshEditors();
    }
    // 教材を画面に合わせる (DB入門の画面では DB入門、Eclipse 風の画面では Java入門・HTML入門)
    const want = (ui.lessonCourse || {})[p] || (db ? 'db' : 'java');
    const fits = c => db ? c === 'db' : c !== 'db';
    if (typeof Lesson !== 'undefined' && !fits(Lesson.course)) Lesson.setCourse(fits(want) ? want : (db ? 'db' : 'java'));
    F.saveUi();
  }

  function init() {
    let p = 'eclipse';
    try { p = localStorage.getItem(KEY) || 'eclipse'; } catch (e) { /* 無視 */ }
    // ツールバーの切り替えボタン (どちらの画面のツールバーにもある)
    document.addEventListener('click', e => {
      const b = e.target.closest('[data-persp]');
      if (b) set(b.dataset.persp);
    });
    set(p, true);
  }

  return { init, set, switcherHtml, get current() { return current; } };
})();
