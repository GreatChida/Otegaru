// お手軽Java - マーカー (エディターの × と波線・マーカー・ビュー・ツールチップ)
'use strict';

(() => {
  const { S, $, $$, ICON_SVG, baseName, esc, files, parentOf, problems, projectOf } = IDE;
  const { gotoPos, icon, openEditor, projects } = IDE.fn;

  // ---------- マーカー (エディター内の × と波線) ----------
  function applyMarkers(ed) {
    const cm = ed.cm;
    cm.operation(() => {
      for (const m of ed.marks) m.clear();
      ed.marks = [];
      cm.clearGutter('markers');
      const list = (problems.get(projectOf(ed.path)) || []).filter(p => p.path === ed.path);
      const byLine = new Map();
      for (const p of list) {
        const prev = byLine.get(p.line);
        if (!prev || (p.kind === 'ERROR' && prev.kind !== 'ERROR')) byLine.set(p.line, p);
        // 波線
        let from, to;
        const doc = files.get(ed.path) || '';
        if (p.start >= 0 && p.end >= p.start && cm.getValue() === doc) {
          from = cm.posFromIndex(p.start); to = cm.posFromIndex(p.end + 1);
        } else {
          from = { line: p.line, ch: p.col }; to = { line: p.line, ch: p.col + 1 };
          const t = cm.getLine(p.line) || '';
          let e = p.col; while (e < t.length && /[\w$]/.test(t[e])) e++;
          if (e > p.col) to.ch = e;
        }
        if (CodeMirror.cmpPos(from, to) === 0) to = { line: to.line, ch: to.ch + 1 };
        ed.marks.push(cm.markText(from, to, { className: p.kind === 'ERROR' ? 'squiggly-error' : 'squiggly-warning', attributes: { 'data-msg': p.msg, 'data-kind': p.kind } }));
      }
      for (const [line, p] of byLine) {
        const all = list.filter(x => x.line === line);
        const el = document.createElement('div');
        el.className = 'marker';
        el.innerHTML = p.kind === 'ERROR' ? ICON_SVG.error : ICON_SVG.warning;
        el.dataset.msg = all.map(x => x.msg).join('\n');
        el.dataset.kind = p.kind;
        cm.setGutterMarker(line, 'markers', el);
      }
      // 概要ルーラー (右端)
      const lc = Math.max(1, cm.lineCount());
      const hasErr = list.some(x => x.kind === 'ERROR'), hasWarn = list.length > 0;
      ed.ruler.innerHTML = `<div class="om-top ${hasErr ? 'error' : hasWarn ? 'warning' : ''}" title="${hasErr ? 'エラーがあります' : hasWarn ? '警告があります' : '問題なし'}"></div>` +
        list.map(p => `<div class="om ${p.kind === 'ERROR' ? 'error' : 'warning'}" style="top:${14 + (p.line / lc) * (ed.pane.clientHeight - 30)}px" data-line="${p.line}" title="${esc(p.msg)}"></div>`).join('');
      $$('.om', ed.ruler).forEach(o => o.onclick = () => gotoPos(ed, +o.dataset.line, 0, true));
    });
  }

  // ---------- マーカー・ビュー ----------
  function renderMarkers() {
    const el = $('#markers');
    const all = [];
    for (const [proj, list] of problems) if (projects().includes(proj)) all.push(...list);
    const errs = all.filter(p => p.kind === 'ERROR'), warns = all.filter(p => p.kind !== 'ERROR');
    const row = (p, i) => {
      const rel = p.path.includes('/') ? p.path : p.path;
      return `<tr class="row" data-i="${i}"><td><div class="mk-desc">${p.kind === 'ERROR' ? ICON_SVG.error : ICON_SVG.warning}<span>${esc(p.msg)}</span></div></td><td>${esc(baseName(rel))}</td><td>${esc('/' + parentOf(rel))}</td><td>行 ${p.line + 1}</td><td>Java の問題</td></tr>`;
    };
    const sorted = errs.concat(warns);
    el._items = sorted;
    const groupRow = (label, n, open) => `<tr class="group"><td colspan="5">${open ? '⌄' : '›'} ${label} (${n} 項目)</td></tr>`;
    el.innerHTML = `<div class="mk-summary">エラー ${errs.length}、警告 ${warns.length}、その他 0</div>
      <table class="mk-table"><colgroup><col style="width:52%"><col style="width:14%"><col style="width:16%"><col style="width:8%"><col style="width:10%"></colgroup>
      <thead><tr><th>説明</th><th>リソース</th><th>パス</th><th>ロケーション</th><th>型</th></tr></thead><tbody>
      ${errs.length ? groupRow('Java の問題 (エラー)', errs.length, true) + errs.map((p, i) => row(p, i)).join('') : ''}
      ${warns.length ? groupRow('Java の問題 (警告)', warns.length, true) + warns.map((p, i) => row(p, errs.length + i)).join('') : ''}
      </tbody></table>`;
    $$('tr.row', el).forEach(tr => {
      tr.addEventListener('mousedown', () => { $$('tr.row.selected', el).forEach(x => x.classList.remove('selected')); tr.classList.add('selected'); });
      tr.addEventListener('dblclick', () => { const p = el._items[+tr.dataset.i]; if (files.has(p.path)) openEditor(p.path, { line: p.line, col: p.col, flash: true }); });
    });
    // タブに件数
    const tab = $('#bottom-tabs .view-tab[data-view="markers"]');
    tab.innerHTML = `<span class="vi">${icon('markers')}</span>マーカー${all.length ? ` <span style="color:var(--text-dim)">(${all.length})</span>` : ''}`;
  }

  // ---------- ツールチップ ----------
  function initTooltips() {
    const tt = $('#tooltip');
    document.addEventListener('mouseover', e => {
      const t = e.target.closest('.marker, [data-msg]');
      if (!t || !t.dataset.msg) { tt.hidden = true; return; }
      const kind = t.dataset.kind;
      tt.innerHTML = t.dataset.msg.split('\n').map(m => `<div class="tt-row">${kind === 'ERROR' ? ICON_SVG.error : ICON_SVG.warning}<span>${esc(m)}</span></div>`).join('');
      tt.hidden = false;
      const r = t.getBoundingClientRect();
      tt.style.left = Math.min(r.left, window.innerWidth - 420) + 'px';
      tt.style.top = (r.bottom + 4) + 'px';
    });
  }

  Object.assign(IDE, { applyMarkers, initTooltips, renderMarkers });
})();
