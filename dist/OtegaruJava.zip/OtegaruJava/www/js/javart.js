// CheerpJ の上で Eclipse のコンパイラー (ECJ) と java を動かす層
//  - JDK のインストールは不要。CheerpJ の Java ランタイム (OpenJDK) の上で ECJ を動かす
//  - CheerpJ は cheerpjRunMain のたびに Java の static な状態を初期化するため、
//    実行ヘルパー otekaru.Runner を「常駐」させ、コマンドを 1 つずつ渡す。
//    こうするとコンパイラーの準備を使い回せて、2 回目以降のコンパイルが 0.1 秒ほどになる。
//  - 実行ヘルパー (runtime/*.java) は初回だけブラウザ内でコンパイルし、
//    CheerpJ の /files/ (IndexedDB) に保存したものを使う
'use strict';

const JavaRT = (() => {
  const CHEERPJ_LOADER = 'https://cjrtnc.leaningtech.com/5.0/loader.js';
  const SEP = '\u0001';
  let version = 17;
  let runnerCp = '';
  let readyPromise = null;
  let queue = Promise.resolve();
  let busy = 0;

  // 常駐している Java とのやり取り
  let serving = null;      // cheerpjRunMain の Promise
  let cmdWaiter = null;    // Java が次のコマンドを待っているときの resolve
  let pendingCmd = null;   // Java がまだ受け取っていないコマンド
  let doneWaiter = null;   // 実行中のコマンドの完了を待つ resolve/reject
  let handlers = null;     // 実行中のコマンドの出力先
  let pendingFiles = '';
  let warmedRelease = null;

  const natives = {
    async Java_otekaru_Runner_out(lib, s) { handlers && handlers.out && handlers.out(s); },
    async Java_otekaru_Runner_err(lib, s) { handlers && handlers.err && handlers.err(s); },
    async Java_otekaru_Runner_readLine(lib) {
      if (!handlers || !handlers.readLine) return null;
      const v = await handlers.readLine();
      return v == null ? null : String(v);
    },
    async Java_otekaru_Runner_diag(lib, kind, file, line, col, start, end, code, msg) {
      handlers && handlers.diag && handlers.diag({ kind, file, line, col, start, end, code, msg });
    },
    async Java_otekaru_Runner_done(lib, kind, code) {
      const w = doneWaiter; doneWaiter = null;
      if (w) w.resolve(code);
    },
    async Java_otekaru_Runner_pullFiles(lib) { return pendingFiles; },
    async Java_otekaru_Runner_nextCommand(lib) {
      if (pendingCmd != null) { const c = pendingCmd; pendingCmd = null; return c; }
      return new Promise(r => { cmdWaiter = r; });
    },
  };

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = resolve;
      s.onerror = () => reject(new Error('CheerpJ を読み込めませんでした。インターネットに接続されているか確認してください。'));
      document.head.appendChild(s);
    });
  }

  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(36);
  }

  async function fileExists(path) {
    try { const b = await cjFileBlob(path); return !!b && b.size > 0; } catch (e) { return false; }
  }

  /** 常駐ヘルパーを起動する (止まっていたら起動し直す) */
  function startServe() {
    if (serving) return;
    serving = cheerpjRunMain('otekaru.Runner', runnerCp, 'serve').then(code => {
      // System.exit() などで Java が止まった
      serving = null; cmdWaiter = null; warmedRelease = null;
      const w = doneWaiter; doneWaiter = null;
      if (w) w.resolve(typeof code === 'number' ? code : -1);
    }, err => {
      serving = null; cmdWaiter = null; warmedRelease = null;
      const w = doneWaiter; doneWaiter = null;
      if (w) w.reject(err);
    });
  }

  /** コマンドを 1 つ実行して、終了コードを返す */
  function send(args, h) {
    return new Promise((resolve, reject) => {
      startServe();
      handlers = Object.assign({}, h);
      doneWaiter = {
        resolve: c => { handlers = null; resolve(c); },
        reject: e => { handlers = null; reject(e); },
      };
      const c = args.map(String).join(SEP);
      if (cmdWaiter) { const w = cmdWaiter; cmdWaiter = null; w(c); } else pendingCmd = c;
    });
  }

  // Java の処理は 1 つずつ順番に行う
  function enqueue(job) {
    const p = queue.then(async () => { busy++; try { return await job(); } finally { busy--; } });
    queue = p.catch(() => {});
    return p;
  }

  async function warm(release) {
    if (warmedRelease === release) return;
    await send(['warmup', release], {});
    warmedRelease = release;
  }

  function packFiles(files) {
    return Object.entries(files).map(([p, c]) => p + '\u0002' + c).join(SEP);
  }

  return {
    get version() { return version; },
    get busy() { return busy > 0; },

    /** CheerpJ を起動し、実行ヘルパーとコンパイラーを準備する */
    init(ver, onStatus) {
      if (readyPromise) return readyPromise;
      version = ver || 17;
      readyPromise = (async () => {
        onStatus && onStatus('Java ランタイムを読み込み中…');
        await loadScript(CHEERPJ_LOADER);
        await cheerpjInit({
          version,
          status: 'none',
          natives,
          javaProperties: ['user.language=ja', 'user.country=JP', 'file.encoding=UTF-8', 'stdout.encoding=UTF-8', 'stderr.encoding=UTF-8'],
        });
        const names = ['Runner', 'EcjCompiler'];
        const srcs = await Promise.all(names.map(async n => (await fetch('runtime/' + n + '.java', { cache: 'no-store' })).text()));
        const dir = '/files/otekaru/rt-' + version + '-' + hash(srcs.join('|')) + '/';
        // 実行ヘルパー + Eclipse のコンパイラー (ECJ) + その日本語メッセージ
        runnerCp = dir + ':/app/lib/ecj-ja.jar:/app/lib/ecj.jar';
        if (!(await fileExists(dir + 'otekaru/Runner.class'))) {
          onStatus && onStatus('初回の準備中 (実行ヘルパーをコンパイルしています)…');
          names.forEach((n, i) => cheerpOSAddStringFile('/str/' + n + '.java', new TextEncoder().encode(srcs[i])));
          const code = await cheerpjRunMain('com.sun.tools.javac.Main', '/app/lib/ecj.jar', ...names.map(n => '/str/' + n + '.java'),
            '-cp', '/app/lib/ecj.jar', '-d', dir, '-encoding', 'UTF-8', '-nowarn');
          if (code !== 0) throw new Error('実行ヘルパーのコンパイルに失敗しました (' + code + ')');
        }
        onStatus && onStatus('Eclipse コンパイラー (ECJ) を準備中…');
        await warm(String(version));
        onStatus && onStatus('');
      })();
      return readyPromise;
    },

    /**
     * プロジェクトをコンパイルする
     * @param project プロジェクト名
     * @param files {"ch03/Basic.java": "..."} (src からの相対パス)
     * @param release '17' など (ECJ のコンプライアンス・レベル)
     * @returns {ok, diags:[{kind,file,line,col,start,end,code,msg}]}
     */
    compile(project, files, release) {
      return enqueue(async () => {
        await readyPromise;
        const rel = String(release || version);
        if (!serving) warmedRelease = null;
        await warm(rel);
        const diags = [];
        const errs = [];
        pendingFiles = packFiles(files);
        let code;
        try {
          code = await send(['compile', project, rel], { diag: d => diags.push(d), err: s => errs.push(s), out: s => errs.push(s) });
        } finally { pendingFiles = ''; }
        if (errs.length) console.log('[compile]', errs.join(''));
        if (code === 99) diags.push({ kind: 'ERROR', file: '', line: 0, col: 0, start: -1, end: -1, code: '', msg: 'コンパイラーの内部エラー: ' + errs.join('').slice(0, 300) });
        return { ok: code === 0, diags };
      });
    },

    /**
     * main メソッドを実行する (直前にコンパイルしたクラスを使う)
     * @param h { out(s), err(s), readLine(): Promise<string|null> }
     */
    run(project, className, args, h) {
      return enqueue(async () => {
        await readyPromise;
        return send(['run', project, className, ...(args || [])], h);
      });
    },

    /** Java が止まっていて (System.exit など)、作り直しが必要か */
    get alive() { return !!serving; },
  };
})();
