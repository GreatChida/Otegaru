// ワークスペースの保存層
//  - start.bat から起動したとき: ローカルサーバの /api を使い、work フォルダに本物のファイルとして保存
//  - それ以外 (静的ホスティングなど): ブラウザの localStorage に保存
'use strict';

const Storage = (() => {
  const LS_KEY = 'otekaru.workspace.v1';
  let mode = 'local';
  let rootPath = '';

  async function api(method, url, body) {
    const res = await fetch(url, { method, body, headers: body != null ? { 'Content-Type': 'text/plain; charset=utf-8' } : {} });
    if (!res.ok) throw new Error(await res.text() || res.statusText);
    return res;
  }

  function lsLoad() {
    try {
      const v = JSON.parse(localStorage.getItem(LS_KEY));
      if (v && v.files) return v;
    } catch (e) { /* 壊れていたら空から */ }
    return { dirs: [], files: {} };
  }
  function lsSave(ws) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(ws)); } catch (e) { console.warn(e); }
  }

  return {
    get mode() { return mode; },
    get rootPath() { return rootPath; },

    /** { dirs: [path], files: {path: content} } を返す */
    async load() {
      try {
        const res = await fetch('/api/tree', { cache: 'no-store' });
        if (res.ok) {
          const t = await res.json();
          mode = 'server';
          rootPath = t.root || '';
          const files = {};
          for (const f of (t.files || [])) files[f.path] = f.content;
          return { dirs: t.dirs || [], files };
        }
      } catch (e) { /* サーバなし */ }
      mode = 'local';
      return lsLoad();
    },

    async writeFile(path, content) {
      if (mode === 'server') return api('PUT', '/api/file?path=' + encodeURIComponent(path), content);
      const ws = lsLoad(); ws.files[path] = content; lsSave(ws);
    },
    async deleteFile(path) {
      if (mode === 'server') return api('POST', '/api/trash?path=' + encodeURIComponent(path));
      const ws = lsLoad(); delete ws.files[path]; lsSave(ws);
    },
    async mkdir(path) {
      if (mode === 'server') return api('POST', '/api/dir?path=' + encodeURIComponent(path));
      const ws = lsLoad(); if (!ws.dirs.includes(path)) ws.dirs.push(path); lsSave(ws);
    },
    async deleteDir(path) {
      if (mode === 'server') return api('DELETE', '/api/dir?path=' + encodeURIComponent(path));
      const ws = lsLoad();
      ws.dirs = ws.dirs.filter(d => d !== path && !d.startsWith(path + '/'));
      for (const f of Object.keys(ws.files)) if (f.startsWith(path + '/')) delete ws.files[f];
      lsSave(ws);
    },
    async rename(from, to) {
      if (mode === 'server') return api('POST', '/api/rename?from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to));
      const ws = lsLoad();
      const mv = p => p === from ? to : (p.startsWith(from + '/') ? to + p.slice(from.length) : p);
      ws.dirs = ws.dirs.map(mv);
      const nf = {};
      for (const [k, v] of Object.entries(ws.files)) nf[mv(k)] = v;
      ws.files = nf;
      lsSave(ws);
    },
    async openFolder(path) {
      if (mode === 'server') return api('POST', '/api/open-folder?path=' + encodeURIComponent(path || ''));
      throw new Error('ブラウザ保存モードではフォルダを開けません');
    },
    async shutdown() {
      if (mode === 'server') { try { await api('POST', '/api/shutdown'); } catch (e) { /* 終了済み */ } }
    },
  };
})();
