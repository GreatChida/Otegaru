package otekaru;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * お手軽DB (DB入門) のデータベース: H2 を Oracle 互換モードで動かす。
 *  - データベースはメモリーに置く。CheerpJ の /files/ に置いた H2 のファイルは、Java を動かし続けている間の書き込みが
 *    ブラウザに残らなかったため、確定した内容を SQL (H2 の SCRIPT) にして JS に返し、JS がワークスペースに保存する。
 *    起動したら、JS がその SQL を load で渡して元に戻す (load するまでは、ほかの命令は -3 を返す)
 *  - 接続 (SQL Developer の「接続」) ごとに JDBC の接続を持ち、自動コミットは切る (SQL Developer の既定と同じ)
 *  - Oracle の SQL から H2 の SQL への置き換えと、エラーの ORA- への置き換えは JS (db/oracle.js) で行う
 *  - 結果は 1 つの JSON を Runner.out で返す
 */
final class DbServer {
    static final String URL = "jdbc:h2:mem:xe;MODE=Oracle;DB_CLOSE_DELAY=-1";
    static final String LOAD_FILE = "/files/otekaru/db-load.sql";
    static boolean loaded;
    // データベースの管理者。Oracle の system に当たる (system の接続は、パスワードを問わずこのユーザーで行う)
    static final String ADMIN = "SYSTEM";
    static final String ADMIN_PW = "otegaru-system";
    static final int MAX_ROWS = 5000;

    static Connection admin;
    static final Map<String, Connection> conns = new HashMap<>();

    private DbServer() {
    }

    static int exec(String[] a) {
        String sub = a.length > 0 ? a[0] : "";
        String json;
        try {
            // Java が作り直された (System.exit など) あとは、保存した内容を読み込むまで使わせない
            if (!loaded && !sub.equals("load")) {
                Runner.out("{\"ok\":false,\"code\":-3,\"msg\":\"not loaded\"}");
                return 0;
            }
            switch (sub) {
                case "load":
                    json = load(a.length > 1 ? a[1] : "");
                    break;
                case "dump":
                    json = dump();
                    break;
                case "connect":
                    json = connect(a[1], a[2], a[3], false);
                    break;
                case "test":
                    json = connect(a[1], a[2], a[3], true);
                    break;
                case "disconnect": {
                    Connection c = conns.remove(a[1]);
                    if (c != null) {
                        try { c.rollback(); } catch (SQLException e) { /* 無視 */ }
                        c.close();
                    }
                    json = "{\"ok\":true}";
                    break;
                }
                case "sql":
                    json = sql(conns.get(a[1]), a[2], a.length > 3 ? Integer.parseInt(a[3]) : MAX_ROWS);
                    break;
                case "admin":
                    // 「接続」パネルの表や列の一覧など、画面のための問い合わせ (利用者の接続とは別)
                    json = sql(admin(), a[1], MAX_ROWS);
                    break;
                case "commit":
                case "rollback": {
                    Connection c = conns.get(a[1]);
                    if (c == null) {
                        json = notConnected();
                        break;
                    }
                    if (sub.equals("commit")) c.commit(); else c.rollback();
                    json = "{\"ok\":true}";
                    break;
                }
                case "reset":
                    json = reset();
                    break;
                default:
                    json = "{\"ok\":false,\"code\":-1,\"msg\":" + q("unknown command " + sub) + "}";
            }
        } catch (SQLException e) {
            json = error(e);
        } catch (Throwable t) {
            json = "{\"ok\":false,\"code\":-1,\"msg\":" + q(t.toString()) + "}";
        }
        Runner.out(json);
        return 0;
    }

    /** 管理者の接続 (初めてならデータベースを作り、Oracle の関数を登録する) */
    static Connection admin() throws SQLException {
        if (admin != null && !admin.isClosed()) {
            return admin;
        }
        admin = DriverManager.getConnection(URL, ADMIN, ADMIN_PW);
        admin.setAutoCommit(true);
        initObjects();
        return admin;
    }
    /** system のスキーマと、Oracle の関数 (無ければ作る) */
    static void initObjects() throws SQLException {
        try (Statement st = admin.createStatement()) {
            st.execute("CREATE SCHEMA IF NOT EXISTS SYSTEM AUTHORIZATION SYSTEM");
            st.execute("CREATE ALIAS IF NOT EXISTS PUBLIC.MONTHS_BETWEEN FOR 'otekaru.OraFuncs.monthsBetween'");
            st.execute("CREATE ALIAS IF NOT EXISTS PUBLIC.SYS_CONTEXT FOR 'otekaru.OraFuncs.sysContext'");
        }
    }

    static String connect(String name, String user, String password, boolean testOnly) throws SQLException {
        admin();
        String u = user.trim().toUpperCase();
        Connection c;
        try {
            c = u.equals(ADMIN) ? DriverManager.getConnection(URL, ADMIN, ADMIN_PW) : DriverManager.getConnection(URL, u, password);
        } catch (SQLException e) {
            return error(e);
        }
        boolean isAdmin = u.equals(ADMIN);
        try (PreparedStatement ps = admin.prepareStatement("SELECT IS_ADMIN FROM INFORMATION_SCHEMA.USERS WHERE USER_NAME = ?")) {
            ps.setString(1, u);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) isAdmin = rs.getBoolean(1);
            }
        }
        if (testOnly) {
            c.close();
            return "{\"ok\":true,\"user\":" + q(u) + ",\"admin\":" + isAdmin + "}";
        }
        c.setAutoCommit(false);
        try (Statement st = c.createStatement()) {
            // Oracle と同じく、ユーザーと同じ名前のスキーマを使う
            try {
                st.execute("SET SCHEMA " + quoteId(u));
            } catch (SQLException e) {
                // スキーマが無い (Oracle の外で作ったユーザー) ときは PUBLIC のまま
            }
            st.execute("SET SCHEMA_SEARCH_PATH " + quoteId(u) + ", PUBLIC");
        }
        Connection old = conns.put(name, c);
        if (old != null) {
            try { old.rollback(); old.close(); } catch (SQLException e) { /* 無視 */ }
        }
        return "{\"ok\":true,\"user\":" + q(u) + ",\"admin\":" + isAdmin + "}";
    }

    static String sql(Connection c, String sql, int maxRows) throws SQLException {
        if (c == null) {
            return notConnected();
        }
        long t0 = System.nanoTime();
        try (Statement st = c.createStatement()) {
            st.setMaxRows(maxRows + 1);
            String s;
            if (st.execute(sql)) {
                try (ResultSet rs = st.getResultSet()) {
                    s = rows(rs, maxRows);
                }
            } else {
                s = ",\"count\":" + st.getUpdateCount();
            }
            return "{\"ok\":true" + s + ",\"ms\":" + (System.nanoTime() - t0) / 1000000 + "}";
        } catch (SQLException e) {
            return error(e);
        }
    }

    static String rows(ResultSet rs, int maxRows) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int n = md.getColumnCount();
        List<String> cols = new ArrayList<>();
        List<String> types = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            cols.add(md.getColumnLabel(i));
            types.add(md.getColumnTypeName(i));
        }
        StringBuilder b = new StringBuilder(",\"cols\":" + arr(cols) + ",\"types\":" + arr(types) + ",\"rows\":[");
        int k = 0;
        boolean more = false;
        while (rs.next()) {
            if (k == maxRows) {
                more = true;
                break;
            }
            if (k++ > 0) b.append(',');
            List<String> v = new ArrayList<>();
            for (int i = 1; i <= n; i++) v.add(value(rs.getObject(i)));
            b.append(arr(v));
        }
        return b.append("],\"more\":").append(more).toString();
    }

    /** 値を、SQL Developer の表示に近い文字にする (日付は YYYY-MM-DD HH24:MI:SS、数は余分な 0 を付けない) */
    static String value(Object o) {
        if (o == null) return null;
        if (o instanceof Timestamp) {
            String s = o.toString();
            int dot = s.indexOf('.');
            return dot > 0 ? s.substring(0, dot) : s;
        }
        if (o instanceof BigDecimal) {
            BigDecimal d = (BigDecimal) o;
            return d.scale() > 0 ? d.stripTrailingZeros().toPlainString() : d.toPlainString();
        }
        if (o instanceof Double || o instanceof Float) {
            BigDecimal d = new BigDecimal(o.toString());
            return d.stripTrailingZeros().toPlainString();
        }
        return o.toString();
    }

    /** データベースを空にする (ツール → データベースの初期化) */
    static String reset() throws SQLException {
        clear();
        initObjects();
        return "{\"ok\":true}";
    }
    /** 接続を閉じ、ユーザー・表などをすべて消す (system だけが残る) */
    static void clear() throws SQLException {
        for (Connection c : conns.values()) {
            try { c.close(); } catch (SQLException e) { /* 無視 */ }
        }
        conns.clear();
        try (Statement st = admin().createStatement()) {
            st.execute("DROP ALL OBJECTS");
        }
    }

    /** 保存しておいた内容 (dump の SQL) でデータベースを作り直す */
    static String load(String script) throws Exception {
        clear();
        String err = null;
        if (!script.trim().isEmpty()) {
            java.nio.file.Path p = java.nio.file.Paths.get(LOAD_FILE);
            java.nio.file.Files.createDirectories(p.getParent());
            java.nio.file.Files.write(p, script.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            try (Statement st = admin.createStatement()) {
                st.execute("RUNSCRIPT FROM '" + LOAD_FILE + "' CHARSET 'UTF-8'");
            } catch (SQLException e) {
                // 読み込めないときは、空のデータベースで始める (理由は JS に返す)
                err = e.getMessage();
                clear();
            } finally {
                java.nio.file.Files.deleteIfExists(p);
            }
        }
        initObjects();
        loaded = true;
        return "{\"ok\":true,\"error\":" + q(err) + "}";
    }

    /** 確定した内容 (ユーザー・表・データ・順序) を SQL にする。利用者の接続で確定していない変更は入らない */
    static String dump() throws SQLException {
        StringBuilder b = new StringBuilder();
        try (Statement st = admin().createStatement(); ResultSet rs = st.executeQuery("SCRIPT DROP")) {
            while (rs.next()) b.append(rs.getString(1)).append('\n');
        }
        return "{\"ok\":true,\"script\":" + q(b.toString()) + "}";
    }

    static String notConnected() {
        return "{\"ok\":false,\"code\":-2,\"msg\":\"not connected\"}";
    }

    static String error(SQLException e) {
        return "{\"ok\":false,\"code\":" + e.getErrorCode() + ",\"state\":" + q(e.getSQLState()) + ",\"msg\":" + q(e.getMessage()) + "}";
    }

    static String quoteId(String s) {
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    static String arr(List<String> l) {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) b.append(',');
            b.append(q(l.get(i)));
        }
        return b.append(']').toString();
    }

    static String q(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '"' || ch == '\\') b.append('\\').append(ch);
            else if (ch < 0x20) b.append(String.format("\\u%04x", (int) ch));
            else b.append(ch);
        }
        return b.append('"').toString();
    }
}
