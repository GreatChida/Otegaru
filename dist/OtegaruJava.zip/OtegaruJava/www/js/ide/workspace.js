// お手軽Java - ワークスペースの選択 (最初の起動のとき)
//   ワークスペースは「ドキュメント (Mac は書類)」の workspace フォルダー。
//   すでにあるときは、そのまま使うか、workspace2 などの無い名前の新しいフォルダーにするかを聞く。
//   以前の版の保存場所 (展開したフォルダーの work) にプロジェクトがあれば、コピーするかも聞く
'use strict';

(() => {
  const { $, IS_MAC, esc } = IDE;
  const { dialog } = IDE.fn;
  const DOCS = IS_MAC ? '書類' : 'ドキュメント';

  /** まだ選んでいなければ選んでもらう。ローカル・サーバーが無い (ブラウザ保存モード) ときは何もしない。
   *  beforeAsk は、画面で聞く直前に呼ぶ (起動中の表示を隠すため) */
  async function ensureWorkspace(beforeAsk) {
    const ws = await Storage.workspaceInfo();
    if (!ws || ws.configured) return null;
    const legacy = (ws.legacy && ws.legacy.projects) || [];
    // workspace がまだ無く、移すプロジェクトも無ければ、聞かずに作る
    if (!ws.candidateExists && !legacy.length) return Storage.selectWorkspace(ws.candidate, false);
    if (beforeAsk) beforeAsk();
    let r = null;
    while (!r) r = await ask(ws, legacy);   // 閉じられても、決めるまで聞く (ワークスペースが無いと使えないため)
    const done = await Storage.selectWorkspace(r.path, r.copy);
    if (done.skipped && done.skipped.length) {
      await dialog({
        title: 'ワークスペースの選択', icon: 'info',
        message: `次のプロジェクトは、ワークスペースに同じ名前のものがあるので、コピーしませんでした:\n\n${done.skipped.join('\n')}\n\n(元のプロジェクトは、${ws.legacy.path} に残っています)`,
      });
    }
    return done;
  }

  function ask(ws, legacy) {
    const choice = ws.candidateExists
      ? `<div style="margin-bottom:6px">${DOCS}に <b>workspace</b> フォルダーがすでにあります。${ws.candidateIsOtegaru
          ? '以前にお手軽Java で使ったワークスペースです。'
          : 'ほかのソフト (Eclipse など) で使っているフォルダーかもしれません。'}</div>
        <label class="chk"><input type="radio" name="ws" value="use" ${ws.candidateIsOtegaru ? 'checked' : ''}>そのまま使う(<u>U</u>)</label>
        <div class="ws-path">${esc(ws.candidate)}</div>
        <label class="chk"><input type="radio" name="ws" value="new" ${ws.candidateIsOtegaru ? '' : 'checked'}>新しいフォルダーにする(<u>N</u>)</label>
        <div class="ws-path">${esc(ws.alternative)}</div>`
      : `<div>ワークスペース:</div><div class="ws-path">${esc(ws.candidate)}</div>`;
    const copy = legacy.length
      ? `<fieldset style="margin-top:12px"><legend>以前の保存場所</legend>
          <div class="hint" style="margin-bottom:4px">これまでの版では、展開したフォルダーの <code>work</code> に保存していました (${esc(ws.legacy.path)})。</div>
          <label class="chk"><input type="checkbox" id="ws-copy" checked>そこにあるプロジェクト (${esc(legacy.join(', '))}) を、ワークスペースにコピーする(<u>C</u>)</label>
          <div class="hint">元の <code>work</code> はそのまま残ります。</div></fieldset>`
      : '';
    return dialog({
      title: 'ワークスペースの選択', width: 600,
      banner: { title: 'ワークスペースとしてのディレクトリーを選択', message: 'お手軽Java は、作ったプログラムをワークスペースのフォルダーに保存します。' },
      html: choice + copy,
      buttons: [{ label: '起動(L)', value: 'ok', default: true }],
      collect: d => ({ pick: ($('input[name=ws]:checked', d) || {}).value || 'use', copy: !!($('#ws-copy', d) || {}).checked }),
    }).then(r => r && r.value === 'ok' ? { path: r.pick === 'new' ? ws.alternative : ws.candidate, copy: r.copy } : null);
  }

  Object.assign(IDE, { ensureWorkspace });
})();
