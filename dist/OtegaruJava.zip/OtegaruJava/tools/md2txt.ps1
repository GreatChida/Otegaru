﻿# Markdown (README) を、メモ帳で読みやすいプレーンテキストに変換する
#   使い方: powershell -ExecutionPolicy Bypass -File tools\md2txt.ps1 -In docs\README-dist.md -Out dist\README.txt
#   - 見出し: # は下線付き、## は【】、### は ◆
#   - リンク: [文字](URL) は「文字 ( URL )」
#   - 表: 1 行を「・1 列目」と「→ 2 列目以降」の箇条書きにする
#   - 太字・コードの記号は外す。出力は UTF-8 (BOM 付き)、改行は CRLF
param(
  [Parameter(Mandatory = $true)][string]$In,
  [Parameter(Mandatory = $true)][string]$Out
)
$ErrorActionPreference = 'Stop'

function Get-DisplayWidth([string]$s) {
  $w = 0
  foreach ($ch in $s.ToCharArray()) { if ([int]$ch -gt 0x7F) { $w += 2 } else { $w += 1 } }
  return $w
}

function Convert-Inline([string]$s) {
  $s = [regex]::Replace($s, '!\[([^\]]*)\]\(([^)]+)\)', '[画像: $1]')
  $s = [regex]::Replace($s, '\[([^\]]+)\]\(([^)\s]+)\)', [System.Text.RegularExpressions.MatchEvaluator] {
      param($m)
      $t = $m.Groups[1].Value -replace '`', ''
      $u = $m.Groups[2].Value
      if ($t -eq $u) { $u } else { "$t ( $u )" }
    })
  $s = $s -replace '\*\*([^*]+)\*\*', '$1'
  $s = $s -replace '`([^`]+)`', '$1'
  $s = $s -replace '<br\s*/?>', ' '
  $s = $s -replace '&lt;', '<' -replace '&gt;', '>' -replace '&amp;', '&'
  return $s
}

function Split-Row([string]$line) {
  $t = $line.Trim()
  if ($t.StartsWith('|')) { $t = $t.Substring(1) }
  if ($t.EndsWith('|')) { $t = $t.Substring(0, $t.Length - 1) }
  # \| (エスケープされた縦棒) は区切りにしない
  $cells = [regex]::Split($t, '(?<!\\)\|') | ForEach-Object { (Convert-Inline $_.Trim()) -replace '\\\|', '|' }
  return , $cells
}

$lines = [System.IO.File]::ReadAllLines((Resolve-Path $In), [System.Text.Encoding]::UTF8)
$buf = New-Object System.Collections.Generic.List[string]
$inCode = $false
$tableHeader = $null
for ($i = 0; $i -lt $lines.Length; $i++) {
  $line = $lines[$i]
  if ($line -match '^\s*```') { $inCode = -not $inCode; continue }
  if ($inCode) { $buf.Add('    ' + $line); continue }

  # 表
  if ($line -match '^\s*\|') {
    $next = if ($i + 1 -lt $lines.Length) { $lines[$i + 1] } else { '' }
    if ($null -eq $tableHeader -and $next -match '^\s*\|[\s:\-|]+\|\s*$') {
      $tableHeader = Split-Row $line
      $i++ # 区切り行を飛ばす
      continue
    }
    $cells = Split-Row $line
    $buf.Add('・' + $cells[0])
    for ($c = 1; $c -lt $cells.Count; $c++) { if ($cells[$c]) { $buf.Add('    → ' + $cells[$c]) } }
    continue
  }
  $tableHeader = $null

  if ($line -match '^# (.+)$') {
    $t = Convert-Inline $Matches[1]
    $buf.Add($t)
    $buf.Add('=' * (Get-DisplayWidth $t))
    continue
  }
  if ($line -match '^## (.+)$') { $buf.Add('【' + (Convert-Inline $Matches[1]) + '】'); continue }
  if ($line -match '^#{3,6} (.+)$') { $buf.Add('◆ ' + (Convert-Inline $Matches[1])); continue }
  if ($line -match '^\s*>\s?(.*)$') {
    $t = Convert-Inline $Matches[1]
    if ($t) { $buf.Add('※ ' + $t) }
    continue
  }
  if ($line -match '^(\s*)[-*] (.+)$') { $buf.Add($Matches[1] + '・' + (Convert-Inline $Matches[2])); continue }
  $buf.Add((Convert-Inline $line))
}

# 3 行以上続く空行を 1 行にする
$text = ($buf -join "`r`n") -replace "(\r\n){3,}", "`r`n`r`n"
$text = $text.TrimEnd() + "`r`n"
$dir = Split-Path -Parent ([System.IO.Path]::GetFullPath($Out))
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
[System.IO.File]::WriteAllText([System.IO.Path]::GetFullPath($Out), $text, (New-Object System.Text.UTF8Encoding($true)))
