package otekaru;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/**
 * お手軽Java の実行ヘルパー (ブラウザ内の CheerpJ 上で動く)
 *   serve                          : 常駐して JS からのコマンドを順に処理する (通常はこれを使う)
 *   warmup                         : Java とコンパイラーの準備
 *   compile <プロジェクト> <17|21>   : JS からソースを受け取り、Eclipse のコンパイラー (ECJ) でコンパイル
 *   run <プロジェクト> <クラス名> [引数...] : 最後にコンパイルしたクラスで main を実行
 * native メソッドは JavaScript 側 (js/javart.js) で実装している。
 */
public class Runner {

    static native void out(String s);

    static native void err(String s);

    static native String readLine();

    static native void diag(String kind, String file, int line, int col, int start, int end, String code, String msg);

    static native void done(String kind, int code);

    /** 常駐モードで、次のコマンドを JS から受け取る (引数を SEP_ENTRY で区切った文字列。終わりは null) */
    static native String nextCommand();

    /** JS 側のソースを取得する。「パス SEP_PATH 内容」を SEP_ENTRY で区切った文字列 */
    static native String pullFiles();

    static final String SEP_ENTRY = String.valueOf((char) 1);
    static final String SEP_PATH = String.valueOf((char) 2);

    /** プロジェクトごとの、最後にコンパイルしたクラス (バイナリ名 -> バイト列) */
    static final Map<String, Map<String, byte[]>> CLASSES = new HashMap<>();

    /** 書かれたバイトを UTF-8 の文字列にして JS へ渡す */
    static class JsStream extends OutputStream {
        private final boolean error;
        private final ByteArrayOutputStream buf = new ByteArrayOutputStream();

        JsStream(boolean error) {
            this.error = error;
        }

        @Override
        public synchronized void write(int b) {
            buf.write(b);
            if (b == '\n') {
                flush();
            }
        }

        @Override
        public synchronized void write(byte[] b, int off, int len) {
            buf.write(b, off, len);
            for (int i = off; i < off + len; i++) {
                if (b[i] == '\n') {
                    flush();
                    break;
                }
            }
        }

        @Override
        public synchronized void flush() {
            if (buf.size() == 0) {
                return;
            }
            String s = new String(buf.toByteArray(), StandardCharsets.UTF_8);
            buf.reset();
            if (error) {
                err(s);
            } else {
                out(s);
            }
        }
    }

    /** コンソールに入力された行を読む標準入力 */
    static class JsInput extends InputStream {
        private byte[] data = new byte[0];
        private int pos = 0;
        private boolean eof = false;

        private boolean fill() {
            if (eof) {
                return false;
            }
            sysOut.flush();
            sysErr.flush();
            String line = readLine();
            if (line == null) {
                eof = true;
                return false;
            }
            data = (line + "\n").getBytes(StandardCharsets.UTF_8);
            pos = 0;
            return true;
        }

        @Override
        public synchronized int read() {
            if (pos >= data.length && !fill()) {
                return -1;
            }
            return data[pos++] & 0xff;
        }

        @Override
        public synchronized int read(byte[] b, int off, int len) {
            if (len == 0) {
                return 0;
            }
            if (pos >= data.length && !fill()) {
                return -1;
            }
            int n = Math.min(len, data.length - pos);
            System.arraycopy(data, pos, b, off, n);
            pos += n;
            return n;
        }

        @Override
        public int available() {
            return data.length - pos;
        }
    }

    /** メモリー上のクラスを読み込むクラスローダー (実行のたびに新しく作る) */
    static class MemLoader extends ClassLoader {
        private final Map<String, byte[]> classes;

        MemLoader(Map<String, byte[]> classes) {
            super(ClassLoader.getPlatformClassLoader());
            this.classes = classes;
        }

        @Override
        protected Class<?> findClass(String name) throws ClassNotFoundException {
            byte[] b = classes.get(name);
            if (b == null) {
                throw new ClassNotFoundException(name);
            }
            return defineClass(name, b, 0, b.length);
        }
    }

    static PrintStream sysOut;
    static PrintStream sysErr;

    public static void main(String[] args) throws Exception {
        sysOut = new PrintStream(new JsStream(false), true, "UTF-8");
        sysErr = new PrintStream(new JsStream(true), true, "UTF-8");
        System.setOut(sysOut);
        System.setErr(sysErr);
        System.setIn(new JsInput());
        Locale.setDefault(Locale.JAPAN);
        if (args.length > 0 && args[0].equals("serve")) {
            // CheerpJ では cheerpjRunMain のたびに static な状態が初期化されるため、
            // 1 つの Java を動かし続け、コンパイラーなどを使い回す
            for (;;) {
                String c = nextCommand();
                if (c == null) {
                    break;
                }
                String[] a = c.split(SEP_ENTRY, -1);
                done(a[0], dispatch(a));
            }
            return;
        }
        done(args.length > 0 ? args[0] : "", dispatch(args));
    }

    static int dispatch(String[] args) {
        String cmd = args.length > 0 ? args[0] : "";
        int code;
        try {
            if (cmd.equals("compile")) {
                code = compile(args[1], args.length > 2 ? args[2] : "17", false);
            } else if (cmd.equals("compile-javac")) {
                code = compile(args[1], args.length > 2 ? args[2] : "17", true);
            } else if (cmd.equals("run")) {
                code = run(args[1], args[2], Arrays.copyOfRange(args, 3, args.length));
            } else if (cmd.equals("db")) {
                // DB入門 (お手軽DB): H2 の操作。結果は JSON で out に返す
                code = DbServer.exec(Arrays.copyOfRange(args, 1, args.length));
            } else if (cmd.equals("warmup")) {
                // コンパイラーの準備 (Java 標準ライブラリの読み込み) を先に済ませる
                // 小さなクラスを 1 度コンパイルして、コンパイラーを温めておく (最初の保存を速くするため)
                try {
                    Map<String, String> warm = new HashMap<>();
                    warm.put("otekaru_warm/Warm.java", String.join(System.lineSeparator(),
                            "package otekaru_warm;",
                            "import java.util.*;",
                            "public class Warm {",
                            "  private int n;",
                            "  public int getN() { return n; }",
                            "  public static void main(String[] args) {",
                            "    List<String> list = new ArrayList<>();",
                            "    for (int i = 0; i < 3; i++) { list.add(\"x\" + i); }",
                            "    if (list.size() > 2) { System.out.println(list); }",
                            "    String s = null; Scanner sc = new Scanner(System.in);",
                            "  }",
                            "}"));
                    if (ecjAvailable()) {
                        EcjCompiler.compile(warm, args.length > 1 ? args[1] : "17", new HashMap<>(), true);
                    }
                } catch (Throwable t) {
                    // ECJ が無ければ javac を使う
                }
                code = 0;
            } else {
                code = 0;
            }
        } catch (Throwable t) {
            t.printStackTrace();
            code = 99;
        }
        System.setOut(sysOut);
        System.setErr(sysErr);
        System.setIn(new JsInput());
        sysOut.flush();
        sysErr.flush();
        return code;
    }

    static Map<String, String> pullSources() {
        Map<String, String> m = new LinkedHashMap<>();
        String all = pullFiles();
        if (all == null || all.isEmpty()) {
            return m;
        }
        for (String entry : all.split(SEP_ENTRY)) {
            int p = entry.indexOf(SEP_PATH);
            if (p > 0) {
                m.put(entry.substring(0, p), entry.substring(p + 1));
            }
        }
        return m;
    }

    static int compile(String project, String release, boolean useJavac) throws IOException {
        Map<String, String> sources = pullSources();
        Map<String, byte[]> classes = new HashMap<>();
        int code;
        if (sources.isEmpty()) {
            code = 0;
        } else if (!useJavac && ecjAvailable()) {
            code = EcjCompiler.compile(sources, release, classes);
        } else {
            code = compileWithJavac(project, sources, release, classes);
        }
        CLASSES.put(project, classes);
        return code;
    }

    static boolean ecjAvailable() {
        try {
            Class.forName("org.eclipse.jdt.internal.compiler.Compiler");
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean patched = false;

    /**
     * ECJ は Java 標準ライブラリを「JDK フォルダーの lib/jrt-fs.jar と release ファイル」から読もうとする。
     * CheerpJ のランタイムにはそれらが無いので、ECJ 内部の表に
     * 「このランタイム自身の jrt ファイルシステム」と「バージョン」を先に登録しておく。
     */
    @SuppressWarnings("unchecked")
    static void patchEcjForCheerpJ() {
        if (patched) {
            return;
        }
        patched = true;
        try {
            java.nio.file.Path home = java.nio.file.Paths.get(System.getProperty("java.home")).toAbsolutePath().normalize();
            java.nio.file.FileSystem jrt = java.nio.file.FileSystems.getFileSystem(java.net.URI.create("jrt:/"));
            Class<?> util = Class.forName("org.eclipse.jdt.internal.compiler.util.JRTUtil");
            java.lang.reflect.Field f = util.getDeclaredField("JRT_FILE_SYSTEMS");
            f.setAccessible(true);
            ((Map<Object, Object>) f.get(null)).putIfAbsent(home, jrt);
            Class<?> jdk = Class.forName("org.eclipse.jdt.internal.compiler.util.Jdk");
            java.lang.reflect.Field r = jdk.getDeclaredField("pathToRelease");
            r.setAccessible(true);
            ((Map<Object, Object>) r.get(null)).putIfAbsent(home, System.getProperty("java.version"));
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // ---------------------------------------------------------------
    // javac (ECJ が使えないときの予備)
    // ---------------------------------------------------------------
    static void deleteTree(File f) {
        File[] list = f.listFiles();
        if (list != null) {
            for (File c : list) {
                deleteTree(c);
            }
        }
        f.delete();
    }

    static void collect(File dir, List<File> list, String ext) {
        File[] files = dir.listFiles();
        if (files == null) {
            return;
        }
        for (File f : files) {
            if (f.isDirectory()) {
                collect(f, list, ext);
            } else if (f.getName().endsWith(ext)) {
                list.add(f);
            }
        }
    }

    static int compileWithJavac(String project, Map<String, String> sources, String release, Map<String, byte[]> classes) throws IOException {
        String base = "/files/ws/" + project.replaceAll("[^\\w\\-.]", "_");
        File src = new File(base + "/src");
        File out = new File(base + "/bin");
        deleteTree(src);
        deleteTree(out);
        out.mkdirs();
        List<File> files = new ArrayList<>();
        for (Map.Entry<String, String> e : sources.entrySet()) {
            File f = new File(src, e.getKey());
            f.getParentFile().mkdirs();
            try (OutputStream os = new FileOutputStream(f)) {
                os.write(e.getValue().getBytes(StandardCharsets.UTF_8));
            }
            files.add(f);
        }
        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> dc = new DiagnosticCollector<>();
        StandardJavaFileManager fm = javac.getStandardFileManager(dc, Locale.JAPAN, StandardCharsets.UTF_8);
        List<String> options = Arrays.asList("-d", out.getPath(), "-g", "-encoding", "UTF-8", "-sourcepath", src.getPath(),
                "--release", release, "-Xlint:unchecked,deprecation");
        boolean ok = javac.getTask(new java.io.StringWriter(), fm, dc, options, null, fm.getJavaFileObjectsFromFiles(files)).call();
        String prefix = src.getPath().replace(File.separatorChar, '/') + "/";
        for (Diagnostic<? extends JavaFileObject> d : dc.getDiagnostics()) {
            String file = d.getSource() == null ? "" : d.getSource().getName().replace(File.separatorChar, '/');
            int p = file.indexOf(prefix);
            if (p >= 0) {
                file = file.substring(p + prefix.length());
            }
            diag(d.getKind() == Diagnostic.Kind.ERROR ? "ERROR" : "WARNING", file, (int) d.getLineNumber(), (int) d.getColumnNumber(),
                    (int) d.getStartPosition(), (int) d.getEndPosition() - 1, String.valueOf(d.getCode()), d.getMessage(Locale.JAPAN));
        }
        fm.close();
        List<File> cls = new ArrayList<>();
        collect(out, cls, ".class");
        String op = out.getPath().replace(File.separatorChar, '/') + "/";
        for (File c : cls) {
            String rel = c.getPath().replace(File.separatorChar, '/');
            rel = rel.substring(rel.indexOf(op) + op.length());
            classes.put(rel.substring(0, rel.length() - 6).replace('/', '.'), Files.readAllBytes(c.toPath()));
        }
        return ok ? 0 : 1;
    }

    // ---------------------------------------------------------------
    // 実行
    // ---------------------------------------------------------------
    static int run(String project, String className, String[] args) throws Exception {
        Map<String, byte[]> classes = CLASSES.get(project);
        if (classes == null) {
            System.err.println("エラー: プロジェクト " + project + " がまだビルドされていません");
            return 1;
        }
        MemLoader loader = new MemLoader(classes);
        Thread.currentThread().setContextClassLoader(loader);
        Class<?> c;
        try {
            c = Class.forName(className, true, loader);
        } catch (ClassNotFoundException e) {
            System.err.println("エラー: メイン・クラス " + className + " が見つからなかったかロードできませんでした");
            return 1;
        } catch (ExceptionInInitializerError e) {
            printUncaught(e.getCause() != null ? e.getCause() : e);
            return 1;
        }
        Method m;
        try {
            m = c.getMethod("main", String[].class);
        } catch (NoSuchMethodException e) {
            System.err.println("エラー: メイン・メソッドがクラス " + className + " で見つかりません。次のようにメイン・メソッドを定義してください。");
            System.err.println("   public static void main(String[] args)");
            return 1;
        }
        if (!Modifier.isStatic(m.getModifiers())) {
            System.err.println("エラー: メイン・メソッドが static ではありません: " + className);
            return 1;
        }
        try {
            m.setAccessible(true);
            m.invoke(null, (Object) args);
        } catch (InvocationTargetException e) {
            printUncaught(e.getCause());
            return 1;
        }
        return 0;
    }

    /** java コマンドと同じ形式で、捕まえられなかった例外を表示する (このクラスの行は除く) */
    static void printUncaught(Throwable t) {
        trim(t);
        System.out.flush();
        System.err.print("Exception in thread \"main\" ");
        t.printStackTrace();
    }

    static void trim(Throwable t) {
        while (t != null) {
            StackTraceElement[] st = t.getStackTrace();
            int n = st.length;
            for (int i = 0; i < st.length; i++) {
                String cn = st[i].getClassName();
                if (cn.startsWith("jdk.internal.reflect.") || cn.startsWith("java.lang.reflect.") || cn.startsWith("otekaru.")) {
                    n = i;
                    break;
                }
            }
            t.setStackTrace(Arrays.copyOf(st, n));
            t = t.getCause();
        }
    }
}
