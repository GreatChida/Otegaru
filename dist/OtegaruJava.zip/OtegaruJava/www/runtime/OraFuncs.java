package otekaru;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/** H2 に無い Oracle の関数 (DbServer が CREATE ALIAS で登録する) */
public final class OraFuncs {
    private OraFuncs() {
    }

    /** MONTHS_BETWEEN(d1, d2): 日が同じか両方が月末なら整数、ほかは Oracle と同じく 31 日を 1 か月として端数を付ける */
    public static Double monthsBetween(Timestamp a, Timestamp b) {
        if (a == null || b == null) return null;
        LocalDateTime x = a.toLocalDateTime(), y = b.toLocalDateTime();
        int months = (x.getYear() - y.getYear()) * 12 + (x.getMonthValue() - y.getMonthValue());
        boolean lastX = x.getDayOfMonth() == x.toLocalDate().lengthOfMonth();
        boolean lastY = y.getDayOfMonth() == y.toLocalDate().lengthOfMonth();
        if (x.getDayOfMonth() == y.getDayOfMonth() || (lastX && lastY)) return (double) months;
        double secX = x.getDayOfMonth() * 86400.0 + x.toLocalTime().toSecondOfDay();
        double secY = y.getDayOfMonth() * 86400.0 + y.toLocalTime().toSecondOfDay();
        return months + (secX - secY) / (31 * 86400.0);
    }

    /** SYS_CONTEXT('USERENV', 名前): 教材で使う CON_NAME などを、Oracle Database XE と同じ値で返す */
    public static String sysContext(String ns, String name) {
        if (ns == null || name == null || !ns.equalsIgnoreCase("USERENV")) return null;
        switch (name.toUpperCase()) {
            case "CON_NAME": return "XEPDB1";
            case "DB_NAME": return "XE";
            case "SERVICE_NAME": return "XEPDB1";
            default: return null;
        }
    }
}
