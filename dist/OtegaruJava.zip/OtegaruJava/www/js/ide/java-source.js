// お手軽Java - Java のソース操作 (アウトライン・生成・インポート・宣言を開く・クイック・フィックスなど)
'use strict';

(() => {
  const { S, $, $$, esc, files, isJava, parentOf, problems, projectOf, settings } = IDE;
  const { contentOf, dialog, gotoPos, icon, javaFilesOf, newTypeWizard, openEditor, pickFromList, projects, showContextMenu, status } = IDE.fn;

  // =================================================================
  // アウトライン
  // =================================================================
  let outlineTimer = null, outlineSyncTimer = null;
  function scheduleOutline() { clearTimeout(outlineTimer); outlineTimer = setTimeout(renderOutline, 500); }
  function scheduleOutlineSync() { clearTimeout(outlineSyncTimer); outlineSyncTimer = setTimeout(syncOutline, 300); }
  function renderOutline() {
    const el = $('#outline');
    if (!S.active || !isJava(S.active.path)) { el.innerHTML = '<div class="ol-empty">アウトラインは使用できません。</div>'; return; }
    const parsed = JavaSrc.parse(S.active.cm.getValue());
    const rows = [];
    if (parsed.pkg) rows.push({ html: `${Assist.ICONS.package}<span>${esc(parsed.pkg)}</span>`, line: parsed.pkgLine, depth: 0 });
    if (parsed.imports.length) rows.push({ html: `<span style="width:16px;text-align:center">⇲</span><span>import 宣言</span>`, line: parsed.imports[0].line, depth: 0 });
    const walk = (types, depth) => {
      for (const t of types) {
        rows.push({ html: `${Assist.typeIcon(t.kind)}<span>${esc(t.name)}</span>`, line: t.line, depth });
        for (const m of t.members) {
          if (m.kind === 'type') { walk([m.type], depth + 1); continue; }
          if (m.kind === 'init') continue;
          const sig = JavaSrc.signature(m);
          const k = sig.indexOf(' : ');
          const label = k >= 0 ? `${esc(sig.slice(0, k))} <span class="type">: ${esc(sig.slice(k + 3))}</span>` : esc(sig);
          const st = m.mods.includes('static') ? '<sup style="font-size:8px;color:#b58a00;margin-left:-6px">S</sup>' : '';
          rows.push({ html: `${Assist.memberIcon(m)}${st}<span>${label}</span>`, line: m.line, depth: depth + 1 });
        }
      }
    };
    walk(parsed.types, 0);
    el.innerHTML = rows.map((r, i) => `<div class="ol-row" data-line="${r.line}" style="padding-left:${6 + r.depth * 16}px">${r.html}</div>`).join('') || '<div class="ol-empty">(要素なし)</div>';
    $$('.ol-row', el).forEach(r => r.addEventListener('click', () => { gotoPos(S.active, +r.dataset.line, 0); }));
    syncOutline();
  }
  function syncOutline() {
    if (!S.active || S.active.custom) return;
    const line = S.active.cm.getCursor().line;
    let best = null;
    for (const r of $$('#outline .ol-row')) { if (+r.dataset.line <= line) best = r; r.classList.remove('selected'); }
    if (best) best.classList.add('selected');
  }

  // ---------- getter / setter など ----------
  function currentTypeForGen() {
    if (!S.active || !isJava(S.active.path)) return null;
    const src = S.active.cm.getValue();
    const parsed = JavaSrc.parse(src);
    const t = JavaSrc.typeAt(parsed, S.active.cm.indexFromPos(S.active.cm.getCursor())) || parsed.types[0];
    return t && (t.kind === 'class' || t.kind === 'enum') ? { t, src } : null;
  }
  function insertBeforeClassEnd(t, text) {
    const cm = S.active.cm;
    const closePos = cm.posFromIndex(t.close);
    const lines = cm.getValue().split('\n');
    let end = closePos.line;
    // 閉じ括弧の前の空行を詰めて、メソッドを空行区切りで入れる
    let last = end - 1;
    while (last > 0 && !lines[last].trim()) last--;
    const from = { line: last, ch: lines[last].length };
    const to = { line: end, ch: closePos.ch };
    const ind = lines[end].match(/^\s*/)[0];
    cm.replaceRange('\n\n' + text + '\n\n' + ind, from, to, '+gen');
  }
  async function genGetSet() {
    const g = currentTypeForGen();
    if (!g) { status('クラスの中にカーソルを置いてください'); return; }
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    const existing = new Set(g.t.members.filter(m => m.kind === 'method').map(m => m.name));
    if (!fields.length) { await dialog({ title: 'getter および setter の生成', message: `型 '${g.t.name}' には getter または setter を必要とするフィールドがありません。`, icon: 'info' }); return; }
    const getName = f => (f.type === 'boolean' ? 'is' : 'get') + Assist.cap(f.name);
    const setName = f => 'set' + Assist.cap(f.name);
    const r = await dialog({
      title: 'getter および setter の生成', width: 520,
      html: `<div style="margin-bottom:4px">getter および setter を作成するフィールドを選択してください(<u>S</u>):</div>
        <div style="display:grid;grid-template-columns:1fr auto;gap:8px">
        <div class="dlg-list" id="gs-list">${fields.map((f, i) => {
          const fin = f.mods.includes('final');
          return `<label class="li"><input type="checkbox" data-f="${i}" class="gs-f">${Assist.memberIcon(f)} ${esc(f.name)}</label>
            <label class="li sub"><input type="checkbox" data-g="${i}" ${existing.has(getName(f)) ? 'disabled' : ''}>${Assist.ICONS.methodPublic} ${esc(getName(f))}()</label>
            ${fin ? '' : `<label class="li sub"><input type="checkbox" data-s="${i}" ${existing.has(setName(f)) ? 'disabled' : ''}>${Assist.ICONS.methodPublic} ${esc(setName(f))}(${esc(f.type)})</label>`}`;
        }).join('')}</div>
        <div class="dlg-side"><button class="dlg-btn" id="gs-all">すべて選択(<u>A</u>)</button><button class="dlg-btn" id="gs-none">選択をすべて解除(<u>D</u>)</button><button class="dlg-btn" id="gs-get">getter の選択(<u>G</u>)</button><button class="dlg-btn" id="gs-set">setter の選択(<u>T</u>)</button></div></div>
        <div class="row" style="margin-top:10px"><label>挿入ポイント(<u>I</u>):</label><select id="gs-pos"><option value="last">最後のメンバー</option><option value="cursor">カーソル位置</option></select><span></span></div>
        <div class="row"><label>アクセス修飾子:</label><div><label><input type="radio" checked> public</label> <label style="color:#999"><input type="radio" disabled> protected</label> <label style="color:#999"><input type="radio" disabled> パッケージ</label> <label style="color:#999"><input type="radio" disabled> private</label></div><span></span></div>
        <div id="gs-count" class="hint"></div>`,
      buttons: [{ label: '生成(G)', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: d => ({
        gets: $$('[data-g]', d).filter(x => x.checked && !x.disabled).map(x => +x.dataset.g),
        sets: $$('[data-s]', d).filter(x => x.checked && !x.disabled).map(x => +x.dataset.s),
        pos: $('#gs-pos', d).value,
      }),
      onOpen: d => {
        const count = () => { const n = $$('[data-g],[data-s]', d).filter(x => x.checked && !x.disabled).length; $('#gs-count', d).textContent = `${n} / ${$$('[data-g],[data-s]', d).filter(x => !x.disabled).length} 個選択されています。`; };
        const setAll = (sel, v) => { $$(sel, d).forEach(x => { if (!x.disabled) x.checked = v; }); sync(); };
        const sync = () => { $$('.gs-f', d).forEach(fb => { const i = fb.dataset.f; const subs = $$(`[data-g="${i}"],[data-s="${i}"]`, d).filter(x => !x.disabled); fb.checked = subs.length > 0 && subs.every(x => x.checked); fb.indeterminate = !fb.checked && subs.some(x => x.checked); }); count(); };
        $$('.gs-f', d).forEach(fb => fb.addEventListener('change', () => { $$(`[data-g="${fb.dataset.f}"],[data-s="${fb.dataset.f}"]`, d).forEach(x => { if (!x.disabled) x.checked = fb.checked; }); sync(); }));
        $$('[data-g],[data-s]', d).forEach(x => x.addEventListener('change', sync));
        $('#gs-all', d).onclick = () => setAll('[data-g],[data-s]', true);
        $('#gs-none', d).onclick = () => setAll('[data-g],[data-s]', false);
        $('#gs-get', d).onclick = () => { setAll('[data-s]', false); setAll('[data-g]', true); };
        $('#gs-set', d).onclick = () => { setAll('[data-g]', false); setAll('[data-s]', true); };
        sync();
      },
    });
    if (!r || r.value !== 'ok' || (!r.gets.length && !r.sets.length)) return;
    const ind = settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t';
    const parts = [];
    fields.forEach((f, i) => {
      if (r.gets.includes(i)) parts.push(Assist.genGetter(f, ind));
      if (r.sets.includes(i)) parts.push(Assist.genSetter(Object.assign({ owner: g.t.name }, f), ind, false));
    });
    if (r.pos === 'cursor') {
      const c = S.active.cm.getCursor();
      S.active.cm.replaceRange(parts.join('\n\n') + '\n\n', { line: c.line, ch: 0 }, null, '+gen');
    } else insertBeforeClassEnd(g.t, parts.join('\n\n'));
  }
  async function genToString() {
    const g = currentTypeForGen();
    if (!g) { status('クラスの中にカーソルを置いてください'); return; }
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    const r = await fieldPicker('toString() の生成', 'toString() に含めるフィールドとメソッドを選択してください(<u>S</u>):', fields, true);
    if (!r) return;
    if (g.t.members.some(m => m.kind === 'method' && m.name === 'toString' && !m.params.length)) {
      const ok = await dialog({ title: 'toString() の生成', message: `型 '${g.t.name}' のメソッド toString() はすでに存在します。置き換えますか?`, icon: 'warning', buttons: [{ label: 'はい', value: true, default: true }, { label: 'いいえ', value: false }] });
      if (!ok) return;
      removeMethod(g.t, 'toString');
      return genToStringAfterRemove(r);
    }
    insertBeforeClassEnd(g.t, Assist.genToString(g.t, fields.filter((f, i) => r.includes(i)), settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t'));
  }
  function genToStringAfterRemove(sel) {
    const g = currentTypeForGen();
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    insertBeforeClassEnd(g.t, Assist.genToString(g.t, fields.filter((f, i) => sel.includes(i)), settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t'));
  }
  function removeMethod(t, name) {
    const cm = S.active.cm;
    const m = t.members.find(x => x.kind === 'method' && x.name === name && !x.params.length);
    if (!m) return;
    const b = JavaSrc.blank(cm.getValue());
    let start = cm.indexFromPos({ line: m.line, ch: 0 });
    // 直前のアノテーション行も含める
    let ln = m.line;
    while (ln > 0 && /^\s*@\w+/.test(cm.getLine(ln - 1))) ln--;
    start = cm.indexFromPos({ line: ln, ch: 0 });
    let i = b.indexOf('{', cm.indexFromPos({ line: m.line, ch: 0 }));
    let depth = 0;
    for (; i < b.length; i++) { if (b[i] === '{') depth++; else if (b[i] === '}') { depth--; if (depth === 0) break; } }
    const endPos = cm.posFromIndex(i + 1);
    cm.replaceRange('', cm.posFromIndex(start), { line: endPos.line + 1, ch: 0 });
  }
  async function genCtor() {
    const g = currentTypeForGen();
    if (!g) { status('クラスの中にカーソルを置いてください'); return; }
    const fields = g.t.members.filter(m => m.kind === 'field' && !m.mods.includes('static'));
    let omit = false;
    const r = await fieldPicker('フィールドを使用してコンストラクターを生成', 'コンストラクターで初期化するフィールドを選択してください(<u>S</u>):', fields, true, '<label class="chk" style="margin-top:8px"><input type="checkbox" id="fp-omit">スーパー・コンストラクターの呼び出しを省略(<u>O</u>)</label>', d => { omit = $('#fp-omit', d).checked; });
    if (!r) return;
    const ind = settings.indentSpaces ? ' '.repeat(settings.indentUnit) : '\t';
    const text = Assist.genCtor(g.t, fields.filter((f, i) => r.includes(i)), ind, omit);
    // 最後のフィールドの後ろに入れる
    const cm = S.active.cm;
    const lastField = fields[fields.length - 1];
    if (lastField) {
      const line = lastField.line;
      cm.replaceRange('\n\n' + text, { line, ch: cm.getLine(line).length }, null, '+gen');
    } else insertBeforeClassEnd(g.t, text);
  }
  async function fieldPicker(title, label, fields, all, extraHtml, onCollect) {
    const r = await dialog({
      title, width: 480,
      html: `<div style="margin-bottom:4px">${label}</div><div style="display:grid;grid-template-columns:1fr auto;gap:8px">
        <div class="dlg-list">${fields.map((f, i) => `<label class="li"><input type="checkbox" data-f="${i}" ${all ? 'checked' : ''}>${Assist.memberIcon(f)} ${esc(f.name)} : ${esc(f.type)}</label>`).join('') || '<div class="hint" style="padding:6px">(フィールドなし)</div>'}</div>
        <div class="dlg-side"><button class="dlg-btn" id="fp-all">すべて選択(<u>A</u>)</button><button class="dlg-btn" id="fp-none">選択をすべて解除(<u>D</u>)</button></div></div>${extraHtml || ''}`,
      buttons: [{ label: '生成(G)', value: 'ok', default: true }, { label: '取り消し', value: null }],
      collect: d => { if (onCollect) onCollect(d); return { sel: $$('[data-f]', d).filter(x => x.checked).map(x => +x.dataset.f) }; },
      onOpen: d => { $('#fp-all', d).onclick = () => $$('[data-f]', d).forEach(x => x.checked = true); $('#fp-none', d).onclick = () => $$('[data-f]', d).forEach(x => x.checked = false); },
    });
    return r && r.value === 'ok' ? r.sel : null;
  }

  // ---------- インポートの編成 ----------
  async function organizeImports() {
    if (!S.active || !isJava(S.active.path)) return;
    const cm = S.active.cm;
    const src = cm.getValue();
    const info = Assist.organizeImports(src);
    const chosen = [];
    for (const a of info.ambiguous) {
      const sel = await pickFromList('インポートの編成', `インポートする型を選択してください: ${a.name}`, a.pkgs.map(p => p + '.' + a.name));
      if (sel) chosen.push(sel);
    }
    const out = Assist.applyImports(src, info, chosen);
    if (out !== src) {
      const cur = cm.getCursor();
      const scroll = cm.getScrollInfo();
      cm.operation(() => { cm.setValue(out); cm.setCursor(cur); cm.scrollTo(scroll.left, scroll.top); });
    }
    status('インポートを編成しました');
  }
  async function addImportAtCursor() {
    if (!S.active) return;
    const cm = S.active.cm;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch, e = c.ch;
    while (s > 0 && /\w/.test(line[s - 1])) s--;
    while (e < line.length && /\w/.test(line[e])) e++;
    const w = line.slice(s, e);
    const cands = (Assist.allClassNames().get(w) || []).filter(x => x.pkg !== 'java.lang');
    if (!cands.length) { status(`'${w}' のインポートは見つかりません`); return; }
    let pkg = cands[0].pkg;
    if (cands.length > 1) { const sel = await pickFromList('インポートの追加', 'インポートする型を選択してください:', cands.map(x => x.pkg + '.' + w)); if (!sel) return; pkg = sel.slice(0, sel.lastIndexOf('.')); }
    Assist.addImport(cm, w, pkg);
  }

  // ---------- 宣言を開く (F3 / Ctrl+クリック) ----------
  function openDeclaration(ed, pos) {
    const cm = ed.cm;
    pos = pos || cm.getCursor();
    const line = cm.getLine(pos.line);
    let s = pos.ch, e = pos.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    while (e < line.length && /[\w$]/.test(line[e])) e++;
    const w = line.slice(s, e);
    if (!w) return;
    const src = cm.getValue();
    const parsed = JavaSrc.parse(src);
    const before = line.slice(0, s);
    // 型
    const types = currentProjectTypes().filter(t => t.name === w);
    if (types.length && !/\.\s*$/.test(before)) {
      const t = types.find(x => x.pkg === parsed.pkg) || types[0];
      openEditor(t.path, { line: t.type.line, flash: true });
      return;
    }
    // メンバー (this. または修飾なし)
    const curT = JavaSrc.typeAt(parsed, cm.indexFromPos(pos));
    if (/\.\s*$/.test(before)) {
      const expr = before.replace(/\.\s*$/, '').match(/([\w$]+)\s*$/);
      if (expr) {
        const vt = JavaSrc.varType(src, cm.indexFromPos(pos), expr[1], parsed) || (types.length ? null : expr[1]);
        const tn = JavaSrc.simpleName(vt || '');
        const pt = currentProjectTypes().find(t => t.name === tn);
        if (pt) {
          const m = pt.type.members.find(x => x.name === w);
          openEditor(pt.path, { line: m ? m.line : pt.type.line, flash: true });
          return;
        }
      }
    }
    // ローカル変数の宣言
    const b = JavaSrc.blank(src).slice(0, cm.indexFromPos({ line: pos.line, ch: s }));
    const re = new RegExp('[\\w>\\]]\\s+' + w + '\\s*(?=[=;,):])', 'g');
    let m, last = null;
    while ((m = re.exec(b))) last = m;
    if (last) { const p = cm.posFromIndex(last.index + last[0].indexOf(w, 1)); gotoPos(ed, p.line, p.ch, true); return; }
    if (curT) {
      const mem = curT.members.find(x => x.name === w);
      if (mem) { gotoPos(ed, mem.line, 0, true); return; }
    }
    status(`'${w}' の宣言が見つかりません`);
  }

  function currentProjectTypes() {
    const proj = S.active ? projectOf(S.active.path) : (projects()[0] || '');
    const out = [];
    for (const f of javaFilesOf(proj)) {
      const src = contentOf(f) || '';
      let parsed;
      try { parsed = JavaSrc.parse(src); } catch (e) { continue; }
      for (const t of parsed.types) out.push({ name: t.name, pkg: parsed.pkg, kind: t.kind, type: t, path: f });
    }
    return out;
  }

  // ---------- クイック・フィックス (Ctrl+1) ----------
  function quickFix(ed, lineArg) {
    ed = ed || S.active;
    if (!ed) return;
    const cm = ed.cm;
    const line = lineArg != null ? lineArg : cm.getCursor().line;
    const list = (problems.get(projectOf(ed.path)) || []).filter(p => p.path === ed.path && p.line === line);
    const items = [];
    for (const p of list) {
      let m;
      if ((m = p.msg.match(/^(\w+) を型に解決できません/)) || (m = p.msg.match(/^(\w+) cannot be resolved to a type/))) {
        for (const c of (Assist.allClassNames().get(m[1]) || []).filter(x => x.pkg !== 'java.lang')) {
          items.push({ label: `'${m[1]}' をインポートします (${c.pkg})`, icon: 'bulb', action: () => Assist.addImport(cm, m[1], c.pkg) });
        }
        items.push({ label: `クラス '${m[1]}' を作成します`, icon: 'class', action: () => { S.selected = 'K:' + parentOf(ed.path); newTypeWizard('class').then(() => {}); } });
      } else if ((m = p.msg.match(/^(\w+) を解決できません/)) && /^[a-z]/.test(m[1])) {
        const cap = m[1].charAt(0).toUpperCase() + m[1].slice(1);
        if (Assist.allClassNames().has(cap)) items.push({ label: `'${cap}' に変更します`, icon: 'bulb', action: () => replaceWordAt(cm, p, m[1], cap) });
      } else if (/インポート .* は使用されていません|is never used/.test(p.msg) && /import/.test(cm.getLine(line))) {
        items.push({ label: 'インポートを除去します', icon: 'bulb', action: () => cm.replaceRange('', { line, ch: 0 }, { line: line + 1, ch: 0 }) });
        items.push({ label: 'インポートを編成します', icon: 'bulb', action: () => organizeImports() });
      } else if ((m = p.msg.match(/"(.+?)" を挿入して/))) {
        items.push({ label: `"${m[1]}" を挿入します`, icon: 'bulb', action: () => { const pos = p.end >= 0 && cm.getValue() === files.get(ed.path) ? cm.posFromIndex(p.end + 1) : { line, ch: cm.getLine(line).length }; cm.replaceRange(m[1], pos); } });
      } else if (/serialVersionUID/.test(p.msg)) {
        items.push({ label: 'デフォルトのシリアル・バージョン ID を追加します', icon: 'bulb', action: () => { const g = currentTypeForGen(); if (g) { const ind = ' '.repeat(settings.indentUnit); cm.replaceRange(`\n${ind}private static final long serialVersionUID = 1L;\n`, { line: cm.posFromIndex(g.t.open).line, ch: cm.getLine(cm.posFromIndex(g.t.open).line).length }); } } });
      } else if (/処理されない例外の型 (\w+)/.test(p.msg)) {
        const ex = p.msg.match(/処理されない例外の型 (\w+)/)[1];
        items.push({ label: `throws 宣言を追加します (${ex})`, icon: 'bulb', action: () => addThrows(cm, line, ex) });
      }
    }
    // 同じ行に同じ種類のエラーが複数あるときの重複を除く
    const seen = new Set();
    for (let i = items.length - 1; i >= 0; i--) { if (seen.has(items[i].label)) items.splice(i, 1); else seen.add(items[i].label); }
    items.reverse(); items.reverse();
    if (!items.length) { status(list.length ? 'この問題のクイック・フィックスはありません' : 'この行に問題はありません'); return; }
    const coords = cm.charCoords({ line, ch: 0 }, 'window');
    showContextMenu(items.map(i => ({ label: i.label, icon: i.icon, action: i.action })), coords.left + 40, coords.bottom + 2);
  }
  function replaceWordAt(cm, p, from, to) {
    const t = cm.getLine(p.line);
    const i = t.indexOf(from, Math.max(0, p.col - 1));
    if (i >= 0) cm.replaceRange(to, { line: p.line, ch: i }, { line: p.line, ch: i + from.length });
  }
  function addThrows(cm, line, ex) {
    for (let l = line; l >= 0; l--) {
      const t = cm.getLine(l);
      const m = t.match(/\)\s*(throws\s+[\w.,\s]+)?\s*\{\s*$/);
      if (m && /\w+\s*\(/.test(t)) {
        const idx = t.lastIndexOf('{');
        if (m[1]) cm.replaceRange(', ' + ex + ' ', { line: l, ch: t.lastIndexOf(m[1]) + m[1].trimEnd().length }, { line: l, ch: idx });
        else cm.replaceRange(' throws ' + ex + ' ', { line: l, ch: t.lastIndexOf(')') + 1 }, { line: l, ch: idx });
        Assist.addImport(cm, ex, (Assist.LIB[ex] || {}).pkg);
        return;
      }
    }
  }

  // ---------- 注釈の移動 ----------
  function gotoAnnotation(dir) {
    if (!S.active) return;
    const list = (problems.get(projectOf(S.active.path)) || []).filter(p => p.path === S.active.path).sort((a, b) => a.line - b.line || a.col - b.col);
    if (!list.length) { status('注釈はありません'); return; }
    const c = S.active.cm.getCursor();
    let t = dir > 0 ? list.find(p => p.line > c.line || (p.line === c.line && p.col > c.ch)) : [...list].reverse().find(p => p.line < c.line || (p.line === c.line && p.col < c.ch));
    if (!t) t = dir > 0 ? list[0] : list[list.length - 1];
    gotoPos(S.active, t.line, t.col);
    status(t.msg);
  }

  // ---------- 名前変更 (ファイル内のリンク編集) ----------
  function renameSymbol() {
    if (!S.active) return;
    const cm = S.active.cm;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch, e = c.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    while (e < line.length && /[\w$]/.test(line[e])) e++;
    const w = line.slice(s, e);
    if (!w) return;
    const b = JavaSrc.blank(cm.getValue());
    const re = new RegExp('(?<![\\w$])' + w + '(?![\\w$])', 'g');
    let m; const holes = [];
    while ((m = re.exec(b))) holes.push({ name: 'sym', from: cm.posFromIndex(m.index), to: cm.posFromIndex(m.index + w.length) });
    if (!holes.length) return;
    status(`名前変更: '${w}' を入力して Enter で確定 (ファイル内 ${holes.length} か所)`);
    // カーソル位置の欄を先頭にする
    holes.sort((a, b) => (CodeMirror.cmpPos(a.from, { line: c.line, ch: s }) === 0 ? -1 : 0) - (CodeMirror.cmpPos(b.from, { line: c.line, ch: s }) === 0 ? -1 : 0));
    window.__startLinked && window.__startLinked(cm, holes);
    // Assist のリンク・モードを使う
    const first = holes[0];
    cm.setSelection(first.from, first.to);
    linkedRename(cm, holes);
  }
  function linkedRename(cm, holes) {
    const marks = holes.map(h => cm.markText(h.from, h.to, { className: 'linked-ph', inclusiveLeft: true, inclusiveRight: true, clearWhenEmpty: false }));
    let syncing = false;
    const onChange = () => {
      if (syncing) return;
      const c = cm.getCursor();
      const curMark = marks.find(mk => { const r = mk.find(); return r && CodeMirror.cmpPos(c, r.from) >= 0 && CodeMirror.cmpPos(c, r.to) <= 0; });
      if (!curMark) return;
      const r0 = curMark.find();
      const val = cm.getRange(r0.from, r0.to);
      syncing = true;
      cm.operation(() => { for (const mk of marks) { if (mk === curMark) continue; const r = mk.find(); if (r && cm.getRange(r.from, r.to) !== val) cm.replaceRange(val, r.from, r.to, '+rename'); } });
      syncing = false;
    };
    const finish = () => { marks.forEach(m => m.clear()); cm.off('change', onChange); cm.off('cursorActivity', onCursor); cm.removeKeyMap(km); status('名前を変更しました'); };
    const onCursor = () => {
      if (syncing) return;
      const c = cm.getCursor();
      if (!marks.some(mk => { const r = mk.find(); return r && CodeMirror.cmpPos(c, r.from) >= 0 && CodeMirror.cmpPos(c, r.to) <= 0; })) finish();
    };
    const km = { Enter: () => finish(), Esc: () => finish() };
    cm.addKeyMap(km);
    cm.on('change', onChange);
    cm.on('cursorActivity', onCursor);
  }

  // ---------- ワード補完 (Alt+/) ----------
  function wordComplete() {
    if (!S.active) return;
    const cm = S.active.cm;
    const c = cm.getCursor();
    const line = cm.getLine(c.line);
    let s = c.ch;
    while (s > 0 && /[\w$]/.test(line[s - 1])) s--;
    const prefix = line.slice(s, c.ch);
    if (!prefix) return;
    const words = [...new Set((cm.getValue().match(/[A-Za-z_$][\w$]*/g) || []))].filter(w => w.startsWith(prefix) && w !== prefix);
    if (!words.length) return;
    cm.replaceRange(words[0], { line: c.line, ch: s }, c);
  }

  Object.assign(IDE, { addImportAtCursor, addThrows, currentProjectTypes, currentTypeForGen, fieldPicker, genCtor, genGetSet, genToString, genToStringAfterRemove, gotoAnnotation, insertBeforeClassEnd, linkedRename, openDeclaration, organizeImports, quickFix, removeMethod, renameSymbol, renderOutline, replaceWordAt, scheduleOutline, scheduleOutlineSync, syncOutline, wordComplete });
})();
