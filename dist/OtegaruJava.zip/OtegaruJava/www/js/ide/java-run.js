// お手軽Java - コンソールと Java アプリケーションの実行
'use strict';

(() => {
  const { S, $, baseName, builtVersion, editors, files, isJava, parentOf, problems, projectOf, run, settings } = IDE;
  const { contentOf, dialog, ensureBuilt, ensureJava, fqnOf, icon, isDirty, openEditor, projectJre, projects, saveAll, saveSettings, saveUi, setJavaStatus,
    showBottom, srcRel, srcRoot, status, updateToolbar } = IDE.fn;

  // =================================================================
  // コンソールと実行
  // =================================================================
  function initConsole() {
    const c = $('#ide-console');
    c.addEventListener('click', e => {
      const a = e.target.closest('a.trace');
      if (a) { e.preventDefault(); openTrace(a.dataset.cls, a.dataset.method, a.dataset.line ? +a.dataset.line : null); return; }
      const inp = $('.console-input', c);
      if (inp && !window.getSelection().toString()) inp.focus();
    });
    setConsoleTitle('');
  }
  function setConsoleTitle(t) { $('#console-title').textContent = t || 'コンソールを表示するものは現在ありません。'; }
  function consoleClear() { $('#console-out').innerHTML = ''; run.text = ''; }
  function consoleAppend(text, cls) {
    const out = $('#console-out');
    const inp = $('.console-input', out);
    const frag = document.createDocumentFragment();
    if (cls === 'err') {
      // スタックトレースの行をリンクにする
      for (const part of text.split(/(\n)/)) {
        if (part === '\n') { frag.appendChild(document.createTextNode('\n')); continue; }
        const m = part.match(/^(\s*at )([\w.$]+)\.([\w$<>]+)\(([^)]*)\)(.*)$/);
        const span = document.createElement('span');
        span.className = 'err';
        if (m) {
          span.appendChild(document.createTextNode(m[1] + m[2] + '.' + m[3] + '('));
          const cls2 = m[2].replace(/\$.*$/, '');
          const loc = m[4];
          const lm = loc.match(/^(\w+\.java):(\d+)$/);
          const path = pathForClass(cls2);
          if (lm && path) {
            const a = document.createElement('a'); a.className = 'trace'; a.textContent = loc; a.dataset.cls = cls2; a.dataset.method = m[3]; a.dataset.line = lm[2];
            span.appendChild(a);
            span.appendChild(document.createTextNode(')' + m[5]));
          } else if (path) {
            const a = document.createElement('a'); a.className = 'trace'; a.textContent = loc || 'Unknown Source'; a.dataset.cls = cls2; a.dataset.method = m[3]; a.title = 'クリックするとメソッドの位置を開きます (ブラウザ版では行番号が分かりません)';
            span.appendChild(a);
            span.appendChild(document.createTextNode(')' + m[5]));
          } else span.appendChild(document.createTextNode(loc + ')' + m[5]));
        } else span.textContent = part;
        frag.appendChild(span);
      }
    } else {
      const span = document.createElement('span');
      if (cls) span.className = cls;
      span.textContent = text;
      frag.appendChild(span);
    }
    if (inp) out.insertBefore(frag, inp); else out.appendChild(frag);
    if (cls !== 'sys' && cls !== 'in') run.text += text;
    if (cls === 'in') run.text += text;
    if (!$('#btn-scrolllock').classList.contains('on')) $('#ide-console').scrollTop = $('#ide-console').scrollHeight;
  }
  function pathForClass(fqn) {
    for (const p of projects()) {
      const f = srcRoot(p) + '/' + fqn.replace(/\./g, '/') + '.java';
      if (files.has(f)) return f;
    }
    // ネストしたクラスなど: 最後の要素を落として探す
    const parts = fqn.split('.');
    for (let i = parts.length - 1; i > 0; i--) {
      for (const p of projects()) {
        const f = srcRoot(p) + '/' + parts.slice(0, i).join('/') + '.java';
        if (files.has(f)) return f;
      }
    }
    return null;
  }
  function openTrace(cls, method, line) {
    const path = pathForClass(cls);
    if (!path) return;
    if (line) { openEditor(path, { line: line - 1, flash: true }); return; }
    const parsed = JavaSrc.parse(contentOf(path));
    let target = 0;
    const sn = cls.split('.').pop();
    const walk = types => { for (const t of types) { if (t.name === sn || method === '<init>') { const m = t.members.find(x => (x.kind === 'method' && x.name === method) || (method === '<init>' && x.kind === 'ctor')); if (m) target = m.line; else target = t.line; } walk(t.members.filter(x => x.kind === 'type').map(x => x.type)); } };
    walk(parsed.types);
    openEditor(path, { line: target, flash: true });
  }
  function addConsoleInput() {
    const out = $('#console-out');
    if ($('.console-input', out)) return;
    const inp = document.createElement('input');
    inp.className = 'console-input';
    inp.spellcheck = false;
    inp.setAttribute('aria-label', 'コンソールへの入力');
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const v = inp.value;
        inp.value = '';
        consoleAppend(v + '\n', 'in');
        if (run.waiting) { const w = run.waiting; run.waiting = null; w(v); } else run.inputQueue.push(v);
      } else if (e.key === 'z' && e.ctrlKey) {
        // Ctrl+Z: 入力の終わり (EOF)
        e.preventDefault();
        if (run.waiting) { const w = run.waiting; run.waiting = null; w(null); } else run.inputQueue.push(null);
      }
    });
    out.appendChild(inp);
  }
  function removeConsoleInput() { const i = $('.console-input'); if (i) i.remove(); }

  function fmtTime(d) {
    const p = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }

  /** クラスを Java アプリケーションとして実行する */
  async function runFile(path) {
    if (run.running) { status('プログラムを実行中です。終了してから実行してください (コンソールの赤い■で終了)'); showBottom('ide-console'); return; }
    if (!path || !isJava(path) || !srcRel(path)) { await dialog({ title: '起動できません', message: '選択にはメイン型が含まれていません。', icon: 'error' }); return; }
    const project = projectOf(path);
    // 保存していないエディター
    const dirty = editors.filter(isDirty);
    if (dirty.length) {
      if (settings.saveBeforeLaunch === 'always') await saveAll();
      else {
        const r = await saveResourcesDialog(dirty);
        if (!r) return;
        if (r.always) { settings.saveBeforeLaunch = 'always'; saveSettings(); }
        await saveAll();
      }
    }
    const src = files.get(path) || '';
    if (!JavaSrc.hasMain(src)) { await dialog({ title: '起動できません', message: '選択にはメイン型が含まれていません。', icon: 'error' }); return; }
    if (!S.javaReady) { status('Java を準備中です。準備ができるまでお待ちください…', true); if (!(await ensureJava())) return; }
    // JRE のバージョンが違うときは、ランタイムを切り替える
    const jre = projectJre(project);
    if (jre > JavaRT.version) {
      const ok = await dialog({ title: 'Java ランタイムの切り替え', message: `プロジェクト '${project}' は JavaSE-${jre} を使います。\nJava ランタイムを JavaSE-${jre} に切り替えるため、画面を読み込み直します。`, buttons: [{ label: '切り替える', value: true, default: true }, { label: '取り消し', value: false }] });
      if (!ok) return;
      sessionStorage.setItem('otekaru.runtime', String(jre >= 21 ? 21 : 17));
      saveUi(); location.reload(); return;
    }
    // Java が止まっていた (System.exit など) ときは、コンパイルからやり直す
    if (!JavaRT.alive) builtVersion.clear();
    await ensureBuilt(project);
    const errs = (problems.get(project) || []).filter(p => p.kind === 'ERROR');
    if (errs.length && settings.launchWithErrors !== 'always') {
      const r = await dialog({
        title: 'エラーが存在します', icon: 'error',
        message: `必須プロジェクトにエラーが存在します:\n\n${project}\n\n起動を続行しますか?`,
        check: '常にエラーを伴って起動',
        buttons: [{ label: '続行', value: 'go' }, { label: '取り消し', value: null, default: true }],
      });
      if (!r || r.value !== 'go') { showBottom('markers'); return; }
      if (r.checked) { settings.launchWithErrors = 'always'; saveSettings(); }
    }
    const fqn = fqnOf(path);
    const name = baseName(path).replace(/\.java$/, '');
    run.running = true; run.inputQueue = []; run.waiting = null; run.start = new Date(); run.className = name; run.project = project;
    run.title = `${name} [Java アプリケーション] `;
    consoleClear();
    showBottom('ide-console');
    setConsoleTitle(run.title + '(' + fmtTime(run.start) + ')');
    addConsoleInput();
    updateToolbar();
    setJavaStatus('実行中: ' + name, true);
    const inp = $('.console-input'); if (inp) setTimeout(() => inp.focus(), 50);
    let code = -1;
    try {
      code = await JavaRT.run(project, fqn, [], {
        out: s => consoleAppend(s),
        err: s => consoleAppend(s, 'err'),
        readLine: () => new Promise(res => {
          if (run.inputQueue.length) res(run.inputQueue.shift());
          else { run.waiting = res; const i = $('.console-input'); if (i) i.focus(); }
        }),
      });
    } catch (e) {
      consoleAppend('\n' + e.message + '\n', 'err');
    } finally {
      run.running = false;
      run.waiting = null;
      removeConsoleInput();
      const end = new Date();
      setConsoleTitle(`<終了> ${run.title}(${fmtTime(run.start)} – ${fmtTime(end).slice(11)})`);
      updateToolbar();
      setJavaStatus('JavaSE-' + JavaRT.version, false);
    }
  }

  async function saveResourcesDialog(dirty) {
    const r = await dialog({
      title: 'リソースの保存',
      message: '保存されていない変更があります。起動する前に、次のリソースを保存しますか?',
      list: dirty.map(e => ({ label: baseName(e.path) + '  (' + parentOf(e.path) + ')', checked: true })),
      check: '起動前に常に変更を保存',
      buttons: [{ label: 'OK', value: 'ok', default: true }, { label: '取り消し', value: null }],
    });
    if (!r || r.value !== 'ok') return null;
    return { always: r.checked };
  }

  function terminate() {
    if (!run.running) return;
    // 入力待ちなら EOF を送り、それでも終わらなければ画面を読み込み直して止める
    if (run.waiting) { const w = run.waiting; run.waiting = null; w(null); }
    setTimeout(() => {
      if (!run.running) return;
      const state = { html: $('#console-out').innerHTML, title: run.title, start: run.start.getTime(), text: run.text };
      try { sessionStorage.setItem('otekaru.terminated', JSON.stringify(state)); } catch (e) { /* 無視 */ }
      saveUi();
      location.reload();
    }, 400);
  }
  function restoreTerminated() {
    let s = null;
    try { s = JSON.parse(sessionStorage.getItem('otekaru.terminated') || 'null'); sessionStorage.removeItem('otekaru.terminated'); } catch (e) { s = null; }
    if (!s) return;
    $('#console-out').innerHTML = s.html;
    removeConsoleInput();
    run.text = s.text || '';
    consoleAppend('\n(プログラムを終了しました)\n', 'sys');
    setConsoleTitle(`<終了> ${s.title}(${fmtTime(new Date(s.start))} – ${fmtTime(new Date()).slice(11)})`);
    showBottom('ide-console');
  }

  Object.assign(IDE, { addConsoleInput, consoleAppend, consoleClear, fmtTime, initConsole, openTrace, pathForClass, removeConsoleInput, restoreTerminated, runFile, saveResourcesDialog, setConsoleTitle, terminate });
})();
